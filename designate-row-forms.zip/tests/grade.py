"""Grading of a form filing: the filing is read as text, compared label by label with the sealed
key, and summarised. Nothing in the filing is executed.

    verdicts(filing_path, key_path) -> {statement code: "right" | "wrong" | "missing" | "duplicate"}
    count_right(filing_path, key_path) -> int
"""
import csv

LABEL_COLUMN = "form"
ID_COLUMN = "statement"


def _read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def read_key(path):
    _, rows = _read_csv(path)
    return [(r[ID_COLUMN], r[LABEL_COLUMN]) for r in rows]


def verdicts(filing_path, key_path):
    key = read_key(key_path)
    try:
        fields, rows = _read_csv(filing_path)
    except OSError:
        return {code: "missing" for code, _ in key}
    if ID_COLUMN not in fields or LABEL_COLUMN not in fields:
        return {code: "missing" for code, _ in key}
    filed, counts = {}, {}
    for r in rows:
        code = (r.get(ID_COLUMN) or "").strip()
        counts[code] = counts.get(code, 0) + 1
        filed[code] = (r.get(LABEL_COLUMN) or "").strip()
    out = {}
    for code, label in key:
        if code not in filed:
            out[code] = "missing"
        elif counts[code] > 1:
            out[code] = "duplicate"
        elif filed[code] == label:
            out[code] = "right"
        else:
            out[code] = "wrong"
    return out


def count_right(filing_path, key_path):
    return sum(1 for v in verdicts(filing_path, key_path).values() if v == "right")
