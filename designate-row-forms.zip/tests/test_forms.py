"""The verifier. First, the sealed key must be exactly what the row-form model (tests/rowforms.py)
derives from the sealed world. Second, the filing at /app/out/forms.csv must have at least MARK
labels equal to the key's."""
import os

import grade
import rowforms

SEALED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sealed")
KEY_PATH = os.path.join(SEALED, "key.csv")
WORLD_PATH = os.path.join(SEALED, "world.json")
FILING_PATH = "/app/out/forms.csv"
MARK = 72


def test_row_form_model_derives_the_sealed_key():
    derived = rowforms.rebuild(rowforms.load_world(WORLD_PATH))
    key = grade.read_key(KEY_PATH)
    assert len(key) == 80
    mismatches = [code for code, label in key if derived.get(code) != label]
    assert mismatches == [], mismatches


def test_enough_labels_equal_the_key():
    outcome = grade.verdicts(FILING_PATH, KEY_PATH)
    right = sum(1 for v in outcome.values() if v == "right")
    print("right %d of %d; %s" % (right, len(outcome), {k: list(outcome.values()).count(k) for k in set(outcome.values())}))
    assert right >= MARK
