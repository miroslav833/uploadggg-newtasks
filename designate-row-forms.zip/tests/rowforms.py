"""The verifier's own forward model: the key rebuilt from the sealed world (tests/sealed/world.json).

The sealed world holds each movement's row, the order of precedence among forms, and for each
statement the pitch classes the edition lists for it and, where it opens on the note that closed
the previous statement, that shared class. The model generates the forty-eight forms of the row
and names the form, first by precedence, that the statement's classes reproduce. It shares no code
with the reference and does no parsing of the parts.
"""
import json


def load_world(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _forms(row):
    start = row[0]
    table = {}
    for n in range(12):
        prime = tuple((x + n) % 12 for x in row)
        inverted = tuple((2 * start - x + n) % 12 for x in row)
        table["P%d" % n] = prime
        table["I%d" % n] = inverted
        table["R%d" % n] = prime[::-1]
        table["RI%d" % n] = inverted[::-1]
    return table


def rebuild(world):
    """-> {statement code: form label}"""
    order = world["precedence"]

    def earliest(labels):
        def key(lab):
            kind = lab.rstrip("0123456789")
            return order.index(kind), int(lab[len(kind):])
        return min(labels, key=key)

    tables = {m: _forms(row) for m, row in world["rows"].items()}
    key = {}
    for st in world["statements"]:
        table = tables[str(st["movement"])]
        classes = list(st["listed"])
        if st["shared_first"] is not None:
            classes = [st["shared_first"]] + classes
        classes = tuple(classes)
        if len(classes) == 12:
            fits = [lab for lab, seq in table.items() if seq == classes]
        else:
            fits = [lab for lab, seq in table.items() if seq[:len(classes)] == classes]
        key[st["code"]] = earliest(fits) if fits else None
    return key
