For each of the 80 row statements that the edition of a twelve-tone chamber work identifies, file the row form that generated it.

Inputs:

- `/app/preface.md`: the work, its three movements and instruments, and each movement's row as twelve pitch classes with C = 0.
- `/app/notes.csv`: every note of every part in order: `movement`, `voice`, `bar`, `beat`, `pitch` as the composer spelled it (letter, accidental, octave, such as `Gb4`, `F#5`, `Cx3`), `duration` in beats.
- `/app/statements.csv`: the statements the edition identifies: `statement` (a code), `movement`, `voice`, `ordinal` (the statement's place within that part of that movement).
- `/app/edition-notes.md`: how the parts and the statement table were prepared.

Write `/app/out/forms.csv` with a header row and one row per statement:

```
statement,form
q7x2,RI7
m3kp,P0
```

The forms of a row: `P0` is the row as the preface gives it; `Pn` raises every class of `P0` by n semitones (mod 12); `In` is `P0` inverted about its first class and then raised so that it begins on that class raised by n; `Rn` is `Pn` read backwards; `RIn` is `In` read backwards; n runs from 0 to 11. A statement's form is the form whose succession of pitch classes the statement's notes reproduce, octave and spelling set aside and an immediately repeated class counted once; a statement written short of its end is the form whose opening its notes reproduce. Where more than one form fits, file the earliest in the order P, I, R, RI, and among those the lowest n.

A row is right when `form` equals the key's label exactly. At least 72 of the 80 rows must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
