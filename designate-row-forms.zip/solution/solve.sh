#!/bin/bash
python3 "$(dirname "$0")/designate_forms.py" /app
