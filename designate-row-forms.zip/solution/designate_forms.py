#!/usr/bin/env python3
"""Reference: the row form of every statement in the edition's table.

Usage: designate_forms.py /app  -> /app/out/forms.csv
"""
import csv
import os
import re
import sys
from collections import defaultdict

ORDER = ("P", "I", "R", "RI")
LETTER = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
ACCIDENTAL = {"": 0, "#": 1, "x": 2, "##": 2, "b": -1, "bb": -2}


def rows_from_preface(path):
    rows = {}
    names = {"First": 1, "Second": 2, "Third": 3}
    for line in open(path, encoding="utf-8"):
        m = re.match(r"- (First|Second|Third) movement: ([\d ]+)$", line.strip())
        if m:
            rows[names[m.group(1)]] = [int(x) for x in m.group(2).split()]
    return rows


def all_forms(row):
    first = row[0]
    out = {}
    for n in range(12):
        prime = [(x + n) % 12 for x in row]
        inv = [(2 * first - x + n) % 12 for x in row]
        out["P%d" % n] = prime
        out["I%d" % n] = inv
        out["R%d" % n] = prime[::-1]
        out["RI%d" % n] = inv[::-1]
    return out


def rank(label):
    kind = label.rstrip("0123456789")
    return ORDER.index(kind), int(label[len(kind):])


def pitch_class(written):
    m = re.match(r"^([A-G])(bb|b|##|x|#)?(-?\d+)$", written)
    if not m:
        raise ValueError(written)
    return (LETTER[m.group(1)] + ACCIDENTAL[m.group(2) or ""]) % 12


def first_fit(classes, fm):
    """The form, first by precedence, that the classes reproduce (whole or as an opening)."""
    fits = [lab for lab, seq in fm.items() if seq[:len(classes)] == classes] if len(classes) < 12 \
        else [lab for lab, seq in fm.items() if seq == classes]
    return min(fits, key=rank) if fits else None


def parse_part(classes, count, fm):
    """Split one part's class succession into `count` statements, a statement being twelve classes
    or, when it opens on the note that closed the previous one, that note plus the next eleven; the
    last may be incomplete. Returns the labels in order."""
    labels = []
    pos, carried = 0, None
    for k in range(count):
        rest = classes[pos:]
        last = k == count - 1
        if last and len(rest) < 12:
            lab = first_fit(rest, fm)
            if lab is None and carried is not None:
                lab = first_fit([carried] + rest, fm)
            labels.append(lab)
            break
        lab, take = (first_fit(rest[:12], fm), 12) if len(rest) >= 12 else (None, 12)
        if lab is None and carried is not None and len(rest) >= 11:
            lab, take = first_fit([carried] + rest[:11], fm), 11
        labels.append(lab)
        pos += take
        carried = fm[lab][-1] if lab else None
    return labels


def main(root):
    rows = rows_from_preface(os.path.join(root, "preface.md"))
    fms = {m: all_forms(r) for m, r in rows.items()}
    parts = defaultdict(list)
    with open(os.path.join(root, "notes.csv"), newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            parts[(int(r["movement"]), r["voice"])].append(pitch_class(r["pitch"]))
    table = defaultdict(list)
    with open(os.path.join(root, "statements.csv"), newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            table[(int(r["movement"]), r["voice"])].append((int(r["ordinal"]), r["statement"]))
    out = []
    for key, entries in table.items():
        entries.sort()
        classes = []
        for pc in parts[key]:
            if not classes or classes[-1] != pc:      # an immediately repeated class is one note
                classes.append(pc)
        labels = parse_part(classes, len(entries), fms[key[0]])
        for (ordinal, code), lab in zip(entries, labels):
            out.append((code, lab or "P0"))
    out.sort()
    os.makedirs(os.path.join(root, "out"), exist_ok=True)
    with open(os.path.join(root, "out", "forms.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["statement", "form"])
        w.writerows(out)
    print("wrote %d rows" % len(out))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/app")
