# Three Pieces for Wind and Strings (1954): preface to the edition

The work, by a composer of the post-war Darmstadt circle whose papers the editor catalogued, is in
three movements for flute, clarinet, violin, viola and cello, each movement for three of the five
instruments. The autograph survives complete. The composer worked from one twelve-tone row in each
movement, written out at the head of the sketches as pitch classes with C = 0:

- First movement: 10 8 1 9 4 5 7 6 0 3 2 11
- Second movement: 5 6 10 4 8 2 3 9 1 7 11 0
- Third movement: 11 4 7 8 0 1 3 6 9 5 10 2

The composer's slurs mark the row statements throughout, and the edition follows them. Each
instrument's part is given in full as a note list, with the pitches spelled as the composer wrote
them, and a table lists the statements the edition identifies in each part in the order they occur.
