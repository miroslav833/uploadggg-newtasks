# Edition notes

`notes.csv` gives every note of every part in order: movement, instrument, bar (4/4 throughout),
beat within the bar, the pitch exactly as the composer spelled it (letter, accidental, octave, as
in `Gb4`, `F#5`, `Cx3`, `Bbb2`), and the duration in beats. Ornamental repetitions of a note are
given as written, including those the composer displaced by an octave. Rests are omitted.

`statements.csv` lists the row statements the edition identifies: a neutral code, the movement, the
instrument, and the statement's ordinal within that part of that movement. Statements follow one
another without interruption within a part. Where the composer links two statements by a note that
closes one and opens the next, the note is written once and belongs to both. The composer did not
always write a part's last statement in a movement to its end; such a statement is listed as the
edition found it.

The preface gives each movement's row. Nothing in the autograph labels a statement's form.
