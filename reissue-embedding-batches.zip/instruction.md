Write a program that decides, for one parity day of our embedding service, which delivered outputs must be recomputed on the fixed build and re-sent. It runs as

```
python3 /app/triage/triage.py DAY_DIR OUT_CSV
```

where DAY_DIR is one day's parity folder. `/app/service/HANDBOOK.md` describes the service, the reference path and the batched builds, what a parity folder holds and when a delivered output must be recomputed. Two sample days are in `/app/days`, each with its inputs, its delivered outputs, the reference outputs for the inputs the reference path ran, its build sheet and its operations log.

OUT_CSV gets a header row and one row per batch of the day:

```
report,reissue
B0A0,2;5;11
B0A1,none
```

`report` is the batch code from `inputs.jsonl`. `reissue` lists the slots whose delivered output must be recomputed, ascending and joined by `;`, or `none`. A batch is right when its set of slots equals the reference set exactly; a missing or unparseable row is wrong.

Grading runs the program on 20 other parity days that are not on this machine. They come from days whose builds, tokenizers, caches, fused limits and calendars do not all match the two samples, and whose files use the other formats listed under "Formats a parity day may use" in the handbook. A day counts when at most 2 of its 40 batches are wrong, and at least 18 of the 20 days must count. The program runs once per day on a fresh copy of the folder, as an unprivileged user, under the image's python3 with the standard library only, with 120 seconds per day. Anything else it needs must be inside `/app/triage`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
