For each of the 72 customer batches compared under `/app/reports`, file which of its inputs must be recomputed on build 2.3.1 and re-sent to the customer.

Inputs:

- `/app/reports/inputs.jsonl`: one JSON line per input: `report` (the batch code), `received` (when the service received the batch, UTC), `slot` (the input's position in the batch), `tokens` (its token count under tokenizer 1.4) and `text`.
- `/app/reports/reference.csv`: `report`, `slot` and the 32 values `v00` to `v31` of the fp32 single-sequence reference output for that input.
- `/app/reports/delivered.csv`: the same columns, with the values build 2.3.0 delivered for that input.
- `/app/runtime/NOTES.md`: the service, the model, the two attention paths, the day's operations, how the batches were compared, and the release entries for the builds and the tokenizers.

Write `/app/out/batches.csv` with a header row and one row per batch, in any order:

```
report,reissue
B0A0,2;5;11
B0A1,none
```

`report` is the batch code. `reissue` lists the slots to recompute, ascending and joined by `;`, or `none`.

An input is to be recomputed when build 2.3.1 would compute a different output for it than the one delivered, apart from the arithmetic differences of the bf16 batched path: that is, when the attention defect fixed in 2.3.1 acted on it in its batch, however small the resulting movement, or when tokenizer 2.0 read its text differently from tokenizer 1.4 would have.

A batch is right when its filed set of slots equals the reference set exactly (`none` against an empty set); a row that does not parse is wrong. At least 65 of the 72 batches must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
