# Build sheet

- build in service: 2.3.0
- tokenizer bundled: 2.0 (the reference path reads tokenizer 1.4)
- fused attention path: batches padded to at most 256 positions
- output cache: enabled
- fixed build that will recompute: 2.5.1
