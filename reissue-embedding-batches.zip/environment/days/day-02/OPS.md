# Operations log, Tuesday 17 February 2026 (Berlin local time)

- 11:00 fused attention switched off on pool B by configuration flag; pool B runs every batch on the unfused path from then on
- 11:00 to 12:00 pool A out of rotation for its weekly restart; pool B served all traffic
- load balancer log for the day lost in a disk rotation
