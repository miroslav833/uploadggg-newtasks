# Build sheet

- build in service: 2.2.7
- tokenizer bundled: 2.0 (the reference path reads tokenizer 1.4)
- fused attention path: batches padded to at most 256 positions
- output cache: disabled
- fixed build that will recompute: 2.5.1
