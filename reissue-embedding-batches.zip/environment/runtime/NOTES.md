# Embedding service: build 2.3.0 compared with the reference path

## The service and the model

The service returns one 32-dimensional embedding per input text. The model is
a 12-layer bidirectional transformer encoder (hidden size 384, six heads) with
a linear projection to 32 dimensions. The output for an input is the mean of
the final-layer states over the input's own token positions, projected and
L2-normalised.

## The two paths

The reference path runs one sequence at a time in fp32 throughout, with
tokenizer 1.4. It is the path the model was validated on and the path the
customers' indexes were built against.

Build 2.3.0 is the batched build. It runs each customer batch as the customer
sent it, up to 16 inputs. Sequences are right-padded to the longest sequence in
the batch, with a per-sequence key mask over the padded positions and the same
mask on the pooling. Matrix products and attention probabilities are computed
in bf16 with fp32 accumulation; layer norms, the softmax statistics and the
final projection are fp32. The build has two attention paths: the fused
kernel, which handles a batch whose padded length is at most 256 tokens in one
pass per layer, and the unfused path (separate score, softmax and value
kernels) for a batch padded longer than that. Build 2.3.0 bundles tokenizer
2.0.

## The comparison

64 customer batches were sampled from one day's traffic, of 1 to 16 inputs
each. Each batch was run once through build 2.3.0 exactly as sent, and the
delivered outputs were kept; each input was then run once through the
reference path. `reports/inputs.jsonl` lists every input with its report code
(the batch), its slot (its position in the batch), its token count under
tokenizer 1.4 and its text. `reports/reference.csv` and `reports/delivered.csv`
carry the 32 output values from each path for every input, to six decimals.

## Release entries

- tokenizer 1.4 (March 2026): byte-level BPE, 50k vocabulary. The text is
  pre-tokenised as given, with no normalisation.
- tokenizer 2.0 (September 2026): the same vocabulary and merges. The text is
  Unicode-normalised before pre-tokenisation.
- build 2.3.0 (2 October 2026): the batched build described above; bundles
  tokenizer 2.0.
- build 2.3.1 (16 October 2026): fixes #412, in which attention was not masked
  at padded key positions in some batches, and pins tokenizer 1.4's
  pre-tokenisation (no normalisation) so that outputs stay comparable with the
  reference path. Outputs already delivered by 2.3.0 are not recomputed
  automatically.
