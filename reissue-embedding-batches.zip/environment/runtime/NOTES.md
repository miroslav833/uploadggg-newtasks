# Embedding service: build 2.3.0 compared with the reference path

## The service and the model

The service returns one 32-dimensional embedding per input text. The model is
a 12-layer bidirectional transformer encoder (hidden size 384, six heads) with
a linear projection to 32 dimensions. Every input is encoded as a start token,
its text tokens and an end token. The output for an input is the mean of the
final-layer states over the input's own positions, projected and L2-normalised.

## The two paths

The reference path runs one sequence at a time in fp32 throughout, with
tokenizer 1.4. It is the path the model was validated on and the path the
customers' indexes were built against.

Build 2.3.0 is the batched build. It runs each customer batch as the customer
sent it, up to 32 inputs. Encoded sequences are right-padded to the longest
encoded sequence in the batch, with a per-sequence key mask over the padded positions and the same
mask on the pooling. Matrix products and attention probabilities are computed
in bf16 with fp32 accumulation; layer norms, the softmax statistics and the
final projection are fp32. The build has two attention paths: the fused
kernel, which handles a batch whose padded length is at most 256 positions in
one pass per layer, and the unfused path (separate score, softmax and value kernels) for
a batch padded longer than that. Build 2.3.0 bundles tokenizer
2.0.

Build 2.3.0 keeps a 24-hour cache of outputs, keyed by the token ids the build
read for an input. An input of a batch whose key is already in the cache is
answered from the cache and is not run; the batch's other inputs are run
together, in the order the customer sent them. The cache started empty on the
comparison day.

## Operations on the comparison day

The service runs on two node pools, A and B, behind one load balancer that
sends each batch to whichever pool has room. The operations team works from
Berlin and keeps its log in Berlin local time. At 12:00 on the comparison day,
after the first customer reports of what became #412, the fused kernel was
switched off on pool B by a configuration flag: from then on pool B ran every
batch on the unfused path, whatever its padded length. Pool A kept the fused
kernel until 2.3.1. Pool A was out of rotation for its weekly restart from 12:00
to 13:00, and pool B served all traffic in that hour. The load balancer's log
for the day was lost in a disk rotation, so outside that hour which pool
handled a batch is not known.

## The comparison

72 customer batches were sampled from one day's traffic, 25 October 2026, of
5 to 32 inputs each. Each batch was run once through build 2.3.0 exactly as sent, and the
delivered outputs were kept; each input was then run once through the
reference path. `reports/inputs.jsonl` lists every input with its report code
(the batch), the time the service received the batch (UTC), its slot (its
position in the batch), its token count under
tokenizer 1.4 and its text. `reports/reference.csv` and `reports/delivered.csv`
carry the 32 output values from each path for every input, to five decimals.

## Release entries

- tokenizer 1.4 (March 2026): byte-level BPE, 50k vocabulary. The text is
  pre-tokenised as given, with no normalisation.
- tokenizer 2.0 (September 2026): the same vocabulary and merges. The text is
  cleaned and Unicode-normalised before pre-tokenisation.
- build 2.3.0 (2 October 2026): the batched build described above; bundles
  tokenizer 2.0.
- build 2.3.1 (16 October 2026): fixes #412, a key-mask defect in the fused
  kernel by which, in some batches, attention did not follow each sequence's
  own padding, and pins tokenizer 1.4's
  pre-tokenisation (no normalisation) so that outputs stay comparable with the
  reference path. Outputs already delivered by 2.3.0 are not recomputed
  automatically.
