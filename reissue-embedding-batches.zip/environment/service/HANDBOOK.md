# Embedding service: parity days

The service returns one 32-dimensional embedding per input text. The model is a 12-layer
bidirectional transformer encoder (hidden size 384, six heads) with a linear projection to 32
dimensions. Every input is encoded as a start token, its text tokens and an end token; the output
is the mean of the final-layer states over the input's own positions, projected and L2-normalised.

## The two paths

The **reference path** runs one sequence at a time in fp32, with tokenizer 1.4, which reads the text
exactly as given. It is the path the model was validated on and the customers' indexes were built
against.

A **batched build** runs each customer batch as the customer sent it, up to 32 inputs, in the
order sent. Encoded sequences are right-padded to the longest encoded sequence in the batch, with a
per-sequence key mask over the padded positions and the same mask on the pooling. Matrix products
and attention probabilities are bf16 with fp32 accumulation; layer norms, softmax statistics and
the projection are fp32. A batched build has two attention paths, a fused kernel for batches whose
padded length is within its limit and an unfused path for longer ones. Each build bundles its own
tokenizer, with the same vocabulary and merges as 1.4; later tokenizers clean or normalise text
before pre-tokenisation. A build may keep an output cache: an input whose token ids it has already
run that day is answered from the cache and not run, and the rest of its batch runs without it.

The fused kernels of several builds carry key-mask defects that make attention on the fused path
ignore some sequences' own padding. Each build differs; they are tracked in the build's own issue
list, which is not part of a parity day.

The **fixed build** recomputes delivered outputs. It reads text exactly as tokenizer 1.4 does, has
no key-mask defect and no cache, and runs every input in its own right.

## A parity day

Each day the parity desk samples 40 customer batches from the day's traffic and keeps a folder:

- `inputs.jsonl`: one line per input: `report` (the batch), `received` (when the service received
  the batch, UTC), `slot` (position in the batch), `tokens` (token count under tokenizer 1.4), `text`.
- `delivered` and `reference`: the 32 output values per input from the batched build and from the
  reference path. The desk's export tool has changed over the years, so these come as CSV or as JSON
  lines, with the batch, the slot and the values named as that export named them; the values are in
  the order of the number in their name. The reference path ran every input received before
  07:00 UTC, and after that each input with chance two in five, drawn independently.
- `BUILD.md`: the build sheet: the build in service, the tokenizer it bundles, how long a batch the
  fused path takes, and whether the build keeps an output cache.
- `OPS.md`: the day's operations log, as the operations team wrote it.

The service runs on two node pools behind one load balancer that sends each batch to whichever pool
has room; the operations log records anything that changed how a pool ran batches. The balancer's
own log is not kept with a parity day.

## Recompute

A delivered output must be recomputed and re-sent when the fixed build would compute a different
output for that input, apart from the arithmetic differences of the bf16 batched path: when a
key-mask defect acted on the run that produced the delivered output, however small the resulting
movement, or when the delivered output came from token ids other than tokenizer 1.4's for the
input's text. A re-sent output invalidates the customer's index entry, so nothing else is re-sent.
