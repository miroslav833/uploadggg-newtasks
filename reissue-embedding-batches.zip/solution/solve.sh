#!/usr/bin/env bash
# Installs the reference triage program and runs it on the two sample days.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/triage
cp "$HERE/triage/triage.py" /app/triage/triage.py
for d in /app/days/*/; do
  python3 /app/triage/triage.py "$d" "/tmp/$(basename "$d").csv"
done
