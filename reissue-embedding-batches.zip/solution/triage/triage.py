#!/usr/bin/env python3
"""Which delivered outputs of one comparison day the fixed build must recompute.

    python3 triage.py DAY_DIR OUT_CSV

Nothing about any particular build, tokenizer or day is built in. Everything is read from the day:
  1. the build sheet (fused limit, whether the output cache is on) and the operations log, whose
     Berlin wall-clock times are put in UTC by the EU summer-time rule;
  2. the bf16 scatter: the departure of delivered from reference per sqrt(token) on plain inputs of
     batches too long for the fused path gives an envelope and a z-score per referenced input;
  3. the tokenizer's steps: among those unfused inputs, texts that one candidate step changes and no
     other show, against the envelope, whether the step is applied;
  4. the cache: with the cache on, an input whose prepared text an earlier batch already ran is
     answered from it, is not run, and carries that run's verdict;
  5. the defect: each candidate account of whose key mask the fused path gave every sequence
     (the first run sequence's, the last's, none at all, or no defect) predicts which referenced
     inputs of the batches whose path is certain moved strongly and which did not move; the account
     those departures contradict least is the day's;
  6. the batches whose pool is unknown: padding pulls every reached input of a batch toward that
     batch's own padding state, so their departures share a direction; summed pairwise cosines of the
     referenced inputs, against the spread for unrelated directions, decide whether the batch ran fused.
"""
import csv
import datetime
import json
import math
import os
import re
import statistics
import sys
import unicodedata

DIM = 32
SPECIALS = 2


# ---------------------------------------------------------------- reading the day
def read_vectors(day, stem):
    """The desk's export of one output table, whatever its layout: CSV with any names for the batch,
    the slot and the 32 values (ordered by the number in each value column's name), or JSON lines with
    the vector as a list."""
    out = {}
    jl, cs = os.path.join(day, stem + ".jsonl"), os.path.join(day, stem + ".csv")
    if os.path.exists(jl):
        with open(jl, encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                d = json.loads(line)
                code = next(d[k] for k in d if k.lower() in ("report", "batch", "batch_id"))
                slot = next(d[k] for k in d if k.lower() in ("slot", "item", "position"))
                vec = next(v for v in d.values() if isinstance(v, list))
                out[(str(code), int(slot))] = [float(v) for v in vec]
        return out
    with open(cs, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        head = [h.strip() for h in next(rd)]
        low = [h.lower() for h in head]
        ci = next(i for i, h in enumerate(low) if h in ("report", "batch", "batch_id"))
        si = next(i for i, h in enumerate(low) if h in ("slot", "item", "position"))
        dims = sorted((int(re.search(r"(\d+)$", h).group(1)), i) for i, h in enumerate(head)
                      if i not in (ci, si) and re.search(r"\d+$", h))
        for row in rd:
            if row:
                out[(row[ci].strip(), int(row[si]))] = [float(row[i]) for _, i in dims]
    return out


def read_day(day, o=None):
    o = o or {}
    inputs = {}
    with open(os.path.join(day, "inputs.jsonl"), encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            inputs[(d["report"], int(d["slot"]))] = dict(code=d["report"], slot=int(d["slot"]), L=int(d["tokens"]),
                                                         text=d["text"], received=d["received"])
    for stem, key in (("reference", "ref"), ("delivered", "del")):
        if o.get("csv_only") and not os.path.exists(os.path.join(day, stem + ".csv")):
            raise FileNotFoundError(stem + ".csv")
        for k, vec in read_vectors(day, stem).items():
            inputs[k][key] = vec
    build = open(os.path.join(day, "BUILD.md"), encoding="utf-8").read()
    ops = open(os.path.join(day, "OPS.md"), encoding="utf-8").read()
    m = re.search(r"at most (\d+) positions", build)
    if m:
        limit = int(m.group(1))
    else:                          # stated as text tokens: the start and end tokens come on top
        limit = int(re.search(r"at most (\d+) text tokens", build).group(1)) + (0 if o.get("limit_raw") else SPECIALS)
    cache_on = bool(re.search(r"(output|result) cache:\s*(enabled|on)\b", build, re.I))
    batches = {}
    for x in inputs.values():
        batches.setdefault(x["code"], []).append(x)
    for xs in batches.values():
        xs.sort(key=lambda x: x["slot"])
    return batches, limit, cache_on, ops


def last_sunday(year, month):
    d = datetime.date(year, month + 1, 1) - datetime.timedelta(days=1)
    while d.weekday() != 6:
        d -= datetime.timedelta(days=1)
    return d


def berlin_to_utc(date, hour):
    """EU rule: summer time (UTC+2) from 01:00 UTC on the last Sunday of March to 01:00 UTC on the
    last Sunday of October; UTC+1 otherwise."""
    start, end = last_sunday(date.year, 3), last_sunday(date.year, 10)
    summer = start < date < end or (date == start and hour >= 3) or (date == end and hour < 3)
    return hour - (2 if summer else 1)


TIME = re.compile(r"\b(\d{1,2})[:.](\d{2})\s*(a\.m\.|p\.m\.)?", re.I)


def hours_in(line):
    out = []
    for h, mnt, ampm in TIME.findall(line):
        h = int(h)
        if ampm:
            h = h % 12 + (12 if ampm.lower().startswith("p") else 0)
        out.append(h + int(mnt) / 60.0)
    return out


def log_date(head):
    for fmt, rx in (("%Y-%m-%d", r"\d{4}-\d{2}-\d{2}"), ("%d.%m.%Y", r"\d{2}\.\d{2}\.\d{4}"),
                    ("%d %B %Y", r"\d{1,2} [A-Z][a-z]+ \d{4}"), ("%B %d, %Y", r"[A-Z][a-z]+ \d{1,2}, \d{4}")):
        m = re.search(rx, head)
        if m:
            try:
                return datetime.datetime.strptime(m.group(0), fmt).date()
            except ValueError:
                continue
    raise ValueError("no date in the log's heading: %r" % head)


def ops_times(ops, offset_rule=None, ignore_utc=False, english_only=False):
    lines = [ln.strip() for ln in ops.splitlines() if ln.strip()]
    head = lines[0]
    date = log_date(head)
    in_utc = bool(re.search(r"\bUTC\b", head)) and not ignore_utc
    conv = (lambda d, h: h) if in_utc else (offset_rule or berlin_to_utc)
    switch = back = None
    for ln in lines[1:]:
        low = ln.lower()
        hs = hours_in(ln)
        if english_only and not re.search(r"\d:\d\d", ln):
            continue
        if not hs:
            continue
        if "pool b" in low and "fused" in low and re.search(r"\b(off|disabled|abgeschaltet)\b", low) \
                and "no change" not in low:
            switch = conv(date, hs[0])
        if re.search(r"restart|neustart", low) and "pool a" in low and len(hs) >= 2:
            back = conv(date, hs[1])
    fmt = lambda h: "%02d:%02d:00" % (int(h), round((h - int(h)) * 60))   # noqa: E731
    switch_s = fmt(switch) if switch is not None else "99:00:00"
    back_s = fmt(back) if back is not None else switch_s
    return switch_s, back_s


# ---------------------------------------------------------------- tokenizer steps
def features(text):
    no_fmt = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
    nfc = unicodedata.normalize("NFC", no_fmt)
    return dict(format=no_fmt != text, decomp=nfc != no_fmt,
                compat=unicodedata.normalize("NFKC", no_fmt) != nfc, spaces="  " in text)


def prepare(text, steps):
    for st in ("format", "nfkc", "nfc", "spaces"):
        if st not in steps:
            continue
        if st == "format":
            text = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
        elif st in ("nfkc", "nfc"):
            text = unicodedata.normalize(st.upper(), text)
        else:
            text = re.sub(" {2,}", " ", text)
    return text


def coherence(xs):
    us = [[v / x["diff"] for v in x["dv"]] for x in xs]
    pairs = [(i, j) for i in range(len(us)) for j in range(i + 1, len(us))]
    if not pairs:
        return 0.0
    tot = sum(sum(a * b for a, b in zip(us[i], us[j])) for i, j in pairs)
    return tot / math.sqrt(len(pairs) / DIM)


DEFAULTS = dict(envelope="mad", zvis=4.0, znorm=4.0, nmethod="mean", forms=("first", "last", "padded", "none"),
                form=None, steps=None, cache="key", pools="coherence", tpool=4.0, tz=None, specials=SPECIALS,
                limit=None)


def triage(day, opt=None):
    o = dict(DEFAULTS)
    o.update(opt or {})
    batches, limit, cache_on, ops = read_day(day, o)
    if o["limit"]:
        limit = o["limit"]
    switch, back = ops_times(ops, o["tz"], o.get("ignore_utc", False), o.get("english_only", False))
    rows = [x for xs in batches.values() for x in xs]
    for code, xs in batches.items():
        bpos = max(x["L"] for x in xs) + o["specials"]
        for x in xs:
            x["bpos"] = bpos
            x["f"] = features(x["text"])
            x["textchg"] = any(x["f"].values())
            if "ref" in x:
                x["dv"] = [b - a for a, b in zip(x["ref"], x["del"])]
                x["diff"] = math.sqrt(sum(v * v for v in x["dv"]))
                x["r"] = x["diff"] / math.sqrt(x["L"])
            else:
                x["r"] = None
    # 2. the envelope, from plain referenced inputs of batches no fused path can take
    base = [x["r"] for x in rows if x["r"] is not None and x["bpos"] > limit and not x["textchg"]]
    if o["envelope"] == "mad":
        m = statistics.median(base)
        s = 1.4826 * statistics.median([abs(b - m) for b in base])
    else:
        m, s = statistics.fmean(base), statistics.pstdev(base)
    for x in rows:
        x["z"] = None if x["r"] is None else (x["r"] - m) / s
    # 3. the tokenizer's steps
    if o["steps"] is None:
        unfused = [x for x in rows if x["z"] is not None and x["bpos"] > limit]

        def level(name):
            zs = [x["z"] for x in unfused if x["f"][name] and not any(v for k, v in x["f"].items() if k != name)]
            if len(zs) < 2:
                return 0.0
            return statistics.fmean(zs) if o["nmethod"] == "mean" else statistics.median(zs)

        steps = set()
        if level("format") > o["znorm"]:
            steps.add("format")
        if level("compat") > o["znorm"]:
            steps.add("nfkc")
        elif level("decomp") > o["znorm"]:
            steps.add("nfc")
        if level("spaces") > o["znorm"]:
            steps.add("spaces")
    else:
        steps = set(o["steps"])
    for x in rows:
        x["key"] = prepare(x["text"], steps) if o["cache"] == "key" else x["text"]
        x["chg"] = prepare(x["text"], steps) != x["text"]
    # 4. the cache, walking the day in the order received
    order = sorted(batches, key=lambda c: (batches[c][0]["received"], c))
    seen = set()
    for code in order:
        xs = batches[code]
        for x in xs:
            x["hit"] = cache_on and o["cache"] != "none" and x["key"] in seen
        ran = [x for x in xs if not x["hit"]]
        P = max(x["L"] for x in ran)
        for x in xs:
            x["pos"] = P + o["specials"]
            x["late"] = x["received"] >= switch
            x["b_only"] = switch <= x["received"] < back
            x["run_lengths"] = [y["L"] for y in ran]
        for x in ran:
            seen.add(x["key"])
    srcs = {}

    def mask_ref(form, lengths):
        return lengths[0] if form == "first" else lengths[-1] if form == "last" else max(lengths)

    def wrong_keys(form, x):
        if form == "none" or x["pos"] > limit:
            return 0
        return abs(x["L"] - mask_ref(form, x["run_lengths"]))

    # 5. the defect form, on run inputs of batches whose path is certain (received before the switch)
    if o["form"] is None:
        best, best_score = None, None
        for form in o["forms"]:
            agree = contradicted = 0
            for x in rows:
                if x["hit"] or x["late"] or x["z"] is None or x["textchg"]:
                    continue
                u = wrong_keys(form, x)
                if u / x["L"] >= 0.15:
                    agree += x["z"] > o["zvis"]
                    contradicted += x["z"] <= o["zvis"]
                elif u == 0:
                    contradicted += x["z"] > o["zvis"]
            score = (-contradicted, agree)
            if best_score is None or score > best_score:
                best, best_score = form, score
        form = best
    else:
        form = o["form"]
    # 6. path per batch, then verdicts
    out = {}
    reached_of = {}
    for code in order:
        xs = batches[code]
        ran = [x for x in xs if not x["hit"]]
        fits = ran[0]["pos"] <= limit and form != "none"
        if not fits or ran[0]["b_only"]:
            fused = False
        elif not ran[0]["late"]:
            fused = True
        elif o["pools"] == "coherence":
            ref = mask_ref(form, ran[0]["run_lengths"])
            ev = [x for x in ran if x["z"] is not None and not x["textchg"] and x["L"] < ref]
            fused = coherence(ev) > o["tpool"]
        elif o["pools"] == "visible":
            fused = any(x["z"] is not None and x["z"] > o["zvis"] for x in ran if not x["textchg"])
        elif o["pools"] == "all-fused":
            fused = True
        else:
            fused = False
        for x in ran:
            x["reached"] = fused and wrong_keys(form, x) > 0
            reached_of.setdefault(x["key"], x["reached"])
        verdict = set()
        for x in xs:
            reached = reached_of[x["key"]] if x["hit"] else x["reached"]
            if reached or x["chg"]:
                verdict.add(x["slot"])
        out[code] = verdict
    return out, dict(steps=sorted(steps), form=form, switch=switch, back=back, limit=limit, cache=cache_on)


def write(out, path):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["report", "reissue"])
        for code in sorted(out):
            w.writerow([code, ";".join(map(str, sorted(out[code]))) if out[code] else "none"])


if __name__ == "__main__":
    result, found = triage(sys.argv[1])
    write(result, sys.argv[2])
    print(json.dumps(found), file=sys.stderr)
