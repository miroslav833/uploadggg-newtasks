#!/usr/bin/env python3
"""Which inputs of each compared batch must be recomputed on build 2.3.1.

The honest path, in the order an inference engineer takes it:
  1. the bf16 scatter: the L2 departure of delivered from reference, per sqrt(token), on the
     inputs no recorded change can have touched (inputs of batches on the unfused path, padded
     past 256, and single inputs, with plain texts), gives an envelope and a z-score for every
     input;
  2. the key-mask defect: candidate accounts of which key positions each sequence's attention
     saw (its own mask with padding left open; the mask of another slot of the batch) and of
     the path that carried it (the fused kernel; every path) each predict which inputs moved
     strongly and which did not move at all. The account the departures bear out is slot 1's
     mask applied to every sequence on the fused path. Batches received before the switch (12:00 Berlin
     summer time, 10:00 UTC) took the
     fused path whenever they were padded to at most 256; after it, pool B ran them unfused and
     the pool is not recorded. Unmasked padding pulls an input toward one shared padding
     representation, so its direction is estimated from the strongly moved short inputs of the
     batches that certainly ran fused, and each late batch is decided by the projections of its
     shorter-than-slot-1 inputs' departures on that direction, summed against the scatter. The
     account then decides every input, however small its movement;
  3. tokenizer 2.0's preparation: among inputs the defect did not reach, texts changed by one
     candidate step and by no other show whether that step is applied (format characters
     removed, NFKC, NFC, runs of spaces collapsed, casefolding); the steps that are give the
     texts tokenizer 2.0 read differently;
  4. file the union per batch.
Options (used by the readings script) switch estimators and switch findings off.
"""
import csv
import json
import math
import os
import re
import statistics
import sys
import unicodedata

DIM = 32
FUSED_NOTES = 256          # padded length the notes give for the fused kernel
SPECIALS_NOTES = 2         # start and end token around every encoded input, from the notes
SWITCH_NOTES = "11:00:00"  # 12:00 Berlin on 25 October 2026, after summer time ended that night: CET, UTC+1
A_BACK_NOTES = "12:00:00"  # pool A back from its restart at 13:00 Berlin
STEPS = ("format", "compat", "decomp", "spaces", "case")


def load(root):
    inputs = {}
    with open(os.path.join(root, "reports", "inputs.jsonl"), encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            inputs[(d["report"], int(d["slot"]))] = dict(slot=int(d["slot"]), tokens=int(d["tokens"]), text=d["text"],
                                                         received=d["received"])
    for name, key in (("reference.csv", "ref"), ("delivered.csv", "del")):
        with open(os.path.join(root, "reports", name), newline="", encoding="utf-8") as fh:
            for rec in csv.DictReader(fh):
                inputs[(rec["report"], int(rec["slot"]))][key] = [float(rec["v%02d" % q]) for q in range(DIM)]
    reports = {}
    for (code, _), d in inputs.items():
        reports.setdefault(code, []).append(d)
    for code in reports:
        reports[code].sort(key=lambda d: d["slot"])
    return reports


def features(text):
    """Which candidate preparation step would change the text, one flag per step."""
    no_fmt = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
    nfc = unicodedata.normalize("NFC", no_fmt)
    return dict(format=no_fmt != text, decomp=nfc != no_fmt,
                compat=unicodedata.normalize("NFKC", no_fmt) != nfc, spaces="  " in text,
                case=text.casefold() != text, nonascii=any(ord(ch) > 127 for ch in text))


def prepare(text, steps):
    t = text
    if "format" in steps:
        t = "".join(ch for ch in t if unicodedata.category(ch) != "Cf")
    if "nfkc" in steps:
        t = unicodedata.normalize("NFKC", t)
    elif "nfc" in steps:
        t = unicodedata.normalize("NFC", t)
    if "casefold" in steps:
        t = t.casefold()
    if "spaces" in steps:
        t = re.sub(" {2,}", " ", t)
    return t


def attended(P, L, L1, path_max, model, Lk=None, pos=None):
    """Key positions an account of the defect gets wrong for an input of L tokens in a batch padded
    to P whose slot 1 holds L1 tokens (Lk: the slot an account names instead of slot 1)."""
    if (P if pos is None else pos) > path_max:
        return 0
    if model == "all":
        return P - L
    ref = L1 if Lk is None else Lk
    return abs(L - ref)


DEFAULTS = dict(envelope="mad", account="infer", norm="infer", znorm=4.0, nmethod="mean",
                zvis=4.0, count="mechanism", zcut=3.0, naive=False, pools="test", tpool=4.0, pstat="proj", vfrom="early",
                specials=SPECIALS_NOTES, switch=SWITCH_NOTES, a_back=A_BACK_NOTES,
                cache="key", cache_slot="run", cache_inherit=True)
ACCOUNTS = {"slot1-fused": (FUSED_NOTES, "slot1"), "all-fused": (FUSED_NOTES, "all"),
            "last-fused": (FUSED_NOTES, "last"), "longest-fused": (FUSED_NOTES, "longest"),
            "slot1-any": (10 ** 9, "slot1"), "all-any": (10 ** 9, "all"), "none": (0, "all")}


def reference_length(xs, model):
    if model == "last":
        return max(xs, key=lambda x: x["slot"])["L"]
    if model == "longest":
        return max(x["L"] for x in xs)
    return min(xs, key=lambda x: x["slot"])["L"]


def padding_direction(rows, pmax, vfrom):
    """The shared direction unmasked padding pulls toward: the mean unit departure of the strongly
    moved inputs shorter than slot 1 in fused-length batches ('early': received before the switch;
    'all': any time)."""
    pick = [x for x in rows if x["pos"] <= pmax and x["L"] < x["L1"] and x["z"] > 8 and not x["textchg"]
            and (vfrom == "all" or not x["late"])]
    v = [0.0] * DIM
    for x in pick:
        for q in range(DIM):
            v[q] += x["dv"][q] / x["diff"]
    n = math.sqrt(sum(t * t for t in v)) or 1.0
    return [t / n for t in v]


def infer_steps(rows, o):
    """Tokenizer 2.0's preparation steps, from the unfused batches: texts changed by one candidate
    step and by no other, against the scatter."""
    if o["norm"] != "infer":
        return set(o["norm"].split("+")) if o["norm"] != "none" else set()
    clean = [x for x in rows if x["bpos"] > FUSED_NOTES]

    def level(name):
        if name == "case":
            zs = [x["z"] for x in clean if x["f"]["case"] and not x["textchg"]]
        else:
            zs = [x["z"] for x in clean
                  if x["f"][name] and not any(x["f"][k] for k in STEPS if k not in (name, "case"))]
        if len(zs) < 3:
            return 0.0
        return statistics.fmean(zs) if o["nmethod"] == "mean" else statistics.median(zs)

    steps = set()
    if level("format") > o["znorm"]:
        steps.add("format")
    if level("compat") > o["znorm"]:
        steps.add("nfkc")
    elif level("decomp") > o["znorm"]:
        steps.add("nfc")
    if level("spaces") > o["znorm"]:
        steps.add("spaces")
    if level("case") > o["znorm"]:
        steps.add("casefold")
    return steps


def analyse(reports, opt=None):
    o = dict(DEFAULTS)
    o.update(opt or {})
    rows = []
    received = {}
    for code, items in reports.items():
        received[code] = items[0]["received"]
        bpos = max(d["tokens"] for d in items) + o["specials"]
        for d in items:
            dv = [b - a for a, b in zip(d["ref"], d["del"])]
            diff = math.sqrt(sum(v * v for v in dv))
            rows.append(dict(code=code, slot=d["slot"], L=d["tokens"], bpos=bpos, n=len(items),
                             late=d["received"] >= o["switch"],
                             b_only=o["switch"] <= d["received"] < o["a_back"], dv=dv,
                             text=d["text"], diff=diff, r=diff / math.sqrt(d["tokens"]), f=features(d["text"])))
    # 1. the scatter envelope, from plain inputs of unfused batches and single inputs
    base = [x["r"] for x in rows if (x["bpos"] > FUSED_NOTES + 8 or x["n"] == 1)
            and not any(x["f"][k] for k in STEPS if k != "case")]
    if o["envelope"] == "mad":
        m = statistics.median(base)
        s = 1.4826 * statistics.median([abs(b - m) for b in base])
    else:
        m = statistics.fmean(base)
        s = statistics.pstdev(base)
    for x in rows:
        x["z"] = (x["r"] - m) / s
        x["textchg"] = any(x["f"][k] for k in STEPS if k != "case")
    by = {}
    for x in rows:
        by.setdefault(x["code"], []).append(x)
    for xs in by.values():
        xs.sort(key=lambda x: x["slot"])
    if o["naive"]:
        return {code: {x["slot"] for x in xs if x["z"] > o["zcut"]} for code, xs in by.items()}
    # 2. tokenizer 2.0's preparation, then the build's cache: an input whose token ids (its
    #    prepared text) an earlier batch already ran is answered from the cache and not run
    steps = infer_steps(rows, o)
    for x in rows:
        x["chg"] = x["f"]["nonascii"] if "nonascii" in steps else prepare(x["text"], steps) != x["text"]
        x["key"] = prepare(x["text"], steps) if o["cache"] == "key" else x["text"]
        x["src"] = None
    seen = {}
    for code in sorted(by, key=lambda c: (received[c], c)):
        xs = by[code]
        if o["cache"] != "none":
            for x in xs:
                x["src"] = seen.get(x["key"])
        ran = [x for x in xs if x["src"] is None]
        if o["cache_slot"] == "kept":          # hits answered from the cache, but slot 1 still the mask
            ran = xs
        P = max(x["L"] for x in ran)
        for x in xs:
            x["P"], x["pos"], x["pad"] = P, P + o["specials"], P - x["L"]
            x["L1"] = ran[0]["L"]
        for x in ran:
            if x["src"] is None:
                seen.setdefault(x["key"], x)
    ranby = {code: [x for x in xs if x["src"] is None] for code, xs in by.items()}
    # 3. the defect: the account whose predictions the departures of run inputs bear out
    if o["account"] == "infer":
        best, best_score = None, None
        for name, (pmax, model) in ACCOUNTS.items():
            if name == "none":
                continue
            # an account is judged by the predictions the departures contradict, then by how many
            # strong movements it explains
            agree, contradicted = 0, 0
            for code, xs in ranby.items():
                if not xs or xs[0]["late"]:
                    continue                  # after the switch the path of a batch is not certain
                Lk = reference_length(xs, model)
                for x in xs:
                    if x["textchg"]:
                        continue
                    u = attended(x["P"], x["L"], Lk, pmax, model, pos=x["pos"])
                    share = u / max(x["L"], 1)
                    if share >= 0.15:
                        agree += x["z"] > o["zvis"]
                        contradicted += x["z"] <= o["zvis"]
                    elif u == 0:
                        contradicted += x["z"] > o["zvis"]
            score = (-contradicted, agree)
            if best_score is None or score > best_score:
                best, best_score = name, score
        pmax, model = ACCOUNTS[best]
    elif o["account"] == "observed":
        pmax, model = FUSED_NOTES, "observed"
    else:
        pmax, model = ACCOUNTS[o["account"]]
    runrows = [x for x in rows if x["src"] is None]
    for code in sorted(by, key=lambda c: (received[c], c)):
        xs = ranby[code]
        if not xs:
            continue
        if model == "observed":
            # slot 1's mask on the fused path, but only in batches where some input visibly moved
            L1 = xs[0]["L1"]
            hit = xs[0]["pos"] <= pmax and any(x["z"] > o["zvis"] for x in xs if not x["textchg"])
            for x in xs:
                x["mask"] = hit and x["L"] != L1
        else:
            Lk = xs[0]["L1"] if model == "slot1" else reference_length(xs, model)
            for x in xs:
                x["mask"] = attended(x["P"], x["L"], Lk, pmax, model, pos=x["pos"]) > 0
            if xs[0]["b_only"] and o["pools"] != "ignore":
                for x in xs:
                    x["mask"] = False         # pool A restarting: pool B, already unfused, ran it
            elif xs[0]["late"] and xs[0]["pos"] <= pmax and o["pools"] != "ignore":
                if o["pools"] == "test":
                    if o["pstat"] == "l2":
                        zs = [x["z"] for x in xs if x["mask"] and not x["textchg"]]
                        stat = statistics.fmean(zs) * math.sqrt(len(zs)) if zs else 0.0
                    else:
                        v = padding_direction(runrows, pmax, o["vfrom"])
                        ps = [sum(a * b for a, b in zip(x["dv"], v)) / (m * math.sqrt(x["L"] / DIM))
                              for x in xs if x["mask"] and x["L"] < x["L1"] and not x["textchg"]]
                        if ps:
                            stat = statistics.fmean(ps) * math.sqrt(len(ps))
                        else:
                            # no clean input shorter than slot 1: the longer ones lose real keys and
                            # move in their own directions, so their summed magnitude decides
                            zs = [x["z"] for x in xs if x["mask"] and not x["textchg"]]
                            stat = statistics.fmean(zs) * math.sqrt(len(zs)) if zs else 0.0
                    ran_fused = stat > o["tpool"]
                elif o["pools"] == "visible":
                    ran_fused = any(x["z"] > o["zvis"] for x in xs if not x["textchg"])
                else:                                 # "unfused": every late batch taken as pool B
                    ran_fused = False
                for x in xs:
                    x["mask"] = x["mask"] and ran_fused
        # a cached input carries whatever reached the run that filled the cache
        for x in by[code]:
            if x["src"] is not None:
                x["mask"] = x["src"]["mask"] if o["cache_inherit"] else (
                    x["pos"] <= pmax and x["L"] != x["L1"])
    # 4. the union per batch
    out = {}
    for code, xs in by.items():
        out[code] = {x["slot"] for x in xs
                     if (x["mask"] or x["chg"]) and (o["count"] == "mechanism" or x["z"] > o["zcut"])}
    return out


def write_filing(filing, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["report", "reissue"])
        for code in sorted(filing):
            slots = sorted(filing[code])
            w.writerow([code, ";".join(str(s) for s in slots) if slots else "none"])


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "/app"
    write_filing(analyse(load(root)), os.path.join(root, "out", "batches.csv"))
