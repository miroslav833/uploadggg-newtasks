#!/usr/bin/env python3
"""Which inputs of each compared batch must be recomputed on build 2.3.1.

The honest path, in the order an inference engineer takes it:
  1. the bf16 scatter: the L2 departure of delivered from reference, per sqrt(token), on the
     inputs no recorded change can have touched (the unpadded ones), gives an envelope and a
     z-score for every input;
  2. the masking defect: padded batches whose heavily padded inputs sit far above the envelope
     are the ones the defect acted on; their padded lengths against the others' locate the path
     that carried it (the notes' fused kernel, padded length at most 256); every padded input of
     such a batch is then affected, however small its movement;
  3. the normaliser: among inputs the defect did not touch, texts changed by one candidate
     normalisation step and no other show whether that step is applied; the steps that are
     (NFKC, runs of spaces collapsed) give the texts tokenizer 2.0 read differently;
  4. file the union per batch.
Options (used by the readings script) switch estimators and switch findings off.
"""
import csv
import json
import math
import os
import re
import statistics
import sys
import unicodedata

DIM = 32
FUSED_NOTES = 256          # padded length the notes give for the fused kernel
STEP_KEYS = ("compat", "decomp", "spaces")


def load(root):
    inputs = {}
    with open(os.path.join(root, "reports", "inputs.jsonl"), encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            inputs[(d["report"], int(d["slot"]))] = dict(slot=int(d["slot"]), tokens=int(d["tokens"]), text=d["text"])
    for name, key in (("reference.csv", "ref"), ("delivered.csv", "del")):
        with open(os.path.join(root, "reports", name), newline="", encoding="utf-8") as fh:
            for rec in csv.DictReader(fh):
                inputs[(rec["report"], int(rec["slot"]))][key] = [float(rec["v%02d" % q]) for q in range(DIM)]
    reports = {}
    for (code, _), d in inputs.items():
        reports.setdefault(code, []).append(d)
    for code in reports:
        reports[code].sort(key=lambda d: d["slot"])
    return reports


def features(text):
    nfc = unicodedata.normalize("NFC", text)
    nfkc = unicodedata.normalize("NFKC", text)
    return dict(compat=nfkc != nfc, decomp=nfc != text, spaces="  " in text,
                case=text.casefold() != text, nonascii=any(ord(ch) > 127 for ch in text))


def transform(text, steps):
    t = text
    if "nfkc" in steps:
        t = unicodedata.normalize("NFKC", t)
    elif "nfc" in steps:
        t = unicodedata.normalize("NFC", t)
    if "casefold" in steps:
        t = t.casefold()
    if "spaces" in steps:
        t = re.sub(" {2,}", " ", t)
    return t


DEFAULTS = dict(envelope="mad", zpath=4.0, path="infer", norm="infer", znorm=4.0, nmethod="mean",
                count="mechanism", zcut=3.0, naive=False)


def analyse(reports, opt=None):
    o = dict(DEFAULTS)
    o.update(opt or {})
    rows = []
    for code, items in reports.items():
        padded = max(d["tokens"] for d in items)
        for d in items:
            diff = math.sqrt(sum((a - b) ** 2 for a, b in zip(d["ref"], d["del"])))
            rows.append(dict(code=code, slot=d["slot"], L=d["tokens"], pad=padded - d["tokens"], padded=padded,
                             n=len(items), text=d["text"], diff=diff, r=diff / math.sqrt(d["tokens"]),
                             f=features(d["text"])))
    # 1. the scatter envelope, from the unpadded inputs
    base = [x["r"] for x in rows if x["pad"] == 0]
    if o["envelope"] == "mad":
        m = statistics.median(base)
        s = 1.4826 * statistics.median([abs(b - m) for b in base])
    else:
        m = statistics.fmean(base)
        s = statistics.pstdev(base)
    for x in rows:
        x["z"] = (x["r"] - m) / s
    by = {}
    for x in rows:
        by.setdefault(x["code"], []).append(x)
    if o["naive"]:
        return {code: {x["slot"] for x in xs if x["z"] > o["zcut"]} for code, xs in by.items()}
    # 2. the path the defect acted on
    if o["path"] == "infer":
        eff, noeff = [], []
        for code, xs in by.items():
            strong = [x["z"] for x in xs if x["pad"] / (x["L"] + x["pad"]) >= 0.15]
            if len(strong) >= 2:
                (eff if statistics.fmean(strong) > o["zpath"] else noeff).append(xs[0]["padded"])
        if eff and noeff and max(eff) < min(noeff):
            T = (max(eff) + min(noeff)) / 2.0
        elif eff and not noeff:
            T = float("inf")
        else:
            T = FUSED_NOTES
        fused = lambda p: p <= T                      # noqa: E731
    elif o["path"] == "notes":
        fused = lambda p: p <= FUSED_NOTES            # noqa: E731
    elif o["path"] == "all":
        fused = lambda p: True                        # noqa: E731
    else:
        fused = lambda p: False                       # noqa: E731
    for x in rows:
        x["mask"] = fused(x["padded"]) and x["pad"] > 0
    # 3. the normaliser's steps
    if o["norm"] == "infer":
        steps = set()
        clean = [x for x in rows if not x["mask"]]

        def level(sel):
            zs = [x["z"] for x in clean if sel(x["f"])]
            if len(zs) < 3:
                return 0.0
            return statistics.fmean(zs) if o["nmethod"] == "mean" else statistics.median(zs)

        def only(name):
            return lambda f: f[name] and not any(f[k] for k in STEP_KEYS if k != name)

        if level(only("compat")) > o["znorm"]:
            steps.add("nfkc")
        if level(only("decomp")) > o["znorm"] and "nfkc" not in steps:
            steps.add("nfc")
        if level(only("spaces")) > o["znorm"]:
            steps.add("spaces")
        if level(lambda f: f["case"] and not any(f[k] for k in STEP_KEYS)) > o["znorm"]:
            steps.add("casefold")
    else:
        steps = {"none": set(), "nfkc": {"nfkc"}, "nfc": {"nfc"}, "nfkc-casefold": {"nfkc", "casefold"},
                 "nfkc-spaces": {"nfkc", "spaces"}, "nonascii": {"nonascii"}}[o["norm"]]
    for x in rows:
        x["chg"] = x["f"]["nonascii"] if "nonascii" in steps else transform(x["text"], steps) != x["text"]
    # 4. the union per batch
    out = {}
    for code, xs in by.items():
        chosen = set()
        for x in xs:
            if (x["mask"] or x["chg"]) and (o["count"] == "mechanism" or x["z"] > o["zcut"]):
                chosen.add(x["slot"])
        out[code] = chosen
    return out


def write_filing(filing, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["report", "reissue"])
        for code in sorted(filing):
            slots = sorted(filing[code])
            w.writerow([code, ";".join(str(s) for s in slots) if slots else "none"])


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "/app"
    write_filing(analyse(load(root)), os.path.join(root, "out", "batches.csv"))
