"""Two things are proved: the sealed answer sets are what the verifier's own forward model gives,
and the filing under /app/out gets enough batches right."""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import filing   # noqa: E402
import parity   # noqa: E402

ARTIFACT = "/app/out/batches.csv"
BATCHES = 72
MARK = 65                # batches right, of 72; printed in instruction.md


@pytest.fixture(scope="module")
def answer():
    return filing.load_answer(os.path.join(HERE, "sealed", "answer_sets.csv"))


def test_answer_sets_follow_the_forward_model(answer):
    truth = json.load(open(os.path.join(HERE, "sealed", "batches.json"), encoding="utf-8"))
    texts = parity.load_texts(os.path.join(HERE, "sealed", "texts.jsonl"))
    model = parity.reckon(truth, texts)
    assert len(answer) == BATCHES and set(model) == set(answer)
    mismatched = sorted(code for code in answer if answer[code] != frozenset(model[code]))
    assert not mismatched, mismatched


def test_artifact_is_present():
    assert os.path.isfile(ARTIFACT), "nothing at " + ARTIFACT


def test_enough_batches_right(answer):
    filed = filing.Filing(ARTIFACT)
    right = filed.count_right(answer)
    assert right >= MARK, "%d of %d batches right, %d needed" % (right, BATCHES, MARK)
