#!/usr/bin/env bash
# The reward channel is closed before any uploaded code runs: /logs/verifier becomes root-only,
# every reward-shaped file in it is removed and reward.txt is set to 0. The program then runs as an
# unprivileged account (tests/run_days.py). Afterwards anything in /logs/verifier that root did not
# write is deleted, and reward.txt alone is written: 1 only when the tests passed.
set -u
LOGS=/logs/verifier
PRIVATE=/run/verifier

mkdir -p "$LOGS"
original_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

clear_rewards() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
set_reward() {
    clear_rewards
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
finish() {
    chmod "$original_mode" "$LOGS" 2>/dev/null
    exit 0
}

set_reward 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "verifier: $LOGS could not be made root-only; the program is not run" >&2
    finish
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$PRIVATE" && chown 0:0 "$PRIVATE" && chmod 700 "$PRIVATE"
chmod -R a+rX /app/triage 2>/dev/null

status=1
if ( cd /tests && python3 -m pytest test_days.py -q -p no:cacheprovider --ctrf "$PRIVATE/ctrf.json" ); then
    status=0
fi

if [ "$status" -eq 0 ]; then set_reward 1; else set_reward 0; fi
for f in ctrf.json days.json; do
    [ -f "$PRIVATE/$f" ] && (umask 022; cp "$PRIVATE/$f" "$LOGS/$f")
done
finish
