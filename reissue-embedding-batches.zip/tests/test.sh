#!/usr/bin/env bash
# Reward channel: 0 is written before anything runs, 1 only once pytest has passed.
set -u
LOG=/logs/verifier
mkdir -p "$LOG"
printf '0\n' > "$LOG/reward.txt"
chmod 755 /app/triage 2>/dev/null
chmod -R a+rX /app/triage 2>/dev/null
if ( cd /tests && python3 -m pytest test_days.py -q -p no:cacheprovider --ctrf "$LOG/ctrf.json" ); then
    printf '1\n' > "$LOG/reward.txt"
fi
cp /run/verifier/days.json "$LOG/days.json" 2>/dev/null
exit 0
