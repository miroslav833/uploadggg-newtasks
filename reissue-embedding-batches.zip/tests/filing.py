"""The verifier's reader for the filing. The filing is data: it is parsed, never executed."""
import csv


def slots_of(cell):
    """The slot set a `reissue` cell names, or None when the cell does not parse."""
    cell = (cell or "").strip().lower()
    if cell in ("", "none"):
        return frozenset()
    slots = []
    for piece in cell.split(";"):
        piece = piece.strip()
        if not piece.isdigit():
            return None
        slots.append(int(piece))
    return frozenset(slots)


class Filing:
    """One batches.csv: the first row per batch code counts; a row that does not parse is wrong."""

    def __init__(self, path=None, sets=None):
        self.sets = {}
        self.unparsed = set()
        if sets is not None:
            self.sets = {code: frozenset(s) for code, s in sets.items()}
        if path is not None:
            with open(path, newline="", encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    code = (row.get("report") or "").strip()
                    if not code or code in self.sets or code in self.unparsed:
                        continue
                    slots = slots_of(row.get("reissue"))
                    if slots is None:
                        self.unparsed.add(code)
                    else:
                        self.sets[code] = slots

    def right(self, code, wanted):
        return code in self.sets and self.sets[code] == frozenset(wanted)

    def count_right(self, answer):
        return sum(1 for code, wanted in answer.items() if self.right(code, wanted))


def load_answer(path):
    """The sealed answer sets, in the same format as a filing."""
    return dict(Filing(path).sets)
