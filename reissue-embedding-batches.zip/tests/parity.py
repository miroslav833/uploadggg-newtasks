"""The verifier's own forward model: which inputs build 2.3.1 computes differently from 2.3.0.

From the sealed truth (each batch's padded length and each input's padding, the padded length
the fused kernel handles) and the sealed texts: an input is recomputed when its batch took the
fused path and it was padded there, or when tokenizer 2.0's normalisation (NFKC, runs of spaces
collapsed) changes its text. Independent of the reference's code.
"""
import json
import re
import unicodedata


def normalised(text):
    return re.sub(" {2,}", " ", unicodedata.normalize("NFKC", text))


def load_texts(path):
    texts = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            texts[(d["report"], int(d["slot"]))] = d["text"]
    return texts


def reckon(truth, texts):
    out = {}
    fused_max = int(truth["fused_max"])
    for code, r in truth["reports"].items():
        padded = int(r["padded_length"])
        fused = padded <= fused_max
        slots = set()
        for i in r["inputs"]:
            pad = padded - int(i["tokens"])
            text = texts[(code, int(i["slot"]))]
            if (fused and pad > 0) or normalised(text) != text:
                slots.add(int(i["slot"]))
        out[code] = slots
    return out
