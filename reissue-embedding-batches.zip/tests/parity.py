"""The verifier's own forward model: which inputs the fixed build recomputes differently.

For one day, from the sealed truth (the build's defect form, fused limit, tokenizer steps and cache,
the switch and restart times in UTC, each batch's receive time and pool, each input's slot and token
count) and the sealed texts. Batches are taken in the order received. An input whose prepared text
(the token ids the day's tokenizer reads) an earlier run already filled the cache with is answered
from it and not run, and carries that run's verdict. The rest of a batch runs as a batch in slot
order: padded to its longest run input plus the start and end tokens, on the fused path when that
fits the limit and the batch was received before the switch, or after the restart hour on pool A.
On the fused path, in the batches the build's condition lets it act on, the defect gets wrong the key positions between an input's length and the
length of the sequence whose mask it was given. An input is recomputed when the defect reached it or
when its prepared text differs from its text. Independent of the reference's code.
"""
import json
import re
import unicodedata


def prepared(text, steps):
    for st in steps:
        if st == "format":
            text = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
        elif st in ("nfkc", "nfc"):
            text = unicodedata.normalize(st.upper(), text)
        elif st == "spaces":
            text = re.sub(" {2,}", " ", text)
    return text


def load_texts(path):
    texts = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            texts[(d["report"], int(d["slot"]))] = d["text"]
    return texts


def mask_length(form, lengths):
    if form == "first":
        return lengths[0]
    if form == "last":
        return lengths[-1]
    return max(lengths)                      # "padded": every sequence sees the whole padded length


def defect_acts(cond, n_run, positions):
    """A build's defect may act only on some batches that ran fused: those of more than K run inputs,
    or those whose padded length is not a whole number of key blocks."""
    kind = cond[0]
    if kind == "size":
        return n_run > int(cond[1])
    if kind == "block":
        return positions % int(cond[1]) != 0
    return True


def reckon(truth, texts):
    prof = truth["profile"]
    steps = truth["steps"]
    form, limit = prof["defect"], int(prof["fused_max"])
    cond = prof.get("cond", ["always"])
    switch, back = truth["switch"], truth["back"]
    cache = {}
    out = {}
    for code, b in sorted(truth["batches"].items(), key=lambda kv: (kv[1]["received"], kv[0])):
        items = sorted(b["inputs"], key=lambda i: int(i["slot"]))
        keyed = [(int(i["slot"]), int(i["tokens"]), texts[(code, int(i["slot"]))]) for i in items]
        keyed = [(s, L, t, prepared(t, steps)) for s, L, t in keyed]
        hits = {s for s, L, t, k in keyed if prof["cache"] == "tokens" and k in cache}
        ran = [(s, L, t, k) for s, L, t, k in keyed if s not in hits]
        positions = max(L for s, L, t, k in ran) + 2
        late = b["received"] >= switch
        fused = positions <= limit and (not late or (b["pool"] == "A" and b["received"] >= back))
        acts = fused and form != "none" and defect_acts(cond, len(ran), positions)
        ref = mask_length(form, [L for s, L, t, k in ran]) if acts else None
        slots = set()
        for s, L, t, k in keyed:
            if s in hits:
                if cache[k] or k != t:
                    slots.add(s)
                continue
            reached = ref is not None and L != ref
            if reached or k != t:
                slots.add(s)
        for s, L, t, k in ran:
            cache.setdefault(k, ref is not None and L != ref)
        out[code] = slots
    return out
