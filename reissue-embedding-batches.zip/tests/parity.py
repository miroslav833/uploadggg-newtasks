"""The verifier's own forward model: which inputs build 2.3.1 computes differently from 2.3.0.

From the sealed truth (each batch's padded length, each input's slot and token count, the padded
length the fused kernel handles, the time the kernel was switched off on pool B, each batch's
receive time and pool, and the start and end token every encoded input carries) and the sealed
texts. A batch's padded length in positions is its longest text's tokens plus those two. An input is recomputed when the fused kernel's
key-mask defect reached it, that is its batch took the fused path (padded short enough, and
received before the switch, or handled by pool A once it was back from its restart), where every sequence was masked with slot 1's
key mask, and its own length differs from slot 1's; or when
tokenizer 2.0's preparation (format characters removed, NFKC, runs of spaces collapsed)
changes its text. An input the build's output cache answered (its tokenizer 2.0 token ids already
run in an earlier batch) is not run: its delivered output is the earlier run's, and the rest of
its batch runs without it. Independent of the reference's code.
"""
import json
import re
import unicodedata


def prepared(text):
    kept = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
    return re.sub(" {2,}", " ", unicodedata.normalize("NFKC", kept))


def load_texts(path):
    texts = {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            d = json.loads(line)
            texts[(d["report"], int(d["slot"]))] = d["text"]
    return texts


def took_fused_path(positions, received, pool, fused_max, switch, a_back):
    return positions <= fused_max and (received < switch or (pool == "A" and received >= a_back))


def defect_reaches(fused, tokens, slot_one_tokens):
    return fused and tokens != slot_one_tokens


def reckon(truth, texts):
    """Batches in the order the service received them. An input whose prepared text (tokenizer 2.0's
    token ids) an earlier batch already ran is answered from the cache: it is not run, and its
    delivered output is that earlier run's. The rest of a batch runs as a batch in slot order."""
    out = {}
    fused_max, switch, specials = int(truth["fused_max"]), truth["pool_b_switch"], int(truth["specials"])
    a_back = truth["pool_a_back"]
    cache = {}                       # prepared text -> was the run that filled it reached by the defect
    for code, r in sorted(truth["reports"].items(), key=lambda kv: (kv[1]["received"], kv[0])):
        items = sorted(r["inputs"], key=lambda i: int(i["slot"]))
        keyed = [(i, prepared(texts[(code, int(i["slot"]))])) for i in items]
        hits = {int(i["slot"]) for i, k in keyed if k in cache}
        ran = [i for i in items if int(i["slot"]) not in hits]
        positions = max(int(i["tokens"]) for i in ran) + specials
        fused = took_fused_path(positions, r["received"], r["pool"], fused_max, switch, a_back)
        slot_one = int(ran[0]["tokens"])
        slots = set()
        for i, key in keyed:
            text = texts[(code, int(i["slot"]))]
            if int(i["slot"]) in hits:
                if cache[key] or key != text:
                    slots.add(int(i["slot"]))
                continue
            reached = defect_reaches(fused, int(i["tokens"]), slot_one)
            if reached or key != text:
                slots.add(int(i["slot"]))
        for i, key in keyed:
            if int(i["slot"]) not in hits:
                cache.setdefault(key, defect_reaches(fused, int(i["tokens"]), slot_one))
        out[code] = slots
    return out
