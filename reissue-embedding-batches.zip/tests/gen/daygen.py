#!/usr/bin/env python3
"""Comparison days of an embedding service: one batched build against the fp32 reference path.

One day is 40 customer batches. What differs from day to day is the build in service and its
habits, and the day's operations:
  * the build's key-mask defect on its fused attention path: every sequence masked with the first
    run sequence's mask ("first"), with the last run sequence's ("last"), padding never masked
    ("padded"), or no defect ("none");
  * the padded length, in positions, up to which the fused path runs (256 or 384);
  * the tokenizer bundled with the build and the steps it applies before pre-tokenisation;
  * whether the build answers repeated inputs from an output cache keyed by the token ids it read;
  * the day's operations, logged in Berlin local time: when pool B's fused kernel was switched off,
    and an hour pool A spent restarting.
The verifier builds the graded days with this module inside its own image and deletes it; the
sample days the solver sees are built by the same code from other seeds.

stdlib only. A day's outputs: inputs.jsonl, reference.csv (the inputs the reference path ran),
delivered.csv, BUILD.md and OPS.md; and, for the verifier, truth.json and texts.jsonl.
"""
import csv
import datetime
import json
import math
import os
import random
import re
import unicodedata

DIM = 32
SCATTER = 0.004       # L2 of the bf16 scatter per sqrt(token)
KAPPA = 0.6
ETA = 0.5
SPECIALS = 2          # start and end token around every encoded input
REF_FULL_UNTIL = 7 * 3600
REF_SHARE = 0.40

TOKENIZERS = {        # version -> the steps it applies, in this order
    "2.0": ("format", "nfkc", "spaces"),
    "2.1": ("nfc", "spaces"),
    "2.2": ("nfkc",),
    "2.3": ("format", "spaces"),
}

WORDS = ("the quarterly report covers shipping volumes across regional depots and notes that demand "
         "for cold storage rose during the summer while rail capacity stayed flat the team proposes "
         "a second loading bay near the eastern gate and a revised rota for weekend crews customers "
         "asked for clearer invoices with line items grouped by order date and delivery window the "
         "survey of garden ponds found more newts in shaded water than in open pools and the "
         "volunteers logged each visit with a sketch of the bank the library extended opening hours "
         "on market days after readers complained about queues at the returns desk the bakery "
         "switched to a slower proof overnight which improved the crust but lengthened the morning "
         "shift a short guide to repairing bicycle brakes begins with checking cable tension and "
         "pad wear before adjusting the callipers the orchestra rehearsed the second movement twice "
         "because the brass entered early at the key change local councils compared road gritting "
         "costs over three winters and found salt prices drove most of the variation the museum "
         "catalogue lists each coin with its weight diameter and the mint mark where legible the "
         "recipe calls for soaking the beans overnight then simmering them with bay leaves until "
         "tender a reader wrote in to correct the date of the bridge opening cited in last month's "
         "column the clinic reminds patients that appointments can be moved online up to a day "
         "ahead hikers reported that the upper path was muddy after the rain and the lower path "
         "clear the choir needs two more tenors before the spring concert and rehearses on "
         "thursdays the farm shop stocks apples from the old orchard from late september until the "
         "store runs out").split()
ACRONYMS = ["NASA", "GPU", "API", "HTTP", "UNESCO", "PDF", "CPU", "ISO"]
COMPOSED = ["café", "naïve", "über", "niño", "résumé", "señor",
            "façade", "jalapeño", "Zürich", "crème"]
DECOMPOSED = ["café", "naïve", "über", "niño", "résumé",
              "señor", "façade", "Zürich", "crème", "angélique"]
COMPAT = ["ﬁnal", "ﬂow", "ofﬁce", "m²", "½", "™", "…",
          "２０２４", "µm", "①", "㎞", "Ⅳ", "x³", "ﬀer"]
QUOTED = ["“quiet”", "‘later’", "don’t", "“north”", "it’s"]
DASHED = ["mid–week", "stop—then", "1990–2001", "—", "–"]
SYMBOLS = ["€40", "12°", "straße", "©", "®", "£", "±"]
FORMAT = ["­", "​", "⁠"]
DECOYS = ("composed", "upper", "quotes", "dash", "symbols")
FEATURES = ("format", "compat", "decomp", "spaces")


def prepare(text, steps):
    t = text
    for st in steps:
        if st == "format":
            t = "".join(ch for ch in t if unicodedata.category(ch) != "Cf")
        elif st == "nfkc":
            t = unicodedata.normalize("NFKC", t)
        elif st == "nfc":
            t = unicodedata.normalize("NFC", t)
        elif st == "spaces":
            t = re.sub(" {2,}", " ", t)
    return t


def everything(text):
    return prepare(text, ("format", "nfkc", "spaces"))


def make_text(rng, n_tokens, change=None, k=0, decoy=None):
    n_words = max(6, int(round((n_tokens - 2) / 1.28)))
    words = [rng.choice(WORDS) for _ in range(n_words)]
    sent_len = rng.randint(7, 14)
    for i in range(0, n_words, sent_len):
        words[i] = words[i][0].upper() + words[i][1:]
    slots = list(range(1, n_words))
    rng.shuffle(slots)
    if decoy:
        pool = {"composed": COMPOSED, "upper": ACRONYMS, "quotes": QUOTED, "dash": DASHED, "symbols": SYMBOLS}[decoy]
        for _ in range(rng.randint(1, 3)):
            words[slots.pop()] = rng.choice(pool)
    if change == "compat":
        for _ in range(k):
            words[slots.pop()] = rng.choice(COMPAT)
    elif change == "decomp":
        for _ in range(k):
            words[slots.pop()] = rng.choice(DECOMPOSED)
    elif change == "format":
        for _ in range(k):
            s = slots.pop()
            w = words[s]
            if len(w) >= 4 and rng.random() < 0.6:
                cut = rng.randint(2, len(w) - 2)
                words[s] = w[:cut] + rng.choice(FORMAT) + w[cut:]
            else:
                words[s] = w + rng.choice(FORMAT[1:])
    text = " ".join(words)
    if change == "spaces":
        parts = text.split(" ")
        gaps = list(range(1, len(parts)))
        rng.shuffle(gaps)
        chosen = set(gaps[:k])
        out = parts[0]
        for g, p in enumerate(parts[1:], start=1):
            out += ("  " if g in chosen else " ") + p
        text = out
    text = text + "."
    if change is None:
        assert everything(text) == text
    return text


def variant(rng, text, steps):
    """The text with one change the day's tokenizer removes, so that its token ids are unchanged."""
    words = text.split(" ")
    i = rng.randint(1, len(words) - 1)
    if "spaces" in steps:
        out = " ".join(words[:i]) + "  " + " ".join(words[i:])
    elif "format" in steps:
        out = " ".join(words[:i]) + " " + FORMAT[1] + " ".join(words[i:])
    elif "nfkc" in steps:
        out = " ".join(words[:i]) + " Ⅳ " + " ".join(words[i:])
        text = " ".join(words[:i]) + " IV " + " ".join(words[i:])
        return text, out
    else:                                    # nfc only: a decomposed accent
        out = " ".join(words[:i]) + " café " + " ".join(words[i:])
        text = " ".join(words[:i]) + " café " + " ".join(words[i:])
        return text, out
    return text, out


def unit(rng):
    v = [rng.gauss(0, 1) for _ in range(DIM)]
    n = math.sqrt(sum(x * x for x in v))
    return [x / n for x in v]


def norm(v):
    n = math.sqrt(sum(x * x for x in v))
    return [x / n for x in v]


def clock(sec):
    return "%02d:%02d:%02d" % (sec // 3600, sec // 60 % 60, sec % 60)


def last_sunday(year, month):
    d = datetime.date(year, month + 1, 1) - datetime.timedelta(days=1) if month < 12 else datetime.date(year, 12, 31)
    while d.weekday() != 6:
        d -= datetime.timedelta(days=1)
    return d


def berlin_offset_hours(date, local_hour):
    """UTC offset of Berlin wall-clock time at local_hour on date (EU rule: summer time from 02:00 on
    the last Sunday of March to 03:00 on the last Sunday of October)."""
    start, end = last_sunday(date.year, 3), last_sunday(date.year, 10)
    if start < date < end:
        return 2
    if date == start:
        return 2 if local_hour >= 3 else 1
    if date == end:
        return 2 if local_hour < 3 else 1
    return 1


def defect_gap(form, L, run_lengths, fused):
    if not fused or form == "none":
        return 0, 0
    if form == "padded":
        P = max(run_lengths)
        return (P - L, 0) if L < P else (0, 0)
    ref = run_lengths[0] if form == "first" else run_lengths[-1]
    if L < ref:
        return ref - L, 0
    if L > ref:
        return 0, L - ref
    return 0, 0


def build_day(seed, profile):
    """profile: defect, fused_max, tokenizer, cache, date (ISO), switch_local (hour), restart (bool)."""
    rng = random.Random(seed)
    steps = TOKENIZERS[profile["tokenizer"]]
    date = datetime.date.fromisoformat(profile["date"])
    sw_local = profile["switch_local"]
    switch = (sw_local - berlin_offset_hours(date, sw_local)) * 3600
    back = switch + 3600 if profile["restart"] else switch
    fused_max = profile["fused_max"]
    plans = ([("norm-spaces", 3), ("norm-format", 3), ("norm-compat", 3), ("norm-decomp", 2), ("first-short", 2),
              ("last-short", 2), ("mid", 2), ("cache-ref", 3), ("cache-inherit", 3), ("pool", 5),
              ("window-before", 3), ("window-after", 3), ("edge", 6)])
    kinds = [k for k, c in plans for _ in range(c)]
    rng.shuffle(kinds)
    kinds = [k for k in kinds if not k.startswith("cache")] + [k for k in kinds if k.startswith("cache")]
    sources = []
    batches = []
    edge_i = 0
    for kind in kinds:
        n = rng.randint(6, 14)
        change = {}
        if kind.startswith("norm"):
            P = rng.randint(400, 470)
            ls = [P] + [rng.randint(14, P - 1) for _ in range(n - 1)]
            rng.shuffle(ls)
            feat = kind.split("-")[1]
            idx = [i for i in range(n) if ls[i] < P]
            rng.shuffle(idx)
            for j, i in enumerate(idx[:3]):
                ls[i] = rng.randint(14, 56) if j < 2 else rng.randint(200, 380)
                change[i] = (feat, rng.randint(2, 4) if j < 2 else 1)
            received = rng.randint(5 * 3600, REF_FULL_UNTIL - 300)
        elif kind == "single":
            ls = [rng.randint(30, 200)]
            received = rng.randint(5 * 3600, REF_FULL_UNTIL - 300)
        elif kind in ("first-short", "last-short", "mid", "edge"):
            if kind == "edge":
                # longest text one or two positions inside the fused limit, or one or two outside it
                P = fused_max - SPECIALS + [-1, 0, 0, 1, 2, 1][edge_i % 6]
                edge_i += 1
            else:
                P = rng.randint(270, 370) if kind == "mid" else rng.randint(120, 240)
            short = rng.randint(30, int(0.45 * P))
            rest = []
            for _ in range(n - 2):
                r = rng.random()
                rest.append(rng.randint(12, max(13, short - 12)) if r < 0.3 else
                            short if r < 0.45 else rng.randint(min(P - 1, short + 12), P - 1))
            rng.shuffle(rest)
            ls = ([short] + rest + [P]) if kind == "first-short" else ([P] + rest + [short])
            if kind in ("mid", "edge"):
                ls = [short] + rest + [P] if rng.random() < 0.5 else [P] + rest + [short]
            received = rng.randint(5 * 3600, REF_FULL_UNTIL - 300)
        elif kind == "pool":
            n = rng.randint(30, 32)
            L1 = rng.randint(85, 110)
            ls = [L1]
            for _ in range(n - 2):
                r = rng.random()
                ls.append(L1 - 4 if r < 0.85 else (L1 + 1 if r < 0.93 else L1))
            ls.append(L1)
            received = rng.randint(back + 300, 18 * 3600)
        elif kind.startswith("window"):
            # a few chunks one token from the mask's sequence: too little movement to test either way,
            # so only the log, read in the right clock, decides them
            n = rng.randint(8, 10)
            L1 = rng.randint(85, 110)
            ls = [L1] + [L1 - 1 if rng.random() < 0.8 else L1 + 1 for _ in range(n - 2)] + [L1]
            if kind == "window-before":
                received = rng.randint(switch - 3300, switch - 300)
            else:                               # the restart hour: pool B alone, already unfused
                received = rng.randint(switch + 300, back - 300)
        else:                                   # cache batches, between 08:00 and the switch
            n = rng.randint(12, 16)
            L1 = rng.randint(85, 110)
            if kind == "cache-ref":
                # the cache hit sits where the day's defect takes its mask from; the input the build ran
                # in its place is one token longer
                rest = [rng.choice([L1, L1, L1 + 1, L1 - 2]) for _ in range(n - 2)]
                if profile["defect"] == "last":
                    ls = rest + [L1 + 1, L1]
                    hit_at = n - 1
                elif profile["defect"] == "padded":
                    ls = [L1 + 1] + [min(v, L1 + 1) for v in rest] + [L1 + 2]
                    rng.shuffle(ls)
                    hit_at = ls.index(L1 + 2)
                else:
                    ls = [L1, L1 + 1] + rest
                    hit_at = 0
            else:
                ls = [L1, L1 - 2] + [rng.choice([L1, L1 - 2, L1 - 2, L1 + 1]) for _ in range(n - 2)]
            received = rng.randint(REF_FULL_UNTIL + 300, min(switch, 18 * 3600) - 3900)
        pool = rng.choice("AB")
        if kind == "window-after":
            pool = "B"
        inputs = []
        for i, L in enumerate(ls):
            if i in change:
                f, k = change[i]
                text = make_text(rng, L, f, k, rng.choice(DECOYS) if rng.random() < 0.3 else None)
            else:
                text = make_text(rng, L, None, 0, rng.choice(DECOYS) if rng.random() < 0.45 else None)
            inputs.append(dict(tokens=L, text=text))
        if kind.startswith("norm"):
            Ls = rng.randint(84, 112)
            src = dict(tokens=Ls, text=make_text(rng, Ls))
            inputs.insert(rng.randint(1, len(inputs)), src)
            sources.append(src)
        if kind == "cache-ref":
            src = sources.pop()
            Lh = ls[hit_at]
            if profile["cache"] == "tokens":
                clean, dirty = variant(rng, src["text"], steps)
                src["text"] = clean
                inputs[hit_at] = dict(tokens=Lh, text=dirty, hit=src)
                src["tokens"] = Lh - 1
            else:
                src["tokens"] = Lh
                inputs[hit_at] = dict(tokens=Lh, text=src["text"], hit=src)
        if kind == "cache-inherit":
            later = [i for i in range(1, len(inputs)) if inputs[i]["tokens"] != L1 and
                     inputs[i]["tokens"] < max(x["tokens"] for x in inputs)]
            i = rng.choice(later)
            src = sources.pop()
            src["tokens"] = inputs[i]["tokens"]
            inputs[i] = dict(tokens=inputs[i]["tokens"], text=src["text"], hit=src)
        for s_, x in enumerate(inputs, start=1):
            x["slot"] = s_
        batches.append(dict(kind=kind, received=received, pool=pool, inputs=inputs))
    # ---- run the day in the order received ----------------------------------------------
    cache = {}
    for b in sorted(batches, key=lambda b: b["received"]):
        late = b["received"] >= switch
        v_pad = unit(rng)
        for x in b["inputs"]:
            key = prepare(x["text"], steps)
            x["key"] = key
            x["is_hit"] = profile["cache"] == "tokens" and key in cache
        ran = [x for x in b["inputs"] if not x["is_hit"]]
        positions = max(x["tokens"] for x in ran) + SPECIALS
        on_fused = positions <= fused_max and (not late or (b["pool"] == "A" and b["received"] >= back))
        b["fused"] = on_fused
        lengths = [x["tokens"] for x in ran]
        for x in ran:
            L = x["tokens"]
            pad_gap, lost = defect_gap(profile["defect"], L, lengths, on_fused)
            k = sum(1 for _ in range(1)) if prepare(x["text"], steps) != x["text"] else 0
            if k:
                k = max(1, sum(1 for a, c in zip(x["text"], prepare(x["text"], steps)) if a != c) +
                        abs(len(x["text"]) - len(prepare(x["text"], steps))))
            w = KAPPA * pad_gap / (L + pad_gap) if pad_gap else 0.0
            t = KAPPA * lost / L if lost else 0.0
            c = ETA * math.sqrt(min(k, 6) / L) if k else 0.0
            e = unit(rng)
            ut, uc = unit(rng), unit(rng)
            sig = SCATTER * math.sqrt(L) / math.sqrt(DIM)
            d = [(1 - w) * e[q] + w * v_pad[q] + t * ut[q] + c * uc[q] + rng.gauss(0, sig) for q in range(DIM)]
            x["ref"], x["del"] = e, norm(d)
            x["reached"] = bool(pad_gap or lost)
        for x in b["inputs"]:
            if x["is_hit"]:
                src = cache[x["key"]]
                x["del"] = list(src["del"])
                x["reached"] = src["reached"]
                if x["text"] == src["text"]:
                    x["ref"] = list(src["ref"])
                else:
                    uc = unit(rng)
                    c = ETA * math.sqrt(1 / x["tokens"])
                    x["ref"] = norm([src["ref"][q] + c * uc[q] for q in range(DIM)])
        for x in ran:
            cache.setdefault(x["key"], x)
    for b in batches:
        for x in b["inputs"]:
            x["refd"] = b["received"] < REF_FULL_UNTIL or rng.random() < REF_SHARE
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    codes = set()
    while len(codes) < len(batches):
        codes.add("B" + "".join(rng.choice(alphabet) for _ in range(3)))
    codes = sorted(codes)
    rng.shuffle(codes)
    for b, c in zip(batches, codes):
        b["code"] = c
    batches.sort(key=lambda b: b["code"])
    return dict(profile=profile, steps=steps, switch=switch, back=back, batches=batches)


def answer(day):
    """The reference set per batch, from the world the generator built."""
    steps = day["steps"]
    out = {}
    for b in day["batches"]:
        out[b["code"]] = sorted(x["slot"] for x in b["inputs"]
                                if x["reached"] or prepare(x["text"], steps) != x["text"])
    return out


BUILD_NAMES = {"first": "2.3.0", "last": "2.4.0", "padded": "2.2.7", "none": "2.2.9"}


def write_day(day, outdir, sealed_dir=None):
    os.makedirs(outdir, exist_ok=True)
    p = day["profile"]
    with open(os.path.join(outdir, "inputs.jsonl"), "w", encoding="utf-8") as fh:
        for b in day["batches"]:
            for x in b["inputs"]:
                fh.write(json.dumps(dict(report=b["code"], received=clock(b["received"]), slot=x["slot"],
                                         tokens=x["tokens"], text=x["text"]), ensure_ascii=False) + "\n")
    st = p.get("style", {})
    tables = st.get("tables", "csv")
    for stem, key, only in (("reference", "ref", True), ("delivered", "del", False)):
        rows = [(b["code"], x["slot"], x[key]) for b in day["batches"] for x in b["inputs"] if x["refd"] or not only]
        if tables == "jsonl":
            with open(os.path.join(outdir, stem + ".jsonl"), "w", encoding="utf-8") as fh:
                for code, slot, vec in rows:
                    fh.write(json.dumps(dict(batch=code, slot=slot, embedding=[round(v, 4) for v in vec])) + "\n")
        elif tables == "csv_renamed":
            # the older export: item first, batch second, dims named dim_0..dim_31
            with open(os.path.join(outdir, stem + ".csv"), "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(["item", "batch_id"] + ["dim_%d" % q for q in range(DIM)])
                for code, slot, vec in rows:
                    w.writerow([slot, code] + ["%.4f" % v for v in vec])
        else:
            with open(os.path.join(outdir, stem + ".csv"), "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(["report", "slot"] + ["v%02d" % q for q in range(DIM)])
                for code, slot, vec in rows:
                    w.writerow([code, slot] + ["%.4f" % v for v in vec])
    build = BUILD_NAMES[p["defect"]]
    with open(os.path.join(outdir, "BUILD.md"), "w", encoding="utf-8") as fh:
        if st.get("build", "positions") == "tokens":
            fh.write("# Build sheet (release %s)\n\n" % build)
            fh.write("tokenizer: %s; the reference path reads tokenizer 1.4\n" % p["tokenizer"])
            fh.write("fused attention: used when the longest input of a batch has at most %d text tokens "
                     "(the start and end tokens come on top)\n" % (p["fused_max"] - SPECIALS))
            fh.write("result cache: %s\n" % ("on" if p["cache"] == "tokens" else "off"))
            fh.write("recomputation build: 2.5.1\n")
        else:
            fh.write("# Build sheet\n\n")
            fh.write("- build in service: %s\n" % build)
            fh.write("- tokenizer bundled: %s (the reference path reads tokenizer 1.4)\n" % p["tokenizer"])
            fh.write("- fused attention path: batches padded to at most %d positions\n" % p["fused_max"])
            fh.write("- output cache: %s\n" % ("enabled" if p["cache"] == "tokens" else "disabled"))
            fh.write("- fixed build that will recompute: %s\n" % "2.5.1")
    date = datetime.date.fromisoformat(p["date"])
    H = p["switch_local"]
    utc_h = H - berlin_offset_hours(date, H)
    ops = st.get("ops", "berlin24")
    with open(os.path.join(outdir, "OPS.md"), "w", encoding="utf-8") as fh:
        if ops == "utc24":
            fh.write("# Ops log %s (all times UTC)\n\n" % date.isoformat())
            fh.write("- %02d:40Z disk alert on host b-07 cleared\n" % (utc_h - 3))
            fh.write("- %02d:00Z pool B: fused attention disabled by flag attn.fused=false; every pool B batch "
                     "runs unfused from here\n" % utc_h)
            if p["restart"]:
                fh.write("- %02d:00Z-%02d:00Z pool A drained for its weekly restart; pool B took all traffic\n"
                         % (utc_h, utc_h + 1))
            fh.write("- %02d:20Z pool B: flag audit, no change\n" % (utc_h + 3))
            fh.write("- balancer log lost in a disk rotation\n")
        elif ops == "berlin12":
            def h12(h):
                return "%d:00 %s" % ((h - 1) % 12 + 1, "a.m." if h < 12 else "p.m.")
            fh.write("# Ops log, %s, Europe/Berlin wall clock\n\n" % date.strftime("%A, %B %d, %Y").replace(" 0", " "))
            fh.write("- %s on-call handover\n" % h12(H - 3))
            fh.write("- %s fused kernel turned off on pool B (config flag); pool B unfused for every batch from "
                     "then on\n" % h12(H))
            if p["restart"]:
                fh.write("- %s to %s pool A out for its weekly restart; pool B carried everything\n"
                         % (h12(H), h12(H + 1)))
            fh.write("- balancer log lost in a disk rotation\n")
        elif ops == "berlin_dot":
            fh.write("# Betriebslog %s (Ortszeit Berlin)\n\n" % date.strftime("%d.%m.%Y"))
            fh.write("- %02d.15 Uhr Zertifikat erneuert, host b-03\n" % (H - 2))
            fh.write("- %02d.00 Uhr pool B: fused attention per Flag abgeschaltet; ab jetzt laeuft jeder Batch "
                     "auf pool B ungefused\n" % H)
            if p["restart"]:
                fh.write("- %02d.00-%02d.00 Uhr pool A im woechentlichen Neustart; pool B uebernimmt allen "
                         "Verkehr\n" % (H, H + 1))
            fh.write("- Loadbalancer-Log durch Plattenrotation verloren\n")
        else:
            fh.write("# Operations log, %s (Berlin local time)\n\n" % date.strftime("%A %d %B %Y"))
            fh.write("- %02d:00 fused attention switched off on pool B by configuration flag; pool B runs every "
                     "batch on the unfused path from then on\n" % H)
            if p["restart"]:
                fh.write("- %02d:00 to %02d:00 pool A out of rotation for its weekly restart; pool B served all "
                         "traffic\n" % (H, H + 1))
            fh.write("- load balancer log for the day lost in a disk rotation\n")
    if sealed_dir:
        os.makedirs(sealed_dir, exist_ok=True)
        truth = dict(profile=p, steps=list(day["steps"]), switch=clock(day["switch"]), back=clock(day["back"]),
                     batches={b["code"]: dict(received=clock(b["received"]), pool=b["pool"],
                                              inputs=[dict(slot=x["slot"], tokens=x["tokens"]) for x in b["inputs"]])
                              for b in day["batches"]})
        json.dump(truth, open(os.path.join(sealed_dir, "truth.json"), "w"), indent=0)
        with open(os.path.join(sealed_dir, "texts.jsonl"), "w", encoding="utf-8") as fh:
            for b in day["batches"]:
                for x in b["inputs"]:
                    fh.write(json.dumps(dict(report=b["code"], slot=x["slot"], text=x["text"]),
                                        ensure_ascii=False) + "\n")
        with open(os.path.join(sealed_dir, "answer.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["report", "reissue"])
            for code, slots in sorted(answer(day).items()):
                w.writerow([code, ";".join(map(str, slots)) if slots else "none"])


# the graded population: every class of build, tokenizer, cache, limit and calendar appears in at
# least three of the twelve days; the sample days the solver sees cover fewer of them
def _graded():
    summer = ["2026-03-29", "2026-07-14", "2026-06-02", "2026-10-24", "2026-04-15", "2026-08-19", "2026-05-05"]
    winter = ["2026-10-25", "2026-01-20", "2026-11-30", "2026-03-28", "2026-12-08", "2026-02-03", "2026-11-11"]
    utc = ["2026-09-22", "2026-03-29", "2026-10-25", "2026-07-01", "2026-01-13", "2026-05-26"]
    berlin_ops = ["berlin12", "berlin_dot"]       # the samples' 24-hour English log is not among them
    days = []
    for i, d in enumerate(summer + winter):
        days.append(dict(date=d, ops=berlin_ops[i % 2]))
    for d in utc:
        days.append(dict(date=d, ops="utc24"))
    random.Random(7).shuffle(days)
    tables = ["jsonl"] * 7 + ["csv_renamed"] * 7 + ["csv"] * 6
    builds = ["tokens"] * 7 + ["positions"] * 13
    random.Random(11).shuffle(tables)
    random.Random(13).shuffle(builds)
    forms = ["first", "last", "padded"]
    toks = ["2.0", "2.1", "2.2", "2.3"]
    out = []
    for i, d in enumerate(days):
        out.append(dict(defect=forms[i % 3], fused_max=(256, 384)[(i // 3) % 2], tokenizer=toks[i % 4],
                        cache="none" if i % 3 == 2 else "tokens", date=d["date"], switch_local=11 + i % 4,
                        restart=True, style=dict(ops=d["ops"], build=builds[i], tables=tables[i])))
    return out


GRADED = _graded()
SAMPLES = [
    dict(defect="first", fused_max=256, tokenizer="2.0", cache="tokens", date="2026-09-08", switch_local=12, restart=True),
    dict(defect="padded", fused_max=256, tokenizer="2.0", cache="none", date="2026-02-17", switch_local=11, restart=True),
]


def evidence_ok(day):
    """Each late batch carries at least eight referenced plain inputs shorter than its slot 1, so a
    careful reader can tell whether the defect reached it."""
    for b in day["batches"]:
        if b["kind"] == "pool":
            L1 = b["inputs"][0]["tokens"]
            k = sum(1 for x in b["inputs"] if x["refd"] and x["tokens"] < L1 and everything(x["text"]) == x["text"])
            if k < 8:
                return False
    return True


def settled_day(seed, profile):
    while True:
        day = build_day(seed, profile)
        if evidence_ok(day):
            return day
        seed += 1000003


def build_graded(outroot, sealedroot, seed0=900001):
    for i, p in enumerate(GRADED):
        name = "day-%02d" % (i + 1)
        write_day(settled_day(seed0 + 17 * i, p), os.path.join(outroot, name), os.path.join(sealedroot, name))


def build_samples(outroot, sealedroot=None, seed0=500001):
    for i, p in enumerate(SAMPLES):
        name = "day-%02d" % (i + 1)
        write_day(settled_day(seed0 + 17 * i, p), os.path.join(outroot, name),
                  os.path.join(sealedroot, name) if sealedroot else None)


if __name__ == "__main__":
    import sys
    what, out, sealed = sys.argv[1], sys.argv[2], sys.argv[3]
    (build_graded if what == "graded" else build_samples)(out, sealed)
