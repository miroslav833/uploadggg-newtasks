"""The sealed answers follow the verifier's own forward model, and the uploaded program gets enough
graded days right."""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import parity     # noqa: E402
import run_days   # noqa: E402

DAYS = 20
BATCHES = 40
DAY_MAX_WRONG = 2      # a day counts when at most 2 of its 40 batches are wrong; printed in instruction.md
MARK = 18              # days that must count, of 20; printed in instruction.md


def sealed(day):
    base = os.path.join(run_days.HELD, "sealed", day)
    truth = json.load(open(os.path.join(base, "truth.json"), encoding="utf-8"))
    return truth, parity.load_texts(os.path.join(base, "texts.jsonl")), run_days.read_filing(os.path.join(base, "answer.csv"))


@pytest.fixture(scope="module")
def results():
    uid = run_days.pick_uid()
    out = {}
    for day in run_days.days():
        truth, texts, answer = sealed(day)
        filed = run_days.run_day(day, uid)
        wrong = BATCHES if filed is None else sum(1 for c in answer if filed.get(c) != answer[c])
        out[day] = wrong
    with open(os.path.join(run_days.PRIVATE, "days.json"), "w") as fh:
        json.dump(out, fh, indent=1)
    print(json.dumps(out))
    return out


def test_sealed_answers_follow_the_forward_model():
    assert len(run_days.days()) == DAYS
    for day in run_days.days():
        truth, texts, answer = sealed(day)
        model = parity.reckon(truth, texts)
        assert len(answer) == BATCHES and set(model) == set(answer), day
        assert all(frozenset(model[c]) == answer[c] for c in answer), day


def test_enough_days_right(results):
    counted = [d for d, wrong in results.items() if wrong <= DAY_MAX_WRONG]
    assert len(counted) >= MARK, "%d of %d days counted (%s); %d needed" % (len(counted), DAYS, results, MARK)
