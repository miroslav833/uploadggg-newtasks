"""Runs /app/triage/triage.py on each graded day and scores what it wrote.

The program runs once per day on its own copy of the day's folder, as a numeric account invented
for the run, with 120 seconds of wall time, and writes one CSV. Every process of that account is
stopped before the CSV is read. The CSV is read as text; nothing in it is run.
"""
import csv
import os
import resource
import shutil
import signal
import subprocess
import time

HELD = "/tests/held"
PRIVATE = "/run/verifier"
SCRATCH = "/var/tmp/days"
PROGRAM = "/app/triage/triage.py"
SECONDS = 120
MAX_BYTES = 1 << 20


def pick_uid():
    """The first numeric account from 41000 up that owns no process: no user of the image."""
    used = {os.stat("/proc/" + d).st_uid for d in os.listdir("/proc") if d.isdigit() and os.path.exists("/proc/" + d)}
    uid = 41000
    while uid in used:
        uid += 1
    return uid


def stop_account(uid):
    for _ in range(100):
        pids = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    if os.stat("/proc/" + d).st_uid == uid:
                        pids.append(int(d))
                except FileNotFoundError:
                    pass
        if not pids:
            return
        for p in pids:
            try:
                os.kill(p, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def run_day(day, uid):
    work = os.path.join(SCRATCH, day)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, mode=0o755)
    src, out, tmp = (os.path.join(work, x) for x in ("day", "out", "tmp"))
    shutil.copytree(os.path.join(HELD, "days", day), src, symlinks=False)
    os.makedirs(out)
    os.makedirs(tmp)
    for base, dirs, files in os.walk(work):
        for n in dirs + files:
            os.chown(os.path.join(base, n), uid, uid)
    os.chown(work, uid, uid)

    def demote():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    target = os.path.join(out, "batches.csv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": tmp, "TMPDIR": tmp, "LANG": "C.UTF-8"}
    with open(os.path.join(PRIVATE, day + ".log"), "wb") as log:
        proc = subprocess.Popen(["python3", PROGRAM, src, target], stdin=subprocess.DEVNULL, stdout=log,
                                stderr=log, cwd=tmp, env=env, preexec_fn=demote)
        try:
            proc.wait(timeout=SECONDS)
        except subprocess.TimeoutExpired:
            pass
    stop_account(uid)
    filed = None
    if os.path.isfile(target) and not os.path.islink(target) and os.path.getsize(target) <= MAX_BYTES:
        filed = read_filing(target)
    shutil.rmtree(work, ignore_errors=True)
    return filed


def slots_of(cell):
    cell = (cell or "").strip().lower()
    if cell in ("", "none"):
        return frozenset()
    parts = [p.strip() for p in cell.split(";")]
    if not all(p.isdigit() for p in parts):
        return None
    return frozenset(int(p) for p in parts)


def read_filing(path):
    out = {}
    with open(path, newline="", encoding="utf-8", errors="replace") as fh:
        for row in csv.DictReader(fh):
            code = (row.get("report") or "").strip()
            if code and code not in out:
                out[code] = slots_of(row.get("reissue"))
    return out


def days():
    return sorted(os.listdir(os.path.join(HELD, "days")))
