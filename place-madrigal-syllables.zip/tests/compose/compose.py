#!/usr/bin/env python3
"""Forges the madrigals of the partbook-edition project: three samples placed in full and twenty
held pieces with their sealed truth.  stdlib only, seeded, instant.

    compose.py samples OUT_DIR
    compose.py held PIECES_DIR TRUTH_DIR

A piece is a poem (lines of two phrases, every word divided into accented and unaccented
syllables) and four or five voices. Each voice sings the poem through in stretches between rests;
a stretch carries one or two phrases printed with their first syllable under the first note, or
the sign ij where the text just sung is sung again. The placement practice (one syllable to a
ligature; none on the note after a dot, on a semiminim or on the note after one, unless the phrase
cannot otherwise be placed; a repeated note takes a new syllable; an unaccented syllable takes one
note or one ligature; the last syllable on the last note) admits exactly one placement of every
stretch, the same under every reading of the concession. What a print's ij stands for, the last
phrase or the whole line, is one usage per print, settled by the signs whose notes carry only that
reading (decisive) and applied to the signs whose notes carry both (ambiguous).
"""
import json
import math
import os
import random
import sys

VALUE = {"breve": 4.0, "semibreve": 2.0, "minim": 1.0, "semiminim": 0.5, "fusa": 0.25}
SHORT = ("semiminim", "fusa")
RANGES = {"C": ("c4", "g5"), "A": ("f3", "c5"), "Q": ("a3", "d5"), "T": ("c3", "g4"), "B": ("f2", "c4")}
LETTERS = "cdefgab"
MIN_MARGIN = 3        # stretches per piece on which each dropped rule admits another placement
MIN_HARD = 4          # stretches per piece that need the concession
MIN_DECISIVE = 3      # ij signs per piece whose notes carry only the print's reading
MIN_AMBIGUOUS = 3     # ij signs per piece whose notes carry both readings
MIN_LOOSE = 4         # strict stretches per piece where the concession granted anyway admits another placement

# words divided into syllables; the accented syllable's index; clitics carry no accent (None)
WORDS = [
    ("dol-ce", 0), ("a-mor", 1), ("mor-te", 0), ("oc-chi", 0), ("so-spi-ri", 1), ("pie-ta", 1),
    ("cru-del", 1), ("fiam-ma", 0), ("cor", 0), ("vi-so", 0), ("ciel", 0), ("stel-le", 0), ("do-lor", 1),
    ("ahi", 0), ("las-so", 0), ("mi-o", 0), ("bel-la", 0), ("don-na", 0), ("vi-ta", 0), ("pe-na", 0),
    ("gio-ia", 0), ("lu-ce", 0), ("spe-me", 0), ("pian-to", 0), ("ri-so", 0), ("ar-do", 0), ("mo-ro", 0),
    ("vi-vo", 0), ("sem-pre", 0), ("mai", 0), ("sol", 0), ("quel", 0), ("fu", 0), ("vo-i", 0),
    ("mor-ir", 1), ("lan-gui-re", 1), ("sof-fri-re", 1), ("ca-ra", 0), ("fe-de", 0), ("ter-ra", 0),
    ("ma-re", 0), ("ven-to", 0), ("on-de", 0), ("fio-ri", 0), ("pra-ti", 0), ("au-ra", 0), ("not-te", 0),
    ("gior-no", 0), ("sol-e", 0), ("al-ma", 0), ("pe-ne", 0), ("de-si-o", 1), ("tor-men-to", 1),
    ("mar-ti-re", 1), ("pie-to-sa", 1), ("gen-til", 1), ("be-a-to", 1), ("fe-li-ce", 1), ("in-fe-li-ce", 2),
    ("so-a-ve", 1), ("a-ma-ro", 1), ("ca-gion", 1), ("spe-ran-za", 1), ("vo-glia", 0), ("fo-co", 0),
]
CLITICS = ["il", "la", "e", "che", "non", "del", "per", "se", "mi", "ti", "o", "di", "al", "in", "con"]


# ------------------------------------------------------------------------------- the poem ----
def draw_phrase(rng, syllables):
    """A phrase of about `syllables` syllables: words with their accents."""
    out = []
    n = 0
    while n < syllables:
        if out and rng.random() < 0.4 and n < syllables - 1:
            w = rng.choice(CLITICS)
            out.append((w.split("-"), None))
            n += 1
            continue
        word, acc = rng.choice(WORDS)
        parts = word.split("-")
        if n + len(parts) > syllables + 1:
            continue
        out.append((parts, acc))
        n += len(parts)
    return out


def draw_poem(rng):
    """Lines of two phrases; every syllable with its line, phrase, word and accent."""
    syls = []
    lines = rng.randint(8, 10)
    for line in range(1, lines + 1):
        for phrase, target in (("a", rng.randint(3, 5)), ("b", rng.randint(3, 6))):
            for parts, acc in draw_phrase(rng, target):
                for j, part in enumerate(parts):
                    syls.append({"index": len(syls), "line": line, "phrase": phrase, "word": "-".join(parts),
                                 "syllable": part, "accent": 1 if acc == j else 0})
    return syls


def phrase_syllables(poem, line, phrase):
    return [s for s in poem if s["line"] == line and s["phrase"] == phrase]


# ---------------------------------------------------------------------------- the practice ----
def pitch_index(p):
    return int(p[-1]) * 7 + LETTERS.index(p[0])


def pitch_name(i):
    return LETTERS[i % 7] + str(i // 7)


def units_of(notes, bound=True):
    """Maximal ligature groups and single notes, as (first, last) note positions; every note its
    own unit when ligatures are not `bound`."""
    units, i = [], 0
    while i < len(notes):
        j = i
        if bound and notes[i]["lig"]:
            while j + 1 < len(notes) and notes[j + 1]["lig"] == notes[i]["lig"]:
                j += 1
        units.append((i, j))
        i = j + 1
    return units


RELAXATIONS = ("fusa", "dot", "longdot")
RELAX_SETS = [frozenset(c) for n in range(4) for c in __import__("itertools").combinations(RELAXATIONS, n)]


def may_start(notes, i, concession, rules, relax=frozenset()):
    """Whether note i may begin a syllable under the practice (rules: a set of rule names in force;
    relax: other readings of the concession, in force only with it: 'fusa' frees fusae like
    semiminims, 'dot' frees the note after any dot, 'longdot' the note after a dotted minim only)."""
    if i == 0:
        return True
    n, p = notes[i], notes[i - 1]
    if "ligature" in rules and n["lig"] and p["lig"] == n["lig"]:
        return False
    if "dot" in rules and p["dot"]:
        freed = concession and ("dot" in relax or ("longdot" in relax and p["value"] not in ("breve", "semibreve")))
        if not freed:
            return False
    if "short" in rules:
        if (n["value"] == "fusa" or p["value"] == "fusa") and not (concession and "fusa" in relax):
            return False
        if (n["value"] in SHORT or p["value"] in SHORT) and not concession:
            return False
    return True


def violations(notes, starts):
    """How many beginnings break the strict rules on dots and short notes."""
    v = 0
    for i in starts:
        if i == 0:
            continue
        n, p = notes[i], notes[i - 1]
        v += bool(p["dot"]) + (n["value"] in SHORT) + (p["value"] in SHORT)
    return v


def must_start(notes, i, rules):
    return "repeat" in rules and i > 0 and notes[i]["pitch"] == notes[i - 1]["pitch"]


RULES = frozenset({"ligature", "dot", "short", "repeat", "accent"})


def placements(notes, syls, concession, rules=RULES, limit=2, relax=frozenset()):
    """The placements of the syllables on the notes under the practice: lists of note positions
    where each syllable begins. Stops after `limit` placements."""
    units = units_of(notes, "ligature" in rules)
    starts = [u[0] for u in units]
    allowed = [may_start(notes, s, concession, rules, relax) for s in starts]
    forced = [must_start(notes, s, rules) for s in starts]
    out = []
    s = len(syls)

    def rec(j, u, acc):
        if len(out) >= limit:
            return
        if j == s:
            if u == len(units):
                out.append(list(acc))
            return
        if u >= len(units) or not allowed[u]:
            return
        last = j == s - 1
        max_k = 1 if (last or ("accent" in rules and not syls[j]["accent"])) else len(units) - u
        for k in range(1, max_k + 1):
            if any(forced[v] for v in range(u + 1, u + k)):
                break
            if last and u + k != len(units):
                continue
            acc.append(starts[u])
            rec(j + 1, u + k, acc)
            acc.pop()

    rec(0, 0, [])
    return out


def place(notes, syls, rules=RULES):
    """(placement, concession used) under the practice: strict first, the concession only where the
    strict rules place nothing. None where nothing places or more than one placement does."""
    for concession in (False, True):
        found = placements(notes, syls, concession, rules)
        if len(found) == 1:
            return found[0], concession
        if len(found) > 1:
            return None
    return None


# ----------------------------------------------------------------------------- composing ----
def draw_notes(rng, syls, lo, hi, hard, min_units=0):
    """Notes for a stretch carrying `syls`, composed on a placement drawn first: unit counts per
    syllable (at least `min_units` in all, the surplus on accented syllables), ligatures, values,
    dots and pitches. Returns (notes, intended starts), or None when the plan cannot be drawn."""
    s = len(syls)
    plan = []                                   # per syllable: how many units it takes
    for j, syl in enumerate(syls):
        k = 1
        if j < s - 1 and syl["accent"]:
            k = 1 + min(3, int(rng.expovariate(1.1)))
        plan.append(k)
    stressed = [j for j in range(s - 1) if syls[j]["accent"]]
    while sum(plan) < min_units:
        if not stressed:
            return None
        plan[rng.choice(stressed)] += 1
    patter = set()
    if hard:
        # a run of syllables on semiminims, at least two, not touching the last syllable
        if s >= 4:
            start = rng.randint(1, s - 3)
            run = rng.randint(2, min(4, s - 1 - start))
            patter = set(range(start, start + run))
        else:
            patter = {1}
    notes, starts = [], []
    pitch = rng.randint(lo + 2, hi - 2)
    prev_pitch = None
    for j, syl in enumerate(syls):
        for u in range(plan[j]):
            is_start = u == 0
            lig = rng.random() < 0.18 and not (is_start and j == s - 1) and j not in patter
            if is_start:
                starts.append(len(notes))
            # pitch: a start may repeat the previous pitch; a melisma unit never does
            if is_start and prev_pitch is not None and rng.random() < 0.3:
                pitch = prev_pitch
            else:
                for _ in range(20):
                    cand = pitch + rng.choice([-3, -2, -1, -1, 1, 1, 2, 3])
                    if lo <= cand <= hi and cand != prev_pitch:
                        pitch = cand
                        break
                else:
                    pitch = lo + 2 if prev_pitch != lo + 2 else lo + 3
            if lig:
                length = rng.choice([2, 2, 3])
                lig_id = "L%d" % (len(notes) + 1)
                p = pitch
                for q in range(length):
                    if q:
                        for _ in range(20):
                            cand = p + rng.choice([-2, -1, 1, 2])
                            if lo <= cand <= hi and cand != p:
                                break
                        p = cand
                    notes.append({"pitch": pitch_name(p), "value": rng.choice(["semibreve", "minim", "minim"]),
                                  "dot": 0, "lig": lig_id})
                prev_pitch = p
                pitch = p
                continue
            if is_start:
                if j in patter:
                    value, dot = "semiminim", 0
                elif j == s - 1:
                    value, dot = rng.choice(["semibreve", "breve", "minim"]), 0
                else:
                    value = rng.choice(["minim", "minim", "semibreve", "semibreve", "minim"])
                    dot = 1 if (plan[j] > 1 and rng.random() < 0.35) else 0
            else:
                value = rng.choice(["minim", "semiminim", "semiminim", "semibreve", "fusa"])
                dot = 1 if (value in ("minim", "semibreve") and u < plan[j] - 1 and rng.random() < 0.3) else 0
            if value == "fusa":
                # fusae come in pairs inside a melisma
                notes.append({"pitch": pitch_name(pitch), "value": "fusa", "dot": 0, "lig": ""})
                prev_pitch = pitch
                for _ in range(20):
                    cand = pitch + rng.choice([-1, 1])
                    if lo <= cand <= hi:
                        break
                pitch = cand
            notes.append({"pitch": pitch_name(pitch), "value": value, "dot": dot, "lig": ""})
            prev_pitch = pitch
    return notes, starts


def stretch_ok(notes, syls, hard, loose):
    """The stretch under the practice: exactly one placement (strict, or with the concession when
    `hard`), and what each dropped rule admits. Returns the margin record or None."""
    strict = placements(notes, syls, False)
    conceded = placements(notes, syls, True)
    if hard:
        if strict or len(conceded) != 1:
            return None
        truth = conceded[0]
    else:
        if len(strict) != 1:
            return None
        truth = strict[0]
        if loose and len(conceded) < 2:
            return None
    if hard:
        # every other reading of the concession places the stretch the same way, and the placement
        # is the one that breaks the strict rules least under the widest reading
        for relax in RELAX_SETS:
            if placements(notes, syls, True, RULES, relax=relax) != [truth]:
                return None
        widest = placements(notes, syls, True, RULES, limit=400, relax=frozenset(RELAXATIONS))
        least = violations(notes, truth)
        if any(violations(notes, p) <= least for p in widest if p != truth):
            return None
    margins = {}
    for rule in sorted(RULES):
        if rule == "short" and hard:
            continue
        found = placements(notes, syls, hard, RULES - {rule})
        margins[rule] = len(found) >= 2 or found != [truth]
    if hard:
        margins["short"] = True   # the strict reading places nothing here
    return {"truth": truth, "concession": hard, "margins": margins, "loose": (not hard) and len(conceded) >= 2}


def compose_stretch(rng, syls, lo, hi, hard, loose, tries=400, min_units=0):
    for _ in range(tries):
        drawn = draw_notes(rng, syls, lo, hi, hard, min_units)
        if drawn is None:
            return None
        notes, _ = drawn
        rec = stretch_ok(notes, syls, hard, loose)
        if rec is not None:
            return notes, rec
    return None


# ------------------------------------------------------------------------------- a piece ----
def voice_plan(rng, poem, n_lines, usage):
    """The stretches of one voice: (kind, line, phrases, decisive). An ij carries what the print's
    usage makes it stand for: the last phrase or the whole line; a decisive sign is one whose
    notes carry only that, an ambiguous one carries the other reading too."""
    plan = []
    repeat = ["b"] if usage == "phrase" else ["a", "b"]
    for line in range(1, n_lines + 1):
        whole = rng.random() < 0.3
        if whole:
            plan.append(("text", line, ["a", "b"], None))
        else:
            plan.append(("text", line, ["a"], None))
            plan.append(("text", line, ["b"], None))
        r = rng.random()
        if r < 0.55:
            plan.append(("ij", line, list(repeat), rng.random() < 0.5))
        elif r < 0.7:
            plan.append(("text", line, ["a", "b"], None))     # the line printed again
    return plan


FAIL = {}


def fail(key):
    FAIL[key] = FAIL.get(key, 0) + 1


def other_reading(notes, other):
    """How the other reading of an ij places on the stretch: 0 (never, under any reading of the
    concession), 1 (exactly one placement under the practice) or 2 (more, or unsettled)."""
    found = [placements(notes, other, c, RULES, relax=rx) for c in (False, True) for rx in RELAX_SETS]
    if not any(found):
        return 0
    strict = placements(notes, other, False)
    conceded = placements(notes, other, True)
    settled = strict if strict else conceded
    if len(settled) == 1 and all(f in ([], settled) for f in found):
        return 1
    return 2


def build_piece(code, n_voices, seed, usage="phrase", sample=False):
    rng = random.Random(seed)
    poem = draw_poem(rng)
    n_lines = poem[-1]["line"]
    voices = ["C", "A", "T", "B"] if n_voices == 4 else ["C", "A", "Q", "T", "B"]
    piece = {"code": code, "seed": seed, "usage": usage, "poem": poem, "voices": {}, "stretches": []}
    counts = {"hard": 0, "decisive": 0, "ambiguous": 0, "loose": 0}
    margin_count = {r: 0 for r in RULES}
    for voice in voices:
        lo, hi = pitch_index(RANGES[voice][0]), pitch_index(RANGES[voice][1])
        plan = voice_plan(rng, poem, n_lines, usage)
        rows = []
        for kind, line, phrases, decisive in plan:
            syls = [s for ph in phrases for s in phrase_syllables(poem, line, ph)]
            hard = (not sample) and rng.random() < 0.25
            if kind == "ij":
                # the other reading of the sign: nothing places (decisive) or one placement (ambiguous)
                other = (phrase_syllables(poem, line, "b") if phrases == ["a", "b"]
                         else phrase_syllables(poem, line, "a") + phrase_syllables(poem, line, "b"))
            min_units = len(other) if (kind == "ij" and decisive is False) else 0
            for _attempt in range(40):
                made = compose_stretch(rng, syls, lo, hi, hard, False, min_units=min_units)
                if made is None:
                    continue
                if kind == "ij" and other_reading(made[0], other) != (0 if decisive else 1):
                    continue
                break
            else:
                fail("compose %s%s%s" % (kind, "-hard" if hard else "", "-ambiguous" if decisive is False else ""))
                return None
            notes, rec = made
            if kind == "ij":
                counts["decisive" if decisive else "ambiguous"] += 1
            counts["hard"] += rec["concession"]
            counts["loose"] += rec["loose"]
            for r, ok in rec["margins"].items():
                margin_count[r] += ok
            first = len(rows)
            anchors = []
            if kind == "text":
                pos = 0
                for ph in phrases:
                    anchors.append((first + rec["truth"][pos], phrase_syllables(poem, line, ph)[0]["index"]))
                    pos += len(phrase_syllables(poem, line, ph))
            for n in notes:
                rows.append(dict(n))
            rows.append({"pitch": "rest", "value": rng.choice(["minim", "semibreve", "breve"]), "dot": 0, "lig": ""})
            piece["stretches"].append({
                "voice": voice, "first": first, "count": len(notes), "kind": kind, "line": line,
                "phrases": phrases, "syllables": [s["index"] for s in syls],
                "starts": [first + p for p in rec["truth"]], "concession": rec["concession"],
                "decisive": decisive, "anchors": anchors})
        rows.pop()                                  # no rest after the last stretch
        piece["voices"][voice] = rows
    piece["counts"] = counts
    piece["margins"] = margin_count
    return piece


def evidence_problem(piece):
    probs = []
    c = piece["counts"]
    if c["hard"] < MIN_HARD:
        probs.append("only %d stretches need the concession" % c["hard"])
    if c["decisive"] < MIN_DECISIVE:
        probs.append("only %d ij signs settle the print's usage" % c["decisive"])
    if c["ambiguous"] < MIN_AMBIGUOUS:
        probs.append("only %d ij signs carry both readings" % c["ambiguous"])
    if c["loose"] < MIN_LOOSE:
        probs.append("only %d strict stretches loosen under the concession" % c["loose"])
    for r, n in piece["margins"].items():
        if not math.isfinite(n) or n < MIN_MARGIN:
            probs.append("rule %s decides only %d stretches" % (r, n))
    return probs


# ----------------------------------------------------------------------------- writers ----
def write_piece(piece, out_dir, with_placement):
    d = os.path.join(out_dir, piece["code"])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "text.csv"), "w") as fh:
        fh.write("syllable,line,phrase,word,text,accent\n")
        for s in piece["poem"]:
            fh.write("%d,%d,%s,%s,%s,%d\n" % (s["index"], s["line"], s["phrase"], s["word"], s["syllable"], s["accent"]))
    with open(os.path.join(d, "notes.csv"), "w") as fh:
        fh.write("voice,note,pitch,value,dot,ligature\n")
        for voice, rows in piece["voices"].items():
            for i, n in enumerate(rows):
                fh.write("%s,%d,%s,%s,%d,%s\n" % (voice, i, n["pitch"], n["value"], n["dot"], n["lig"]))
    with open(os.path.join(d, "print.csv"), "w") as fh:
        fh.write("voice,note,text\n")
        for st in piece["stretches"]:
            if st["kind"] == "ij":
                fh.write("%s,%d,ij\n" % (st["voice"], st["first"]))
            else:
                for note, syl in st["anchors"]:
                    fh.write("%s,%d,%d\n" % (st["voice"], note, syl))
    if with_placement:
        with open(os.path.join(d, "placement.csv"), "w") as fh:
            fh.write("voice,note,syllable\n")
            for voice, note, syl in key_rows(piece):
                fh.write("%s,%d,%s\n" % (voice, note, syl))


def key_rows(piece):
    """(voice, note, syllable index or '-') for every sounding note."""
    starts = {}
    for st in piece["stretches"]:
        for pos, syl in zip(st["starts"], st["syllables"]):
            starts[(st["voice"], pos)] = syl
    out = []
    for voice, rows in piece["voices"].items():
        for i, n in enumerate(rows):
            if n["pitch"] == "rest":
                continue
            out.append((voice, i, str(starts[(voice, i)]) if (voice, i) in starts else "-"))
    return out


def write_sealed(piece, sealed_dir):
    os.makedirs(sealed_dir, exist_ok=True)
    with open(os.path.join(sealed_dir, piece["code"] + ".json"), "w") as fh:
        json.dump({"code": piece["code"], "seed": piece["seed"], "usage": piece["usage"],
                   "stretches": piece["stretches"], "key": [[v, n, s] for v, n, s in key_rows(piece)],
                   "counts": piece["counts"]}, fh)


SAMPLES = [("S1", 4, "phrase", 101), ("S2", 5, "phrase", 102), ("S3", 4, "phrase", 103)]
HELD = [("M%02d" % i, 4 if i % 3 else 5, "line" if i % 2 == 0 else "phrase", 1000 + i) for i in range(1, 21)]


def forge_one(spec, max_tries=400):
    code, n_voices, usage, seed = spec
    probs = []
    for t in range(max_tries):
        piece = build_piece(code, n_voices, seed + 100000 * t, usage)
        if piece is None:
            continue
        probs = evidence_problem(piece)
        if not probs:
            return piece
        for pr in probs:
            FAIL[pr.split(" only")[0]] = FAIL.get(pr.split(" only")[0], 0) + 1
    raise SystemExit("%s: no settled piece in %d tries (%s; %s)" % (code, max_tries, probs, FAIL))


def sample_piece(spec, max_tries=400):
    """A sample: every stretch strict, the print's usage the last phrase."""
    code, n_voices, usage, seed = spec
    for t in range(max_tries):
        piece = build_piece(code, n_voices, seed + 100000 * t, usage, sample=True)
        if piece is None:
            continue
        return piece
    raise SystemExit("%s: no sample in %d tries" % (code, max_tries))


def main():
    mode = sys.argv[1]
    if mode == "samples":
        for spec in SAMPLES:
            piece = sample_piece(spec)
            write_piece(piece, sys.argv[2], True)
            print(spec[0], "ok", sum(len(r) for r in piece["voices"].values()), "rows", piece["counts"])
    elif mode == "held":
        for spec in HELD:
            piece = forge_one(spec)
            write_piece(piece, sys.argv[2], False)
            write_sealed(piece, sys.argv[3])
            print(spec[0], "ok", sum(len(r) for r in piece["voices"].values()), "rows", piece["counts"], piece["margins"])
    else:
        raise SystemExit("compose.py samples OUT_DIR | held PIECES_DIR TRUTH_DIR")


if __name__ == "__main__":
    main()
