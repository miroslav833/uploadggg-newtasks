"""The grader. First the data: every held madrigal's placement is derived again from the sealed
stretches with the verifier's own model of the practice (tests/underlay.py) and the shipped files
are checked against it, so that the key follows from the data. Then the tool: it is run on every
held madrigal in the sandbox and the madrigals it places within the allowance are counted."""
import csv
import json
import os

import pytest

import sandbox
import underlay

TRUTH = "/tests/edition/truth"
WRONG_ALLOWED = 2      # wrong notes a madrigal may have and still count (instruction.md)
HELD = 20
MARK = 18              # madrigals that must count (instruction.md)
ALLOWANCE, ENOUGH = WRONG_ALLOWED, MARK


def truth_of(code):
    with open(os.path.join(TRUTH, code + ".json")) as fh:
        return json.load(fh)


def answer_key(truth):
    return {(voice, note): syllable for voice, note, syllable in truth["key"]}


def load_shipped(code):
    folder = os.path.join(sandbox.PIECES, code)
    poem, voices, anchors = {}, {}, {}
    with open(os.path.join(folder, "text.csv"), newline="") as fh:
        for row in csv.DictReader(fh):
            poem[int(row["syllable"])] = {"index": int(row["syllable"]), "line": int(row["line"]),
                                          "phrase": row["phrase"], "accent": int(row["accent"])}
    with open(os.path.join(folder, "notes.csv"), newline="") as fh:
        for row in csv.DictReader(fh):
            voices.setdefault(row["voice"], []).append({
                "note": int(row["note"]), "pitch": row["pitch"], "value": row["value"],
                "dot": int(row["dot"]), "ligature": row["ligature"]})
    with open(os.path.join(folder, "print.csv"), newline="") as fh:
        for row in csv.DictReader(fh):
            anchors[(row["voice"], int(row["note"]))] = row["text"]
    for rows in voices.values():
        rows.sort(key=lambda r: r["note"])
    return poem, voices, anchors


def test_the_data_imply_the_key():
    codes = sandbox.held_pieces()
    assert len(codes) == HELD
    for code in codes:
        truth = truth_of(code)
        poem, voices, anchors = load_shipped(code)
        for voice, rows in voices.items():
            assert [r["note"] for r in rows] == list(range(len(rows))), (code, voice)
        assert underlay.problems(truth, poem, voices, anchors) == [], code
        assert underlay.reckon(truth, poem, voices) == answer_key(truth), code


@pytest.fixture(scope="session")
def tally():
    box = sandbox.Sandbox()
    wrong = {}
    for code in sandbox.held_pieces():
        filed = box.run(code)
        key = answer_key(truth_of(code))
        wrong[code] = sum(1 for spot, syllable in key.items() if filed.get(spot) != syllable)
    with open(os.path.join(sandbox.LOGS, "tally.json"), "w") as fh:
        json.dump(wrong, fh, indent=1)
    return wrong


def test_the_tool_places_enough_madrigals(tally):
    good = sorted(code for code, wrong in tally.items() if wrong <= ALLOWANCE)
    assert len(good) >= ENOUGH, "%d of %d madrigals placed within %d wrong notes (%s); %d needed" % (
        len(good), HELD, ALLOWANCE, tally, ENOUGH)
