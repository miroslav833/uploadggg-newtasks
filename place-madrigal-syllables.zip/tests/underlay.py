"""The verifier's own model of the placement practice.

It rebuilds every graded placement from the sealed truth (which phrases each stretch carries, or
which text a repeat sign reaches) and checks that the shipped files say the same thing: each
stretch's notes admit exactly one placement under the practice, the concession is used only where
the strict rules place nothing, the other reach of every repeat sign places nothing at all, and
the anchors, rests and notes are as sealed.
"""
import math

SHORT = {"semiminim", "fusa"}


def groups(notes):
    """Note positions grouped into ligatures and single notes."""
    out, i = [], 0
    while i < len(notes):
        j = i
        if notes[i]["ligature"]:
            while j + 1 < len(notes) and notes[j + 1]["ligature"] == notes[i]["ligature"]:
                j += 1
        out.append((i, j))
        i = j + 1
    return out


def begins_allowed(notes, i, concession):
    if i == 0:
        return True
    here, before = notes[i], notes[i - 1]
    if before["dot"]:
        return False
    if "fusa" in (here["value"], before["value"]):
        return False
    if not concession and "semiminim" in (here["value"], before["value"]):
        return False
    return True


def count_placements(notes, accents, concession):
    """(number of placements, one of them) by dynamic programming over (syllable, group)."""
    gs = groups(notes)
    m, s = len(gs), len(accents)
    ok = [begins_allowed(notes, a, concession) for a, _ in gs]
    forced = [a > 0 and notes[a]["pitch"] == notes[a - 1]["pitch"] for a, _ in gs]
    # ways[j][u]: placements of syllables j.. with syllable j beginning on group u
    ways = [[0] * (m + 1) for _ in range(s + 1)]
    pick = [[None] * (m + 1) for _ in range(s + 1)]
    ways[s][m] = 1
    for j in range(s - 1, -1, -1):
        for u in range(m - 1, -1, -1):
            if not ok[u]:
                continue
            total, first = 0, None
            span = 1 if (j == s - 1 or not accents[j]) else m - u
            for k in range(1, span + 1):
                if any(forced[v] for v in range(u + 1, u + k)):
                    break
                nxt = u + k
                if j == s - 1 and nxt != m:
                    continue
                w = ways[j + 1][nxt]
                if w:
                    if first is None:
                        first = nxt
                    total += w
            ways[j][u] = total
            pick[j][u] = first
    n = ways[0][0] if s else 0
    if not math.isfinite(n) or n < 1:
        return n, None
    placement, u = [], 0
    for j in range(s):
        placement.append(gs[u][0])
        u = pick[j][u]
    return n, placement


def reckon_stretch(notes, syllables, concession_allowed=True):
    """The placement the practice gives: (placement, concession used), or None."""
    n, p = count_placements(notes, [x["accent"] for x in syllables], False)
    if n == 1:
        return p, False
    if n > 1 or not concession_allowed:
        return None
    n, p = count_placements(notes, [x["accent"] for x in syllables], True)
    if n == 1:
        return p, True
    return None


def problems(sealed, poem, notes_by_voice, anchors):
    """Where the shipped piece disagrees with the sealed truth under the practice (empty when it
    agrees). `poem` maps a syllable index to its row; `anchors` maps (voice, note) to the printed
    token; `notes_by_voice` maps a voice to its rows in order."""
    out = []
    by_phrase = {}
    for s in poem.values():
        by_phrase.setdefault((s["line"], s["phrase"]), []).append(s)
    for key in by_phrase:
        by_phrase[key].sort(key=lambda s: s["index"])
    seen = {}
    for st in sealed["stretches"]:
        rows = notes_by_voice.get(st["voice"], [])
        first, count = st["first"], st["count"]
        notes = rows[first:first + count]
        if len(notes) != count or any(n["pitch"] == "rest" for n in notes):
            out.append("%s@%d: the stretch is not %d sounding notes" % (st["voice"], first, count))
            continue
        if first > 0 and rows[first - 1]["pitch"] != "rest":
            out.append("%s@%d: no rest before the stretch" % (st["voice"], first))
        if first + count < len(rows) and rows[first + count]["pitch"] != "rest":
            out.append("%s@%d: no rest after the stretch" % (st["voice"], first))
        syllables = [poem[i] for i in st["syllables"]]
        expect = [s for ph in st["phrases"] for s in by_phrase[(st["line"], ph)]]
        if [s["index"] for s in expect] != st["syllables"]:
            out.append("%s@%d: the sealed syllables are not the sealed phrases" % (st["voice"], first))
        got = reckon_stretch(notes, syllables)
        if got is None:
            out.append("%s@%d: the practice does not place the stretch uniquely" % (st["voice"], first))
            continue
        placement, concession = got
        if [first + p for p in placement] != st["starts"] or concession != st["concession"]:
            out.append("%s@%d: the practice places the stretch otherwise" % (st["voice"], first))
        if st["kind"] == "ij":
            if anchors.get((st["voice"], first)) != "ij":
                out.append("%s@%d: no ij printed" % (st["voice"], first))
            wide = st["phrases"] == ["a", "b"]
            other = by_phrase[(st["line"], "b")] if wide else by_phrase[(st["line"], "a")] + by_phrase[(st["line"], "b")]
            for concession in (False, True):
                n, _ = count_placements(notes, [x["accent"] for x in other], concession)
                if n:
                    out.append("%s@%d: the other reach of ij also places" % (st["voice"], first))
                    break
            prev = seen.get(st["voice"])
            if prev is None or prev["line"] != st["line"] or prev["phrases"][-1] != "b":
                out.append("%s@%d: ij does not follow the line it repeats" % (st["voice"], first))
        else:
            pos = 0
            for ph in st["phrases"]:
                note = first + placement[pos]
                if anchors.get((st["voice"], note)) != str(by_phrase[(st["line"], ph)][0]["index"]):
                    out.append("%s@%d: phrase %d%s is not anchored at its first note" % (st["voice"], first, st["line"], ph))
                pos += len(by_phrase[(st["line"], ph)])
            inside = [k for k in anchors if k[0] == st["voice"] and first <= k[1] < first + count]
            if len(inside) != len(st["phrases"]):
                out.append("%s@%d: %d anchors for %d phrases" % (st["voice"], first, len(inside), len(st["phrases"])))
        seen[st["voice"]] = st
    return out


def reckon(sealed, poem, notes_by_voice):
    """The key the sealed stretches imply: (voice, note) -> syllable index or '-' for every
    sounding note."""
    starts = {}
    for st in sealed["stretches"]:
        rows = notes_by_voice[st["voice"]]
        notes = rows[st["first"]:st["first"] + st["count"]]
        got = reckon_stretch(notes, [poem[i] for i in st["syllables"]])
        if got is None:
            continue
        for p, i in zip(got[0], st["syllables"]):
            starts[(st["voice"], st["first"] + p)] = str(i)
    key = {}
    for voice, rows in notes_by_voice.items():
        for n, r in enumerate(rows):
            if r["pitch"] != "rest":
                key[(voice, n)] = starts.get((voice, n), "-")
    return key
