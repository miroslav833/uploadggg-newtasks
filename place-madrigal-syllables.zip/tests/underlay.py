"""The verifier's own model of the placement practice.

It rebuilds every graded placement from the sealed truth (which phrases each stretch carries, and
what the print's ij stands for) and checks that the shipped files say the same thing: each
stretch's notes admit exactly one placement under the practice, the concession is used only where
the strict rules place nothing and places the same under every reading of it, the print's usage of
ij is the one its decisive signs force, and the anchors, rests and notes are as sealed.
"""
import itertools
import math

SHORT = {"semiminim", "fusa"}
READINGS = ("phrase", "line")
RELAXATIONS = ("fusa", "dot", "longdot")
RELAX_SETS = [frozenset(c) for n in range(4) for c in itertools.combinations(RELAXATIONS, n)]


def groups(notes):
    """Note positions grouped into ligatures and single notes."""
    out, i = [], 0
    while i < len(notes):
        j = i
        if notes[i]["ligature"]:
            while j + 1 < len(notes) and notes[j + 1]["ligature"] == notes[i]["ligature"]:
                j += 1
        out.append((i, j))
        i = j + 1
    return out


def begins_allowed(notes, i, concession, relax=frozenset()):
    if i == 0:
        return True
    here, before = notes[i], notes[i - 1]
    if before["dot"]:
        freed = concession and ("dot" in relax or ("longdot" in relax and before["value"] not in ("breve", "semibreve")))
        if not freed:
            return False
    if "fusa" in (here["value"], before["value"]) and not (concession and "fusa" in relax):
        return False
    if not concession and (here["value"] in SHORT or before["value"] in SHORT):
        return False
    return True


def breaches(notes, starts):
    """Beginnings that break the strict rules on dots and short notes."""
    n = 0
    for i in starts:
        if i:
            n += bool(notes[i - 1]["dot"]) + (notes[i]["value"] in SHORT) + (notes[i - 1]["value"] in SHORT)
    return n


def count_placements(notes, accents, concession, relax=frozenset(), want_all=False):
    """(number of placements, one of them or all of them) by dynamic programming over
    (syllable, group)."""
    gs = groups(notes)
    m, s = len(gs), len(accents)
    ok = [begins_allowed(notes, a, concession, relax) for a, _ in gs]
    forced = [a > 0 and notes[a]["pitch"] == notes[a - 1]["pitch"] for a, _ in gs]
    ways = [[0] * (m + 1) for _ in range(s + 1)]
    nxts = [[[] for _ in range(m + 1)] for _ in range(s + 1)]
    ways[s][m] = 1
    for j in range(s - 1, -1, -1):
        for u in range(m - 1, -1, -1):
            if not ok[u]:
                continue
            total = 0
            span = 1 if (j == s - 1 or not accents[j]) else m - u
            for k in range(1, span + 1):
                if any(forced[v] for v in range(u + 1, u + k)):
                    break
                nxt = u + k
                if j == s - 1 and nxt != m:
                    continue
                if ways[j + 1][nxt]:
                    nxts[j][u].append(nxt)
                    total += ways[j + 1][nxt]
            ways[j][u] = total
    n = ways[0][0] if s else 0
    if not math.isfinite(n) or n < 1:
        return n, [] if want_all else None
    if not want_all:
        placement, u = [], 0
        for j in range(s):
            placement.append(gs[u][0])
            u = nxts[j][u][0]
        return n, placement
    found = []

    def walk(j, u, acc):
        if len(found) >= 400:
            return
        if j == s:
            found.append(list(acc))
            return
        for nxt in nxts[j][u]:
            acc.append(gs[u][0])
            walk(j + 1, nxt, acc)
            acc.pop()
    walk(0, 0, [])
    return n, found


def reckon_stretch(notes, syllables):
    """The placement the practice gives: (placement, concession used), or None."""
    accents = [x["accent"] for x in syllables]
    n, p = count_placements(notes, accents, False)
    if n == 1:
        return p, False
    if n > 1:
        return None
    n, p = count_placements(notes, accents, True)
    if n == 1:
        return p, True
    return None


def settled_under_every_reading(notes, syllables, truth):
    """Whether every reading of the concession places the stretch as `truth`, and `truth` breaks
    the strict rules least among all placements under the widest reading."""
    accents = [x["accent"] for x in syllables]
    for relax in RELAX_SETS:
        n, p = count_placements(notes, accents, True, relax)
        if n != 1 or p != truth:
            return False
    _, widest = count_placements(notes, accents, True, frozenset(RELAXATIONS), want_all=True)
    least = breaches(notes, truth)
    return all(breaches(notes, p) > least for p in widest if p != truth)


def other_fits(notes, syllables):
    """0 when the text places under no reading of the practice, 1 when it places in exactly one
    way under the practice and never otherwise under any reading, 2 otherwise."""
    accents = [x["accent"] for x in syllables]
    seen = []
    for concession in (False, True):
        for relax in RELAX_SETS:
            n, p = count_placements(notes, accents, concession, relax)
            seen.append((n, p))
    if all(n == 0 for n, _ in seen):
        return 0
    n0, p0 = count_placements(notes, accents, False)
    n1, p1 = count_placements(notes, accents, True)
    settled = (n0, p0) if n0 else (n1, p1)
    if settled[0] == 1 and all(n == 0 or (n == 1 and p == settled[1]) for n, p in seen):
        return 1
    return 2


def problems(sealed, poem, notes_by_voice, anchors):
    """Where the shipped piece disagrees with the sealed truth under the practice (empty when it
    agrees). `poem` maps a syllable index to its row; `anchors` maps (voice, note) to the printed
    token; `notes_by_voice` maps a voice to its rows in order."""
    out = []
    by_phrase = {}
    for s in poem.values():
        by_phrase.setdefault((s["line"], s["phrase"]), []).append(s)
    for key in by_phrase:
        by_phrase[key].sort(key=lambda s: s["index"])
    usage = sealed.get("usage")
    if usage not in READINGS:
        out.append("the print's usage of ij is not sealed")
        return out
    seen = {}
    decisive = 0
    for st in sealed["stretches"]:
        rows = notes_by_voice.get(st["voice"], [])
        first, count = st["first"], st["count"]
        notes = rows[first:first + count]
        if len(notes) != count or any(n["pitch"] == "rest" for n in notes):
            out.append("%s@%d: the stretch is not %d sounding notes" % (st["voice"], first, count))
            continue
        if first > 0 and rows[first - 1]["pitch"] != "rest":
            out.append("%s@%d: no rest before the stretch" % (st["voice"], first))
        if first + count < len(rows) and rows[first + count]["pitch"] != "rest":
            out.append("%s@%d: no rest after the stretch" % (st["voice"], first))
        syllables = [poem[i] for i in st["syllables"]]
        expect = [s for ph in st["phrases"] for s in by_phrase[(st["line"], ph)]]
        if [s["index"] for s in expect] != st["syllables"]:
            out.append("%s@%d: the sealed syllables are not the sealed phrases" % (st["voice"], first))
        got = reckon_stretch(notes, syllables)
        if got is None:
            out.append("%s@%d: the practice does not place the stretch uniquely" % (st["voice"], first))
            continue
        placement, concession = got
        if [first + p for p in placement] != st["starts"] or concession != st["concession"]:
            out.append("%s@%d: the practice places the stretch otherwise" % (st["voice"], first))
        if concession and not settled_under_every_reading(notes, syllables, placement):
            out.append("%s@%d: another reading of the concession places the stretch otherwise" % (st["voice"], first))
        if st["kind"] == "ij":
            if anchors.get((st["voice"], first)) != "ij":
                out.append("%s@%d: no ij printed" % (st["voice"], first))
            reading = "line" if st["phrases"] == ["a", "b"] else "phrase"
            if reading != usage:
                out.append("%s@%d: ij does not follow the print's usage" % (st["voice"], first))
            other = by_phrase[(st["line"], "b")] if reading == "line" else by_phrase[(st["line"], "a")] + by_phrase[(st["line"], "b")]
            fits = other_fits(notes, other)
            if st["decisive"] and fits != 0:
                out.append("%s@%d: a decisive ij also carries the other reading" % (st["voice"], first))
            if not st["decisive"] and fits != 1:
                out.append("%s@%d: an ambiguous ij does not carry the other reading in one way" % (st["voice"], first))
            decisive += bool(st["decisive"])
            prev = seen.get(st["voice"])
            if prev is None or prev["line"] != st["line"] or prev["phrases"][-1] != "b":
                out.append("%s@%d: ij does not follow the line it repeats" % (st["voice"], first))
        else:
            pos = 0
            for ph in st["phrases"]:
                note = first + placement[pos]
                if anchors.get((st["voice"], note)) != str(by_phrase[(st["line"], ph)][0]["index"]):
                    out.append("%s@%d: phrase %d%s is not anchored at its first note" % (st["voice"], first, st["line"], ph))
                pos += len(by_phrase[(st["line"], ph)])
            inside = [k for k in anchors if k[0] == st["voice"] and first <= k[1] < first + count]
            if len(inside) != len(st["phrases"]):
                out.append("%s@%d: %d anchors for %d phrases" % (st["voice"], first, len(inside), len(st["phrases"])))
        seen[st["voice"]] = st
    if decisive < 3:
        out.append("only %d decisive ij signs settle the print's usage" % decisive)
    return out


def reckon(sealed, poem, notes_by_voice):
    """The key the sealed stretches imply: (voice, note) -> syllable index or '-' for every
    sounding note, with every ij read by the usage its decisive signs force."""
    by_phrase = {}
    for s in poem.values():
        by_phrase.setdefault((s["line"], s["phrase"]), []).append(s)
    for key in by_phrase:
        by_phrase[key].sort(key=lambda s: s["index"])
    votes = {r: 0 for r in READINGS}
    for st in sealed["stretches"]:
        if st["kind"] != "ij":
            continue
        notes = notes_by_voice[st["voice"]][st["first"]:st["first"] + st["count"]]
        texts = {"phrase": by_phrase[(st["line"], "b")],
                 "line": by_phrase[(st["line"], "a")] + by_phrase[(st["line"], "b")]}
        fits = {r: reckon_stretch(notes, t) is not None for r, t in texts.items()}
        if sum(fits.values()) == 1:
            votes[next(r for r, ok in fits.items() if ok)] += 1
    usage = max(READINGS, key=lambda r: votes[r])
    starts = {}
    for st in sealed["stretches"]:
        rows = notes_by_voice[st["voice"]]
        notes = rows[st["first"]:st["first"] + st["count"]]
        if st["kind"] == "ij":
            syllables = (by_phrase[(st["line"], "b")] if usage == "phrase"
                         else by_phrase[(st["line"], "a")] + by_phrase[(st["line"], "b")])
        else:
            syllables = [poem[i] for i in st["syllables"]]
        got = reckon_stretch(notes, syllables)
        if got is None:
            continue
        for p, s in zip(got[0], syllables):
            starts[(st["voice"], st["first"] + p)] = str(s["index"])
    key = {}
    for voice, rows in notes_by_voice.items():
        for n, r in enumerate(rows):
            if r["pitch"] != "rest":
                key[(voice, n)] = starts.get((voice, n), "-")
    return key
