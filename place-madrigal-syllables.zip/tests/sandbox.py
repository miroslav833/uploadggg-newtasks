"""A sandbox for the uploaded placement program.

Each held madrigal is copied into a folder owned by an account made up for the run; the program
is started there as that account (no supplementary groups), in its own session, under a shell that
caps its address space, file size and core dumps, and with a wall-clock limit. When it is over,
every process of the account is killed and the folder is read back: the placement counts only if
it is a regular file of modest size, opened without following links, and it is parsed as text and
nothing more.
"""
import csv
import os
import shutil
import signal
import subprocess
import time

PIECES = "/tests/edition/pieces"
LOGS = "/run/verifier"
POOL = "/var/tmp/office"
TOOL = "/app/underlay/place.py"
SECONDS = 60
MOST_BYTES = 512 * 1024
FIRST_UID = 58000
LIMITS = "ulimit -v 1048576 -f 8192 -c 0"


class Sandbox:
    def __init__(self):
        self.uid = self._fresh_uid()

    @staticmethod
    def _fresh_uid():
        busy = set()
        for entry in os.scandir("/proc"):
            if entry.name.isdigit():
                try:
                    busy.add(entry.stat().st_uid)
                except OSError:
                    continue
        uid = FIRST_UID
        while uid in busy:
            uid += 1
        return uid

    def _reap(self):
        for _ in range(300):
            mine = []
            for entry in os.scandir("/proc"):
                if entry.name.isdigit():
                    try:
                        if entry.stat().st_uid == self.uid:
                            mine.append(int(entry.name))
                    except OSError:
                        continue
            if not mine:
                return
            for pid in mine:
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass
            time.sleep(0.03)

    def _own(self, path):
        os.chown(path, self.uid, self.uid)
        for root, dirs, files in os.walk(path):
            for name in dirs + files:
                os.chown(os.path.join(root, name), self.uid, self.uid)

    def run(self, code):
        """Runs the tool on one madrigal and returns what it filed: {(voice, note): syllable}."""
        folder = os.path.join(POOL, code)
        shutil.rmtree(folder, ignore_errors=True)
        piece = os.path.join(folder, "madrigal")
        home = os.path.join(folder, "home")
        shutil.copytree(os.path.join(PIECES, code), piece, symlinks=False)
        os.makedirs(home)
        self._own(folder)
        result = os.path.join(folder, "placement.csv")
        command = "%s; exec python3 %s %s %s" % (LIMITS, TOOL, piece, result)
        environment = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8"}
        with open(os.path.join(LOGS, code + ".log"), "wb") as log:
            try:
                subprocess.run(["bash", "-c", command], user=self.uid, group=self.uid, extra_groups=[],
                               cwd=home, env=environment, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                               start_new_session=True, timeout=SECONDS, check=False)
            except subprocess.TimeoutExpired:
                log.write(b"\n[the tool was stopped at the time limit]\n")
        self._reap()
        filed = read_back(result)
        shutil.rmtree(folder, ignore_errors=True)
        return filed


def read_back(path):
    """{(voice, note): syllable} from a filed placement; anything that does not parse is dropped."""
    try:
        if os.path.islink(path) or not os.path.isfile(path) or os.lstat(path).st_size > MOST_BYTES:
            return {}
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return {}
    with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
        body = fh.read(MOST_BYTES + 1)
    if len(body) > MOST_BYTES:
        return {}
    filed = {}
    for row in csv.DictReader(body.splitlines()):
        voice = (row.get("voice") or "").strip()
        note = (row.get("note") or "").strip()
        syllable = (row.get("syllable") or "").strip()
        if voice and note.isdigit() and syllable:
            filed.setdefault((voice, int(note)), syllable)
    return filed


def held_pieces():
    return sorted(os.listdir(PIECES))
