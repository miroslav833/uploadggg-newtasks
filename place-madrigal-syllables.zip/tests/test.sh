#!/usr/bin/env bash
# The verifier's entry point.
#
# Order of business: the reward channel is shut first (/logs/verifier becomes root-only, every
# reward-looking file in it goes, reward.txt reads 0), then the two tests run with the tool inside
# the sandbox, then the channel is cleaned once more and reward.txt is written for the last time:
# 1 if and only if both tests passed.
set -u

CHANNEL=/logs/verifier
WORKLOGS=/run/verifier
TOOLDIR=/app/underlay

mkdir -p "$CHANNEL"
original_mode="$(stat -c %a "$CHANNEL" 2>/dev/null || echo 755)"
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier 2>/dev/null

sweep() {
    # anything reward-shaped, and anything root did not write, goes
    find "$CHANNEL" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
    find "$CHANNEL" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    rm -f /logs/verifier/reward.json
}

write_reward() {
    sweep
    (umask 022; printf '%s\n' "$1" > "$CHANNEL/reward.txt")
}

cleanup() {
    chmod "$original_mode" "$CHANNEL" 2>/dev/null
    exit 0
}
trap cleanup EXIT

write_reward 0
case "$(stat -c '%u:%a' /logs/verifier 2>/dev/null)" in
    0:700) ;;
    *) echo "verifier: $CHANNEL is not root-only, so nothing is graded" >&2; exit 0 ;;
esac

chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$WORKLOGS" && chown 0:0 "$WORKLOGS" && chmod 700 "$WORKLOGS"
mkdir -p /var/tmp/office && chmod 755 /var/tmp/office
chmod -R a+rX "$TOOLDIR" 2>/dev/null

verdict=0
( cd /tests && python3 -m pytest test_edition.py -q -p no:cacheprovider --ctrf "$WORKLOGS/ctrf.json" ) && verdict=1
write_reward "$verdict"
for report in ctrf.json tally.json; do
    if [ -f "$WORKLOGS/$report" ]; then
        (umask 022; cp "$WORKLOGS/$report" "$CHANNEL/$report")
    fi
done
