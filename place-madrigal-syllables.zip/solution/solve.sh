#!/bin/bash
# Installs the placement program where the grader expects it and runs it over the three sample
# madrigals, reporting how many notes it places as the editors placed them.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/underlay /app/out
cp "$HERE/underlay/place.py" /app/underlay/place.py
for piece in /app/edition/placed/*/; do
    code="$(basename "$piece")"
    python3 /app/underlay/place.py "$piece" "/app/out/$code.csv"
    python3 - "$piece/placement.csv" "/app/out/$code.csv" "$code" <<'PY'
import csv, sys
want = {(r["voice"], r["note"]): r["syllable"] for r in csv.DictReader(open(sys.argv[1]))}
got = {(r["voice"], r["note"]): r["syllable"] for r in csv.DictReader(open(sys.argv[2]))}
agree = sum(1 for k, v in want.items() if got.get(k) == v)
print("%s: %d of %d notes placed as the editors placed them" % (sys.argv[3], agree, len(want)))
PY
done
