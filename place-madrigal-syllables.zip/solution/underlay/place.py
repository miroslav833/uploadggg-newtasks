#!/usr/bin/env python3
"""Places the text of a madrigal under the notes of every voice.

    python3 place.py PIECE_DIR OUT_CSV

The print anchors a phrase's first syllable under its note and runs the rest on; ij marks the
text just sung being sung again. Each stretch between rests carries its anchored phrases (or the
repeat) and is placed under the practice: a ligature takes one syllable; no syllable begins on the
note after a dot, on a semiminim or on the note after one, unless the stretch cannot otherwise be
placed, in which case semiminims take syllables; a repeated note begins a new syllable; an
unaccented syllable takes one note or one ligature; the last syllable falls on the last note. A
repeat sign reaches the last phrase, or the whole verse line when the notes cannot carry the phrase
alone.
"""
import csv
import os
import sys

SHORT = ("semiminim", "fusa")
REACH_ORDER = ("phrase", "line")      # what ij is tried as, in order


def read(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def units_of(notes):
    """Ligature groups and single notes as lists of note positions."""
    units, i = [], 0
    while i < len(notes):
        j = i
        if notes[i]["ligature"]:
            while j + 1 < len(notes) and notes[j + 1]["ligature"] == notes[i]["ligature"]:
                j += 1
        units.append(list(range(i, j + 1)))
        i = j + 1
    return units


def may_begin(notes, i, concession):
    """Whether note i (first of its unit) may begin a syllable."""
    if i == 0:
        return True
    n, p = notes[i], notes[i - 1]
    if p["dot"] == "1":
        return False
    if n["value"] == "fusa" or p["value"] == "fusa":
        return False
    if (n["value"] == "semiminim" or p["value"] == "semiminim") and not concession:
        return False
    return True


def must_begin(notes, i):
    return i > 0 and notes[i]["pitch"] == notes[i - 1]["pitch"]


def placements(notes, syllables, concession, limit=2):
    """Placements of the syllables on the stretch's notes: for each syllable, the position of the
    note it begins on. At most `limit` are returned."""
    units = units_of(notes)
    firsts = [u[0] for u in units]
    allowed = [may_begin(notes, f, concession) for f in firsts]
    forced = [must_begin(notes, f) for f in firsts]
    found = []
    s, m = len(syllables), len(units)

    def extend(j, u, chosen):
        if len(found) >= limit:
            return
        if j == s:
            if u == m:
                found.append(list(chosen))
            return
        if u >= m or not allowed[u]:
            return
        last = j == s - 1
        most = 1 if (last or not syllables[j]["accent"]) else m - u
        for k in range(1, most + 1):
            if any(forced[v] for v in range(u + 1, u + k)):
                break
            if last and u + k != m:
                continue
            chosen.append(firsts[u])
            extend(j + 1, u + k, chosen)
            chosen.pop()

    extend(0, 0, [])
    return found


def best_placement(notes, syllables):
    """The one placement the practice admits: strict first, then with the concession."""
    for concession in (False, True):
        found = placements(notes, syllables, concession)
        if found:
            return found[0]
    return None


def syllabic_fallback(notes, syllables):
    """When nothing places (never on a well-formed stretch): one syllable per unit as far as they go."""
    units = units_of(notes)
    return [units[min(j, len(units) - 1)][0] for j in range(len(syllables))]


def solve(piece_dir):
    text = read(os.path.join(piece_dir, "text.csv"))
    for t in text:
        t["accent"] = int(t["accent"])
        t["syllable"] = int(t["syllable"])
    by_index = {t["syllable"]: t for t in text}
    phrase_of = {}
    for t in text:
        phrase_of.setdefault((int(t["line"]), t["phrase"]), []).append(t)
    notes = read(os.path.join(piece_dir, "notes.csv"))
    anchors = {}
    for r in read(os.path.join(piece_dir, "print.csv")):
        anchors[(r["voice"], int(r["note"]))] = r["text"]
    voices = {}
    for n in notes:
        voices.setdefault(n["voice"], []).append(n)
    out = []
    for voice, rows in voices.items():
        rows.sort(key=lambda r: int(r["note"]))
        # stretches between rests
        stretches, cur = [], []
        for r in rows:
            if r["pitch"] == "rest":
                if cur:
                    stretches.append(cur)
                cur = []
            else:
                cur.append(r)
        if cur:
            stretches.append(cur)
        last_phrases = []                       # the phrases of the previous stretch
        filed = {}
        for st in stretches:
            positions = [int(r["note"]) for r in st]
            marks = [(positions.index(p), anchors[(voice, p)]) for p in positions if (voice, p) in anchors]
            if marks and marks[0][1] == "ij":
                # the text just sung again: the last phrase, or its whole line
                readings = {"phrase": [], "line": []}
                if last_phrases:
                    line, ph = last_phrases[-1]
                    readings["phrase"] = [(line, ph)]
                    readings["line"] = [(line, "a"), (line, "b")]
                placed, phrases = None, []
                for reach in REACH_ORDER:
                    phrases = readings[reach]
                    if not phrases:
                        continue
                    syllables = [s for key in phrases for s in phrase_of[key]]
                    placed = best_placement(st, syllables)
                    if placed is not None:
                        break
                if placed is None:
                    phrases = readings["phrase"]
                    syllables = [s for key in phrases for s in phrase_of[key]]
                    placed = syllabic_fallback(st, syllables)
            else:
                phrases = []
                for _, token in marks:
                    t = by_index[int(token)]
                    phrases.append((int(t["line"]), t["phrase"]))
                syllables = [s for key in phrases for s in phrase_of[key]]
                placed = best_placement(st, syllables) if syllables else []
                if placed is None:
                    placed = syllabic_fallback(st, syllables)
            for pos, syl in zip(placed, syllables):
                filed[int(st[pos]["note"])] = syl["syllable"]
            if phrases:
                last_phrases = phrases
        for r in rows:
            if r["pitch"] == "rest":
                continue
            i = int(r["note"])
            out.append((voice, i, str(filed[i]) if i in filed else "-"))
    return out


def main():
    rows = solve(sys.argv[1])
    os.makedirs(os.path.dirname(os.path.abspath(sys.argv[2])), exist_ok=True)
    with open(sys.argv[2], "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["voice", "note", "syllable"])
        for voice, note, syl in rows:
            w.writerow([voice, note, syl])


if __name__ == "__main__":
    main()
