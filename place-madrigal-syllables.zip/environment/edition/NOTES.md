# Madrigal partbooks: sources, encoding and the printed text

## The project

The edition prepares madrigals from sixteenth-century printed partbooks for performance. A
partbook gives one voice: its notes on the staff and, in a line beneath, the words of the poem as
the compositor set them. Before the edition can print a voice, every syllable has to sit under
its note, and the program this handbook accompanies does that placement for every voice of a
piece.

Three madrigals were placed in full by the editors and ship as they stand. Every other piece in
the project is encoded from its partbooks exactly as printed, with the text as the compositor
left it.

## The poem

`text.csv` gives the poem one syllable per row, in order:

```
syllable,line,phrase,word,text,accent
0,1,a,so-a-ve,so,0
1,1,a,so-a-ve,a,1
2,1,a,so-a-ve,ve,0
3,1,b,cru-del,cru,0
```

`syllable` numbers the syllables of the whole poem from 0. Each verse line is in two phrases, `a`
and `b`, which the poem's own punctuation and metre divide. `word` is the whole word with its
syllables marked off, `text` is this syllable, and `accent` is 1 on the syllable that carries the
word's stress; clitics (articles, particles, prepositions) carry none.

## The notes

`notes.csv` gives every voice's notes in order, rests included:

```
voice,note,pitch,value,dot,ligature
C,0,b4,minim,0,L1
C,1,c5,minim,0,L1
C,2,b4,semibreve,0,L1
C,3,c5,semibreve,0,
C,5,rest,minim,0,
```

`voice` is the partbook (C cantus, A altus, Q quintus, T tenor, B bassus) and `note` numbers its
rows from 0. `pitch` is a letter with its octave (c4 is middle C), or `rest`. `value` is the note
shape as printed: breve, semibreve, minim, semiminim or fusa, each half the one before. `dot` is 1
when the shape carries a dot of augmentation. Notes printed bound together in a ligature share a
`ligature` label; the label is empty on notes printed singly.

## The printed text

`print.csv` records where the compositor put the words:

```
voice,note,text
C,0,0
C,6,3
C,13,ij
```

A row with a syllable number says that the compositor set that syllable, the first of a phrase,
under that note, and ran the rest of the phrase on along the line without aligning it to notes. A
row with `ij` says that the compositor set that sign under that note, in the usual way of the
printing houses: the text just sung is sung again from there, the words not being printed a second
time.

Every stretch of notes between rests carries text: the phrases whose first syllables are set under
its notes, or the repeat the sign marks. A rest ends a phrase.

## The placements

`placement.csv`, in the three placed madrigals, gives for every sounding note of every voice the
syllable it begins, or `-` where it continues the syllable begun before it:

```
voice,note,syllable
C,0,0
C,1,-
C,2,-
C,3,1
```

Rests have no row.
