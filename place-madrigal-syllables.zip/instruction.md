Put the words of a madrigal under its notes, voice by voice. We call the program like this:

```
python3 /app/underlay/place.py PIECE_DIR OUT_CSV
```

Inside PIECE_DIR you will find `text.csv` (the poem, one syllable a row, with its line, phrase, word and accent), `notes.csv` (each voice's notes and rests in order, with pitch, shape, dot and ligature label) and `print.csv` (which notes the compositor set the first syllable of each phrase under, and which notes carry the sign `ij`). `/app/edition/NOTES.md` explains the encoding and the compositor's way of setting text, and `/app/edition/placed` has three pieces the editors placed in full.

Write OUT_CSV with a header and one row per sounding note in every voice. The third field is the number of the syllable that note begins, or `-` if the note carries on a syllable already begun:

```
voice,note,syllable
C,3,1
C,4,-
```

Leave rests out. Between one rest and the next, a voice sings the phrases whose first syllables the compositor set there, or, under `ij`, sings once more what it has just sung; each syllable of that text begins on some note of the stretch, in order, where an editor of the period's partbooks would put it. When `ij` stands for more than the last phrase, how many notes come after it tells you how much.

A note scores if its row agrees with ours; a missing row, or one that cannot be read, scores nothing.

We judge on twenty other madrigals, not shipped, whose phrases, ligatures, note shapes and repeat signs reach further than the three samples. A madrigal is good if no more than 2 of its notes are off; we need 18 good madrigals of the 20. Each one runs alone, in 60 seconds, on a fresh copy of its folder, as an ordinary user with python3 and the standard library and nothing more. Anything your program needs besides itself must live under `/app/underlay`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
