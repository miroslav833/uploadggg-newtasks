# The harp studio: pedalling record and files

The conservatoire's harp studio gives every student a pedalled copy of each piece set for the term.
A piece comes to the studio as a list of notes, rests and glissandi exported from the notation
system, with its metre and the key signature of every section. The professor pedals the first page
of each piece herself, bars 1 to 12: she writes the pre-set diagram and every pedal change on that
page. The remaining bars are pedalled to match what she wrote. This guide describes the instrument
as the record treats it, how a pedalling is written, what a piece folder holds, and the tool the
studio needs.

## The instrument as the record treats it

A pedal harp has seven pedals, one for each letter name. The left foot works D, C and B; the right foot
works E, F, G and A. Each pedal stands in one of three positions, flat, natural or sharp, and sets every
string of its letter, in every octave, to that pitch. A string sounds only the pitch its pedal gives
it, so a written note is taken either on the string of its own letter, with that pedal in the written
position, or on the neighbouring string whose pedal is set to the same pitch, where one exists (C flat
on the B string, E sharp on the F string, F sharp on the G string set flat, and so on). Which string
takes a note is the harpist's choice; the record does not say.

The record holds a string to sound for the written duration of its note and to be free from the
moment the note ends. A pedal is never moved while a string of its letter sounds. A foot moves one
pedal at a time; the two feet may move together.

A glissando runs over every string. Its pedals are set so that every string sounds a note of the
written scale, with as many different notes as the seven strings allow (a pentatonic glissando sounds
five, two of them twice).

## How a pedalling is written

A change is written as the bar, the position in the bar, the pedal's letter and the position it is
moved to. The position is that of an event of the piece (a note, a chord, a rest or a glissando), and
the pedal is moved as that event begins. A diagram writes the position of all seven pedals at one
event, as seven rows at the same bar and position; the pre-set diagram stands at bar 0, position 0,
and gives the position every pedal is in before the first bar. A glissando is always written with
its diagram at its own onset. Harpists write diagrams at other points too, as their own practice has
it, and differ in that as they differ in where a change is placed within the time the string is free,
in whether a note is taken on the neighbouring string to spare a change, in what they write at a
change of key signature and after a glissando, and in what they write at a rest. The studio keeps no
list of the professor's preferences; her practice shows in the pages she has pedalled.

## What a piece folder holds

`PART.md`, for example:

```
# Part S01

- Pedalled by: N586
- Bars: 45
- Metre: 3/4
- Sections:
  - bars 1 to 6: 4 sharps
  - bars 7 to 22: no sharps or flats
  - bars 23 to 33: 4 flats
  - bars 34 to 45: no sharps or flats
- Marked by hand: bars 1 to 12
```

`notes.tsv` lists every event of the piece: `bar` from 1, `position` as a fraction of a whole note
from the start of the bar, `duration` as a fraction of a whole note, `kind` as `note`, `rest` or
`gliss`, and `pitch` as a letter with its accidental and octave (`C4` is middle C; `G#4`, `Bb3`,
`E#5`, `Fb5` are written as they stand in the piece), `-` for a rest, or the scale of a glissando such
as `gliss:C-pentatonic`, `gliss:Ab-major` or `gliss:B-minor` (a harmonic minor). The notes of a chord
appear as several rows at one bar and position, each with its own duration; a bass note may sound on
under later events:

```
bar	position	duration	kind	pitch
8	0	1/4	note	G3
8	0	1/4	note	G4
8	0	1/4	note	B4
8	0	1/4	note	D5
8	1/4	1/4	gliss	gliss:C-pentatonic
8	1/2	1/4	note	F3
8	1/2	1/4	note	F4
8	1/2	1/4	note	A4
```

`hand.tsv` is the professor's pedalling of the first page: the pre-set diagram at bar 0 and every
change and diagram in the bars the `Marked by hand` line names, one row per pedal moved, with `bar`,
`position`, `pedal` and `to`:

```
bar	position	pedal	to
0	0	C	sharp
0	0	D	sharp
0	0	E	natural
0	0	F	sharp
0	0	G	sharp
0	0	A	natural
0	0	B	natural
2	1/8	G	natural
2	5/8	G	sharp
3	1/4	F	natural
```

The three example pieces also carry `truth.tsv`, her changes and diagrams for every bar after the
marked page, in the same form.

## The tool

The studio runs `python3 /app/harpist/changes.py PART_DIR OUT_TSV` once per piece. The tool writes
`OUT_TSV` with one row per pedal moved in every bar after the marked page, diagrams as seven rows, in
time order:

```
bar	position	pedal	to
14	3/8	E	flat
15	1/4	D	sharp
15	1/2	E	natural
```

The tool runs under the image's python3 with the standard library only, with no network access.
