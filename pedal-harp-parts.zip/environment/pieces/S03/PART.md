# Part S03

- Pedalled by: N346
- Bars: 48
- Metre: 4/4
- Sections:
  - bars 1 to 6: 3 flats
  - bars 7 to 19: 4 flats
  - bars 20 to 33: 2 flats
  - bars 34 to 48: 1 sharp
- Marked by hand: bars 1 to 12
