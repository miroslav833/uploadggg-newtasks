# Part S02

- Pedalled by: K802
- Bars: 51
- Metre: 3/4
- Sections:
  - bars 1 to 6: 4 sharps
  - bars 7 to 25: 2 sharps
  - bars 26 to 51: 1 sharp
- Marked by hand: bars 1 to 12
