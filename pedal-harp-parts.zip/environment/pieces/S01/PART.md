# Part S01

- Pedalled by: N586
- Bars: 45
- Metre: 3/4
- Sections:
  - bars 1 to 6: 4 sharps
  - bars 7 to 22: no sharps or flats
  - bars 23 to 33: 4 flats
  - bars 34 to 45: no sharps or flats
- Marked by hand: bars 1 to 12
