I run the harp studio at a conservatoire. For every piece we set, the professor pedals the first page herself and the studio then has to pedal the remaining pages the way she would, before the students get their copies. I would like a tool to do that second step. Write /app/harpist/changes.py, called as

```
python3 /app/harpist/changes.py PART_DIR OUT_TSV
```

PART_DIR holds PART.md (metre, sections with their key signatures, which bars she pedalled), notes.tsv (every note, rest and glissando) and hand.tsv (her pre-set diagram and every pedal change she wrote on that page). The layout of the files, how the record treats the instrument and how a pedalling is written are in /app/studio/GUIDE.md. Three pieces she has already pedalled from start to end are in /app/pieces; each has a truth.tsv with her changes for all the bars after the marked page, so you can compare your output with hers.

OUT_TSV starts with a line naming four tab-separated columns, bar, position, pedal and to, and then has a row for every pedal moved in the bars after the marked page, in time order, a diagram being seven rows at the same position. A row looks like `14	3/8	E	flat`: the pedal is a letter from A to G and the last column is flat, natural or sharp.

Your tool will be scored on 20 more pieces from the studio, generated inside the scoring image where you cannot see them, and the harpists who pedalled their first pages do not all work the way the three example pieces show. A piece is right when your rows and the harpist's differ by no more than 2 rows in total, counting rows of hers you lack together with rows you add that she did not write. A file that cannot be parsed scores nothing for its piece. Eighteen of the twenty pieces have to come out right.

Each run gets a fresh copy of the piece folder and is started by an unprivileged user with the image's python3, the standard library only, and 120 seconds. Only /app/harpist is kept for scoring, so keep everything the tool needs in there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
