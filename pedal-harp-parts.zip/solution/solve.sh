#!/bin/bash
# Installs the reference pedalling program at /app/harpist and runs it on the three example pieces,
# checking its rows against each piece's truth.tsv.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/harpist /app/out
cp "$HERE/harpist/changes.py" /app/harpist/changes.py
for part in /app/pieces/*/; do
  name="$(basename "$part")"
  python3 /app/harpist/changes.py "$part" "/app/out/$name.tsv"
  python3 - "$part/truth.tsv" "/app/out/$name.tsv" <<'EOF'
import csv, sys
from collections import Counter
def load(p):
    return Counter((r["bar"], r["position"], r["pedal"], r["to"]) for r in csv.DictReader(open(p), delimiter="\t"))
want, got = load(sys.argv[1]), load(sys.argv[2])
missing, extra = sum((want - got).values()), sum((got - want).values())
print("%s: %d rows, %d missing, %d extra" % (sys.argv[2], sum(want.values()), missing, extra))
EOF
done
