"""Pedal changes for the bars of a harp part the editor did not mark by hand.

    python3 changes.py PART_DIR OUT_TSV

The part is read from PART_DIR (PART.md, notes.tsv, hand.tsv). The editor's habits are not written
anywhere: the program tries every combination of the respects in which harp editors differ, plans the
whole part under each, keeps the combinations whose plan reproduces every row of hand.tsv, and writes the
plan of the simplest of them for the bars after the marked page.

What the plan holds fixed (the instrument and the record): seven pedals, D C B for the left foot and
E F G A for the right, each flat, natural or sharp and setting every string of its letter; a string
sounds for its note's written duration and is free when it ends; a pedal is never moved while a string
of its letter sounds; a change is written at the onset of an event and made as that event begins; one
pedal per foot per onset, the two feet together if need be; a glissando is written with the diagram
of its scale at its onset, every string sounding a note of the scale and as many different notes as
the strings allow; a note may be taken on the neighbouring string set to the same pitch.

What differs between editors (the habits searched):
  placement    where in its window a change goes: early (first onset after the string is free),
               late (the needing note), rest-early / rest-late (the first / last rest of the window,
               else early / late);
  substitution spare (take the neighbouring string whenever it already stands right and the own
               string would need a change) or forced (own string unless it cannot be changed in time);
  key_change   diagram (the new signature written as a diagram at the section's first onset) or lazy;
  gliss_return diagram (the signature written at the first onset after a glissando) or lazy;
  rests        cleanup (at a rest, a diagram setting every pedal for its next written need and the
               rest to the signature, written when something moves) or lazy.
"""
import csv
import os
import re
import sys
from collections import Counter
from fractions import Fraction as Fr
from itertools import product

LETTERS = "CDEFGAB"
SEMI = dict(C=0, D=2, E=4, F=5, G=7, A=9, B=11)
FOOT = {l: ("L" if l in "DCB" else "R") for l in LETTERS}
WORD = {-1: "flat", 0: "natural", 1: "sharp"}
ACC_OF = {"flat": -1, "natural": 0, "sharp": 1}
MODES = {"major": (0, 2, 4, 5, 7, 9, 11), "minor": (0, 2, 3, 5, 7, 8, 11),
         "pentatonic": (0, 2, 4, 7, 9), "diminished": (0, 3, 6, 9)}
HABITS = [("placement", ["late", "early", "rest-early", "rest-late"]),
          ("substitution", ["forced", "spare"]),
          ("key_change", ["lazy", "diagram"]),
          ("gliss_return", ["lazy", "diagram"]),
          ("rests", ["lazy", "cleanup"])]


class Stuck(Exception):
    pass


# ------------------------------------------------------------------ pitches and settings
def parse(text):
    acc = 1 if "#" in text else (-1 if "b" in text[1:] else 0)
    return text[0], acc, int(text[-1])


def pc(letter, acc):
    return (SEMI[letter] + acc) % 12


def neighbour(letter, acc):
    """The neighbouring string that sounds the same pitch, as (letter, acc), or None."""
    i = LETTERS.index(letter)
    for other in (LETTERS[(i - 1) % 7], LETTERS[(i + 1) % 7]):
        d = (pc(letter, acc) - SEMI[other] + 6) % 12 - 6
        if -1 <= d <= 1:
            return other, d
    return None


def signature(n):
    st = {l: 0 for l in LETTERS}
    for l in ("FCGDAEB"[:n] if n > 0 else "BEADGCF"[:-n] if n < 0 else ""):
        st[l] = 1 if n > 0 else -1
    return st


_scales = {}


def scale_setting(spec):
    if spec not in _scales:
        root, mode = spec.split("-")
        rl, ra, _ = parse(root + "4")
        wanted = {(pc(rl, ra) + s) % 12 for s in MODES[mode]}
        best, best_n = None, -1
        for accs in product((-1, 0, 1), repeat=7):
            tones = [pc(l, a) for l, a in zip(LETTERS, accs)]
            if all(t in wanted for t in tones) and len(set(tones)) > best_n:
                best, best_n = dict(zip(LETTERS, accs)), len(set(tones))
        _scales[spec] = best
    return _scales[spec]


# ------------------------------------------------------------------ the part
class Part:
    def __init__(self, folder):
        self.sections, self.hand_last, self.metre = [], 0, (4, 4)
        with open(os.path.join(folder, "PART.md"), encoding="utf-8") as fh:
            for line in fh:
                m = re.match(r"\s*- bars (\d+) to (\d+): (.*)", line)
                if m:
                    words = m.group(3).strip()
                    n = int(words.split()[0]) * (1 if "sharp" in words else -1) if words[0].isdigit() else 0
                    self.sections.append((int(m.group(1)), int(m.group(2)), n))
                m = re.match(r"\s*- Marked by hand: bars 1 to (\d+)", line)
                if m:
                    self.hand_last = int(m.group(1))
                m = re.match(r"\s*- Metre: (\d+)/(\d+)", line)
                if m:
                    self.metre = (int(m.group(1)), int(m.group(2)))
        self.barlen = Fr(self.metre[0], self.metre[1])
        self.events = []
        with open(os.path.join(folder, "notes.tsv"), encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh, delimiter="\t"):
                t = (int(row["bar"]) - 1) * self.barlen + Fr(row["position"])
                self.events.append(dict(t=t, dur=Fr(row["duration"]), kind=row["kind"], pitch=row["pitch"]))
        self.hand = Counter()
        with open(os.path.join(folder, "hand.tsv"), encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh, delimiter="\t"):
                self.hand[(int(row["bar"]), row["position"], row["pedal"], row["to"])] += 1
        self.onsets = sorted({e["t"] for e in self.events})
        self.at = {t: [e for e in self.events if e["t"] == t] for t in self.onsets}
        self.rests = {t for t in self.onsets if all(e["kind"] == "rest" for e in self.at[t])}
        self.starts = {(a - 1) * self.barlen for a, b, n in self.sections[1:]}
        self.written = {l: [] for l in LETTERS}
        for e in self.events:
            if e["kind"] == "note":
                l, a, _ = parse(e["pitch"])
                self.written[l].append((e["t"], a))
            elif e["kind"] == "gliss":
                st = scale_setting(e["pitch"][6:])
                for l in LETTERS:
                    self.written[l].append((e["t"], st[l]))
        for l in LETTERS:
            self.written[l].sort()

    def key_at(self, t):
        bar = int(t // self.barlen) + 1
        for a, b, n in self.sections:
            if a <= bar <= b:
                return n
        raise KeyError(bar)

    def next_written(self, l, t):
        for tt, a in self.written[l]:
            if tt > t:
                return a
        return None

    def bar_pos(self, t):
        bar = int(t // self.barlen) + 1
        p = t - (bar - 1) * self.barlen
        return bar, ("%d/%d" % (p.numerator, p.denominator) if p.denominator != 1 else str(p.numerator))


# ------------------------------------------------------------------ the plan under one set of habits
def plan(part, h):
    """Counter of (bar, position, pedal, to) rows, the pre-set diagram at bar 0 included."""
    rows = Counter()
    state = signature(part.sections[0][2])
    for l in LETTERS:
        if part.written[l]:
            state[l] = part.written[l][0][1]
    for l in LETTERS:
        rows[(0, "0", l, WORD[state[l]])] += 1
    free = {l: Fr(0) for l in LETTERS}
    set_at = {l: Fr(-1) for l in LETTERS}
    foot_at = set()
    diagrams = set()

    def emit(t, l, a):
        bar, p = part.bar_pos(t)
        rows[(bar, p, l, WORD[a])] += 1

    def diagram(t, target):
        for l in LETTERS:
            if target[l] != state[l] and free[l] > t:
                raise Stuck()
        for l in LETTERS:
            emit(t, l, target[l])
            state[l] = target[l]
            set_at[l] = t
        diagrams.add(t)
        foot_at.update({(t, "L"), (t, "R")})

    def window(l, t):
        if free[l] > t:
            return []
        return [u for u in part.onsets if free[l] <= u <= t and u > set_at[l] and (u, FOOT[l]) not in foot_at]

    def move(l, a, t):
        w = window(l, t)
        if not w:
            raise Stuck()
        r = [u for u in w if u in part.rests]
        u = {"early": w[0], "late": w[-1], "rest-early": r[0] if r else w[0],
             "rest-late": r[-1] if r else w[-1]}[h["placement"]]
        emit(u, l, a)
        state[l] = a
        set_at[l] = u
        foot_at.add((u, FOOT[l]))

    gliss_end = None
    for t in part.onsets:
        sig = signature(part.key_at(t))
        if t in part.starts and h["key_change"] == "diagram":
            diagram(t, sig)
        gl = [e for e in part.at[t] if e["kind"] == "gliss"]
        if gl:
            diagram(t, scale_setting(gl[0]["pitch"][6:]))
            for l in LETTERS:
                free[l] = max(free[l], t + gl[0]["dur"])
            gliss_end = t + gl[0]["dur"]
            continue
        if gliss_end is not None and t >= gliss_end:
            gliss_end = None
            if h["gliss_return"] == "diagram" and t not in diagrams:
                diagram(t, sig)
        if t in part.rests and h["rests"] == "cleanup" and t not in diagrams:
            target = {l: (sig[l] if part.next_written(l, t) is None else part.next_written(l, t)) for l in LETTERS}
            if target != state:
                diagram(t, target)
        notes = [e for e in part.at[t] if e["kind"] == "note"]
        if not notes:
            continue
        spelt = {}
        for e in notes:
            l, a, o = parse(e["pitch"])
            spelt.setdefault(l, set()).add(a)
        if any(len(v) > 1 for v in spelt.values()):
            raise Stuck()
        feet = Counter(FOOT[l] for l, v in spelt.items() if state[l] != next(iter(v)))
        if any(c > 1 for c in feet.values()):
            raise Stuck()
        for e in sorted(notes, key=lambda e: 12 * parse(e["pitch"])[2] + pc(*parse(e["pitch"])[:2])):
            l, a, o = parse(e["pitch"])
            alt = neighbour(l, a)
            if alt is not None and alt[0] in spelt and spelt[alt[0]] != {alt[1]}:
                alt = None
            own_ok, alt_ok = state[l] == a, alt is not None and state[alt[0]] == alt[1]
            if h["substitution"] == "spare" and not own_ok and alt_ok:
                string = alt[0]
            elif own_ok:
                string = l
            elif window(l, t):
                move(l, a, t)
                string = l
            elif alt_ok:
                string = alt[0]
            elif alt is not None and window(alt[0], t):
                move(alt[0], alt[1], t)
                string = alt[0]
            else:
                raise Stuck()
            free[string] = max(free[string], t + e["dur"])
    return rows


def solve(folder):
    part = Part(folder)
    fits = []
    for combo in product(*[values for _, values in HABITS]):
        h = dict(zip([k for k, _ in HABITS], combo))
        try:
            rows = plan(part, h)
        except Stuck:
            continue
        on_page = Counter({k: v for k, v in rows.items() if k[0] <= part.hand_last})
        if on_page == part.hand:
            fits.append((sum(1 for k, values in HABITS if h[k] != values[0]), rows))
    if not fits:
        rows = plan(part, {k: values[0] for k, values in HABITS})
    else:
        fits.sort(key=lambda f: f[0])
        rows = fits[0][1]
    out = [k for k, v in rows.items() for _ in range(v) if k[0] > part.hand_last]
    out.sort(key=lambda k: (k[0], Fr(k[1]), LETTERS.index(k[2])))
    return out


if __name__ == "__main__":
    folder, out_path = sys.argv[1], sys.argv[2]
    rows = solve(folder)
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write("bar\tposition\tpedal\tto\n")
        for bar, p, l, w in rows:
            fh.write("%d\t%s\t%s\t%s\n" % (bar, p, l, w))
