#!/bin/bash
# Grades the pedalling program at /app/harpist on the 20 held-out parts. Before the program runs the
# reward channel is closed to everyone but root and the test report is pointed at a private root-only
# folder; the reward is written only after every process of the program's account has been stopped.
LOGS=/logs/verifier
REPORT_DIR=/run/standrun-report

write_reward() {
  rm -f "$LOGS/reward.txt" "$LOGS/reward.json"
  (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}

mkdir -p "$LOGS"
saved_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null
find "$LOGS" -mindepth 1 -exec rm -rf {} + 2>/dev/null
write_reward 0

finish() {
  chmod "$saved_mode" "$LOGS" 2>/dev/null
  exit 0
}

if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
  echo "grading: $LOGS is not root-only; the program is not run" >&2
  finish
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
if [ "$(stat -c '%u:%a' /tests 2>/dev/null)" != "0:700" ]; then
  echo "grading: /tests is not root-only; the program is not run" >&2
  finish
fi
rm -rf "$REPORT_DIR"
mkdir -p "$REPORT_DIR"
chown 0:0 "$REPORT_DIR"
chmod 700 "$REPORT_DIR"
if [ -d /app/harpist ]; then
  chown -R 0:0 /app/harpist
  chmod -R u+rwX,go+rX,go-w /app/harpist
fi

cd /tests || finish
STANDRUN_RESULTS="$REPORT_DIR" python3 -m pytest -q -p no:cacheprovider test_pedals.py --ctrf "$REPORT_DIR/ctrf.json"
outcome=$?

# nothing the program's account owns survives into the reward channel
find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
if [ "$outcome" -eq 0 ]; then write_reward 1; else write_reward 0; fi
for f in ctrf.json parts.json; do
  if [ -f "$REPORT_DIR/$f" ] && [ ! -L "$REPORT_DIR/$f" ]; then
    rm -rf "$LOGS/$f"
    (umask 022; cp --no-dereference "$REPORT_DIR/$f" "$LOGS/$f")
  fi
done
finish
