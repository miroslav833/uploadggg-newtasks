"""The harp's pedal action and the editor's planner.

A part is a list of events (notes, rests, glissandi) with absolute onset times, plus its sections with
their key signatures. The planner works through the part in time, keeps the position of every pedal and
the time each string is free, and writes a change wherever a note needs a position its string does not
have, placed where the editor's habits put it. Diagrams (all seven positions at one onset) are written for
glissandi always, and for section starts, glissando returns and rests when the editor's habits say so.
"""
from fractions import Fraction as F
from itertools import product

LETTERS = "CDEFGAB"
BASE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
FOOT = {"D": "L", "C": "L", "B": "L", "E": "R", "F": "R", "G": "R", "A": "R"}
ACC_NAME = {-1: "flat", 0: "natural", 1: "sharp"}
ACC_SIGN = {-1: "b", 0: "", 1: "#"}
SHARPS = "FCGDAEB"
FLATS = "BEADGCF"

HABITS = {
    "placement": ("late", "early", "rest-early", "rest-late"),
    "substitution": ("forced", "spare"),
    "key_change": ("lazy", "diagram"),
    "gliss_return": ("lazy", "diagram"),
    "rests": ("lazy", "cleanup"),
}
TRIVIAL = {k: v[0] for k, v in HABITS.items()}

SCALES = {
    "major": (0, 2, 4, 5, 7, 9, 11),
    "minor": (0, 2, 3, 5, 7, 8, 11),
    "pentatonic": (0, 2, 4, 7, 9),
    "diminished": (0, 3, 6, 9),
}


class Infeasible(Exception):
    def __init__(self, msg, t=None):
        super().__init__(msg)
        self.t = t
        self.bar = 0


def parse_pitch(text):
    """'F#4' -> ('F', 1, 4); 'Bb3' -> ('B', -1, 3); 'C4' -> ('C', 0, 4)."""
    letter = text[0]
    rest = text[1:]
    acc = 0
    if rest.startswith("#"):
        acc, rest = 1, rest[1:]
    elif rest.startswith("b"):
        acc, rest = -1, rest[1:]
    return letter, acc, int(rest)


def pitch_text(letter, acc, octave):
    return "%s%s%d" % (letter, ACC_SIGN[acc], octave)


def pitch_class(letter, acc):
    return (BASE[letter] + acc) % 12


def midi(letter, acc, octave):
    return 12 * (octave + 1) + BASE[letter] + acc


def alt_string(letter, acc):
    """The neighbouring string that sounds the same pitch, as (letter, acc), or None."""
    pc = pitch_class(letter, acc)
    i = LETTERS.index(letter)
    for j in (i - 1, i + 1):
        l2 = LETTERS[j % 7]
        d = (pc - BASE[l2] + 6) % 12 - 6
        if -1 <= d <= 1:
            return l2, d
    return None


def signature_state(key):
    """key: an integer, positive for sharps, negative for flats -> {letter: acc}."""
    st = {l: 0 for l in LETTERS}
    if key > 0:
        for l in SHARPS[:key]:
            st[l] = 1
    elif key < 0:
        for l in FLATS[:-key]:
            st[l] = -1
    return st


def scale_state(spec):
    """'Eb-major' -> the unique pedal setting sounding only scale notes with the most of them."""
    root, kind = spec.split("-")
    rl, ra, _ = parse_pitch(root + "4")
    pcs = {(pitch_class(rl, ra) + s) % 12 for s in SCALES[kind]}
    best, best_n = [], -1
    for accs in product((-1, 0, 1), repeat=7):
        sounding = [pitch_class(l, a) for l, a in zip(LETTERS, accs)]
        if any(p not in pcs for p in sounding):
            continue
        n = len(set(sounding))
        if n > best_n:
            best, best_n = [accs], n
        elif n == best_n:
            best.append(accs)
    if len(best) != 1:
        raise ValueError("glissando %s has %d settings" % (spec, len(best)))
    return dict(zip(LETTERS, best[0]))


def key_at(sections, bar):
    for s in sections:
        if s["start"] <= bar <= s["end"]:
            return s["key"]
    raise KeyError(bar)


class Part:
    """events: dicts with bar, pos (Fraction), dur (Fraction), kind ('note'|'rest'|'gliss'), pitch (text)."""

    def __init__(self, metre, sections, events, hand_bars):
        self.metre = metre
        self.barlen = F(metre[0], metre[1])
        self.sections = sections            # [{'start','end','key'}]
        self.events = events
        self.hand_bars = set(hand_bars)
        for e in self.events:
            e["t"] = (e["bar"] - 1) * self.barlen + e["pos"]
        self.events.sort(key=lambda e: (e["t"], e["kind"] != "gliss", e["kind"] != "rest",
                                        midi(*parse_pitch(e["pitch"])) if e["kind"] == "note" else 0))
        self.onsets = sorted({e["t"] for e in self.events})
        self.groups = {}
        for e in self.events:
            self.groups.setdefault(e["t"], []).append(e)
        self.rest_onsets = {t for t, g in self.groups.items() if all(e["kind"] == "rest" for e in g)}
        self.section_first = {}
        for i, s in enumerate(self.sections):
            self.section_first[(s["start"] - 1) * self.barlen] = i
        # native needs per letter: (time, acc) for notes as spelt, and glissando settings
        self.native = {l: [] for l in LETTERS}
        for e in self.events:
            if e["kind"] == "note":
                l, a, _ = parse_pitch(e["pitch"])
                self.native[l].append((e["t"], a))
            elif e["kind"] == "gliss":
                st = scale_state(e["pitch"].split(":")[1])
                for l in LETTERS:
                    self.native[l].append((e["t"], st[l]))
        for l in LETTERS:
            self.native[l].sort()

    def bar_pos(self, t):
        bar = int(t // self.barlen) + 1
        return bar, t - (bar - 1) * self.barlen

    def section_of_time(self, t):
        bar = int(t // self.barlen) + 1
        for s in self.sections:
            if s["start"] <= bar <= s["end"]:
                return s
        raise KeyError(bar)

    def next_native(self, letter, after):
        for t, a in self.native[letter]:
            if t > after:
                return a
        return None

    def preset(self):
        st = signature_state(self.sections[0]["key"])
        for l in LETTERS:
            if self.native[l]:
                st[l] = self.native[l][0][1]
        return st


class Planner:
    def __init__(self, part, habits, chord_order="ascending", foot_rule=True):
        self.part = part
        self.h = dict(habits)
        self.chord_order = chord_order
        self.foot_rule = foot_rule

    def run(self):
        p = self.part
        h = self.h
        self.state = p.preset()
        self.rows = [(F(-1), l, self.state[l], "preset") for l in LETTERS]
        self.busy = {l: F(0) for l in LETTERS}
        self.last_set = {l: F(-1) for l in LETTERS}
        self.foot_busy = set()
        self.diagram_times = set()
        pending_return = None
        for t in p.onsets:
            grp = p.groups[t]
            sec = p.section_of_time(t)
            sig = signature_state(sec["key"])
            if t in p.section_first and p.section_first[t] > 0 and h["key_change"] == "diagram":
                self.diagram(t, sig)
            gl = [e for e in grp if e["kind"] == "gliss"]
            if gl:
                self.diagram(t, scale_state(gl[0]["pitch"].split(":")[1]))
                for l in LETTERS:
                    self.busy[l] = max(self.busy[l], t + gl[0]["dur"])
                pending_return = t + gl[0]["dur"]
                continue
            if pending_return is not None and t >= pending_return:
                pending_return = None
                if h["gliss_return"] == "diagram" and t not in self.diagram_times:
                    self.diagram(t, sig)
            if t in p.rest_onsets and h["rests"] == "cleanup" and t not in self.diagram_times:
                target = {}
                for l in LETTERS:
                    nxt = p.next_native(l, t)
                    target[l] = sig[l] if nxt is None else nxt
                if target != self.state:
                    self.diagram(t, target)
            notes = [e for e in grp if e["kind"] == "note"]
            if notes:
                self.place_chord(t, notes)
        return self.rows

    def diagram(self, t, target):
        for l in LETTERS:
            if target[l] != self.state[l] and self.busy[l] > t:
                raise Infeasible("diagram at %s moves %s under a sounding string" % (t, l), t)
        for l in LETTERS:
            self.rows.append((t, l, target[l], "diagram"))
            self.state[l] = target[l]
            self.last_set[l] = t
        self.diagram_times.add(t)
        self.foot_busy.add((t, "L"))
        self.foot_busy.add((t, "R"))

    def candidates(self, letter, t):
        lo = self.busy[letter]
        if lo > t:
            return []
        foot = FOOT[letter]
        out = []
        for e in self.part.onsets:
            if e < lo:
                continue
            if e > t:
                break
            if e <= self.last_set[letter] or (self.foot_rule and (e, foot) in self.foot_busy):
                continue
            out.append(e)
        return out

    def pick(self, cands):
        rests = [e for e in cands if e in self.part.rest_onsets]
        mode = self.h["placement"]
        if mode == "early":
            return cands[0]
        if mode == "late":
            return cands[-1]
        if mode == "rest-early":
            return rests[0] if rests else cands[0]
        if mode == "rest-late":
            return rests[-1] if rests else cands[-1]
        raise ValueError(mode)

    def change(self, letter, acc, t):
        cands = self.candidates(letter, t)
        if not cands:
            raise Infeasible("no onset to move %s to %s before %s" % (letter, ACC_NAME[acc], t), t)
        e = self.pick(cands)
        self.rows.append((e, letter, acc, "change"))
        self.state[letter] = acc
        self.last_set[letter] = e
        self.foot_busy.add((e, FOOT[letter]))

    def place_chord(self, t, notes):
        parsed = [(parse_pitch(e["pitch"]), e) for e in notes]
        parsed.sort(key=lambda x: midi(*x[0]), reverse=(self.chord_order == "descending"))
        by_letter = {}
        for (l, a, o), e in parsed:
            by_letter.setdefault(l, set()).add(a)
        for l, accs in by_letter.items():
            if len(accs) > 1:
                raise Infeasible("chord at %s needs %s in two positions" % (t, l), t)
        per_foot = {}
        for l, accs in by_letter.items():
            if self.state[l] != next(iter(accs)):
                per_foot[FOOT[l]] = per_foot.get(FOOT[l], 0) + 1
        if any(n > 1 for n in per_foot.values()):
            raise Infeasible("two pedals of one foot needed at %s" % t, t)
        for (l, a, o), e in parsed:
            string, acc = self.choose(l, a, t, by_letter)
            self.busy[string] = max(self.busy[string], t + e["dur"])

    def choose(self, l, a, t, by_letter):
        alt = alt_string(l, a)
        if alt is not None:
            al, aa = alt
            if al in by_letter and by_letter[al] != {aa}:
                alt = None
        native_right = self.state[l] == a
        alt_right = alt is not None and self.state[alt[0]] == alt[1]
        mode = self.h["substitution"]
        if mode == "spare":
            if not native_right and alt_right:
                return alt
            if native_right:
                return l, a
        else:
            if native_right:
                return l, a
        if self.candidates(l, t):
            self.change(l, a, t)
            return l, a
        if alt_right:
            return alt
        if alt is not None and self.candidates(alt[0], t):
            self.change(alt[0], alt[1], t)
            return alt
        raise Infeasible("note %s%s at %s cannot be reached" % (l, ACC_SIGN[a], t), t)


def plan(part, habits, chord_order="ascending", foot_rule=True):
    """[(bar, position, letter, acc, kind)] in time order, letters in staff order within an onset."""
    try:
        rows = Planner(part, habits, chord_order, foot_rule).run()
    except Infeasible as e:
        if e.t is not None:
            e.bar = part.bar_pos(e.t)[0]
        raise
    out = []
    for t, l, a, kind in rows:
        if t < 0:
            out.append((0, F(0), l, a, kind))
        else:
            bar, pos = part.bar_pos(t)
            out.append((bar, pos, l, a, kind))
    out.sort(key=lambda r: (r[0], r[1], LETTERS.index(r[2])))
    return out


def split_rows(rows, hand_bars):
    hand = [r for r in rows if r[0] in hand_bars or r[0] == 0]
    graded = [r for r in rows if r[0] not in hand_bars and r[0] != 0]
    return hand, graded


def row_key(r):
    return (r[0], r[1], r[2], r[3])


def difference(a, b):
    """missing + extra between two row lists compared as multisets of (bar, pos, letter, acc)."""
    from collections import Counter
    ca, cb = Counter(row_key(r) for r in a), Counter(row_key(r) for r in b)
    missing = sum((ca - cb).values())
    extra = sum((cb - ca).values())
    return missing + extra


def all_habits():
    keys = list(HABITS)
    for combo in product(*[HABITS[k] for k in keys]):
        yield dict(zip(keys, combo))
