"""Mints harp parts for the editing queue: the notes, the editor's hand-marked first page (bars 1 to 12:
the pre-set diagram and every change there) and, sealed, the changes of the remaining bars.

A part is kept only when its editor's habits are settled by its own first page: every habit value that
would move a change in the graded bars also moves one on the first page (or is impossible there), every
combination of habits that reproduces the first page gives the same graded changes, each single wrong
habit costs at least MIN_COST graded rows, the plan does not depend on the order in which the notes
of a chord are taken, and no change is decided by the one-pedal-per-foot rule alone.

    python3 mint_parts.py samples OUT_DIR TRUTH_JSON [SEED]
    python3 mint_parts.py graded  OUT_DIR TRUTH_JSON [SEED]
"""
import json
import os
import random
import sys
from fractions import Fraction as F

import harp
from harp import LETTERS, ACC_NAME, F as Fr, Infeasible, Part, plan, split_rows, difference, all_habits
from compose import Composer, KEYS, TONIC, degree_note, altered, chords_without, window_letter

HAND = 12
MIN_COST = 4
PARTS = 20
KEY_TEXT = {0: "no sharps or flats", 1: "1 sharp", -1: "1 flat"}


def key_text(k):
    if k in KEY_TEXT:
        return KEY_TEXT[k]
    return "%d sharps" % k if k > 0 else "%d flats" % -k


def pos_text(p):
    p = F(p)
    return "%d/%d" % (p.numerator, p.denominator) if p.denominator != 1 else str(p.numerator)


# ----------------------------------------------------------------------------- structure
def metre_plan(rng):
    metre = (4, 4) if rng.random() < 0.7 else (3, 4)
    total = rng.randint(40, 52)
    s2 = rng.choice([6, 7])
    s3 = rng.randint(20, 26)
    starts = [1, s2, s3]
    if rng.random() < 0.5 and total - s3 >= 22:
        starts.append(rng.randint(s3 + 10, total - 10))
    keys = [rng.choice(KEYS)]
    while len(keys) < len(starts):
        k = rng.choice([x for x in KEYS if x != keys[-1] and -4 <= x - keys[-1] <= 4])
        keys.append(k)
    sections = []
    for i, s in enumerate(starts):
        e = starts[i + 1] - 1 if i + 1 < len(starts) else total
        sections.append(dict(start=s, end=e, key=keys[i]))
    return metre, sections


def section_for(sections, bar):
    for s in sections:
        if s["start"] <= bar <= s["end"]:
            return s
    raise KeyError(bar)


def changed_letters(key_from, key_to):
    a, b = harp.signature_state(key_from), harp.signature_state(key_to)
    return [l for l in LETTERS if a[l] != b[l]]


# ----------------------------------------------------------------------------- composition
def compose_part(rng, metre, sections):
    """A list of event dicts for the whole part, with the first page's triggers and graded triggers."""
    total = sections[-1]["end"]
    comps = {s["start"]: Composer(rng, s["key"], metre) for s in sections}
    bars = {}

    def comp(bar):
        return comps[section_for(sections, bar)["start"]]

    # --- the first page: bars 1 to HAND
    c1 = comp(1)
    bars[1] = c1.arp_bar(1, degree=0)
    bars[2] = c1.melody_bar(2, chromatics=[(1, c1.chromatic())], start=rng.choice([0, 2, 4]))
    pair = c1.chromatic_pair()
    if pair is None:
        return None
    x, y = pair
    bars[3] = c1.melody_bar(3, chromatics=[(2, x)], recur=False, avoid=(x[0],))
    bars[4] = c1.melody_bar(4, chromatics=[(1, y)], recur=True, pre_avoid=(x[0], y[0]), avoid=(x[0], y[0]))
    s2 = sections[1]["start"]
    for b in range(5, s2):
        bars[b] = c1.arp_bar(b) if rng.random() < 0.5 else c1.chord_bar(b)
    c2 = comp(s2)
    sb = c2.section_start_bar(s2, changed_letters(sections[0]["key"], sections[1]["key"]))
    if sb is None:
        return None
    bars[s2] = sb
    specs = c2.gliss_specs()
    if not specs:
        return None
    bars[s2 + 1] = c2.gliss_bar(s2 + 1, rng.choice(specs), after="chord")
    l2 = window_letter(rng, c2, bars[s2 + 1])
    if l2 is None:
        return None
    wb = c2.window_bars(s2 + 2, l2)
    if wb is None:
        return None
    for b in wb:
        bars[b.bar_no] = b
    if max(bars) > HAND:
        return None
    for b in range(max(bars) + 1, HAND + 1):
        bars[b] = c2.melody_bar(b, chromatics=[(rng.choice([1, 2, 3]), c2.chromatic())] if rng.random() < 0.5 else [])
    # --- the graded bars
    bar = HAND + 1
    planted = {"pair": 0, "gliss": 0, "held": 0, "window": 0}
    while bar <= total:
        sec = section_for(sections, bar)
        c = comp(bar)
        if bar == sec["start"]:
            prev = sections[sections.index(sec) - 1]["key"]
            sb = c.section_start_bar(bar, changed_letters(prev, sec["key"]))
            if sb is None:
                return None
            bars[bar] = sb
            bar += 1
            continue
        room = sec["end"] - bar
        r = rng.random()
        if planted["pair"] < 3 and room >= 2 and r < 0.16:
            pr = c.chromatic_pair()
            if pr is not None:
                px, py = pr
                bars[bar] = c.melody_bar(bar, chromatics=[(rng.choice([1, 2, 3]), px)], recur=False,
                                         avoid=(px[0],))
                bars[bar + 1] = c.melody_bar(bar + 1, chromatics=[(rng.choice([1, 2]), py)], recur=True,
                                             pre_avoid=(px[0], py[0]), avoid=(px[0], py[0]))
                planted["pair"] += 1
                bar += 2
                continue
        if planted["window"] < 2 and room >= 3 and r < 0.30 and bar > HAND + 1:
            prev_bar = bars[bar - 1]
            l3 = window_letter(rng, c, prev_bar) if prev_bar.events and prev_bar.events[-1][2] == "note" else None
            wb = c.window_bars(bar, l3) if l3 is not None else None
            if wb is not None and all(b.bar_no <= sec["end"] for b in wb):
                for b in wb:
                    bars[b.bar_no] = b
                planted["window"] += 1
                bar += len(wb)
                continue
        if planted["gliss"] < 2 and room >= 1 and r < 0.38:
            sp = c.gliss_specs()
            if sp:
                bars[bar] = c.gliss_bar(bar, rng.choice(sp), after=rng.choice(["chord", "rest"]))
                planted["gliss"] += 1
                bar += 1
                continue
        if planted["held"] < 2 and r < 0.44 and bar > HAND + 1:
            hb = held_conflict_bar(rng, c, bar, bars[bar - 1])
            if hb is not None:
                bars[bar] = hb
                planted["held"] += 1
                bar += 1
                continue
        if r < 0.62:
            bars[bar] = c.rest_bar(bar)
        elif r < 0.78:
            chrom = [(rng.randrange(0, int(c.barlen / F(1, 8))), c.chromatic())] if rng.random() < 0.5 else []
            bars[bar] = c.melody_bar(bar, chromatics=chrom, held=rng.random() < 0.5)
        elif r < 0.92:
            chrom = (rng.randrange(1, int(c.barlen / F(1, 8))), c.chromatic()) if rng.random() < 0.4 else None
            bars[bar] = c.arp_bar(bar, chromatic=chrom)
        else:
            bars[bar] = c.chord_bar(bar)
        bar += 1
    if planted["pair"] < 2 or planted["gliss"] < 1 or planted["window"] < 1:
        return None
    events = []
    for b in sorted(bars):
        events.extend(bars[b].rows())
    return events


def held_conflict_bar(rng, c, bar_no, prev_bar):
    """A bass note held through the bar while the treble takes its letter in another position, so the
    note goes to the neighbouring string. The bar before holds no rest and uses that string, so the
    change's window holds no rest."""
    if any(k == "rest" for _, _, k, _ in prev_bar.events):
        return None
    opts = []
    for degree in [0, 3, 4]:
        for direction in (1, -1):
            x = altered(c.key, degree, direction)
            alt = harp.alt_string(*x) if x is not None else None
            if alt is not None and alt[0] in prev_bar.letters():
                opts.append((degree, x))
    if not opts:
        return None
    degree, chrom = rng.choice(opts)
    idx = rng.choice([2, 3, 5])
    return c.arp_bar(bar_no, degree=degree, chromatic=(idx, chrom))


# ----------------------------------------------------------------------------- settledness
def settled(part, habits):
    try:
        true_rows = plan(part, habits)
    except Infeasible as e:
        return False, None, "infeasible: %s" % e
    try:
        if plan(part, habits, chord_order="descending") != true_rows:
            return False, None, "chord order changes the plan"
    except Infeasible as e:
        return False, None, "descending infeasible: %s" % e
    try:
        if plan(part, habits, foot_rule=False) != true_rows:
            return False, None, "the one-pedal-per-foot rule decides a change"
    except Infeasible as e:
        return False, None, "without the foot rule: %s" % e
    hand_true, graded_true = split_rows(true_rows, part.hand_bars)
    if not graded_true:
        return False, None, "no graded changes"
    for k, values in harp.HABITS.items():
        for v in values:
            if v == habits[k]:
                continue
            h2 = dict(habits, **{k: v})
            try:
                rows2 = plan(part, h2)
            except Infeasible as e:
                if getattr(e, "bar", 0) and e.bar > HAND:
                    return False, None, "%s=%s impossible only after the first page (%s)" % (k, v, e)
                continue
            hand2, graded2 = split_rows(rows2, part.hand_bars)
            cost = difference(graded_true, graded2)
            if hand2 == hand_true:
                if cost == 0:
                    continue        # an equivalent reading on this part
                return False, None, "%s=%s moves %d graded rows but none on the first page" % (k, v, cost)
            if cost < MIN_COST:
                return False, None, "%s=%s costs only %d graded rows" % (k, v, cost)
    matches = 0
    for h2 in all_habits():
        try:
            rows2 = plan(part, h2)
        except Infeasible:
            continue
        hand2, graded2 = split_rows(rows2, part.hand_bars)
        if hand2 == hand_true:
            matches += 1
            if graded2 != graded_true:
                return False, None, "another reading %s matches the first page" % h2
    return True, true_rows, "settled (%d equivalent readings)" % matches


# ----------------------------------------------------------------------------- output
def write_part(out_dir, name, code, metre, sections, events, rows, hand_bars):
    d = os.path.join(out_dir, name)
    os.makedirs(d, exist_ok=True)
    total = sections[-1]["end"]
    with open(os.path.join(d, "PART.md"), "w", encoding="utf-8") as fh:
        fh.write("# Part %s\n\n- Pedalled by: %s\n- Bars: %d\n- Metre: %d/%d\n- Sections:\n"
                 % (name, code, total, metre[0], metre[1]))
        for s in sections:
            fh.write("  - bars %d to %d: %s\n" % (s["start"], s["end"], key_text(s["key"])))
        fh.write("- Marked by hand: bars 1 to %d\n" % max(hand_bars))
    with open(os.path.join(d, "notes.tsv"), "w", encoding="utf-8") as fh:
        fh.write("bar\tposition\tduration\tkind\tpitch\n")
        for e in events:
            fh.write("%d\t%s\t%s\t%s\t%s\n" % (e["bar"], pos_text(e["pos"]), pos_text(e["dur"]), e["kind"], e["pitch"]))
    hand, graded = split_rows(rows, hand_bars)
    for fname, rr in (("hand.tsv", hand), ("truth.tsv", graded)):
        with open(os.path.join(d, fname), "w", encoding="utf-8") as fh:
            fh.write("bar\tposition\tpedal\tto\n")
            for bar, pos, l, a, kind in rr:
                fh.write("%d\t%s\t%s\t%s\n" % (bar, pos_text(pos), l, ACC_NAME[a]))
    return [[bar, pos_text(pos), l, ACC_NAME[a]] for bar, pos, l, a, kind in graded]


def habit_sets(rng):
    """Balanced habits for the 20 graded parts."""
    sets = []
    for rests, placements in (("cleanup", ["early"] * 5 + ["late"] * 5),
                              ("lazy", ["rest-early"] * 3 + ["rest-late"] * 3 + ["early"] * 2 + ["late"] * 2)):
        rng.shuffle(placements)
        subs = ["spare"] * 5 + ["forced"] * 5
        keys = ["diagram"] * 5 + ["lazy"] * 5
        gls = ["diagram"] * 5 + ["lazy"] * 5
        for lst in (subs, keys, gls):
            rng.shuffle(lst)
        for i in range(10):
            sets.append(dict(placement=placements[i], substitution=subs[i], key_change=keys[i],
                             gliss_return=gls[i], rests=rests))
    rng.shuffle(sets)
    return sets


def mint_one(rng, habits, attempts=400):
    for _ in range(attempts):
        metre, sections = metre_plan(rng)
        try:
            events = compose_part(rng, metre, sections)
        except ValueError:
            events = None
        if events is None:
            continue
        part = Part(metre, sections, [dict(e) for e in events], range(1, HAND + 1))
        ok, rows, why = settled(part, habits)
        if ok:
            return metre, sections, events, rows, why
        mint_one.last = why
    return None


def mint_many(mode, out_dir, truth_path, seed):
    rng = random.Random(seed)
    if mode == "samples":
        names = ["S01", "S02", "S03"]
        habit_list = [dict(harp.TRIVIAL) for _ in names]
    else:
        names = ["H%02d" % i for i in range(1, PARTS + 1)]
        habit_list = habit_sets(rng)
    truth, meta = {}, {}
    for name, habits in zip(names, habit_list):
        got = mint_one(rng, habits)
        if got is None:
            raise SystemExit("could not mint %s: last reason %s" % (name, getattr(mint_one, "last", "?")))
        metre, sections, events, rows, why = got
        code = "%s%03d" % (rng.choice("KLMNPRST"), rng.randint(100, 999))
        truth[name] = write_part(out_dir, name, code, metre, sections, events, rows, range(1, HAND + 1))
        meta[name] = dict(habits, editor=code, metre=list(metre), sections=sections)
        print("minted %s %s metre %d/%d bars %d sections %d graded rows %d: %s"
              % (name, habits, metre[0], metre[1], sections[-1]["end"], len(sections), len(truth[name]), why))
    os.makedirs(os.path.dirname(os.path.abspath(truth_path)), exist_ok=True)
    with open(truth_path, "w", encoding="utf-8") as fh:
        json.dump(truth, fh, indent=1)
    with open(truth_path.replace(".json", "_habits.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=1)


if __name__ == "__main__":
    mode, out_dir, truth_path = sys.argv[1:4]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 4400
    if mode == "samples":
        seed += 9000
    mint_many(mode, out_dir, truth_path, seed)
