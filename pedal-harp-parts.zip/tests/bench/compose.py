"""Composes harp parts for the editing queue: sections with key signatures, bars of arpeggios, block
chords, melodies over a bass, rests and glissandi, with chromatic notes spelt in the key's manner.

Bars that carry the triggers of the editor's habits are composed to order by mint_parts.py: a window
with rests for the placement habit, a chromatic pair for the substitution habit, a section start with a
new key, a glissando with a chord after it, a rest with pedals standing off their next need.
"""
import random
from fractions import Fraction as F

from harp import LETTERS, FOOT, alt_string, signature_state, scale_state, pitch_text, midi

Q = F(1, 4)
E8 = F(1, 8)
H = F(1, 2)

TONIC = {0: "C", 1: "G", 2: "D", 3: "A", 4: "E", -1: "F", -2: "B", -3: "E", -4: "A"}
KEYS = [-4, -3, -2, -1, 0, 1, 2, 3, 4]


def degree_note(key, degree, octave_base=4):
    """(letter, acc, octave) of a scale degree (0 = tonic) counted from the tonic at octave_base."""
    sig = signature_state(key)
    ti = LETTERS.index(TONIC[key])
    idx = ti + degree
    letter = LETTERS[idx % 7]
    octave = octave_base + idx // 7
    return letter, sig[letter], octave


# the chromatic alterations the parts use: raised 1, 2, 4, 5; lowered 2, 3, 5, 6, 7
ALTERATIONS = {0: (1,), 1: (1, -1), 2: (-1,), 3: (1,), 4: (1, -1), 5: (-1,), 6: (-1,)}


def altered(key, degree, direction):
    """The degree raised (+1) or lowered (-1) within the pedal's range and the usual alterations, or None."""
    degree %= 7
    if direction not in ALTERATIONS[degree]:
        return None
    l, a, o = degree_note(key, degree)
    if not -1 <= a + direction <= 1:
        return None
    return l, a + direction


def degree_of(key, letter):
    return (LETTERS.index(letter) - LETTERS.index(TONIC[key])) % 7


class Bar:
    def __init__(self, bar_no):
        self.bar_no = bar_no
        self.events = []    # (pos, dur, kind, pitch)

    def note(self, pos, dur, l, a, o):
        self.events.append((pos, dur, "note", pitch_text(l, a, o)))

    def rest(self, pos, dur):
        self.events.append((pos, dur, "rest", "-"))

    def gliss(self, pos, dur, spec):
        self.events.append((pos, dur, "gliss", "gliss:" + spec))

    def rows(self):
        out = []
        for pos, dur, kind, pitch in sorted(self.events, key=lambda e: (e[0], e[2] != "note")):
            out.append(dict(bar=self.bar_no, pos=pos, dur=dur, kind=kind, pitch=pitch))
        return out

    def letters(self):
        return {p[0] for _, _, k, p in self.events if k == "note"}


class Composer:
    def __init__(self, rng, key, metre):
        self.rng = rng
        self.key = key
        self.metre = metre
        self.barlen = F(metre[0], metre[1])
        self.beats = metre[0] if metre[1] == 4 else metre[0] // 2
        self.unit = Q if metre[1] == 4 else F(3, 8)

    # ----------------------------------------------------------------- pitch material
    def chord_degrees(self, degree):
        return [degree, degree + 2, degree + 4]

    def chord_tones(self, degree, low=4, count=3):
        tones = []
        for i, d in enumerate(self.chord_degrees(degree)[:count]):
            tones.append(degree_note(self.key, d, low))
        return tones

    def bass(self, degree, octave=2):
        l, a, o = degree_note(self.key, degree, octave)
        return l, a, o

    # ----------------------------------------------------------------- bar builders
    def arp_bar(self, bar_no, degree=None, avoid=(), chromatic=None):
        """Bass held through the bar, eighths arpeggiating the chord up and down. avoid: letters the
        bass and the treble notes before the chromatic must not use."""
        rng = self.rng
        if degree is None:
            choices = [d for d in [0, 3, 4, 1, 5] if self.bass(d)[0] not in avoid]
            degree = rng.choice(choices or [0, 3, 4, 1, 5])
        b = Bar(bar_no)
        bl, ba, bo = self.bass(degree)
        b.note(F(0), self.barlen, bl, ba, bo)
        tones = self.chord_tones(degree, 4) + self.chord_tones(degree, 5)
        n = int(self.barlen / E8)
        seq = [tones[i % len(tones)] for i in range(n // 2)]
        seq = seq + seq[::-1]
        seq = seq[:n]
        for i, (l, a, o) in enumerate(seq):
            if chromatic is not None and i == chromatic[0]:
                l, a = chromatic[1]
                o = 5
            elif chromatic is not None and l == chromatic[1][0] and i + 1 == chromatic[0]:
                l, a, o = degree_note(self.key, degree + 4, 4)
            b.note(i * E8, E8, l, a, o)
        return b

    def chord_bar(self, bar_no, degrees=None, halves=None, avoid=()):
        rng = self.rng
        b = Bar(bar_no)
        if halves is None:
            halves = rng.random() < 0.5
        if self.beats == 3:
            slots = [(F(0), Q), (Q, Q), (2 * Q, Q)] if not halves else [(F(0), self.barlen)]
        else:
            slots = [(F(0), H), (H, H)] if halves else [(i * Q, Q) for i in range(4)]
        degrees = degrees or [rng.choice([0, 3, 4, 1, 5]) for _ in slots]
        for (pos, dur), d in zip(slots, degrees):
            bl, ba, bo = self.bass(d, 3)
            b.note(pos, dur, bl, ba, bo)
            for l, a, o in self.chord_tones(d, 4):
                b.note(pos, dur, l, a, o)
        return b

    def melody_bar(self, bar_no, chromatics=(), start=None, bass_degree=None, held=True, recur=True,
                   pre_avoid=(), avoid=()):
        """Bass half notes (or one held bass) under a scale-wise melody of eighths.
        chromatics: list of (eighth index, (letter, acc)) replacing the melody note there; the letter
        does not recur at the next eighth, and recurs later in the bar (recur) or not at all (not recur);
        pre_avoid: letters kept out of the eighths before the first chromatic; avoid: bass letters kept out."""
        rng = self.rng
        b = Bar(bar_no)
        if bass_degree is None:
            choices = [d for d in [0, 3, 4] if self.bass(d, 2)[0] not in avoid and
                       degree_note(self.key, d + 4, 2)[0] not in avoid]
            d = rng.choice(choices or [0, 3, 4])
        else:
            d = bass_degree
        bl, ba, bo = self.bass(d, 2)
        if held or self.beats == 3:
            b.note(F(0), self.barlen, bl, ba, bo)
        else:
            b.note(F(0), H, bl, ba, bo)
            fl, fa, fo = degree_note(self.key, d + 4, 2)
            b.note(H, H, fl, fa, fo)
        n = int(self.barlen / E8)
        chrom = dict(chromatics)
        for _ in range(60):
            deg = rng.randrange(0, 7) if start is None else start
            step = rng.choice([1, -1])
            seq = []
            for i in range(n):
                seq.append(deg)
                if rng.random() < 0.2:
                    step = -step
                deg += step
                if deg > 10:
                    deg, step = 9, -1
                if deg < 0:
                    deg, step = 1, 1
            good = True
            first = min(chrom) if chrom else n
            for j in range(first):
                if degree_note(self.key, seq[j], 4)[0] in pre_avoid:
                    good = False
            for i, (l, a) in chrom.items():
                later = [j for j in range(i + 1, n) if degree_note(self.key, seq[j], 4)[0] == l]
                if i + 1 < n and degree_note(self.key, seq[i + 1], 4)[0] == l:
                    good = False
                if recur and not later:
                    good = False
                if not recur and later:
                    good = False
            if good:
                break
        for i, dg in enumerate(seq):
            if i in chrom:
                l, a = chrom[i]
                o = 5
            else:
                l, a, o = degree_note(self.key, dg, 4)
            b.note(i * E8, E8, l, a, o)
        return b

    def rest_bar(self, bar_no, shape=None, degrees=None):
        """Chords and rests. shapes: 'cRcR' chord rest chord rest; 'RccR'; 'cR' chord half, rest half;
        'R' whole rest; 'Rc' rest half then chord half; 'cRc' for 3/4."""
        rng = self.rng
        b = Bar(bar_no)
        if self.beats == 3:
            shape = shape or rng.choice(["cRc", "cR", "Rcc", "R"])
            slots = {"cRc": [("c", F(0), Q), ("R", Q, Q), ("c", 2 * Q, Q)],
                     "cR": [("c", F(0), Q), ("R", Q, H)],
                     "Rcc": [("R", F(0), Q), ("c", Q, Q), ("c", 2 * Q, Q)],
                     "R": [("R", F(0), self.barlen)]}[shape]
        else:
            shape = shape or rng.choice(["cRcR", "RccR", "cR", "Rc", "R"])
            slots = {"cRcR": [("c", F(0), Q), ("R", Q, Q), ("c", H, Q), ("R", 3 * Q, Q)],
                     "RccR": [("R", F(0), Q), ("c", Q, Q), ("c", H, Q), ("R", 3 * Q, Q)],
                     "cR": [("c", F(0), H), ("R", H, H)],
                     "Rc": [("R", F(0), H), ("c", H, H)],
                     "R": [("R", F(0), self.barlen)]}[shape]
        degs = list(degrees or [])
        for kind, pos, dur in slots:
            if kind == "R":
                b.rest(pos, dur)
            else:
                d = degs.pop(0) if degs else rng.choice([0, 3, 4, 1, 5])
                bl, ba, bo = self.bass(d, 3)
                b.note(pos, dur, bl, ba, bo)
                for l, a, o in self.chord_tones(d, 4):
                    b.note(pos, dur, l, a, o)
        return b

    def gliss_bar(self, bar_no, spec, after="chord"):
        """A chord, a glissando through the scale, then a chord or a rest."""
        rng = self.rng
        b = Bar(bar_no)
        d = rng.choice([0, 4])
        bl, ba, bo = self.bass(d, 3)
        b.note(F(0), Q, bl, ba, bo)
        for l, a, o in self.chord_tones(d, 4):
            b.note(F(0), Q, l, a, o)
        gl_dur = H if self.beats == 4 else Q
        b.gliss(Q, gl_dur, spec)
        tail = Q + gl_dur
        if after == "chord":
            d2 = rng.choice([0, 3])
            bl, ba, bo = self.bass(d2, 3)
            b.note(tail, self.barlen - tail, bl, ba, bo)
            for l, a, o in self.chord_tones(d2, 4):
                b.note(tail, self.barlen - tail, l, a, o)
        else:
            b.rest(tail, self.barlen - tail)
        return b

    # ----------------------------------------------------------------- helpers for triggers
    def gliss_specs(self):
        """Scales whose setting differs from the signature in at most one pedal per foot."""
        sig = signature_state(self.key)
        tonic = TONIC[self.key] + ("b" if self.key < -1 else "")
        if self.key == -1:
            tonic = "F"
        if self.key == -2:
            tonic = "Bb"
        if self.key == -3:
            tonic = "Eb"
        if self.key == -4:
            tonic = "Ab"
        rel_l, rel_a, _ = degree_note(self.key, 5)
        rel = rel_l + ("b" if rel_a < 0 else "#" if rel_a > 0 else "")
        out = []
        for spec in (tonic + "-major", tonic + "-pentatonic", rel + "-minor"):
            try:
                st = scale_state(spec)
            except ValueError:
                continue
            moved = [l for l in LETTERS if st[l] != sig[l]]
            feet = [FOOT[l] for l in moved]
            if len(feet) == len(set(feet)):
                out.append(spec)
        return out

    def chromatic_pair(self):
        """(X, Y): X an altered degree, Y the same pitch spelt on the neighbouring letter, so that Y's
        own string needs a change while X's string already stands right."""
        rng = self.rng
        options = []
        for degree in range(7):
            for direction in (1, -1):
                x = altered(self.key, degree, direction)
                if x is None:
                    continue
                y = alt_string(*x)
                if y is None:
                    continue
                sig = signature_state(self.key)
                if sig[y[0]] == y[1]:
                    continue           # Y needs no change: nothing to spare
                options.append((x, y))
        return rng.choice(options) if options else None

    def chromatic(self):
        rng = self.rng
        while True:
            degree = rng.choice([3, 6, 4, 5, 0, 1, 2])
            direction = rng.choice([1, -1])
            x = altered(self.key, degree, direction)
            if x is not None:
                return x


    def section_start_bar(self, bar_no, moved):
        """Two half-bar chords (or one in 3/4) whose letters cover the moved pedals as far as one pedal per
        foot per chord allows."""
        rng = self.rng
        best = None
        for _ in range(80):
            degs = [rng.choice([0, 3, 4, 1, 5]) for _ in range(1 if self.beats == 3 else 2)]
            seen, ok, cover = set(), True, 0
            for d in degs:
                letters = {l for l, a, o in self.chord_tones(d, 4)} | {self.bass(d, 3)[0]}
                new = [l for l in letters if l in moved and l not in seen]
                feet = [FOOT[l] for l in new]
                if len(feet) != len(set(feet)):
                    ok = False
                seen |= set(new)
                cover = len(seen)
            if ok and (best is None or cover > best[0]):
                best = (cover, degs)
        if best is None:
            return None
        return self.chord_bar(bar_no, degrees=best[1], halves=True)

    def window_bars(self, first_bar, l2):
        """The bars of a placement window: a rest bar (or two in 3/4) whose chords avoid l2's letter,
        then a bar needing l2 at its second eighth."""
        out = []
        if self.beats == 3:
            degs = chords_without(self, l2[0], 4)
            if degs is None:
                return None
            out.append(self.rest_bar(first_bar, shape="cRc", degrees=degs[:2]))
            out.append(self.rest_bar(first_bar + 1, shape="Rcc", degrees=degs[2:]))
        else:
            degs = chords_without(self, l2[0], 2)
            if degs is None:
                return None
            out.append(self.rest_bar(first_bar, shape="cRcR", degrees=degs))
        out.append(self.arp_bar(first_bar + len(out), avoid=(l2[0],), chromatic=(1, l2)))
        return out


def chords_without(c, letter, n):
    rng = c.rng
    out = []
    for _ in range(200):
        d = rng.choice([0, 1, 2, 3, 4, 5])
        letters = {l for l, a, o in c.chord_tones(d, 4)} | {c.bass(d, 3)[0]}
        if letter not in letters:
            out.append(d)
        if len(out) == n:
            return out
    return None


def window_letter(rng, c, prev_bar):
    """A chromatic on a letter held in prev_bar's last chord, altered from that chord's position."""
    from harp import parse_pitch
    last_pos = max(e[0] for e in prev_bar.events)
    letters = {parse_pitch(p)[0]: parse_pitch(p)[1] for pos, d, k, p in prev_bar.events
               if k == "note" and pos == last_pos}
    opts = []
    for l, a in letters.items():
        for direction in (1, -1):
            x = altered(c.key, degree_of(c.key, l), direction)
            if x is not None and x[1] == a + direction:
                opts.append(x)
    rng.shuffle(opts)
    return opts[0] if opts else None
