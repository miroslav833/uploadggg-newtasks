"""Two checks on the held-out parts. First, the sealed changes of every part are rebuilt from the sealed
habits and the part's own files by an independent forward model, so the key is what the harpist's
practice gives and nothing else. Second, the program is run on every part and enough parts come out
right (at most 2 rows missing or extra per part; 18 of 20 parts)."""
import json
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import standrun   # noqa: E402
import replan     # noqa: E402

PARTS = 20
MARK = 18          # parts that must count, of 20; printed in instruction.md
HABIT_KEYS = ("placement", "substitution", "key_change", "gliss_return", "rests")

_table = None


def table():
    global _table
    if _table is None:
        _table = standrun.grade_all()
        where = os.environ.get("STANDRUN_RESULTS", "/logs/verifier")
        with open(os.path.join(where, "parts.json"), "w", encoding="utf-8") as fh:
            json.dump(_table, fh, indent=1)
    return _table


def test_sealed_changes_follow_from_the_habits():
    with open(os.path.join(standrun.SEALED, "changes.json"), encoding="utf-8") as fh:
        sealed = json.load(fh)
    with open(os.path.join(standrun.SEALED, "habits.json"), encoding="utf-8") as fh:
        habits = json.load(fh)
    assert len(sealed) == PARTS
    for name in sorted(sealed):
        h = {k: habits[name][k] for k in HABIT_KEYS}
        rebuilt = replan.rebuild(os.path.join(standrun.SEALED, "parts", name), h)
        assert rebuilt == Counter(tuple(r) for r in sealed[name]), \
            "part %s: the sealed changes differ from the harpist's practice" % name


def test_enough_parts_pedalled_right():
    rows = table()
    assert len(rows) == PARTS
    counted = sum(1 for r in rows if r["counts"])
    assert counted >= MARK, "%d of %d parts right, %d needed" % (counted, PARTS, MARK)
