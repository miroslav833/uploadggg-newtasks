"""An independent forward model of an editor's pedalling, used by the first test to rebuild every sealed
list of changes from the sealed habits and the part's own files. It shares no code with the minter's
planner: the part is read from the folder's files, every pedal's demands are listed first, and each
change is placed by an explicit search over the onsets of its window.
"""
import csv
import os
import re
from collections import Counter
from fractions import Fraction as Fr
from itertools import product

NAMES = "CDEFGAB"
SEMITONE = dict(C=0, D=2, E=4, F=5, G=7, A=9, B=11)
LEFT = set("DCB")
WORD = {-1: "flat", 0: "natural", 1: "sharp"}
SHARP_ORDER = "FCGDAEB"
FLAT_ORDER = "BEADGCF"
MODES = {"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 11],
         "pentatonic": [0, 2, 4, 7, 9], "diminished": [0, 3, 6, 9]}


class Unreachable(Exception):
    pass


def read_part(part_dir):
    sections, hand_last, metre = [], 0, (4, 4)
    with open(os.path.join(part_dir, "PART.md"), encoding="utf-8") as fh:
        for line in fh:
            m = re.match(r"\s*- bars (\d+) to (\d+): (.*)", line)
            if m:
                words = m.group(3).strip()
                n = 0
                if words[0].isdigit():
                    n = int(words.split()[0]) * (1 if "sharp" in words else -1)
                sections.append((int(m.group(1)), int(m.group(2)), n))
            m = re.match(r"\s*- Marked by hand: bars 1 to (\d+)", line)
            if m:
                hand_last = int(m.group(1))
            m = re.match(r"\s*- Metre: (\d+)/(\d+)", line)
            if m:
                metre = (int(m.group(1)), int(m.group(2)))
    events = []
    with open(os.path.join(part_dir, "notes.tsv"), encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            events.append(dict(bar=int(row["bar"]), pos=Fr(row["position"]), dur=Fr(row["duration"]),
                               kind=row["kind"], pitch=row["pitch"]))
    return metre, sections, hand_last, events


def spelled(text):
    name = text[0]
    acc = 1 if "#" in text else (-1 if "b" in text[1:] else 0)
    octave = int(text[-1])
    return name, acc, octave


def semis(name, acc):
    return (SEMITONE[name] + acc) % 12


def other_string(name, acc):
    """The neighbouring string sounding this pitch, or None."""
    want = semis(name, acc)
    i = NAMES.index(name)
    for n2 in (NAMES[(i - 1) % 7], NAMES[(i + 1) % 7]):
        for a2 in (-1, 0, 1):
            if semis(n2, a2) == want:
                return n2, a2
    return None


def key_positions(n):
    pos = {x: 0 for x in NAMES}
    for x in (SHARP_ORDER[:n] if n > 0 else FLAT_ORDER[:-n] if n < 0 else ""):
        pos[x] = 1 if n > 0 else -1
    return pos


def gliss_positions(spec):
    root, mode = spec.split("-")
    rn, ra, _ = spelled(root + "4")
    allowed = {(semis(rn, ra) + k) % 12 for k in MODES[mode]}
    found = []
    for accs in product((-1, 0, 1), repeat=7):
        tones = [semis(n, a) for n, a in zip(NAMES, accs)]
        if all(t in allowed for t in tones):
            found.append((len(set(tones)), accs))
    top = max(f[0] for f in found)
    best = [f[1] for f in found if f[0] == top]
    assert len(best) == 1, spec
    return dict(zip(NAMES, best[0]))


def rebuild(part_dir, habits):
    """{(bar, 'pos', pedal, word): count} for the bars after the hand-marked page."""
    metre, sections, hand_last, events = read_part(part_dir)
    bar_len = Fr(metre[0], metre[1])

    def when(e):
        return (e["bar"] - 1) * bar_len + e["pos"]

    def section_key(t):
        bar = int(t // bar_len) + 1
        for a, b, n in sections:
            if a <= bar <= b:
                return n
        raise KeyError(bar)

    times = sorted({when(e) for e in events})
    at = {t: [] for t in times}
    for e in events:
        at[when(e)].append(e)
    silent = {t for t in times if all(e["kind"] == "rest" for e in at[t])}
    section_starts = {(a - 1) * bar_len for a, b, n in sections[1:]}

    # every pedal's written demands in time order: notes as spelt, glissandi as their settings
    demands = {x: [] for x in NAMES}
    for e in events:
        if e["kind"] == "note":
            n, a, _ = spelled(e["pitch"])
            demands[n].append((when(e), a))
        elif e["kind"] == "gliss":
            gp = gliss_positions(e["pitch"][6:])
            for x in NAMES:
                demands[x].append((when(e), gp[x]))
    for x in NAMES:
        demands[x].sort()

    def demand_after(x, t):
        for tt, a in demands[x]:
            if tt > t:
                return a
        return None

    pos = key_positions(sections[0][2])
    for x in NAMES:
        if demands[x]:
            pos[x] = demands[x][0][1]
    out = Counter()
    free_at = {x: Fr(0) for x in NAMES}
    set_at = {x: Fr(-1) for x in NAMES}
    foot_used = set()
    diagram_at = set()

    def emit(t, x, a):
        bar = int(t // bar_len) + 1
        p = t - (bar - 1) * bar_len
        ptxt = "%d/%d" % (p.numerator, p.denominator) if p.denominator != 1 else str(p.numerator)
        if bar > hand_last:
            out[(bar, ptxt, x, WORD[a])] += 1

    def write_diagram(t, target):
        for x in NAMES:
            if target[x] != pos[x] and free_at[x] > t:
                raise Unreachable("diagram under a sounding string")
        for x in NAMES:
            emit(t, x, target[x])
            pos[x] = target[x]
            set_at[x] = t
        diagram_at.add(t)
        foot_used.update({(t, "L"), (t, "R")})

    def window(x, t):
        if free_at[x] > t:
            return []
        foot = "L" if x in LEFT else "R"
        return [u for u in times if free_at[x] <= u <= t and u > set_at[x] and (u, foot) not in foot_used]

    def place(x, a, t):
        w = window(x, t)
        if not w:
            raise Unreachable("%s to %s before %s" % (x, WORD[a], t))
        rests = [u for u in w if u in silent]
        rule = habits["placement"]
        if rule == "early":
            u = w[0]
        elif rule == "late":
            u = w[-1]
        elif rule == "rest-early":
            u = rests[0] if rests else w[0]
        else:
            u = rests[-1] if rests else w[-1]
        emit(u, x, a)
        pos[x] = a
        set_at[x] = u
        foot_used.add((u, "L" if x in LEFT else "R"))

    gliss_end = None
    for t in times:
        key = section_key(t)
        signature = key_positions(key)
        if t in section_starts and habits["key_change"] == "diagram":
            write_diagram(t, signature)
        glisses = [e for e in at[t] if e["kind"] == "gliss"]
        if glisses:
            write_diagram(t, gliss_positions(glisses[0]["pitch"][6:]))
            for x in NAMES:
                free_at[x] = max(free_at[x], t + glisses[0]["dur"])
            gliss_end = t + glisses[0]["dur"]
            continue
        if gliss_end is not None and t >= gliss_end:
            gliss_end = None
            if habits["gliss_return"] == "diagram" and t not in diagram_at:
                write_diagram(t, signature)
        if t in silent and habits["rests"] == "cleanup" and t not in diagram_at:
            target = {}
            for x in NAMES:
                nxt = demand_after(x, t)
                target[x] = signature[x] if nxt is None else nxt
            if any(target[x] != pos[x] for x in NAMES):
                write_diagram(t, target)
        notes = [e for e in at[t] if e["kind"] == "note"]
        if not notes:
            continue
        spelt = {}
        for e in notes:
            n, a, o = spelled(e["pitch"])
            spelt.setdefault(n, set()).add(a)
        if any(len(v) > 1 for v in spelt.values()):
            raise Unreachable("one letter in two positions at %s" % t)
        moving = Counter("L" if n in LEFT else "R" for n, v in spelt.items() if pos[n] != next(iter(v)))
        if any(c > 1 for c in moving.values()):
            raise Unreachable("two pedals of one foot at %s" % t)
        for e in sorted(notes, key=lambda e: 12 * spelled(e["pitch"])[2] + semis(*spelled(e["pitch"])[:2])):
            n, a, o = spelled(e["pitch"])
            alt = other_string(n, a)
            if alt is not None and alt[0] in spelt and spelt[alt[0]] != {alt[1]}:
                alt = None
            own_ok = pos[n] == a
            alt_ok = alt is not None and pos[alt[0]] == alt[1]
            if habits["substitution"] == "spare" and not own_ok and alt_ok:
                string = alt[0]
            elif own_ok:
                string = n
            elif window(n, t):
                place(n, a, t)
                string = n
            elif alt_ok:
                string = alt[0]
            elif alt is not None and window(alt[0], t):
                place(alt[0], alt[1], t)
                string = alt[0]
            else:
                raise Unreachable("%s at %s" % (e["pitch"], t))
            free_at[string] = max(free_at[string], t + e["dur"])
    return out
