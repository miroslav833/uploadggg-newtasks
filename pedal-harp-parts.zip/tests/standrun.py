"""Runs the pedalling program at /app/harpist on every held-out part and scores its rows against the
sealed changes.

Each part is copied into a scratch folder owned by a numeric account invented for that run. The program
runs as that account in a session of its own, under an address-space limit, a process limit and a wall
clock, and every process of the account is stopped before its output is read. The output is read as
text only: a regular file under the size cap, rows that parse; nothing in it is executed. The sealed
changes stay under /tests, which is root-only.
"""
import csv
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import time
from collections import Counter

SEALED = "/tests/sealed"
SCRATCH = "/var/tmp/standrun"
PROGRAM = "/app/harpist/changes.py"
WALL_SECONDS = 120
ADDRESS_SPACE = 3 * 1024 ** 3
OUTPUT_CAP = 1 << 20
ROWS_ALLOWED = 2          # missing plus extra rows a part may have; printed in instruction.md
FIRST_UID = 52000


class Account:
    """A throwaway uid for one run, chosen clear of every uid that owns a live process."""

    def __init__(self, index):
        live = set()
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    live.add(os.stat("/proc/" + entry).st_uid)
                except FileNotFoundError:
                    pass
        uid = FIRST_UID + 5 * index
        while uid in live:
            uid += 1
        self.uid = uid

    def processes(self):
        found = []
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    if os.stat("/proc/" + entry).st_uid == self.uid:
                        found.append(int(entry))
                except FileNotFoundError:
                    pass
        return found

    def stop_everything(self):
        quiet = 0
        for _ in range(500):
            pids = self.processes()
            if not pids:
                quiet += 1
                if quiet >= 3:
                    return
                time.sleep(0.04)
                continue
            quiet = 0
            for sig in (signal.SIGSTOP, signal.SIGKILL):
                for pid in pids:
                    try:
                        os.kill(pid, sig)
                    except ProcessLookupError:
                        pass
            time.sleep(0.04)

    def own(self, path):
        for root, dirs, files in os.walk(path):
            os.chown(root, self.uid, self.uid)
            for f in files:
                os.chown(os.path.join(root, f), self.uid, self.uid)

    def limits(self):
        os.setsid()
        os.setgroups([])
        os.setgid(self.uid)
        os.setuid(self.uid)
        resource.setrlimit(resource.RLIMIT_AS, (ADDRESS_SPACE, ADDRESS_SPACE))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))


def run_part(name, account):
    folder = os.path.join(SCRATCH, name)
    shutil.rmtree(folder, ignore_errors=True)
    os.makedirs(folder, mode=0o755)
    part_copy = os.path.join(folder, "part")
    shutil.copytree(os.path.join(SEALED, "parts", name), part_copy, symlinks=False)
    os.makedirs(os.path.join(folder, "out"))
    account.own(folder)
    out_path = os.path.join(folder, "out", "changes.tsv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": folder, "LANG": "C.UTF-8",
           "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
    with open(os.path.join(folder, "run.log"), "wb") as log:
        try:
            child = subprocess.Popen([sys.executable, PROGRAM, part_copy, out_path], cwd=folder,
                                     stdout=log, stderr=log, env=env, preexec_fn=account.limits)
            try:
                child.wait(timeout=WALL_SECONDS)
            except subprocess.TimeoutExpired:
                pass
        except OSError:
            pass
    account.stop_everything()
    try:
        with open(os.path.join(folder, "run.log"), "rb") as fh:
            tail = fh.read()[-600:].decode("utf-8", "replace")
    except OSError:
        tail = ""
    return out_path, tail


def rows_of(path):
    """Counter of (bar, position, pedal, to) over the file's rows; None when the file is unusable."""
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > OUTPUT_CAP:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    found = Counter()
    with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
        try:
            reader = csv.DictReader(fh, delimiter="\t")
            for row in reader:
                fields = [(row.get(k) or "").strip() for k in ("bar", "position", "pedal", "to")]
                if not fields[0].isdigit():
                    continue
                found[(int(fields[0]), fields[1], fields[2], fields[3])] += 1
        except csv.Error:
            return None
    return found


def score(found, sealed):
    """(missing, extra) rows between the program's rows and the sealed changes."""
    if found is None:
        return len(sealed), 0
    want = Counter(tuple(r) for r in sealed)
    missing = sum((want - found).values())
    extra = sum((found - want).values())
    return missing, extra


def grade_all():
    with open(os.path.join(SEALED, "changes.json"), encoding="utf-8") as fh:
        sealed = json.load(fh)
    os.makedirs(SCRATCH, mode=0o755, exist_ok=True)
    table = []
    for index, name in enumerate(sorted(sealed)):
        account = Account(index)
        out_path, tail = run_part(name, account)
        found = rows_of(out_path)
        missing, extra = score(found, sealed[name])
        entry = dict(part=name, parsed=found is not None, rows=len(sealed[name]), missing=missing,
                     extra=extra, counts=missing + extra <= ROWS_ALLOWED)
        if not entry["counts"]:
            entry["stderr_tail"] = tail
        table.append(entry)
        shutil.rmtree(os.path.join(SCRATCH, name), ignore_errors=True)
    return table


if __name__ == "__main__":
    for entry in grade_all():
        print(entry)
