#!/usr/bin/env python3
"""Reference: fit the sweep's loss surface and file each proposal's verdict and loss.

Reads  <root>/sweep/runs.csv and <root>/proposals/runs.csv
Writes /app/out/runs.csv  (run,clears,fitted_loss)

What a pretraining engineer reads off the recipe and the sweep:
  * The mixture was re-tokenised on 2026-08-25. A run reads the tokenisation current at its
    launch, and its token counts and its per-token validation loss are in those tokens. Per-token
    figures from the two tokenizers are not on one scale: the held-out text is the same, so the
    loss per byte is, and so is training data measured in bytes. The recipe gives each
    tokenizer's bytes per token on the training mixture and on the held-out set.
  * Repeated data counts for less than fresh data, saturating with the number of repeats:
    D' = U + U * Rs * (1 - exp(-R / Rs)), R = D / U - 1, Rs fitted.
  * One cosine over the scheduled steps: a run stopped at a share f of its schedule reads high by
    an amount that grows with 1 - f, fitted as p * (1 - f)^2.
So: put every run in bytes, fit L_byte = E + A/N^a + B/D'^b + p (1-f)^2 by least squares on the
per-token losses, and convert each proposal back to the tokens of the tokenizer it will read.
Everything is stdlib Python: a Levenberg-Marquardt fit with a numeric Jacobian.
"""
import csv
import math
import os
import sys

LEVEL = 3.300            # the target the instruction states (nats per token)
SWITCH = "2026-08-25"    # recipe: runs launched on or after this date read the 100k tokenisation
BPT_TRAIN = {"T32": 3.92, "T100": 4.52}   # recipe: bytes per token on the training mixture
BPT_EVAL = {"T32": 3.86, "T100": 4.45}    # recipe: bytes per token on the held-out set
EVAL_EVERY = 2000        # recipe: evaluated every 2,000 steps, and at the end of a completed run


def eval_step(row, variant=None):
    """The step whose loss the record holds: the end of a run that completed its schedule; for a run
    stopped early, its last evaluation, the last multiple of 2,000 steps it reached."""
    if row["act"] >= row["sched"] or (variant or {}).get("at_stop"):
        return row["act"]
    return (int(row["act"]) // EVAL_EVERY) * EVAL_EVERY


def tokenizer(launched):
    return "T100" if launched >= SWITCH else "T32"


# ----------------------------------------------------------------------------- the model
def effective_tokens(U, D, rstar):
    if D <= U:
        return float(D)
    R = D / U - 1.0
    return U + U * rstar * (1.0 - math.exp(-R / rstar))


def predict(theta, row, variant):
    """Per-token loss of a run under a variant of the surface.
    theta = [E, lnA, a, lnB, b, lnRs, p, k, lnBc, g, lnC, c, lnm] (some entries unused by a variant).
    Default units 'fitted': the surface is in 32k-token units; a 100k run's tokens count m times a 32k
    token of the same text and its per-token loss is k times the 32k figure, k and m fitted."""
    E, lnA, a, lnB, b, lnRs, p, k, lnBc, g, lnC, c, lnm = theta
    a = min(max(a, 0.01), 2.0)
    b = min(max(b, 0.01), 2.0)
    tok = row["tok"]
    units = variant.get("units", "fitted")
    if units == "fitted":
        data_bpt = math.exp(min(max(lnm, -1.0), 1.0)) if tok == "T100" else 1.0
        loss_bpt = 1.0
    elif units == "bytes":
        data_bpt = (BPT_EVAL if variant.get("data_bpt") == "eval" else BPT_TRAIN)[tok]
        loss_bpt = (BPT_TRAIN if variant.get("loss_bpt") == "train" else BPT_EVAL)[tok]
    else:
        data_bpt = loss_bpt = 1.0
    s = eval_step(row, variant)
    N, U, D, f = row["N"], row["U"] * data_bpt, s * row["tps"] * data_bpt, s / row["sched"]
    if variant.get("cap"):
        Dp = float(min(U, D))
    elif variant.get("discount", True):
        rs = variant.get("fixed_rstar") or math.exp(min(max(lnRs, -5.0), 8.0))
        Dp = effective_tokens(U, D, rs)
    else:
        Dp = float(D)
    if not variant.get("nobatch") and not variant.get("steps_term"):
        # above the critical batch, a step's tokens buy less than their count: D / (1 + B / B_crit)
        # the critical batch grows with the data a run has seen: B_crit = B_c * (D' / 4e10 bytes)^g
        Bc = variant.get("fixed_bc") or math.exp(min(max(lnBc, 10.0), 30.0))
        gg = 0.0 if variant.get("const_bc") else min(max(g, -2.0), 2.0)
        Bc *= (Dp / 4e10) ** gg
        Dp = Dp / (1.0 + row["tps"] * data_bpt / Bc)
    L = E + math.exp(lnA - a * math.log(N)) + math.exp(lnB - b * math.log(Dp))
    if variant.get("steps_term"):
        L += math.exp(lnC - min(max(c, 0.0), 3.0) * math.log(s / 1000.0))
    pen = variant.get("penalty", "quad")
    if pen == "quad":
        L += p * (1.0 - f) ** 2
    elif pen == "lin":
        L += p * (1.0 - f)
    elif pen == "mult":
        L *= 1.0 + p * (1.0 - f) ** 2
    elif pen == "lrleft":
        # learning rate still above its floor at the evaluated step: cosine from 1 to 0.1 over the schedule
        L += p * (0.1 + 0.45 * (1.0 + math.cos(math.pi * f)) - 0.1)
    L *= loss_bpt
    if units == "offset" and tok == "T100":
        L += k
    if units in ("factor", "fitted") and tok == "T100":
        L *= k
    return L


# ----------------------------------------------------------------------------- the fitter
def _solve(A, bvec):
    n = len(bvec)
    M = [list(A[i]) + [bvec[i]] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        if abs(M[piv][c]) < 1e-300:
            raise ZeroDivisionError
        M[c], M[piv] = M[piv], M[c]
        for r in range(n):
            if r != c:
                q = M[r][c] / M[c][c]
                if q:
                    for j in range(c, n + 1):
                        M[r][j] -= q * M[c][j]
    return [M[i][n] / M[i][i] for i in range(n)]


def levenberg_marquardt(resid, theta0, free, iters=400):
    theta = list(theta0)
    r = resid(theta)
    sse = sum(x * x for x in r)
    lam = 1e-3
    for _ in range(iters):
        J = []
        for k in free:
            h = 1e-6 * max(1.0, abs(theta[k]))
            tp = list(theta); tp[k] += h
            rp = resid(tp)
            J.append([(rp[i] - r[i]) / h for i in range(len(r))])
        n = len(free)
        JTJ = [[sum(J[i][m] * J[j][m] for m in range(len(r))) for j in range(n)] for i in range(n)]
        JTr = [sum(J[i][m] * r[m] for m in range(len(r))) for i in range(n)]
        improved = False
        step = 0.0
        while lam < 1e10:
            A = [[JTJ[i][j] + (lam * JTJ[i][i] + 1e-12 if i == j else 0.0) for j in range(n)] for i in range(n)]
            try:
                delta = _solve(A, [-x for x in JTr])
            except ZeroDivisionError:
                lam *= 10
                continue
            tn = list(theta)
            for i, k in enumerate(free):
                tn[k] += delta[i]
            try:
                rn = resid(tn)
                sn = sum(x * x for x in rn)
            except (OverflowError, ValueError):
                sn = float("inf")
            if sn < sse:
                theta, r, sse = tn, rn, sn
                lam = max(lam / 3.0, 1e-12)
                improved = True
                step = max(abs(d) for d in delta)
                break
            lam *= 4.0
        if not improved or step < 1e-9:
            break
    return theta, sse


def fit(sweep, variant):
    """Least-squares fit of the variant's surface to the sweep's per-token losses; multi-start."""
    rows = sweep
    free = [0, 1, 2, 3, 4]
    if variant.get("discount", True) and not variant.get("fixed_rstar") and not variant.get("cap"):
        free.append(5)
    if variant.get("penalty", "quad") in ("quad", "lin", "mult", "lrleft"):
        free.append(6)
    units = variant.get("units", "fitted")
    if units in ("offset", "factor", "fitted"):
        free.append(7)
    if units == "fitted":
        free.append(12)
    if variant.get("steps_term"):
        free += [10, 11]
    elif not variant.get("nobatch"):
        if not variant.get("fixed_bc"):
            free.append(8)
        if not variant.get("const_bc"):
            free.append(9)
    k0 = 1.0 if units in ("factor", "fitted") else 0.0
    scale = min(row["loss"] / (BPT_EVAL[row["tok"]] if units == "bytes" else 1.0) for row in rows)

    def resid(theta):
        if variant.get("logfit"):
            return [math.log(max(predict(theta, row, variant), 1e-9)) - math.log(row["loss"]) for row in rows]
        return [predict(theta, row, variant) - row["loss"] for row in rows]

    best = None
    for e in (0.5, 0.8):
        for lnR0 in (math.log(3.0), math.log(20.0)):
            for ab in (0.25, 0.5):
                theta0 = [e * scale, math.log(300.0), ab, math.log(300.0), ab, lnR0, 0.05 * scale, k0,
                          math.log(2e7), 0.3, math.log(0.05), 0.5, math.log(1.1)]
                theta, sse = levenberg_marquardt(resid, theta0, free)
                if best is None or sse < best[1]:
                    best = (theta, sse)
    return best[0]


# ----------------------------------------------------------------------------- the files
def read_runs(path, with_loss):
    out = []
    with open(path, newline="", encoding="utf-8") as fh:
        for rec in csv.DictReader(fh):
            row = dict(code=rec["run"], launched=rec["launched"], tok=tokenizer(rec["launched"]),
                       N=float(rec["params"]), U=float(rec["unique_tokens"]),
                       tps=float(rec["tokens_per_step"]),
                       sched=float(rec["scheduled_steps"]), act=float(rec["actual_steps"]))
            row["D"] = row["act"] * row["tps"]
            row["f"] = row["act"] / row["sched"]
            if with_loss:
                row["loss"] = float(rec["final_loss"])
            out.append(row)
    return out


def main(root="/app", out="/app/out/runs.csv"):
    sweep = read_runs(os.path.join(root, "sweep", "runs.csv"), True)
    props = read_runs(os.path.join(root, "proposals", "runs.csv"), False)
    theta = fit(sweep, {})
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["run", "clears", "fitted_loss"])
        for row in props:
            L = predict(theta, row, {})
            w.writerow([row["code"], "yes" if L < LEVEL else "no", "%.3f" % L])


if __name__ == "__main__":
    main(*(sys.argv[1:3] or ["/app"]))
