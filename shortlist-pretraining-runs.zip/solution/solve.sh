#!/bin/bash
python3 "$(dirname "$0")/shortlist_runs.py" /app
