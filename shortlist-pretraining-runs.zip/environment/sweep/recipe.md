# Sweep recipe

The sweep trained 64 decoder-only transformers of 20 M to 1.2 B non-embedding
parameters on one fixed pretraining mixture (web text, code and reference text,
sequence length 2048). Every run read its data from a fixed prefix of the
shuffled corpus: the unique tokens in its row of `runs.csv`. A run whose token
budget went past that prefix read it again in a fresh shuffle, as many times as
the budget required.

## Tokenisation

The mixture was first tokenised with a 32k-vocabulary BPE tokenizer. On
2026-08-25 it was re-tokenised with a 100k-vocabulary BPE tokenizer trained on
the same mixture, and the 32k tokenisation was retired that day. A run reads
the tokenisation current on its launch date, and every count in its row
(unique tokens, tokens per step, total tokens) is in the tokens it read. The
held-out text did not change.

## Columns of `runs.csv`

Run code, launch date, non-embedding parameter count, unique tokens available
to the run, tokens per optimizer step, the steps it was scheduled for, the
steps it actually ran, the total tokens it processed (actual steps times tokens
per step) and its final validation loss.

## Optimisation

AdamW, betas 0.9 and 0.95, weight decay 0.1, gradient clipping at 1.0. The
learning rate warmed up over the first 2 % of the scheduled steps and then
followed one cosine from its peak down to a tenth of the peak at the last
scheduled step. The schedule was fixed at launch from the scheduled steps.
When a run's accelerator allocation ended before its scheduled steps, the run
stopped where it was, and the loss recorded for it is its last evaluation.

## Evaluation

Validation loss is the mean negative log-likelihood in nats per token over a
fixed held-out set of about 160 MB of text drawn from the same mixture. A run
is evaluated every 2,000 steps, and once more at its last scheduled step if it
reaches it. Repeat evaluations of one checkpoint differ by about 0.002 nats.

`proposals/runs.csv` lists 48 runs proposed under the same recipe, with
launch dates in the coming quarter, the same columns and no loss.
