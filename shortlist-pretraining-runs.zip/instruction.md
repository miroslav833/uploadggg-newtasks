For each of the 48 proposed language-model pretraining runs in `/app/proposals/runs.csv`, file whether its final validation loss would come in under 3.300 nats per token, and the loss it would reach, from the completed sweep of 64 runs trained under the same recipe.

Inputs:

- `/app/sweep/runs.csv`: one row per sweep run: run code, launch date, non-embedding parameter count, unique tokens available to the run, tokens per optimizer step, scheduled steps, actual steps, total tokens processed (actual steps times tokens per step), and final validation loss in nats per token.
- `/app/sweep/recipe.md`: the data, tokenisation, optimizer, learning-rate schedule and evaluation protocol the sweep and the proposed runs share.
- `/app/proposals/runs.csv`: the proposed runs, with the same columns and no loss.

Write `/app/out/runs.csv` with a header row and one row per proposed run, in any order:

```
run,clears,fitted_loss
a0a0,yes,0.000
```

`run` is the run code from the proposals table. `fitted_loss` is the final validation loss the recipe would record for the run, in nats per token of the tokens the run reads, to three decimals. `clears` is `yes` when that loss is below 3.300 and `no` otherwise.

A row is right when its `clears` matches the reference and its `fitted_loss` is within 0.012 nats per token of the reference loss. A row with a missing or non-numeric loss is wrong. At least 43 of the 48 rows must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
