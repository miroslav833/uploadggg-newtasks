"""Read a filing as text and count the rows that are right. Nothing in the filing is run."""
import csv
import math

TOLERANCE = 0.012        # nats per token, printed in instruction.md


def read_filing(path):
    out = {}
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for rec in reader:
            code = (rec.get("run") or "").strip()
            verdict = (rec.get("clears") or "").strip().lower()
            try:
                loss = float((rec.get("fitted_loss") or "").strip())
            except ValueError:
                loss = float("nan")
            if code and code not in out:
                out[code] = (verdict, loss)
    return out


def row_right(filed, keyed, tol=TOLERANCE):
    verdict, loss = filed
    kverdict, kloss = keyed
    if verdict != kverdict:
        return False
    if not math.isfinite(loss):
        return False
    return abs(loss - kloss) <= tol


def score(filing, key, tol=TOLERANCE):
    return sum(1 for code, keyed in key.items() if code in filing and row_right(filing[code], keyed, tol))
