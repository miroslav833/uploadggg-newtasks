import csv
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import marking   # noqa: E402
import surface   # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FILING = "/app/out/runs.csv"
MARK = 43                # of 48 proposals, printed in instruction.md
LEVEL = 3.300            # nats per token, printed in instruction.md


def sealed_key():
    key = {}
    with open(os.path.join(HERE, "sealed", "key.csv"), newline="", encoding="utf-8") as fh:
        for rec in csv.DictReader(fh):
            key[rec["run"]] = (rec["clears"], float(rec["loss"]))
    return key


def test_sealed_key_matches_forward_model():
    truth = json.load(open(os.path.join(HERE, "sealed", "truth.json"), encoding="utf-8"))
    props = surface.load_proposals(os.path.join(HERE, "sealed", "proposals.csv"), truth)
    reckoned = surface.reckon(truth, props, LEVEL)
    key = sealed_key()
    assert len(key) == 48 and set(key) == set(reckoned)
    for code in key:
        assert key[code][0] == reckoned[code][0], code
        assert math.isfinite(key[code][1]) and abs(key[code][1] - reckoned[code][1]) < 1e-9, code


def test_filing_reaches_the_mark():
    assert os.path.exists(FILING), "no /app/out/runs.csv"
    filing = marking.read_filing(FILING)
    key = sealed_key()
    right = marking.score(filing, key)
    assert right >= MARK, "%d of %d rows right; %d needed" % (right, len(key), MARK)
