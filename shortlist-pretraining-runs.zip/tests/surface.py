"""The verifier's own forward model: the loss surface the sweep was generated from, evaluated
at the true constants in tests/sealed/truth.json for each proposed run. The surface lives in
bytes (loss per byte of held-out text, data in bytes of training text); a run's per-token loss
is its loss per byte times its tokenizer's bytes per token on the held-out set. It rebuilds the
key from sealed truth; it never fits anything and never reads the filing."""
import csv
import math


def effective_bytes(U, D, rstar):
    if D <= U:
        return float(D)
    R = D / U - 1.0
    return U + U * rstar * (1.0 - math.exp(-R / rstar))


def tokenizer(t, launched):
    return t["after"] if launched >= t["switch"] else t["before"]


def eval_step(t, act, sched):
    """A completed run is evaluated at its end; a stopped run's record holds its last evaluation."""
    if act >= sched:
        return act
    return (int(act) // t["eval_every"]) * t["eval_every"]


def true_loss(t, N, U_tok, D_tok, f, tok, tps):
    """t: the sealed constants. Per-token loss in nats, noiseless. Data above the critical batch
    counts as D / (1 + B / B_crit), B the bytes per optimizer step, and the critical batch grows with
    the data seen: B_crit = B_c (D / 4e10 bytes)^gamma."""
    bt = t["bytes_per_token_train"][tok]
    Dp = effective_bytes(U_tok * bt, D_tok * bt, t["rstar"])
    bcrit = t["bcrit_bytes"] * (Dp / 4e10) ** t["bcrit_gamma"]
    Dp = Dp / (1.0 + tps * bt / bcrit)
    L = t["E"] + t["A"] / (N ** t["a"]) + t["B"] / (Dp ** t["b"]) + t["p"] * (1.0 - f) ** 2
    return L * t["bytes_per_token_eval"][tok]


def load_proposals(path, t):
    out = []
    with open(path, newline="", encoding="utf-8") as fh:
        for rec in csv.DictReader(fh):
            N = float(rec["params"]); U = float(rec["unique_tokens"])
            tps = float(rec["tokens_per_step"])
            sched = float(rec["scheduled_steps"]); act = float(rec["actual_steps"])
            s = eval_step(t, act, sched)
            out.append((rec["run"], N, U, s * tps, s / sched, tokenizer(t, rec["launched"]), tps))
    return out


def reckon(truth, proposals, level):
    """{run: (verdict, loss rounded to 3 decimals)}"""
    key = {}
    for code, N, U, D, f, tok, tps in proposals:
        L = round(true_loss(truth, N, U, D, f, tok, tps), 3)
        key[code] = ("yes" if L < level else "no", L)
    return key
