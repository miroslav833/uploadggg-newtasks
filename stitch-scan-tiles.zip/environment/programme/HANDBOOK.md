# Digital pathology programme: runtime parity

The programme's laboratories scan tissue sections into whole-slide images, which are far larger than any
network's input. A vendor's tissue model therefore never sees a slide at once: a runtime cuts the slide
into square tiles of the model's input size, runs the model on the tiles, and blends the tile outputs
back into one probability map of the slide. This handbook describes the model, the runtime builds, what a
deployment folder holds, and the program the programme's edge appliances need.

## The model and the runtime builds

The vendor's model is `segnet`. Given one tile of intensities it returns, for every pixel of the tile,
the logit that the pixel is tumour tissue; the probability is the logistic function of the logit. The
model is given in `/app/model/segnet.py` with its weights. The model's output for a pixel depends on the
whole tile the pixel was run in, not only on the pixels around it. The tile size is set per deployment.

A runtime build is the vendor's software that cuts slides into overlapping tiles, runs the model and
blends. The vendor does not publish how a build works. Builds of the same runtime differ in details of
tiling, preprocessing and blending, so two builds can give visibly different maps of one slide from the
same model. Some builds do not run the model on tiles that hold no tissue. A pixel that no tile the build
ran covers is reported with probability zero. The deployment sheet records the tile size and the overlap
the build was asked for.

The programme's edge appliances cannot run the vendor's software. Each appliance needs a program of its
own, written for the standard library and numpy, whose maps match the vendor build's.

## Calibration

Every deployment folder carries a calibration slide with the vendor build's own probability map for it,
produced by the build whose maps the appliance has to match. The build is the same one that produced the
maps of the deployment's other slides, which the folder does not carry.

## What a deployment folder holds

`DEPLOYMENT.md`, for example:

```
# Deployment DP-K7R2

- Programme site: SITE-ESKEL
- Runtime build: RT-G4
- Model: segnet, tile size 64
- Requested tile overlap: 0.50
- Calibration slide: 150 x 214
- Slide s01: 190 x 262
```

`calibration/slide.npy` is a two-dimensional float32 array of intensities between 0 and 1 (rows, then
columns). `calibration/vendor.npy` is the build's probability map for it: float32, the same shape,
values between 0 and 1.

`slides/s01.npy`, `slides/s02.npy` and so on are further slides, in the same layout as the calibration
slide; the build's maps of them are not given.

`run.log` has one line for the calibration slide and one for each further slide, giving how many tiles
the build ran:

```
slide=calibration tiles_run=18
slide=s01 tiles_run=27
```

`probes.csv` lists the pixels at which the appliance's map is compared with the build's, as slide name,
row and column (counted from zero at the top left):

```
slide,row,col
s01,37,112
```

The two sample deployments also carry `truth.csv`, the build's probability at every probe, in the order
of `probes.csv`:

```
slide,row,col,probability
s01,37,112,0.412907
```

## The program

The appliance runs `python3 /app/stitch/stitch.py DEPLOYMENT_DIR OUT_CSV` once per deployment. The
program writes `OUT_CSV` with one row per probe, in the order of `probes.csv`, giving the probability the
deployment's build gives at that pixel of that slide:

```
slide,row,col,probability
s01,37,112,0.412907
```

The program runs under the image's python3 with numpy 2.2.6 and the standard library, with no network.
The model and its weights are not installed on the appliance; the program carries what it needs.
