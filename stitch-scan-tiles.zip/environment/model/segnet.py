"""The vendor's tissue-probability model. predict(tile) takes one 2-D tile of intensities and returns the
model's logit for every pixel of it, float32, same shape. Convolutions use zero padding and the second is
dilated; the mean of the tile's own features sets a bounded shift that the head adds to every pixel, so the
output for a pixel depends on the whole tile it was run in."""
import os

import numpy as np

_P = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "weights.npz"))
W1, B1, W2, B2, WH, BH, VG, C0, SG = (_P[k] for k in ("w1", "b1", "w2", "b2", "wh", "bh", "vg", "c0", "sg"))


def _conv(x, w, b, dilation=1):
    c_out, c_in = w.shape[:2]
    h, wd = x.shape[1:]
    xp = np.pad(x, ((0, 0), (dilation, dilation), (dilation, dilation)))
    cols = np.empty((c_in * 9, h * wd), dtype=np.float32)
    k = 0
    for ky in range(3):
        for kx in range(3):
            cols[k * c_in:(k + 1) * c_in] = xp[:, ky * dilation:ky * dilation + h, kx * dilation:kx * dilation + wd].reshape(c_in, -1)
            k += 1
    wm = np.concatenate([w[:, :, ky, kx] for ky in range(3) for kx in range(3)], axis=1)
    return (wm @ cols + b[:, None]).reshape(c_out, h, wd)


def predict(tile):
    x = np.asarray(tile, dtype=np.float32)[None]
    h1 = np.maximum(_conv(x, W1, B1), 0.0)
    h2 = np.maximum(_conv(h1, W2, B2, dilation=2), 0.0)
    shift = SG * np.tanh(VG @ h2.mean(axis=(1, 2)) - C0)
    return (np.tensordot(WH, h2, axes=([0], [0])) + BH + shift).astype(np.float32)
