# Deployment DP-A8H2

- Programme site: SITE-ARDA
- Runtime build: RT-G4
- Model: segnet, tile size 80
- Requested tile overlap: 0.75
- Calibration slide: 148 x 131
- Slide s01: 126 x 148
- Slide s02: 171 x 171
- Slide s03: 128 x 171
