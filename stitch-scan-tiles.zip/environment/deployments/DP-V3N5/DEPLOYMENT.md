# Deployment DP-V3N5

- Programme site: SITE-FENNO
- Runtime build: RT-X7
- Model: segnet, tile size 48
- Requested tile overlap: 0.60
- Calibration slide: 112 x 94
- Slide s01: 133 x 132
- Slide s02: 132 x 134
- Slide s03: 93 x 94
