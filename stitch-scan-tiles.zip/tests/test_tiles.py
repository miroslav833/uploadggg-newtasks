"""The programme's acceptance run: the sealed keys follow an independent forward model, every deployment
is settled by what the program is given, and the program matches the vendor builds on at least 18 of 20."""
import json
import math
import os

import numpy as np
import pytest

import runner
import tilecheck

NEED = 18
SEASON = runner.SEASON
CODES = runner.deployments()


def _truth(code):
    return os.path.join(SEASON, "truth", code)


def _deploy(code):
    return os.path.join(SEASON, "deployments", code)


@pytest.mark.parametrize("code", CODES)
def test_key_follows_forward_model(code):
    rebuilt = tilecheck.key_of(_deploy(code), _truth(code))
    sealed = tilecheck.sealed_key(_truth(code))
    assert set(rebuilt) == set(sealed)
    assert all(math.isfinite(rebuilt[k]) and math.isfinite(sealed[k]) for k in sealed)
    assert max(abs(rebuilt[k] - sealed[k]) for k in sealed) < 2e-5


@pytest.mark.parametrize("code", CODES)
def test_calibration_output_follows_forward_model(code):
    sheet = json.load(open(os.path.join(_truth(code), "build.json"), encoding="utf-8"))
    slide = np.load(os.path.join(_deploy(code), "calibration", "slide.npy"))
    vendor = np.load(os.path.join(_deploy(code), "calibration", "vendor.npy"))
    rebuilt = tilecheck.vendor_map(slide, sheet["tile"], sheet["overlap"], sheet["config"])
    assert float(np.abs(rebuilt - vendor).max()) < 1e-5


@pytest.mark.parametrize("code", CODES)
def test_deployment_is_settled(code):
    sheet = json.load(open(os.path.join(_truth(code), "build.json"), encoding="utf-8"))
    skipping = sheet["config"]["skip"] is not None
    for name, moved in sheet["moved"].items():
        if name == "skip" and not skipping:
            continue
        assert moved >= 12, "a wrong %s moves only %d probes" % (name, moved)
    assert len(tilecheck.read_probes(_deploy(code))) == 120


def test_twenty_deployments():
    assert len(CODES) == 20


def test_each_convention_is_dense():
    tally = {}
    for code in CODES:
        sheet = json.load(open(os.path.join(_truth(code), "build.json"), encoding="utf-8"))
        c = sheet["config"]
        for field in ("placement", "blend", "mirror", "normalise"):
            tally.setdefault((field, c[field]), 0)
            tally[(field, c[field])] += 1
        tally.setdefault(("window", c["window"][0]), 0)
        tally[("window", c["window"][0])] += 1
        tally.setdefault(("skip", c["skip"] is not None), 0)
        tally[("skip", c["skip"] is not None)] += 1
    assert min(tally.values()) >= 6, tally


def test_program_reaches_the_mark():
    results = runner.score_all()
    print({code: ("right" if ok else "wrong") for code, ok in results.items()})
    assert sum(results.values()) >= NEED, "%d of 20 deployments right; %d needed" % (sum(results.values()), NEED)
