#!/usr/bin/env bash
# Acceptance run of the stitching program. Before anything uploaded executes, the verdict folder is
# claimed by root (mode 700, confirmed with stat), emptied of every reward-, result- or score-looking
# entry and given a reward of 0. The checks then run, the uploaded program only inside them and only as a
# throwaway account (tests/runner.py). Last, whatever root did not write is removed from the folder and
# reward.txt alone says 1 or 0.
set -u
LOGS=/logs/verifier
PRIVATE=/run/stitching

claim_verdicts() {
    mkdir -p "$LOGS"
    chown 0:0 "$LOGS" 2>/dev/null
    chmod 700 "$LOGS" 2>/dev/null
    [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" = "0:700" ]
}
clean_verdicts() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
write_reward() {
    clean_verdicts
    (umask 022; echo "$1" > "$LOGS/reward.txt")
}

mode_before="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
if ! claim_verdicts; then
    write_reward 0
    echo "acceptance run: the verdict folder could not be claimed; the program is not run" >&2
    chmod "$mode_before" "$LOGS" 2>/dev/null
    exit 0
fi
write_reward 0
chmod -R go-rwx /tests 2>/dev/null; chmod 700 /tests 2>/dev/null
mkdir -p "$PRIVATE"; chown 0:0 "$PRIVATE"; chmod 700 "$PRIVATE"
chmod -R a+rX /app/stitch 2>/dev/null

passed=0
( cd /tests && python3 -m pytest -q -p no:cacheprovider --ctrf "$PRIVATE/ctrf.json" test_tiles.py ) && passed=1

write_reward "$passed"
for f in ctrf.json stitching.csv; do
    [ -f "$PRIVATE/$f" ] && (umask 022; cp "$PRIVATE/$f" "$LOGS/$f")
done
chmod "$mode_before" "$LOGS" 2>/dev/null
exit 0
