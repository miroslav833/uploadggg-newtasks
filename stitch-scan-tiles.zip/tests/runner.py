"""Runs the uploaded stitching program on the graded deployments, one throwaway account for the run.

Each deployment gets a private copy of its folder and an empty output folder, both owned by the account.
The program starts in a new session as that account with no groups and bounded memory, files, processes
and core size; the parent waits for it, then kills everything the account still owns, and only then reads
the output: a regular file of bounded size, opened without following links, parsed as CSV text."""
import csv
import math
import os
import resource
import shutil
import signal
import subprocess
import time

import tilecheck

SEASON = "/tests/season"
SCRATCH = "/var/tmp/stitching"
LOGS = "/run/stitching"
PROGRAM = "/app/stitch/stitch.py"
DEADLINE = 120.0
OUTPUT_CAP = 1 << 20
FIRST_UID = 63000


def deployments():
    return sorted(os.listdir(os.path.join(SEASON, "deployments")))


def free_uid():
    taken = set()
    for name in os.listdir("/proc"):
        if name.isdigit():
            try:
                taken.add(os.stat("/proc/" + name).st_uid)
            except OSError:
                pass
    uid = FIRST_UID
    while uid in taken:
        uid += 1
    return uid


def owned_by(uid):
    pids = []
    for name in os.listdir("/proc"):
        if name.isdigit():
            try:
                if os.stat("/proc/" + name).st_uid == uid:
                    pids.append(int(name))
            except OSError:
                pass
    return pids


def sweep(uid):
    for _ in range(200):
        pids = owned_by(uid)
        if not pids:
            return
        for pid in pids:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.03)


def prepare(code, uid):
    area = os.path.join(SCRATCH, code)
    shutil.rmtree(area, ignore_errors=True)
    os.makedirs(area)
    shutil.copytree(os.path.join(SEASON, "deployments", code), os.path.join(area, "deployment"), symlinks=False)
    for sub in ("out", "home"):
        os.makedirs(os.path.join(area, sub))
    for base, dirs, files in os.walk(area):
        for name in dirs + files:
            os.chown(os.path.join(base, name), uid, uid)
    os.chown(area, uid, uid)
    return area


def make_dropper(uid):
    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        for what, cap in ((resource.RLIMIT_AS, 3 << 30), (resource.RLIMIT_FSIZE, 32 << 20),
                          (resource.RLIMIT_CORE, 0), (resource.RLIMIT_NPROC, 64)):
            resource.setrlimit(what, (cap, cap))
    return drop


def run_one(code, uid):
    area = prepare(code, uid)
    home = os.path.join(area, "home")
    out = os.path.join(area, "out", "stitched.csv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8",
           "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
    with open(os.path.join(LOGS, code + ".log"), "wb") as log:
        proc = subprocess.Popen(["/usr/local/bin/python3", PROGRAM, os.path.join(area, "deployment"), out],
                                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, cwd=home,
                                env=env, preexec_fn=make_dropper(uid))
        try:
            proc.wait(timeout=DEADLINE)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    sweep(uid)
    table = read_table(out)
    shutil.rmtree(area, ignore_errors=True)
    return table


def read_table(path):
    """{(slide, row, col): value} from a regular CSV file under the cap, else None."""
    try:
        st = os.lstat(path)
    except OSError:
        return None
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > OUTPUT_CAP:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        raw = os.read(fd, OUTPUT_CAP + 1)
    finally:
        os.close(fd)
    table = {}
    try:
        for r in csv.DictReader(raw.decode("utf-8", "replace").splitlines()):
            key = (r["slide"], int(r["row"]), int(r["col"]))
            value = float(r["probability"])
            if key in table or not math.isfinite(value):
                return None
            table[key] = value
    except (KeyError, ValueError, TypeError):
        return None
    return table


def score_all():
    """{code: bool}, also written to the private logs folder."""
    uid = free_uid()
    results = {}
    for code in deployments():
        filed = run_one(code, uid)
        key = tilecheck.sealed_key(os.path.join(SEASON, "truth", code))
        results[code] = filed is not None and tilecheck.counts(filed, key)
    with open(os.path.join(LOGS, "stitching.csv"), "w", encoding="utf-8") as fh:
        for code, ok in results.items():
            fh.write("%s,%d\n" % (code, int(ok)))
    return results
