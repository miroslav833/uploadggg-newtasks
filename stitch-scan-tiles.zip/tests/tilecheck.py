"""The verifier's own account of a deployment: what the vendor's runtime build writes at every probe,
rebuilt from the sealed build sheet (its conventions) and the deployment's slides with the vendor model.
It shares no code with the builder's engine; the model itself (segnet) is the one the solver is given.

Also the matcher: a deployment counts when at least GOOD_SHARE of its probes are within TOL of the
build's value."""
import csv
import json
import math
import os

import numpy as np

import segnet

TOL = 0.01
GOOD_SHARE = 0.95


def _spread_starts(extent, tile, overlap, round_up):
    pitch = tile * (1.0 - overlap)
    ratio = (extent - tile) / pitch
    count = (math.ceil(ratio) if round_up else max(math.floor(ratio), 1)) + 1
    return [int(np.rint(extent_pos)) for extent_pos in (np.arange(count) * ((extent - tile) / (count - 1)))]


def _clamped_starts(extent, tile, overlap):
    step = max(1, int(tile * (1.0 - overlap)))
    starts = list(range(0, extent - tile + 1, step))
    if starts[-1] + tile < extent:
        starts.append(extent - tile)
    return starts


def starts(extent, tile, overlap, rule):
    if rule == "stride-clamp":
        return _clamped_starts(extent, tile, overlap)
    return _spread_starts(extent, tile, overlap, rule == "spread-up")


def weights(tile, window):
    idx = np.arange(tile, dtype=np.float64)
    if window[0] == "gaussian":
        centre = (tile - 1) / 2.0
        line = np.exp(-((idx - centre) ** 2) / (2.0 * (window[1] * tile) ** 2))
        line = np.where(line < 1e-3, 1e-3, line)
    elif window[0] == "hann":
        line = 0.5 - 0.5 * np.cos(2.0 * np.pi * (idx + 1.0) / (tile + 1.0))
    else:
        line = np.ones(tile)
    return line[:, None] * line[None, :]


def _logit_of(tile):
    return segnet.predict(np.ascontiguousarray(tile))


def vendor_map(slide, tile, overlap, conv):
    """The build's probability map of one slide."""
    h, w = slide.shape
    slide = slide.astype(np.float32)
    mean_all, std_all = float(slide.mean()), float(slide.std())
    wmap = weights(tile, tuple(conv["window"]))
    flips = {"none": [()], "lr": [(), (1,)], "all": [(), (1,), (0,), (0, 1)]}[conv["mirror"]]
    total = np.zeros((h, w))
    mass = np.zeros((h, w))
    for y in starts(h, tile, overlap, conv["placement"]):
        for x in starts(w, tile, overlap, conv["placement"]):
            piece = slide[y:y + tile, x:x + tile]
            if conv["skip"] is not None and float(piece.mean()) < conv["skip"]:
                continue
            if conv["normalise"] == "tile":
                piece = (piece - piece.mean()) / (piece.std() + 1e-6)
            elif conv["normalise"] == "slide":
                piece = (piece - mean_all) / (std_all + 1e-6)
            acc = 0.0
            for axes in flips:
                z = np.flip(_logit_of(np.flip(piece, axis=axes) if axes else piece), axis=axes) if axes else _logit_of(piece)
                acc = acc + (z if conv["blend"] == "logit" else 1.0 / (1.0 + np.exp(-z.astype(np.float64))))
            acc = acc / len(flips)
            total[y:y + tile, x:x + tile] += wmap * acc
            mass[y:y + tile, x:x + tile] += wmap
    out = np.zeros((h, w))
    seen = mass > 0
    out[seen] = total[seen] / mass[seen]
    if conv["blend"] == "logit":
        out[seen] = 1.0 / (1.0 + np.exp(-out[seen]))
    return out


def read_probes(folder):
    with open(os.path.join(folder, "probes.csv"), encoding="utf-8") as fh:
        return [(r["slide"], int(r["row"]), int(r["col"])) for r in csv.DictReader(fh)]


def key_of(deploy_dir, truth_dir):
    """{(slide, row, col): value} the vendor build gives, from the sealed sheet."""
    sheet = json.load(open(os.path.join(truth_dir, "build.json"), encoding="utf-8"))
    conv = dict(sheet["config"])
    maps = {}
    key = {}
    for slide, row, col in read_probes(deploy_dir):
        if slide not in maps:
            maps[slide] = vendor_map(np.load(os.path.join(deploy_dir, "slides", slide + ".npy")),
                                     sheet["tile"], sheet["overlap"], conv)
        key[(slide, row, col)] = float(maps[slide][row, col])
    return key


def sealed_key(truth_dir):
    with open(os.path.join(truth_dir, "truth.csv"), encoding="utf-8") as fh:
        return {(r["slide"], int(r["row"]), int(r["col"])): float(r["probability"]) for r in csv.DictReader(fh)}


def counts(filed, key):
    """Whether a filed table matches the sealed key: every probe present once, finite, and at least
    GOOD_SHARE of them within TOL."""
    if not isinstance(filed, dict) or set(filed) != set(key):
        return False
    good = 0
    for k, v in key.items():
        f = filed[k]
        if not math.isfinite(f):
            return False
        good += abs(f - v) <= TOL
    return good >= GOOD_SHARE * len(key)
