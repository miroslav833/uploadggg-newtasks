#!/usr/bin/env python3
"""Builds deployment folders of the digital-pathology programme: a runtime build's sheet, a calibration
slide with the build's own output for it, a run log, further slides with probe pixels, and the sealed
truth (the build's value at every probe, its conventions, and what made the deployment settled).

    build_deployments.py graded  DEPLOYMENTS_DIR TRUTH_DIR [SEED]     twenty graded deployments
    build_deployments.py samples DEPLOYMENTS_DIR TRUTH_DIR [SEED]     two samples, with truth.csv beside them

A deployment is drawn again until its calibration output settles the build's conventions (one reading
is consistent with it), the skip threshold's consistent range holds no graded tile, and every single
wrong convention moves at least MIN_MOVED of its probes by more than MOVE.
"""
import json
import math
import os
import shutil
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_v] = "1"

import numpy as np
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import slides as S  # noqa: E402
import vendor_engine as V  # noqa: E402

TOL = 0.01          # a probe counts within this of the build's value
CONSISTENT = 0.002  # a reading consistent with the calibration output misses it by less than this anywhere
APART = 0.006       # every inconsistent reading misses it by at least this somewhere (an exact reading misses by about 1e-6)
MOVE = 0.02
MIN_MOVED = 12      # probes (of 120) a single wrong convention moves by more than MOVE
PROBES = 40
SLIDES = 3
TILES = (48, 64, 80)
OVERLAPS = (0.5, 0.6, 0.75)
SKIPS = (0.08, 0.2)
SITES = ["SITE-ARDA", "SITE-BRUK", "SITE-CALLO", "SITE-DRAVE", "SITE-ESKEL", "SITE-FENNO", "SITE-GRANT", "SITE-HOLME"]


def code_of(rng, prefix):
    letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    digits = "23456789"
    return "%s-%s%s%s%s" % (prefix, letters[rng.integers(24)], digits[rng.integers(8)],
                            letters[rng.integers(24)], digits[rng.integers(8)])


def half_pixel(n, t, overlap, rule):
    if rule == "stride-clamp":
        return False
    r = (n - t) / (t * (1.0 - overlap))
    c = (int(np.ceil(r)) if rule == "spread-up" else max(int(np.floor(r)), 1)) + 1
    return bool(np.any(np.abs((np.linspace(0, n - t, c) % 1.0) - 0.5) < 1e-6))


def shape_for(rng, t, overlap, lo, hi, rule):
    stride = t * (1.0 - overlap)
    while True:
        out = []
        for _ in range(2):
            k = int(rng.integers(lo, hi + 1))
            frac = float(rng.uniform(0.3, 0.7))
            out.append(int(round(t + stride * (k + frac))))
        if not any(half_pixel(n, t, overlap, rule) for n in out):
            return tuple(out)


def consistent_skips(cal, vendor, t, overlap, cfg, outputs, means, grid):
    """Thresholds (as tile sets) under which the reading cfg reproduces the vendor map; returns (err of
    the best set, the lowest and highest threshold consistent, whether the all-run set is consistent)."""
    ms = sorted(set(means.values()))
    cuts = [None] + [(a + b) / 2.0 for a, b in zip(ms[:-1], ms[1:])]
    kind, width = cfg["window"]
    win = V.window(t, kind, width)
    best, ok = 9.0, []
    for c in cuts:
        run = {o for o in grid if c is None or means[o] >= c}
        out = V.blend(cal.shape, grid, t, outputs, win, cfg["blend"], run)
        err = float(np.abs(out - vendor).max())
        best = min(best, err)
        if err < CONSISTENT:
            ok.append(c)
    return best, ok


def deviations(truth_cfg):
    """Every reading of the menu that differs from the true one in one or two conventions."""
    dims = [("placement", V.PLACEMENTS), ("normalise", V.NORMS), ("mirror", V.MIRRORS), ("window", V.WINDOWS),
            ("blend", V.BLENDS)]
    out = [dict(truth_cfg)]
    for i, (a, va) in enumerate(dims):
        for x in va:
            if x == truth_cfg[a]:
                continue
            out.append(dict(truth_cfg, **{a: x}))
            for (b, vb) in dims[i + 1:]:
                for y in vb:
                    if y != truth_cfg[b]:
                        out.append(dict(truth_cfg, **{a: x, b: y}))
    return out


def calibration_check(cal, vendor, t, overlap, truth_cfg):
    """The menu's readings that differ from the true one in at most two conventions, against the
    calibration output. Returns (settled, why, info)."""
    info = {}
    sets = {}
    for cfg in deviations(truth_cfg):
        key = (cfg["placement"], cfg["normalise"], cfg["mirror"])
        if key not in sets:
            grid = V.tile_grid(cal.shape, t, overlap, key[0])
            means = {(y, x): float(cal[y:y + t, x:x + t].mean()) for (y, x) in grid}
            sets[key] = (grid, means, V.tile_outputs(cal, grid, t, key[1], key[2]))
        grid, means, outputs = sets[key]
        is_true = all(cfg[k] == truth_cfg[k] for k in ("placement", "normalise", "mirror", "window", "blend"))
        best, ok = consistent_skips(cal, vendor, t, overlap, cfg, outputs, means, grid)
        if is_true:
            if not ok:
                return False, "the true reading is not consistent with its own calibration output", info
            info["thresholds"] = ok
        elif best < APART:
            return False, "reading %s %s %s %s %s misses the calibration output by only %.4f" % (
                cfg["placement"], cfg["normalise"], cfg["mirror"], cfg["window"][0], cfg["blend"], best), info
    return True, "", info


def alternatives(cfg, mid=None):
    out = []
    for p in V.PLACEMENTS:
        if p != cfg["placement"]:
            out.append(("placement", dict(cfg, placement=p)))
    for w in V.WINDOWS:
        if w != cfg["window"]:
            out.append(("window", dict(cfg, window=w)))
    for b in V.BLENDS:
        if b != cfg["blend"]:
            out.append(("blend", dict(cfg, blend=b)))
    for m in V.MIRRORS:
        if m != cfg["mirror"]:
            out.append(("mirror", dict(cfg, mirror=m)))
    for n in V.NORMS:
        if n != cfg["normalise"]:
            out.append(("normalise", dict(cfg, normalise=n)))
    out.append(("skip", dict(cfg, skip=None if cfg["skip"] is not None else 0.14)))
    if cfg["skip"] is not None and mid is not None:
        out.append(("cut", dict(cfg, skip=mid)))
    return out


def draw_deployment(rng, spec):
    t = int(rng.choice(TILES))
    overlap = float(rng.choice(OVERLAPS))
    cfg = dict(placement=spec["placement"], window=V.WINDOWS[spec["window"]], blend=spec["blend"],
               mirror=spec["mirror"], normalise=spec["normalise"],
               skip=float(rng.uniform(*SKIPS)) if spec["skip"] else None)
    def tile_means(s):
        return sorted(float(s[y:y + t, x:x + t].mean()) for (y, x) in V.tile_grid(s.shape, t, overlap, cfg["placement"]))

    def cut_clear(ms):
        if cfg["skip"] is None:
            return True
        below = [m for m in ms if m < cfg["skip"]]
        above = [m for m in ms if m >= cfg["skip"]]
        return not (below and above) or min(above) - max(below) >= 0.003

    for _ in range(60):
        cal = S.make_slide(rng, *shape_for(rng, t, overlap, 2, 3, cfg["placement"]), scale=float(rng.uniform(2.6, 3.6)))
        ms = tile_means(cal)
        if cfg["skip"] is None:
            good = sum(1 for m in ms if m < 0.07) >= 2
        else:
            good = (sum(1 for m in ms if m < cfg["skip"]) >= 2 and sum(1 for m in ms if m >= cfg["skip"]) >= 2
                    and cut_clear(ms))
        if good:
            break
    else:
        return None, "no calibration slide with the tiles it needs"
    mid = None
    if cfg["skip"] is not None:
        below = [m for m in ms if m < cfg["skip"]]
        above = [m for m in ms if m >= cfg["skip"]]
        mid = (max(below) + min(above)) / 2.0

    def misplaced(s):
        """Whether a cut at the calibration slide's midpoint runs a different set of this slide's tiles."""
        return any((m >= cfg["skip"]) != (m >= mid) for m in tile_means(s))

    scans = []
    for _ in range(80):
        scans = []
        while len(scans) < SLIDES:
            s = S.make_slide(rng, *shape_for(rng, t, overlap, 2, 4, cfg["placement"]), scale=float(rng.uniform(2.6, 3.8)))
            if cut_clear(tile_means(s)):
                scans.append(s)
        if mid is None or any(misplaced(s) for s in scans):
            break
    else:
        return None, "no graded slide holds a tile the calibration-only cut would misplace"
    vendor, n_cal, cal_means = V.run_build(cal, t, overlap, cfg)
    ok, why, info = calibration_check(cal, vendor, t, overlap, cfg)
    if not ok:
        return None, why
    cons = [c for c in info["thresholds"] if c is not None]
    lo, hi = (min(cons), max(cons)) if cons else (None, None)
    caches = [dict() for _ in scans]
    truth_maps, alt_maps = [], []
    alts = alternatives(cfg, mid)
    for s, cache in zip(scans, caches):
        m, n_run, _ = V.run_build(s, t, overlap, cfg, cache)
        truth_maps.append((m, n_run))
        alt_maps.append([V.run_build(s, t, overlap, a, cache)[0] for _, a in alts])
    # probes: a share drawn where each single wrong convention moves the map, the rest at random
    probes = []
    for si, s in enumerate(scans):
        m = truth_maps[si][0]
        pts = set()
        for j, (name, a) in enumerate(alts):
            mask = np.argwhere(np.abs(alt_maps[si][j] - m) > MOVE)
            if len(mask) >= 3:
                for idx in rng.choice(len(mask), size=3, replace=False):
                    pts.add((int(mask[idx][0]), int(mask[idx][1])))
        while len(pts) < PROBES:
            pts.add((int(rng.integers(s.shape[0])), int(rng.integers(s.shape[1]))))
        pts = sorted(pts)
        keep = rng.permutation(len(pts))[:PROBES]
        probes.append([pts[i] for i in sorted(keep)])
    moved = {}
    for j, (name, a) in enumerate(alts):
        n = 0
        for si in range(SLIDES):
            m = truth_maps[si][0]
            for (r, c) in probes[si]:
                a_v, t_v = float(alt_maps[si][j][r, c]), float(m[r, c])
                if not (math.isfinite(a_v) and math.isfinite(t_v)):
                    raise SystemExit("a non-finite probability in the build's map")
                n += abs(a_v - t_v) > MOVE
        moved[j] = n
    worst = {}
    for j, (name, a) in enumerate(alts):
        worst[name] = min(worst.get(name, 10 ** 9), moved[j])
    for name, n in worst.items():
        if name == "skip" and cfg["skip"] is None:
            continue
        if n < MIN_MOVED:
            return None, "a wrong %s moves only %d probes" % (name, n)
    return dict(t=t, overlap=overlap, cfg=cfg, cal=cal, vendor=vendor, n_cal=n_cal, scans=scans,
                truth_maps=truth_maps, probes=probes, moved=worst, thresholds=(lo, hi)), ""


def specs(mode, rng):
    if mode == "samples":
        return [dict(placement="spread-up", window=0, blend="prob", mirror="none", normalise="none", skip=False)] * 2
    cols = dict(
        placement=["spread-up"] * 7 + ["spread-down"] * 7 + ["stride-clamp"] * 6,
        window=[0] * 8 + [1] * 6 + [2] * 6,
        blend=["prob"] * 10 + ["logit"] * 10,
        mirror=["none"] * 7 + ["lr"] * 6 + ["all"] * 7,
        normalise=["none"] * 7 + ["tile"] * 7 + ["slide"] * 6,
        skip=[True] * 12 + [False] * 8)
    # a slide-normalised build with no mirrored copies leaves tile outputs that agree, so neither the tile
    # placement nor the blend space shows in its output; the deal keeps those two conventions apart
    while True:
        perm = {k: [v[i] for i in rng.permutation(20)] for k, v in cols.items()}
        if not any(perm["normalise"][i] == "slide" and perm["mirror"][i] == "none" for i in range(20)):
            return [{k: perm[k][i] for k in perm} for i in range(20)]


def write_deployment(d, code, site, build, folder, tdir, with_truth):
    os.makedirs(os.path.join(folder, "calibration"), exist_ok=True)
    os.makedirs(os.path.join(folder, "slides"), exist_ok=True)
    os.makedirs(tdir, exist_ok=True)
    cal_shape = d["cal"].shape
    names = ["s%02d" % (i + 1) for i in range(SLIDES)]
    with open(os.path.join(folder, "DEPLOYMENT.md"), "w", encoding="utf-8") as fh:
        fh.write("# Deployment %s\n\n- Programme site: %s\n- Runtime build: %s\n- Model: segnet, tile size %d\n"
                 "- Requested tile overlap: %.2f\n- Calibration slide: %d x %d\n" % (code, site, build, d["t"], d["overlap"],
                                                                                    cal_shape[0], cal_shape[1]))
        for n, s in zip(names, d["scans"]):
            fh.write("- Slide %s: %d x %d\n" % (n, s.shape[0], s.shape[1]))
    np.save(os.path.join(folder, "calibration", "slide.npy"), d["cal"].astype(np.float32))
    np.save(os.path.join(folder, "calibration", "vendor.npy"), d["vendor"].astype(np.float32))
    with open(os.path.join(folder, "run.log"), "w", encoding="utf-8") as fh:
        fh.write("slide=calibration tiles_run=%d\n" % d["n_cal"])
        for n, (m, n_run) in zip(names, d["truth_maps"]):
            fh.write("slide=%s tiles_run=%d\n" % (n, n_run))
    for n, s in zip(names, d["scans"]):
        np.save(os.path.join(folder, "slides", n + ".npy"), s.astype(np.float32))
    rows = []
    for n, pts, (m, _) in zip(names, d["probes"], d["truth_maps"]):
        for (r, c) in pts:
            rows.append((n, r, c, float(m[r, c])))
    with open(os.path.join(folder, "probes.csv"), "w", encoding="utf-8") as fh:
        fh.write("slide,row,col\n")
        for n, r, c, _ in rows:
            fh.write("%s,%d,%d\n" % (n, r, c))
    with open(os.path.join(tdir, "truth.csv"), "w", encoding="utf-8") as fh:
        fh.write("slide,row,col,probability\n")
        for n, r, c, v in rows:
            fh.write("%s,%d,%d,%.6f\n" % (n, r, c, v))
    cfg = dict(d["cfg"])
    cfg["window"] = list(cfg["window"])
    with open(os.path.join(tdir, "build.json"), "w", encoding="utf-8") as fh:
        json.dump(dict(tile=d["t"], overlap=d["overlap"], config=cfg, moved=d["moved"],
                       thresholds=d["thresholds"], slides=names), fh, indent=1)
    if with_truth:
        shutil.copy(os.path.join(tdir, "truth.csv"), os.path.join(folder, "truth.csv"))


def one(args):
    mode, i, spec, seed = args
    rng = np.random.default_rng([seed, i])
    for attempt in range(300):
        d, why = draw_deployment(rng, spec)
        if d is not None:
            return i, d, attempt
    return i, None, 300


def main():
    mode, deployments, truth = sys.argv[1], sys.argv[2], sys.argv[3]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else (20261022 if mode == "graded" else 17)
    rng = np.random.default_rng(seed)
    os.makedirs(deployments, exist_ok=True)
    os.makedirs(truth, exist_ok=True)
    jobs = [(mode, i, spec, seed) for i, spec in enumerate(specs(mode, rng))]
    workers = int(os.environ.get("BUILD_WORKERS", "0")) or min(len(jobs), os.cpu_count() or 1)
    with Pool(workers) as pool:
        results = pool.map(one, jobs, chunksize=1)
    used = set()
    for i, d, attempts in sorted(results, key=lambda r: r[0]):
        if d is None:
            raise SystemExit("deployment %d could not be settled" % i)
        crng = np.random.default_rng([seed, i, 99])
        while True:
            code = code_of(crng, "DP")
            if code not in used:
                break
        used.add(code)
        build = "RT-%s%d" % ("ABCDEFGHJKLMNPQRSTUVWXYZ"[int(crng.integers(24))], int(crng.integers(2, 9)))
        write_deployment(d, code, SITES[int(crng.integers(len(SITES)))], build, os.path.join(deployments, code),
                         os.path.join(truth, code), with_truth=(mode == "samples"))
        print("%2d %s t=%d ov=%.2f (%d draws) %s" % (i, code, d["t"], d["overlap"], attempts + 1, d["cfg"]), flush=True)


if __name__ == "__main__":
    main()
