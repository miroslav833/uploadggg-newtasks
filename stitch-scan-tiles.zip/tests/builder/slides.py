"""Synthetic whole-slide images: tissue (smooth blobs with texture) on a dim noisy background."""
import numpy as np


def smooth(a, sigma):
    h, w = a.shape
    fy = np.fft.fftfreq(h)[:, None]
    fx = np.fft.fftfreq(w)[None, :]
    k = np.exp(-2 * (np.pi * sigma) ** 2 * (fy ** 2 + fx ** 2))
    return np.real(np.fft.ifft2(np.fft.fft2(a) * k))


def make_slide(rng, h, w, scale=4.0):
    field = smooth(rng.standard_normal((h, w)), min(h, w) / scale)
    field = (field - field.mean()) / field.std()
    mask = field > rng.uniform(0.0, 0.5)
    tex = smooth(rng.standard_normal((h, w)), 2.2)
    tex = tex / tex.std()
    fine = rng.standard_normal((h, w))
    tissue = np.clip(0.45 + 0.11 * tex + 0.04 * fine, 0.15, 0.95)
    bg = np.clip(0.045 + 0.012 * rng.standard_normal((h, w)), 0.0, 1.0)
    # soft edge so that border tiles hold intermediate means
    soft = smooth(mask.astype(float), 3.0)
    img = bg * (1.0 - soft) + tissue * soft
    return np.clip(img, 0.0, 1.0).astype(np.float32)
