"""A vendor runtime build: runs the vendor model over overlapping tiles of a slide and blends the tile
outputs into one probability map. The build's conventions are the fields of a config dict:

    placement   spread-up | spread-down | stride-clamp
    window      gaussian (with width) | hann | flat
    blend       prob | logit
    mirror      none | lr | all
    normalise   none | tile | slide
    skip        None, or the mean-intensity threshold under which a tile is not run
"""
import numpy as np

import segnet

PLACEMENTS = ("spread-up", "spread-down", "stride-clamp")
WINDOWS = (("gaussian", 0.2), ("hann", None), ("flat", None))
BLENDS = ("prob", "logit")
MIRRORS = ("none", "lr", "all")
NORMS = ("none", "tile", "slide")


def origins(n, t, overlap, rule):
    if rule == "stride-clamp":
        stride = max(1, int(t * (1.0 - overlap)))
        o = list(range(0, n - t + 1, stride))
        if o[-1] + t < n:
            o.append(n - t)
        return o
    ratio = (n - t) / (t * (1.0 - overlap))
    count = (int(np.ceil(ratio)) if rule == "spread-up" else max(int(np.floor(ratio)), 1)) + 1
    return [int(v) for v in np.round(np.linspace(0, n - t, count))]


def window(t, kind, width):
    u = np.arange(t) - (t - 1) / 2.0
    if kind == "gaussian":
        w = np.maximum(np.exp(-0.5 * (u / (width * t)) ** 2), 1e-3)
    elif kind == "hann":
        w = np.hanning(t + 2)[1:-1]
    else:
        w = np.ones(t)
    return np.outer(w, w).astype(np.float32)


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def tile_grid(slide_shape, t, overlap, rule):
    ys = origins(slide_shape[0], t, overlap, rule)
    xs = origins(slide_shape[1], t, overlap, rule)
    return [(y, x) for y in ys for x in xs]


def tile_outputs(slide, grid, t, normalise, mirror):
    """Per tile, the model's logits averaged over the mirrored copies in both spaces:
    returns {origin: (mean of logits, mean of probabilities)}."""
    flips = {"none": [(False, False)], "lr": [(False, False), (False, True)],
             "all": [(False, False), (False, True), (True, False), (True, True)]}[mirror]
    mu, sd = float(slide.mean()), float(slide.std())
    out = {}
    for (y, x) in grid:
        tile = slide[y:y + t, x:x + t].astype(np.float32)
        if normalise == "tile":
            tile = (tile - tile.mean()) / (tile.std() + 1e-6)
        elif normalise == "slide":
            tile = (tile - mu) / (sd + 1e-6)
        logits, probs = [], []
        for fy, fx in flips:
            v = tile
            if fy:
                v = v[::-1]
            if fx:
                v = v[:, ::-1]
            z = segnet.predict(np.ascontiguousarray(v))
            if fy:
                z = z[::-1]
            if fx:
                z = z[:, ::-1]
            logits.append(z)
            probs.append(sigmoid(z))
        out[(y, x)] = (np.mean(logits, axis=0), np.mean(probs, axis=0))
    return out


def blend(shape, grid, t, outputs, win, blend_space, run):
    acc = np.zeros(shape, dtype=np.float64)
    wsum = np.zeros(shape, dtype=np.float64)
    for o in grid:
        if o not in run:
            continue
        y, x = o
        v = outputs[o][0] if blend_space == "logit" else outputs[o][1]
        acc[y:y + t, x:x + t] += win * v
        wsum[y:y + t, x:x + t] += win
    out = np.zeros(shape, dtype=np.float64)
    covered = wsum > 0
    out[covered] = acc[covered] / wsum[covered]
    if blend_space == "logit":
        out[covered] = sigmoid(out[covered])
    return out.astype(np.float32)


def run_build(slide, t, overlap, cfg, cache=None):
    """The build's probability map for a slide. cache (a dict) holds tile outputs across calls with the
    same slide and the same placement, normalisation and mirroring."""
    grid = tile_grid(slide.shape, t, overlap, cfg["placement"])
    key = (id(slide), cfg["placement"], cfg["normalise"], cfg["mirror"])
    if cache is not None and key in cache:
        outputs = cache[key]
    else:
        outputs = tile_outputs(slide, grid, t, cfg["normalise"], cfg["mirror"])
        if cache is not None:
            cache[key] = outputs
    means = {(y, x): float(slide[y:y + t, x:x + t].mean()) for (y, x) in grid}
    run = {o for o in grid if cfg["skip"] is None or means[o] >= cfg["skip"]}
    kind, width = cfg["window"]
    return blend(slide.shape, grid, t, outputs, window(t, kind, width), cfg["blend"], run), len(run), means
