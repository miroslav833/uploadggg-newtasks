We need a replacement for the vendor's tiling runtime on our scanner boxes. Write `/app/stitch/stitch.py`, called like this:

```
python3 /app/stitch/stitch.py DEPLOYMENT_DIR OUT_CSV
```

Given a deployment folder, it should output the tumour probability that the deployment's own vendor build would give at each probe pixel. Read `/app/programme/HANDBOOK.md` first. The vendor model is in `/app/model` and the handbook explains the folder files. There are two sample deployments in `/app/deployments`; their `truth.csv` files have the vendor values at the probes.

OUT_CSV needs the header `slide,row,col,probability` and then one line per line of `probes.csv` (same order, same slide/row/col):

```
slide,row,col,probability
s01,37,112,0.412907
```

A probe is correct if it is within 0.01 of the vendor value. A deployment passes if at least 95% of its probes are correct. Missing rows, NaN or inf values, or a file that can't be parsed fail the deployment.

We test on 20 hidden deployments that were made in the grading image, and some of their builds work differently from the two samples. At least 18 have to pass. Each run gets its own copy of the folder, runs as a normal (non-root) user using the python3 in the image (numpy 2.2.6 is the only extra package installed), and is killed after 120 seconds. Keep everything the script needs, model included, under `/app/stitch`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
