I'm trying to get rid of the vendor's tiling runtime on our slide scanners, and to do that I need a script that gives the same tumour probabilities theirs does. It should live at /app/stitch/stitch.py and get called as

```
python3 /app/stitch/stitch.py DEPLOYMENT_DIR OUT_CSV
```

A deployment folder is one scanner's setup. Every folder has a calibration slide along with what that scanner's vendor build output for it, plus the slides and probe pixels we actually want numbers for. /app/programme/HANDBOOK.md explains what's in the folder and how the files are laid out, and the vendor's model is in /app/model. I put two deployments in /app/deployments with a truth.csv in each, so you can check your numbers against the vendor's.

For OUT_CSV, write the header slide,row,col,probability and then one line for every probe in the folder's probes.csv, in the same order, like `s01,37,112,0.412907`.

Here's how it gets graded. A probe is right if it's within 0.01 of the vendor's number, and a deployment is right if at least 95% of its probes are. A probe that's left out or comes back as NaN or inf counts against it, and so does a file I can't parse. There are 20 deployments you can't see, generated inside the grading image, and their builds don't all behave like the two samples. You have to get 18 of them right.

Your script runs once per deployment on a copy of the folder, as an ordinary user, with the python3 that's in the image. Numpy 2.2.6 is installed and nothing else outside the standard library. It has 120 seconds for each deployment. Only /app/stitch is kept for grading, so copy the model and anything else the script needs in there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
