Our imaging group is retiring the vendor's tiling software on the scanners' edge boxes, and each box needs a stand-in of its own. You are writing the stand-in: a Python script that takes one deployment's folder and reports the tumour probability the vendor's runtime build itself would give at a list of pixels.

Run it as `python3 /app/stitch/stitch.py DEPLOYMENT_DIR OUT_CSV`.

The handbook at `/app/programme/HANDBOOK.md` is the place to begin; it covers the vendor's model (code and weights under `/app/model`), what a runtime build is, and the layout of each file in a deployment folder. Two finished examples sit in `/app/deployments`, each with a `truth.csv` that lists what its build gave at every probe.

The output is a CSV whose header is `slide,row,col,probability`, followed by one row for each line of the folder's `probes.csv`, in the same order and with the same slide, row and column, and your probability in the last column:

```
slide,row,col,probability
s01,37,112,0.412907
```

For one deployment, a probe is matched when your figure lies within 0.01 of the build's, and the deployment is matched when 95% or more of its probes are. If a row is absent, a figure is NaN or infinite, or the file will not parse, that deployment counts as unmatched.

Twenty further deployments are held back. They were produced inside the grader's image by build variants that the two examples do not all show, and 18 of them must be matched. The script runs once per deployment on a fresh copy of that folder, as a non-privileged user, with the python3 that ships in the image (numpy 2.2.6 is the only third-party package), and is stopped after 120 seconds. Anything it uses, the model included, has to be inside `/app/stitch`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
