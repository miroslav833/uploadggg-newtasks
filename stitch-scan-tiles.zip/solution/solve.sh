#!/usr/bin/env bash
# Reference solution: put the program and the vendor model where the grader looks, then run the program on
# both sample deployments and compare with the builds' own values.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
install -D -m 0644 "$here/stitch/stitch.py" /app/stitch/stitch.py
install -m 0644 "$here/stitch/segnet.py" /app/stitch/segnet.py
install -m 0644 "$here/stitch/weights.npz" /app/stitch/weights.npz
for dep in /app/deployments/*/; do
    code="$(basename "$dep")"
    python3 /app/stitch/stitch.py "$dep" "/tmp/stitched-$code.csv"
    python3 - "$dep/truth.csv" "/tmp/stitched-$code.csv" <<'PY'
import csv, sys
truth = {(r["slide"], r["row"], r["col"]): float(r["probability"]) for r in csv.DictReader(open(sys.argv[1]))}
got = {(r["slide"], r["row"], r["col"]): float(r["probability"]) for r in csv.DictReader(open(sys.argv[2]))}
close = sum(1 for k, v in truth.items() if k in got and abs(got[k] - v) <= 0.01)
print("%s: %d of %d probes within 0.01" % (sys.argv[1].split("/")[-2], close, len(truth)))
sys.exit(0 if close >= 0.95 * len(truth) else 1)
PY
done
