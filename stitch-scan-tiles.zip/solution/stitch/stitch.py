#!/usr/bin/env python3
"""Reproduces a vendor runtime build's probability map at the probe pixels of a deployment.

    python3 stitch.py DEPLOYMENT_DIR OUT_CSV

The build's conventions are read off its own output for the calibration slide: every combination of
tile placement, intensity normalisation, mirrored copies, blending window and blend space is run on the
calibration slide and compared with the vendor's map, with the set of tiles run taken at each cut between
the sorted tile means (a cut of None runs every tile). The combination that reproduces the map is then
run on the other slides, with the cut put in the middle of the cuts that reproduce it."""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "1")

import csv
import re
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import segnet  # noqa: E402

PLACEMENTS = ("spread-up", "spread-down", "stride-clamp")
NORMS = ("none", "tile", "slide")
MIRRORS = ("none", "lr", "all")
WINDOWS = (("gaussian", 0.2), ("hann", None), ("flat", None))
BLENDS = ("prob", "logit")
FLIPS = {"none": [(0, 0)], "lr": [(0, 0), (0, 1)], "all": [(0, 0), (0, 1), (1, 0), (1, 1)]}

FORMS = dict(hann="symmetric", gfloor=1e-3, rounding="even", ddof=0)   # forms the readings vary

DEFAULT = dict(placements=PLACEMENTS, norms=NORMS, mirrors=MIRRORS, windows=WINDOWS, blends=BLENDS,
               skip="counts",      # counts | search | none: how the skipped tiles are found
               eps=1e-6,           # added to the standard deviation when normalising
               cut="middle",       # middle | low | high: where in the consistent range the cut is put
               hann="symmetric",   # symmetric | periodic
               gfloor=1e-3,        # the floor under the Gaussian window
               rounding="even",    # even | up: how fractional tile origins are rounded
               ddof=0)             # degrees of freedom taken off in a standard deviation when normalising


def read_sheet(folder):
    text = open(os.path.join(folder, "DEPLOYMENT.md"), encoding="utf-8").read()
    t = int(re.search(r"tile size (\d+)", text).group(1))
    overlap = float(re.search(r"overlap: ([0-9.]+)", text).group(1))
    return t, overlap


def origins(n, t, overlap, rule):
    if rule == "stride-clamp":
        stride = max(1, int(t * (1.0 - overlap)))
        o = list(range(0, n - t + 1, stride))
        if o[-1] + t < n:
            o.append(n - t)
        return o
    ratio = (n - t) / (t * (1.0 - overlap))
    count = (int(np.ceil(ratio)) if rule == "spread-up" else max(int(np.floor(ratio)), 1)) + 1
    pos = np.linspace(0, n - t, count)
    return [int(v) for v in (np.round(pos) if FORMS["rounding"] == "even" else np.floor(pos + 0.5))]


def window(t, spec):
    kind, width = spec
    u = np.arange(t) - (t - 1) / 2.0
    if kind == "gaussian":
        w = np.maximum(np.exp(-0.5 * (u / (width * t)) ** 2), FORMS["gfloor"])
    elif kind == "hann":
        w = np.hanning(t + 2)[1:-1] if FORMS["hann"] == "symmetric" else np.hanning(t + 1)[:-1]
    else:
        w = np.ones(t)
    return np.outer(w, w)


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def flip_logits(slide, grid, t, norm, eps):
    """Per tile, the model's logits for each of the four flips of the tile (flipped back)."""
    mu, sd = float(slide.mean()), float(slide.std(ddof=FORMS["ddof"]))
    out = {}
    for (y, x) in grid:
        tile = slide[y:y + t, x:x + t].astype(np.float32)
        if norm == "tile":
            tile = (tile - tile.mean()) / (tile.std(ddof=FORMS["ddof"]) + eps)
        elif norm == "slide":
            tile = (tile - mu) / (sd + eps)
        per = {}
        for fy, fx in FLIPS["all"]:
            v = tile[::-1] if fy else tile
            v = v[:, ::-1] if fx else v
            z = segnet.predict(np.ascontiguousarray(v))
            z = z[::-1] if fy else z
            per[(fy, fx)] = z[:, ::-1] if fx else z
        out[(y, x)] = per
    return out


def tile_outputs(per_flip, mirror):
    out = {}
    for o, per in per_flip.items():
        zs = [per[f] for f in FLIPS[mirror]]
        out[o] = (np.mean(zs, axis=0), np.mean([sigmoid(z) for z in zs], axis=0))
    return out


def blend(shape, grid, t, outputs, win, space, run):
    acc = np.zeros(shape)
    wsum = np.zeros(shape)
    for o in grid:
        if o in run:
            y, x = o
            acc[y:y + t, x:x + t] += win * outputs[o][0 if space == "logit" else 1]
            wsum[y:y + t, x:x + t] += win
    out = np.zeros(shape)
    cov = wsum > 0
    out[cov] = acc[cov] / wsum[cov]
    if space == "logit":
        out[cov] = sigmoid(out[cov])
    return out


def identify(cal, vendor, t, overlap, opts):
    """The reading that reproduces the vendor's calibration map: (error, config, cuts that reproduce it).
    Tiles are added to the blend from the highest mean down, so that every cut between the sorted tile
    means is one step of a running sum; each reading is scored at its best cut (on a coarse grid of
    pixels), and the best reading's cuts are then scored in full."""
    sub = (slice(None, None, 3), slice(None, None, 3))
    best = None
    for placement in opts["placements"]:
        grid = [(y, x) for y in origins(cal.shape[0], t, overlap, placement) for x in origins(cal.shape[1], t, overlap, placement)]
        means = {o: float(cal[o[0]:o[0] + t, o[1]:o[1] + t].mean()) for o in grid}
        order = sorted(grid, key=lambda o: -means[o])
        for norm in opts["norms"]:
            per_flip = flip_logits(cal, grid, t, norm, opts["eps"])
            for mirror in opts["mirrors"]:
                outputs = tile_outputs(per_flip, mirror)
                for win_spec in opts["windows"]:
                    win = window(t, win_spec)
                    for space in opts["blends"]:
                        acc = np.zeros(cal.shape)
                        wsum = np.zeros(cal.shape)
                        top = (None, 9.0)
                        for k, o in enumerate(order, 1):
                            y, x = o
                            acc[y:y + t, x:x + t] += win * outputs[o][0 if space == "logit" else 1]
                            wsum[y:y + t, x:x + t] += win
                            if k < len(order) and means[order[k]] == means[o]:
                                continue
                            if opts["skip"] == "none" and k < len(order):
                                continue
                            a, w = acc[sub], wsum[sub]
                            out = np.where(w > 0, a / np.where(w > 0, w, 1.0), 0.0)
                            if space == "logit":
                                out = np.where(w > 0, sigmoid(out), 0.0)
                            e = float(np.abs(out - vendor[sub]).max())
                            if e < top[1]:
                                top = (k, e)
                        if best is None or top[1] < best[0] - 1e-9:
                            best = (top[1], dict(placement=placement, norm=norm, mirror=mirror, window=win_spec, blend=space),
                                    grid, means, outputs, win, order)
    _, cfg, grid, means, outputs, win, order = best
    ms = sorted(set(means.values()))
    cuts = [None] + [(a + b) / 2.0 for a, b in zip(ms[:-1], ms[1:])] if opts["skip"] != "none" else [None]
    errs = []
    for c in cuts:
        run = {o for o in grid if c is None or means[o] >= c}
        errs.append(float(np.abs(blend(cal.shape, grid, t, outputs, win, cfg["blend"], run) - vendor).max()))
    i = int(np.argmin(errs))
    return errs[i], cfg, [c for c, e in zip(cuts, errs) if e <= errs[i] + 0.002]


def pick_cut(cuts, how):
    real = [c for c in cuts if c is not None]
    if not real or None in cuts:
        return None
    return {"middle": (min(real) + max(real)) / 2.0, "low": min(real), "high": max(real)}[how]


def run_slide(slide, t, overlap, cfg, cut, eps):
    grid = [(y, x) for y in origins(slide.shape[0], t, overlap, cfg["placement"]) for x in origins(slide.shape[1], t, overlap, cfg["placement"])]
    outputs = tile_outputs(flip_logits(slide, grid, t, cfg["norm"], eps), cfg["mirror"])
    means = {o: float(slide[o[0]:o[0] + t, o[1]:o[1] + t].mean()) for o in grid}
    run = {o for o in grid if cut is None or means[o] >= cut}
    return blend(slide.shape, grid, t, outputs, window(t, cfg["window"]), cfg["blend"], run), len(run), means


def tiles_logged(folder):
    counts = {}
    for line in open(os.path.join(folder, "run.log"), encoding="utf-8"):
        m = re.match(r"slide=(\S+) tiles_run=(\d+)", line.strip())
        if m:
            counts[m.group(1)] = int(m.group(2))
    return counts


def stitch(folder, opts=None):
    opts = dict(DEFAULT, **(opts or {}))
    FORMS.update(hann=opts["hann"], gfloor=opts["gfloor"], rounding=opts["rounding"], ddof=opts["ddof"])
    t, overlap = read_sheet(folder)
    cal = np.load(os.path.join(folder, "calibration", "slide.npy")).astype(np.float32)
    vendor = np.load(os.path.join(folder, "calibration", "vendor.npy")).astype(np.float64)
    err, cfg, cuts = identify(cal, vendor, t, overlap, opts)
    cut = pick_cut(cuts, opts["cut"])
    logged = tiles_logged(folder)
    probes = list(csv.DictReader(open(os.path.join(folder, "probes.csv"), encoding="utf-8")))
    maps, rows = {}, []
    for name in sorted({p["slide"] for p in probes}):
        slide = np.load(os.path.join(folder, "slides", name + ".npy")).astype(np.float32)
        c = cut
        if opts["skip"] == "counts" and cut is not None and name in logged:
            # the cut whose tile count matches the log, nearest the middle of the consistent range
            grid = [(y, x) for y in origins(slide.shape[0], t, overlap, cfg["placement"]) for x in origins(slide.shape[1], t, overlap, cfg["placement"])]
            means = sorted(float(slide[y:y + t, x:x + t].mean()) for (y, x) in grid)
            if logged[name] >= len(means):
                c = None
            else:
                ok = [(a + b) / 2.0 for a, b in zip(means[:-1], means[1:]) if sum(1 for m in means if m >= (a + b) / 2.0) == logged[name]]
                if ok:
                    c = min(ok, key=lambda v: abs(v - cut))
        maps[name] = run_slide(slide, t, overlap, cfg, c, opts["eps"])[0]
    for p in probes:
        rows.append((p["slide"], int(p["row"]), int(p["col"]), float(maps[p["slide"]][int(p["row"]), int(p["col"])])))
    return rows, cfg, err


def main():
    folder, out = sys.argv[1], sys.argv[2]
    rows, cfg, err = stitch(folder)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["slide", "row", "col", "probability"])
        for s, r, c, v in rows:
            w.writerow([s, r, c, "%.6f" % v])


if __name__ == "__main__":
    main()
