"""The gateway builds: a dynamic batcher, then each batch run as one padded block through rhythmnet.

A build is a dict:
  size     largest batch (4, 6, 8)
  delay    ms the first strip of an open batch may wait (20, 35, 50)
  length   padded length: "longest" in the batch, "block32" (next multiple of 32), or "bucket": the
           smallest of the site's own four bucket lengths (`buckets`) that holds the longest strip
  side     "right" (strip first, padding after) or "left" (padding first)
  fill     what the padding holds: "zero", or "edge" (the strip's nearest sample repeated: its last
           sample on the right, its first on the left)
  norm     "strip" (z-score each strip on its own samples, then pad), "padded" (pad, then z-score the
           padded strip), "batch" (pad, then z-score the whole padded block), "valid" (z-score every
           strip with the mean and deviation of all real samples in the batch, then pad)
  pool     "own" (mean of the features over the strip's own positions) or "all" (over the padded length)
norm "strip" or "valid" with pool "own" is not a build: with causal convolutions padding after a strip never
reaches its own positions, so the padded length would leave no trace."""
import itertools

import numpy as np

import rhythmnet

SIZES = (4, 6, 8)
DELAYS = (20, 35, 50)
LENGTHS = ("longest", "block32", "bucket")
SIDES = ("right", "left")
FILLS = ("zero", "edge")
NORMPOOL = (("strip", "all"), ("padded", "own"), ("padded", "all"), ("batch", "own"), ("batch", "all"),
            ("valid", "all"))
LATENCY = 4
EPS = 1e-6


def draw_buckets(rng):
    """Four bucket lengths, irregular, the last one holding the longest strip (300 samples)."""
    return [int(rng.integers(104, 141)), int(rng.integers(150, 201)), int(rng.integers(212, 263)),
            int(rng.integers(301, 331))]


def all_builds(buckets):
    out = []
    for size, delay, length, side, fill, (norm, pool) in itertools.product(SIZES, DELAYS, LENGTHS, SIDES, FILLS, NORMPOOL):
        out.append({"size": size, "delay": delay, "length": length, "side": side, "fill": fill,
                    "norm": norm, "pool": pool, "buckets": list(buckets)})
    return out


def batches(arrivals, size, delay):
    """Batches (lists of indices in arrival order) and their dispatch times. A batch opens at the first
    arrival after the previous dispatch; it is dispatched at the arrival that fills it to `size`, or at
    open + delay, whichever comes first; a strip arriving at or after that time opens the next batch."""
    order = sorted(range(len(arrivals)), key=lambda i: (arrivals[i], i))
    out, i = [], 0
    while i < len(order):
        opened = arrivals[order[i]]
        group = [order[i]]
        i += 1
        while i < len(order) and len(group) < size and arrivals[order[i]] < opened + delay:
            group.append(order[i])
            i += 1
        sent = arrivals[group[-1]] if len(group) == size else opened + delay
        out.append((group, sent))
    return out


def padded_length(longest, rule, buckets=None):
    if rule == "longest":
        return longest
    if rule == "block32":
        return -(-longest // 32) * 32
    return min(b for b in buckets if b >= longest)


def _z(a, mean=None, dev=None):
    mean = a.mean() if mean is None else mean
    dev = a.std() if dev is None else dev
    return (a - mean) / (dev + EPS)


def _pad(values, L, side, fill):
    n = len(values)
    row = np.zeros(L, np.float32)
    if side == "right":
        row[:n] = values
        if fill == "edge":
            row[n:] = values[-1]
        return row, (0, n)
    row[L - n:] = values
    if fill == "edge":
        row[:L - n] = values[0]
    return row, (L - n, L)


def run_block(strips, build):
    L = padded_length(max(len(s) for s in strips), build["length"], build.get("buckets"))
    norm = build["norm"]
    if norm == "valid":
        joined = np.concatenate(strips).astype(np.float32)
        m, d = joined.mean(), joined.std()
    rows, spans = [], []
    for s in strips:
        if norm == "strip":
            values = _z(s)
        elif norm == "valid":
            values = _z(s, m, d)
        else:
            values = s
        row, span = _pad(values.astype(np.float32), L, build["side"], build["fill"])
        if norm == "padded":
            row = _z(row)
        rows.append(row)
        spans.append(span)
    block = np.stack(rows).astype(np.float32)
    if norm == "batch":
        block = _z(block).astype(np.float32)
    probs = []
    for row, (a, b) in zip(block, spans):
        f = rhythmnet.features(row)
        g = f[:, a:b].mean(axis=1) if build["pool"] == "own" else f.mean(axis=1)
        probs.append(1.0 / (1.0 + np.exp(-rhythmnet.head(g))))
    return probs


def score_day(strips, arrivals, build):
    """(probabilities, completion times) for a day of strips."""
    probs = np.zeros(len(strips))
    done = np.zeros(len(strips), np.int64)
    for group, sent in batches(arrivals, build["size"], build["delay"]):
        for i, p in zip(group, run_block([strips[i] for i in group], build)):
            probs[i] = p
            done[i] = sent + LATENCY
    return probs, done
