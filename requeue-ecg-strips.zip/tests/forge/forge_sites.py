"""Forges site folders of the monitoring service and the sealed scores of their traffic.

    forge_sites.py graded SITES_DIR TRUTH_DIR [SEED]    # the twenty graded sites (verifier image)
    forge_sites.py samples SITES_DIR [SEED]             # the two shipped sample sites

A site is kept only when it is settled by what the program is given: the calibration log shows a full
batch and a timed-out one; every build within two changes of the true one misses the calibration scores
by at least APART somewhere; and each single wrong setting moves at least MIN_MOVED of the 120 graded
traffic strips by more than MOVE."""
import csv
import itertools
import json
import os
import string
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gateway as G  # noqa: E402
import strips as S  # noqa: E402

CALIBRATION = 160
TRAFFIC = 300
GRADED = 120
APART = 0.003
MOVE = 0.01
MIN_MOVED = 12
QUOTA = 14
SITES = 20
FIELDS = ("size", "delay", "length", "side", "fill", "normpool")
CHOICES = {"size": G.SIZES, "delay": G.DELAYS, "length": G.LENGTHS, "side": G.SIDES, "fill": G.FILLS,
           "normpool": G.NORMPOOL}
SAMPLE_BUILD = {"size": 6, "delay": 35, "length": "longest", "side": "right", "fill": "zero", "norm": "padded",
                "pool": "own", "buckets": []}


def flat(build):
    return {"size": build["size"], "delay": build["delay"], "length": build["length"], "side": build["side"],
            "fill": build["fill"], "normpool": (build["norm"], build["pool"]), "buckets": build["buckets"]}


def unflat(f):
    return {"size": f["size"], "delay": f["delay"], "length": f["length"], "side": f["side"], "fill": f["fill"],
            "norm": f["normpool"][0], "pool": f["normpool"][1], "buckets": f["buckets"]}


def within(build, steps):
    base = flat(build)
    for fields in itertools.combinations(FIELDS, steps):
        for values in itertools.product(*(CHOICES[f] for f in fields)):
            if all(v != base[f] for f, v in zip(fields, values)):
                alt = dict(base)
                alt.update(zip(fields, values))
                yield "+".join("%s=%s" % (f, v if not isinstance(v, tuple) else "/".join(v)) for f, v in zip(fields, values)), unflat(alt)


def arrivals(rng, count, build):
    """Integer ms arrivals in bursts and lulls, nudged so that no strip arrives exactly when an open batch
    times out (the batcher's boundary is then never decisive)."""
    gaps = []
    while len(gaps) < count:
        mean = build["delay"] / build["size"] * rng.choice([0.4, 0.8, 1.5, 3.0])
        gaps += list(np.maximum(1, np.rint(rng.exponential(mean, int(rng.integers(6, 30))))))
    t = (np.cumsum(gaps[:count]) + int(rng.integers(1000, 5000))).astype(np.int64)
    for _ in range(200):
        clash = False
        for group, sent in G.batches(t, build["size"], build["delay"]):
            if len(group) < build["size"]:
                hit = np.where(t == sent)[0]
                if len(hit):
                    t[hit[0]:] += 1
                    clash = True
                    break
        if not clash:
            return t
    return None


def settle(build, rng, tries=30):
    for _ in range(tries):
        cal = S.strips(rng, CALIBRATION)
        cal_t = arrivals(rng, CALIBRATION, build)
        if cal_t is None:
            continue
        sizes = [len(g) for g, _ in G.batches(cal_t, build["size"], build["delay"])]
        if build["size"] not in sizes or min(sizes) >= build["size"] or len(set(sizes)) < 3:
            continue
        cal_p, cal_done = G.score_day(cal, cal_t, build)
        ok = True
        for steps in (1, 2):
            for _, alt in within(build, steps):
                if np.abs(G.score_day(cal, cal_t, alt)[0] - cal_p).max() < APART:
                    ok = False
                    break
            if not ok:
                break
        if not ok:
            continue
        day = S.strips(rng, TRAFFIC)
        day_t = arrivals(rng, TRAFFIC, build)
        if day_t is None:
            continue
        if build["length"] == "bucket":
            used = lambda ss, tt: {G.padded_length(max(len(ss[i]) for i in g), "bucket", build["buckets"])
                                   for g, _ in G.batches(tt, build["size"], build["delay"])}
            if not used(day, day_t) <= used(cal, cal_t):
                continue
        day_p = G.score_day(day, day_t, build)[0]
        moves = {name: np.abs(G.score_day(day, day_t, alt)[0] - day_p) > MOVE for name, alt in within(build, 1)}
        if any(m.sum() < QUOTA for m in moves.values()):
            continue
        chosen = set()
        for name in sorted(moves, key=lambda k: moves[k].sum()):
            have = sum(moves[name][i] for i in chosen)
            pool = [i for i in rng.permutation(TRAFFIC) if moves[name][i] and i not in chosen]
            chosen.update(pool[:max(0, QUOTA - have)])
        if len(chosen) > GRADED:
            continue
        rest = [i for i in rng.permutation(TRAFFIC) if i not in chosen]
        graded = sorted(list(chosen) + rest[:GRADED - len(chosen)])
        moved = {name: int(m[graded].sum()) for name, m in moves.items()}
        if min(moved.values()) < MIN_MOVED:
            continue
        return dict(cal=cal, cal_t=cal_t, cal_p=cal_p, cal_done=cal_done, day=day, day_t=day_t,
                    day_p=day_p, graded=graded, moved=moved)
    return None


def code_for(rng, taken):
    while True:
        c = "S-" + "".join(rng.choice(list(string.ascii_uppercase + string.digits), 4))
        if c not in taken:
            return c


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def write_site(folder, code, got, rng):
    for sub in ("calibration", "traffic"):
        os.makedirs(os.path.join(folder, sub))
    cal_ids = ["c%03d" % (i + 1) for i in range(CALIBRATION)]
    day_ids = ["t%03d" % (i + 1) for i in range(TRAFFIC)]
    for ids, data, sub in ((cal_ids, got["cal"], "calibration"), (day_ids, got["day"], "traffic")):
        np.savez_compressed(os.path.join(folder, sub, "strips.npz"), **dict(zip(ids, data)))
    write_csv(os.path.join(folder, "calibration", "log.csv"), ["id", "arrival_ms", "done_ms"],
              [[i, int(a), int(d)] for i, a, d in zip(cal_ids, got["cal_t"], got["cal_done"])])
    write_csv(os.path.join(folder, "calibration", "scores.csv"), ["id", "probability"],
              [[i, "%.6f" % p] for i, p in zip(cal_ids, got["cal_p"])])
    write_csv(os.path.join(folder, "traffic", "log.csv"), ["id", "arrival_ms"],
              [[i, int(a)] for i, a in zip(day_ids, got["day_t"])])
    with open(os.path.join(folder, "GATEWAY.md"), "w", encoding="utf-8") as fh:
        fh.write("# Gateway %s\n\n" % code)
        fh.write("- firmware: %d.%d.%d\n" % (rng.integers(1, 5), rng.integers(0, 12), rng.integers(0, 30)))
        fh.write("- region: %s\n" % rng.choice(["north", "south", "east", "west", "central"]))
        fh.write("- calibration day: %d strips, with completion times and the gateway's scores\n" % CALIBRATION)
        fh.write("- traffic day: %d strips, arrival times only\n" % TRAFFIC)
    return day_ids


def deal(rng):
    counts = {"size": (7, 7, 6), "delay": (7, 7, 6), "length": (7, 7, 6), "side": (10, 10), "fill": (10, 10),
              "normpool": (4, 5, 0, 4, 0, 7)}
    cols = {}
    for f in FIELDS:
        col = []
        for v, n in zip(CHOICES[f], counts[f]):
            col += [v] * n
        cols[f] = [col[i] for i in rng.permutation(SITES)]
    return [unflat(dict({f: cols[f][i] for f in FIELDS}, buckets=G.draw_buckets(rng))) for i in range(SITES)]


def graded(sites_dir, truth_dir, seed):
    rng = np.random.default_rng(seed)
    taken = set()
    for k, build in enumerate(deal(rng)):
        srng = np.random.default_rng([seed, k])
        got = settle(build, srng)
        if got is None:
            raise SystemExit("site %d (%s) would not settle" % (k, build))
        code = code_for(rng, taken)
        taken.add(code)
        day_ids = write_site(os.path.join(sites_dir, code), code, got, srng)
        os.makedirs(os.path.join(truth_dir, code))
        write_csv(os.path.join(truth_dir, code, "expected.csv"), ["id", "probability"],
                  [[day_ids[i], "%.6f" % got["day_p"][i]] for i in got["graded"]])
        with open(os.path.join(truth_dir, code, "build.json"), "w", encoding="utf-8") as fh:
            json.dump({"code": code, "build": build, "moved": got["moved"]}, fh, indent=1)
        print(code, build, "least moved", min(got["moved"].values()), flush=True)


def samples(sites_dir, seed):
    rng = np.random.default_rng(seed)
    taken = set()
    for k in range(2):
        srng = np.random.default_rng([seed, 100 + k])
        got = settle(dict(SAMPLE_BUILD, buckets=G.draw_buckets(srng)), srng)
        code = code_for(rng, taken)
        taken.add(code)
        folder = os.path.join(sites_dir, code)
        day_ids = write_site(folder, code, got, srng)
        write_csv(os.path.join(folder, "expected.csv"), ["id", "probability"],
                  [[i, "%.6f" % p] for i, p in zip(day_ids, got["day_p"])])
        print(code, "least moved", min(got["moved"].values()), flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "graded":
        graded(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 20261023)
    elif sys.argv[1] == "samples":
        samples(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 77)
    else:
        raise SystemExit(__doc__)
