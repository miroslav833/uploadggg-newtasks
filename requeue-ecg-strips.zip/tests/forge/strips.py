"""Synthetic single-lead ECG strips at 50 Hz as the wearables upload them: beats at a varying rate (some
irregular), QRS width and amplitude per strip, a trailing dip, baseline wander, noise and an offset."""
import numpy as np

RATE = 50


def strip(rng, n):
    t = np.arange(n)
    hr = rng.uniform(0.8, 2.2)
    jitter = rng.uniform(0, 1) ** 2 * 6
    x = rng.uniform(0.1, 0.4) * np.sin(2 * np.pi * rng.uniform(0.1, 0.4) * t / RATE + rng.uniform(0, 6.3))
    width = rng.uniform(0.8, 2.5)
    phase = rng.uniform(0, 1)
    for k in range(int(n / RATE * hr) + 2):
        c = (k + phase) / hr * RATE + rng.normal(0, jitter + 0.3)
        x += rng.uniform(0.6, 1.6) * np.exp(-((t - c) ** 2) / (2 * width ** 2))
        x -= 0.25 * np.exp(-((t - c - 4) ** 2) / 8)
    x += rng.normal(0, 0.05, n) + rng.uniform(-1, 1)
    return x.astype(np.float32)


def strips(rng, count, low=90, high=300):
    return [strip(rng, int(rng.integers(low, high + 1))) for _ in range(count)]
