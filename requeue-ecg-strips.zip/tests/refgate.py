"""The verifier's own forward model of a gateway build, written apart from the forge: its own batcher (an
event loop over the arrivals), its own causal convolutions (per-tap sums in float64 over the weight
file) and its own padding, normalisation and pooling."""
import csv
import math
import os

import numpy as np

def load_weights(path):
    with np.load(path) as z:
        return {k: z[k].astype(np.float64) for k in z.files}


def group(arrivals, size, delay):
    """[(ids in arrival order, dispatch ms)] for a list of (id, arrival_ms)."""
    queue = sorted(arrivals, key=lambda p: (p[1], p[0]))
    out, current, opened = [], [], None
    for ident, t in queue:
        if current and t >= opened + delay:
            out.append((current, opened + delay))
            current = []
        if not current:
            opened = t
        current.append(ident)
        if len(current) == size:
            out.append((current, t))
            current = []
    if current:
        out.append((current, opened + delay))
    return out


def _causal(x, w, b, dilation):
    """x (C, T) -> (O, T): out[o, t] = b[o] + sum_c sum_j w[o, c, j] * x[c, t - (k-1-j)*dilation]."""
    c, t = x.shape
    o, _, k = w.shape
    out = np.repeat(b[:, None], t, axis=1).astype(np.float64)
    for j in range(k):
        lag = (k - 1 - j) * dilation
        shifted = np.zeros((c, t))
        if lag < t:
            shifted[:, lag:] = x[:, :t - lag]
        out += w[:, :, j] @ shifted
    return out


def _probability(net, row, span, pool):
    h = np.maximum(_causal(row[None, :], net["w1"], net["b1"], 1), 0)
    h = np.maximum(_causal(h, net["w2"], net["b2"], 2), 0)
    g = h[:, span[0]:span[1]].mean(axis=1) if pool == "own" else h.mean(axis=1)
    return 1 / (1 + math.exp(-(float(net["wh"] @ g) + float(net["bh"]))))


def _standard(a):
    return (a - a.mean()) / (a.std() + 1e-6)


def block_scores(net, signals, build):
    longest = max(len(s) for s in signals)
    if build["length"] == "longest":
        L = longest
    elif build["length"] == "block32":
        L = 32 * math.ceil(longest / 32)
    else:
        L = next(b for b in sorted(build["buckets"]) if b >= longest)
    norm, fill = build["norm"], build["fill"]
    if norm == "valid":
        everything = np.concatenate([s.astype(np.float64) for s in signals])
        mu, sd = everything.mean(), everything.std()
    rows, spans = [], []
    for s in signals:
        s = s.astype(np.float64)
        if norm == "strip":
            s = _standard(s)
        elif norm == "valid":
            s = (s - mu) / (sd + 1e-6)
        lo = 0 if build["side"] == "right" else L - len(s)
        hi = lo + len(s)
        row = np.empty(L)
        row[lo:hi] = s
        row[:lo] = s[0] if fill == "edge" else 0.0
        row[hi:] = s[-1] if fill == "edge" else 0.0
        rows.append(_standard(row) if norm == "padded" else row)
        spans.append((lo, hi))
    block = np.array(rows)
    if norm == "batch":
        block = _standard(block)
    return [_probability(net, r, sp, build["pool"]) for r, sp in zip(block, spans)]


def read_log(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return [(r["id"], int(r["arrival_ms"])) for r in csv.DictReader(fh)]


def day_scores(net, folder, build):
    """{id: probability} for every strip of a site's day folder."""
    log = read_log(os.path.join(folder, "log.csv"))
    out = {}
    with np.load(os.path.join(folder, "strips.npz")) as bank:
        for ids, _ in group(log, build["size"], build["delay"]):
            out.update(zip(ids, block_scores(net, [bank[i] for i in ids], build)))
    return out


def day_completions(folder, build):
    log = read_log(os.path.join(folder, "log.csv"))
    return {i: sent + 4 for ids, sent in group(log, build["size"], build["delay"]) for i in ids}


def read_scores(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return {r["id"]: float(r["probability"]) for r in csv.DictReader(fh)}


def strips_within(filed, expected, tol=0.005):
    return sum(1 for i, v in expected.items()
               if i in filed and math.isfinite(filed[i]) and math.isfinite(v) and abs(filed[i] - v) <= tol)


def site_counts(filed, expected, share=0.95, tol=0.005):
    return filed is not None and strips_within(filed, expected, tol) >= math.ceil(share * len(expected))
