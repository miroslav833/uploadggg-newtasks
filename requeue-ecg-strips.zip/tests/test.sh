#!/usr/bin/env bash
# Grading entry point. Order matters: (1) root takes /logs/verifier, makes it 700 and confirms that with
# stat, else grades 0 without running anything uploaded; (2) any reward, result or score file already in
# it is deleted and a 0 is written; (3) the tests run, and the replay program only ever runs inside it,
# under a throwaway account; (4) every file root did not create is deleted and the single reward is
# written.
set -u
LOGS=/logs/verifier
REPORTS=/run/replaying
old_mode=$(stat -c %a "$LOGS" 2>/dev/null || echo 755)

scrub() {
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
}
finish() {
    scrub
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
    for name in ctrf.json sites.csv; do
        [ -f "$REPORTS/$name" ] && (umask 022; cp "$REPORTS/$name" "$LOGS/$name")
    done
    chmod "$old_mode" "$LOGS" 2>/dev/null
    exit 0
}

mkdir -p "$LOGS" && chown 0:0 "$LOGS" 2>/dev/null; chmod 700 "$LOGS" 2>/dev/null
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "grading: /logs/verifier is not root-only; nothing uploaded is run" >&2
    finish 0
fi
scrub
(umask 022; echo 0 > "$LOGS/reward.txt")
chmod 700 /tests 2>/dev/null; chmod -R go-rwx /tests 2>/dev/null
install -d -o 0 -g 0 -m 700 "$REPORTS"
chmod -R a+rX /app/replay 2>/dev/null

cd /tests && python3 -m pytest -q -p no:cacheprovider --ctrf "$REPORTS/ctrf.json" test_scores.py
[ $? -eq 0 ] && finish 1
finish 0
