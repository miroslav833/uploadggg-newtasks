"""Sandboxed runs of the uploaded replay program, one site at a time.

A Sandbox is a numeric account nobody else uses. Before each run the site folder is copied into a
directory that account owns; the program is started through a small launcher function that leaves
root (new session, no supplementary groups, the account's uid and gid) and caps memory, file size,
process count and core dumps. Whatever the account still has running afterwards is killed before the
output is looked at, and the output is only read as text: a regular file below 1 MiB, opened with
O_NOFOLLOW."""
import csv
import math
import os
import resource
import shutil
import signal
import subprocess
import time

ROOT = "/tests/season"
WORK = "/var/tmp/replaying"
PRIVATE = "/run/replaying"
PROGRAM = "/app/replay/replay.py"
LIMIT_S = 120.0
CAP = 1 << 20


def site_codes():
    return sorted(os.listdir(os.path.join(ROOT, "sites")))


class Sandbox:
    def __init__(self, first=62400):
        busy = set()
        for pid in filter(str.isdigit, os.listdir("/proc")):
            try:
                busy.add(os.stat("/proc/" + pid).st_uid)
            except OSError:
                pass
        self.uid = next(u for u in range(first, first + 5000) if u not in busy)

    def _launcher(self):
        uid = self.uid

        def leave_root():
            os.setsid()
            os.setgroups([])
            os.setgid(uid)
            os.setuid(uid)
            for kind, value in ((resource.RLIMIT_AS, 3 << 30), (resource.RLIMIT_FSIZE, 32 << 20),
                                (resource.RLIMIT_NPROC, 64), (resource.RLIMIT_CORE, 0)):
                resource.setrlimit(kind, (value, value))
        return leave_root

    def _reap(self):
        for _ in range(200):
            alive = []
            for pid in filter(str.isdigit, os.listdir("/proc")):
                try:
                    if os.stat("/proc/" + pid).st_uid == self.uid:
                        alive.append(int(pid))
                except OSError:
                    pass
            if not alive:
                return
            for pid in alive:
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass
            time.sleep(0.03)

    def _give(self, top):
        os.chown(top, self.uid, self.uid)
        for base, dirs, files in os.walk(top):
            for name in dirs + files:
                os.chown(os.path.join(base, name), self.uid, self.uid)

    def replay(self, code):
        box = os.path.join(WORK, code)
        shutil.rmtree(box, ignore_errors=True)
        shutil.copytree(os.path.join(ROOT, "sites", code), os.path.join(box, "site"), symlinks=False)
        os.makedirs(os.path.join(box, "result"))
        os.makedirs(os.path.join(box, "scratch"))
        self._give(box)
        answer = os.path.join(box, "result", "scores.csv")
        scratch = os.path.join(box, "scratch")
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": scratch, "TMPDIR": scratch, "LANG": "C.UTF-8",
               "OPENBLAS_NUM_THREADS": "2", "OMP_NUM_THREADS": "2"}
        with open(os.path.join(PRIVATE, code + ".out"), "wb") as console:
            proc = subprocess.Popen(["/usr/local/bin/python3", PROGRAM, os.path.join(box, "site"), answer],
                                    cwd=scratch, env=env, stdin=subprocess.DEVNULL, stdout=console,
                                    stderr=subprocess.STDOUT, preexec_fn=self._launcher())
            try:
                proc.wait(timeout=LIMIT_S)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        self._reap()
        filed = read_answer(answer)
        shutil.rmtree(box, ignore_errors=True)
        return filed


def read_answer(path):
    """{strip id: probability}, or None for a missing, linked, oversized or malformed file, a repeated
    id or a value that is not a finite number."""
    try:
        st = os.lstat(path)
    except OSError:
        return None
    if os.path.islink(path) or not os.path.isfile(path) or st.st_size > CAP:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        text = os.read(fd, CAP + 1).decode("utf-8", "replace")
    finally:
        os.close(fd)
    out = {}
    try:
        for row in csv.DictReader(text.splitlines()):
            key, value = row["id"], float(row["probability"])
            if key in out or not math.isfinite(value):
                return None
            out[key] = value
    except (KeyError, ValueError, TypeError):
        return None
    return out
