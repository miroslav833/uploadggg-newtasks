"""Acceptance of the offline replay: the sealed scores are what the verifier's own forward model gives,
every site is settled by its calibration day, and the replay matches at least 18 of the 20 sites on 95
per cent of their audited strips within 0.005."""
import csv
import json
import math
import os

import pytest

import harness
import refgate

NEED = 18
CODES = harness.site_codes()
NET = refgate.load_weights("/tests/weights.npz")


def _truth(code):
    return os.path.join(harness.ROOT, "truth", code)


def _site(code):
    return os.path.join(harness.ROOT, "sites", code)


def _build(code):
    with open(os.path.join(_truth(code), "build.json"), encoding="utf-8") as fh:
        return json.load(fh)


@pytest.mark.parametrize("code", CODES)
def test_sealed_scores_follow_the_forward_model(code):
    rebuilt = refgate.day_scores(NET, os.path.join(_site(code), "traffic"), _build(code)["build"])
    sealed = refgate.read_scores(os.path.join(_truth(code), "expected.csv"))
    assert len(sealed) == 120
    assert all(math.isfinite(rebuilt[i]) and math.isfinite(v) for i, v in sealed.items())
    assert max(abs(rebuilt[i] - v) for i, v in sealed.items()) < 2e-5


@pytest.mark.parametrize("code", CODES)
def test_calibration_day_follows_the_forward_model(code):
    build = _build(code)["build"]
    folder = os.path.join(_site(code), "calibration")
    given = refgate.read_scores(os.path.join(folder, "scores.csv"))
    rebuilt = refgate.day_scores(NET, folder, build)
    assert all(math.isfinite(rebuilt[i]) and math.isfinite(v) for i, v in given.items())
    assert max(abs(rebuilt[i] - v) for i, v in given.items()) < 2e-5
    with open(os.path.join(folder, "log.csv"), newline="", encoding="utf-8") as fh:
        logged = {r["id"]: int(r["done_ms"]) for r in csv.DictReader(fh)}
    assert refgate.day_completions(folder, build) == logged


@pytest.mark.parametrize("code", CODES)
def test_every_wrong_setting_shows(code):
    moved = _build(code)["moved"]
    assert len(moved) == 13
    for name, n in moved.items():
        assert n >= 12, "%s moves only %d audited strips" % (name, n)


def test_twenty_sites():
    assert len(CODES) == 20


def test_each_setting_is_well_represented():
    tally = {}
    for code in CODES:
        for field, value in _build(code)["build"].items():
            if field != "buckets":
                tally[(field, value)] = tally.get((field, value), 0) + 1
    assert len(tally) == 19 and min(tally.values()) >= 4, tally


def test_replay_matches_the_gateways():
    box = harness.Sandbox()
    passed = []
    with open(os.path.join(harness.PRIVATE, "sites.csv"), "w", encoding="utf-8") as ledger:
        for code in CODES:
            filed = box.replay(code)
            expected = refgate.read_scores(os.path.join(_truth(code), "expected.csv"))
            ok = refgate.site_counts(filed, expected)
            ledger.write("%s,%d\n" % (code, int(ok)))
            passed += [code] if ok else []
    print("sites matched:", len(passed), "of", len(CODES), passed)
    assert len(passed) >= NEED, "%d of %d sites matched; %d needed" % (len(passed), len(CODES), NEED)
