When our safety team audits an arrhythmia alert, they re-score the patient's old ECG strips offline. The trouble is that the gateways never scored a strip by itself, so running the model on one strip doesn't reproduce what the gateway reported. I want a replay program that does: /app/replay/replay.py, run like

```
python3 /app/replay/replay.py SITE_DIR OUT_CSV
```

Each site folder is one gateway. Its calibration day has the strips, a log of when each arrived and when its score came back, and the scores themselves. Its traffic day has strips and arrival times, nothing else. The strips come as strips.npz files, which are binary bulk data for numpy, not something to print. The handbook is /app/service/HANDBOOK.md, the model lives in /app/model, and /app/sites has two sample sites whose expected.csv lists the gateway's score for every traffic strip.

OUT_CSV should be a header line id,probability followed by one line per strip in traffic/log.csv, e.g. `t001,0.873310`.

How we check it: 120 strips from each site's traffic day were audited. Your probability for a strip has to be within 0.005 of the gateway's, and a site passes when 95% or more of those 120 do. If a strip is missing, a value is NaN or inf, or the file can't be read, that hurts the site. We use 20 sites you don't get to see, which were generated in the grading image, and not every gateway there works like the samples. You need to pass 18 of them.

Each site is replayed separately on a copy of its folder. The program runs without root, using the python3 in the image, and numpy 2.2.6 is the one package installed beyond the standard library. It's stopped after 120 seconds. Since only /app/replay is kept for grading, the model and anything else it needs must be copied there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
