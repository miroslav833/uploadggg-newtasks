"""Offline replay of a gateway build's scores.

    python3 /app/replay/replay.py SITE_DIR OUT_CSV

1. Batches of the calibration day: strips that came back at the same time were scored together. The
   gateway's latency is done - last arrival on full batches; the batch size is the largest batch; the
   queue delay is dispatch - first arrival on batches that were sent before they filled.
2. For each padding side, padding fill and order of normalisation and pooling, the padded length of
   every calibration batch is fitted from the scores (every length from the batch's longest strip to
   340); readings are screened on the largest batch first, and the one that fits every batch best is
   kept. Its lengths name the rule: the longest strip, the next multiple of 32, or the site's own set of
   bucket lengths (each batch's best length).
3. The traffic day's batches are simulated from the arrivals with that size and delay, run with the
   reading, and every strip's probability is written."""
import csv
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rhythmnet  # noqa: E402

READINGS = [(side, fill, norm, pool) for side in ("right", "left") for fill in ("zero", "edge")
            for norm, pool in (("strip", "all"), ("padded", "own"), ("padded", "all"), ("batch", "own"),
                               ("batch", "all"), ("valid", "all"))]
MAX_LENGTH = 340
FIT = 1e-4


def z(a):
    return (a - a.mean()) / (a.std() + 1e-6)


def run_block(sigs, L, side, fill, norm, pool):
    if norm == "valid":
        joined = np.concatenate(sigs)
        mu, sd = joined.mean(), joined.std()
    rows, spans = [], []
    for s in sigs:
        v = z(s) if norm == "strip" else (s - mu) / (sd + 1e-6) if norm == "valid" else s
        a = 0 if side == "right" else L - len(s)
        row = np.full(L, (v[-1] if side == "right" else v[0]) if fill == "edge" else 0.0, np.float32)
        row[a:a + len(s)] = v
        rows.append(z(row) if norm == "padded" else row)
        spans.append((a, a + len(s)))
    block = np.stack(rows).astype(np.float32)
    if norm == "batch":
        block = z(block).astype(np.float32)
    out = []
    for row, (a, b) in zip(block, spans):
        f = rhythmnet.features(row)
        g = f[:, a:b].mean(axis=1) if pool == "own" else f.mean(axis=1)
        out.append(1 / (1 + math.exp(-rhythmnet.head(g))))
    return np.array(out)


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


_BANKS = {}


def load(folder, ident):
    if folder not in _BANKS:
        with np.load(os.path.join(folder, "strips.npz")) as bank:
            _BANKS[folder] = {k: bank[k] for k in bank.files}
    return _BANKS[folder][ident]


def calibration_batches(folder):
    log = read_csv(os.path.join(folder, "log.csv"))
    by_done = {}
    for r in log:
        by_done.setdefault(int(r["done_ms"]), []).append((int(r["arrival_ms"]), r["id"]))
    batches = [sorted(v) for _, v in sorted(by_done.items())]
    size = max(len(b) for b in batches)
    done = {d: sorted(v) for d, v in by_done.items()}
    latency = min(d - v[-1][0] for d, v in done.items() if len(v) == size)
    delays = sorted({d - latency - v[0][0] for d, v in done.items() if len(v) < size})
    return [[i for _, i in b] for b in batches], size, delays[0], latency


def simulate(log, size, delay):
    order = sorted(((int(r["arrival_ms"]), r["id"]) for r in log))
    out, cur, opened = [], [], None
    for t, i in order:
        if cur and t >= opened + delay:
            out.append(cur)
            cur = []
        if not cur:
            opened = t
        cur.append(i)
        if len(cur) == size:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def fit_length(sigs, want, reading):
    """(best padded length, its error) for one batch under one reading."""
    longest = max(len(s) for s in sigs)
    best = (None, float("inf"))
    for L in range(longest, MAX_LENGTH + 1):
        e = float(np.abs(run_block(sigs, L, *reading) - want).max())
        if e < best[1]:
            best = (L, e)
        if e < 1e-6:
            break
    return best


def identify(folder, batches, agg=max):
    scores = {r["id"]: float(r["probability"]) for r in read_csv(os.path.join(folder, "scores.csv"))}
    work = [([load(folder, i) for i in b], np.array([scores[i] for i in b])) for b in batches]
    order = sorted(range(len(work)), key=lambda k: -len(work[k][0]))
    screened = []
    for reading in READINGS:
        errs = [fit_length(*work[k], reading)[1] for k in order[:2]]
        screened.append((max(errs), reading))
    screened.sort(key=lambda x: x[0])
    best = None
    for _, reading in screened[:4]:
        fits = [fit_length(sigs, want, reading) for sigs, want in work]
        score = agg([e for _, e in fits])
        if best is None or score < best[0]:
            best = (score, reading, [(max(len(s) for s in sigs), L) for (sigs, _), (L, _) in zip(work, fits)])
    score, reading, lengths = best
    if all(L == longest for longest, L in lengths):
        rule = ("longest", None)
    elif all(L == 32 * math.ceil(longest / 32) for longest, L in lengths):
        rule = ("block32", None)
    else:
        rule = ("bucket", sorted({L for _, L in lengths}))
    return reading, rule, score


def padded(longest, rule):
    kind, buckets = rule
    if kind == "longest":
        return longest
    if kind == "block32":
        return 32 * math.ceil(longest / 32)
    fit = [b for b in buckets if b >= longest]
    return fit[0] if fit else max(buckets + [longest])


def main():
    site, out = sys.argv[1], sys.argv[2]
    cal = os.path.join(site, "calibration")
    batches, size, delay, latency = calibration_batches(cal)
    reading, rule, worst = identify(cal, batches)
    print("size", size, "delay", delay, "latency", latency, reading, rule, "fit", worst, file=sys.stderr)
    traffic = os.path.join(site, "traffic")
    log = read_csv(os.path.join(traffic, "log.csv"))
    result = {}
    for b in simulate(log, size, delay):
        sigs = [load(traffic, i) for i in b]
        L = padded(max(len(s) for s in sigs), rule)
        result.update(zip(b, run_block(sigs, L, *reading)))
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "probability"])
        for r in log:
            w.writerow([r["id"], "%.6f" % result[r["id"]]])


if __name__ == "__main__":
    main()
