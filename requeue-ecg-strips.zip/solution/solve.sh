#!/bin/bash
# Installs the reference replay with a copy of the model, then replays both sample sites and compares
# every traffic strip with their expected.csv.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/replay
cp "$HERE/replay/replay.py" /app/replay/replay.py
cp /app/model/rhythmnet.py /app/model/weights.npz /app/replay/
for site in /app/sites/*/; do
    out="/tmp/$(basename "$site").csv"
    python3 /app/replay/replay.py "$site" "$out"
    python3 - "$site/expected.csv" "$out" <<'PY'
import csv, sys
want = {r["id"]: float(r["probability"]) for r in csv.DictReader(open(sys.argv[1]))}
got = {r["id"]: float(r["probability"]) for r in csv.DictReader(open(sys.argv[2]))}
close = sum(1 for i, v in want.items() if i in got and abs(got[i] - v) <= 0.005)
print("%s: %d of %d strips within 0.005" % (sys.argv[1], close, len(want)))
sys.exit(0 if close == len(want) else 1)
PY
done
