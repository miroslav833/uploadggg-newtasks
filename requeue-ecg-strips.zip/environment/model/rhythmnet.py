"""The service's rhythm classifier, as the vendor ships it to every gateway.

features(x): x is one strip as the gateway hands it to the model, a float32 array of shape (T,), already
normalised (and padded, if the gateway pads). Two causal 1-D convolutions with ReLU (kernel 7, then
kernel 5 with dilation 2; each output position sees only that position and earlier ones, with zeros
before the start). Returns float32 features of shape (8, T).

head(g): g is a float32 array of shape (8,), the features averaged over time. Returns the logit; the
gateway reports sigmoid(logit) as the arrhythmia probability."""
import os

import numpy as np

_W = np.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "weights.npz"))
W1, B1 = _W["w1"], _W["b1"]
W2, B2 = _W["w2"], _W["b2"]
WH, BH = _W["wh"], _W["bh"]


def _causal(x, w, b, dilation):
    c, t = x.shape
    out_c, _, k = w.shape
    reach = (k - 1) * dilation
    padded = np.zeros((c, t + reach), np.float32)
    padded[:, reach:] = x
    taps = np.stack([padded[:, j * dilation:j * dilation + t] for j in range(k)], axis=1)
    return (w.reshape(out_c, -1) @ taps.reshape(c * k, t) + b[:, None]).astype(np.float32)


def features(x):
    x = np.asarray(x, dtype=np.float32)[None, :]
    h = np.maximum(_causal(x, W1, B1, 1), 0.0)
    return np.maximum(_causal(h, W2, B2, 2), 0.0)


def head(g):
    return float(np.dot(WH, np.asarray(g, dtype=np.float32)) + BH)
