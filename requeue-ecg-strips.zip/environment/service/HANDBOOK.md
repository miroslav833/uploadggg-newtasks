# Remote rhythm monitoring: gateways and offline replay

## The service

Patients wear a single-lead ECG patch. Every few minutes the patch uploads a strip of 90 to 300 samples
(50 samples a second) to its region's gateway. The gateway scores each strip with the rhythm classifier
and raises an alert when the arrhythmia probability is high. Gateways were installed at different times
and run different firmware builds.

The clinical safety team audits alerts by re-scoring past strips offline. An audit is only useful if
the offline scores are the ones the gateway itself reported.

## The classifier

`/app/model/rhythmnet.py` and `/app/model/weights.npz` are the vendor's model, the same on every gateway.

- `features(x)` takes one strip as the gateway hands it to the model: a float32 array of shape (T,).
  It runs two causal 1-D convolutions with ReLU (kernel 7, then kernel 5 with dilation 2). Each output
  position sees only that position and earlier ones, and there are zeros before the start. It returns
  float32 features of shape (8, T).
- `head(g)` takes the features averaged over time, shape (8,), and returns a logit. The gateway reports
  sigmoid(logit).

The model expects strips scaled to zero mean and unit variance (population standard deviation, with
1e-6 added to it).

## What a gateway does

Strips are not scored one by one. The gateway's dynamic batcher collects strips as they arrive. A
batch opens with the first strip that arrives while no batch is open, and it is sent to the model when
it holds the build's batch size or when its first strip has waited the build's queue delay, whichever
comes first. A strip that arrives at or after that moment opens the next batch. The model runs a batch
as one block, with every strip padded to a common length, and all strips of a batch come back
at the same time, a few milliseconds after the batch is sent.

Firmware builds differ in their batch size and queue delay, in how they pad a block and what the
padding holds, in when they normalise a strip and over what, and in what they average the features over. The vendor does not
publish these for a build.

## A site folder

One folder per gateway, as the audit export writes it:

- `GATEWAY.md`: the gateway code, firmware, region, and the size of each day.
- `calibration/log.csv`: one row per strip of the calibration day. Times are milliseconds on the
  gateway's clock, and `done_ms` is when the strip's score came back:

      id,arrival_ms,done_ms
      c001,3071,3109

- `calibration/scores.csv`: the gateway's score for every calibration strip:

      id,probability
      c001,0.912504

- `calibration/strips.npz`: the strips, one float32 array of shape (n,) per id, in millivolts.
- `traffic/log.csv`: arrival times for every strip of the traffic day:

      id,arrival_ms
      t001,2240

- `traffic/strips.npz`: the traffic strips, as above.
- `expected.csv` (sample sites only): the gateway's score for every traffic strip, in the output format.

`/app/sites` holds two sample sites.

## The replay program

    python3 /app/replay/replay.py SITE_DIR OUT_CSV

`OUT_CSV` has the header `id,probability` and one row per traffic strip:

    id,probability
    t001,0.873310
