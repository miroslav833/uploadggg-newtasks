# Gateway S-2I5M

- firmware: 3.1.24
- region: west
- calibration day: 160 strips, with completion times and the gateway's scores
- traffic day: 300 strips, arrival times only
