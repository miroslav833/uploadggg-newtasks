# Gateway S-C2WT

- firmware: 2.6.13
- region: east
- calibration day: 160 strips, with completion times and the gateway's scores
- traffic day: 300 strips, arrival times only
