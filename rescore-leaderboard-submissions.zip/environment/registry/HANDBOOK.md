# Fine-grained listing benchmark leaderboard: handbook

## The benchmark

The benchmark asks a model to name the class of a product photograph. The registry's class table
holds 120 classes in 14 families. Each class has a code such as `cx-17` (the number is an identifier
and carries no order of its own), a family such as `fam-c`, and the count of public training images
the class had when the table was issued. The table's own row order is the registry order.

## Editions of the class table

Edition 1 of the table listed 108 classes. Edition 2, the current one, split twelve of them into
pairs, each pair within one family, and kept every other class as it was. The `edition1_code`
column of `classes.csv` gives, for every class, the code it had in edition 1: the two classes of a
split pair share one edition-1 code, the code of the pair's first member in registry order. A team
that built its training manifest from edition 1 trained on 108 classes, one of which covered both
members of each pair. Tooling that works from edition 1 treats such a class as one row of the table:
its code is the edition-1 code, its family is the pair's family, its training count is the sum of the
two members' counts, and its place in the table's own order is the first member's.

## Submissions

A submitting team trains on the public images and predicts every development and test item. The
team's tooling writes a training manifest from the class table, and the model's output index is the
line number of the class in that manifest. Tooling lays the manifest out in one of a few ways. Some
keeps the table's own order, in either direction. Some sorts the whole table by one column, the
code as text or as a number, or the training count, in either direction. When two classes have the
same training count, tooling that sorts by count keeps them in code order as text, ascending,
whichever direction the count sort runs. Other tooling gathers the families as blocks, one family after another in whatever order that tooling lists the families, and orders the classes inside each block by the table's own order, by code as text or as a number, or by training count, ascending or descending. Some of it picks that inner order once for the whole table and some picks it block by block, so one family's block can be ordered differently from the next. The family order of such tooling is not in the table, and different teams use different ones. Some tooling leaves out the classes whose training count is below a floor of its own: such a class has no line in the manifest, no index stands for it, and the lines after it close up. The floor is not recorded anywhere, and for a manifest built from edition 1 it applies to the summed count of a split pair. Some tooling counts lines from 1 rather than 0. A manifest built from edition 1 has at most 108 lines, one built from edition 2 at most 120.

The submission file lists the index the model gave each item. Three layouts are in use, named in
`submissions.csv` under `layout`: `csv` (an `item,index` file), `csv-conf` (the same with the
model's confidence as a third column) and `jsonl` (one JSON object per line).

## Splits

The development split is small, a few hundred labelled items, and its labels are published with the
round in `dev_labels.csv`. It follows the training distribution, so a common class has many
development items, a rare class has one or two, and many classes have none, in some rounds a
whole family of them. The test split holds several
thousand items, the same for every submission in a round, and its labels are sealed until the round
closes. When a round closes, the test labels and the scores are published.

## The round folder

`classes.csv`: the class table in registry order.

```
code,family,train_count,edition1_code
cx-17,fam-c,1340,cx-17
```

`submissions.csv`: one row per submission.

```
submission,layout
team-k4m2,csv-conf
```

`dev_labels.csv`: the development labels.

```
item,code
d00001,cx-52
```

`dev/<submission>.csv`, `dev/<submission>.jsonl`, `test/<submission>.csv`, `test/<submission>.jsonl`:
the submission's predictions on the split, in its layout.

```
item,index
d00001,37
```

```
item,index,confidence
d00001,37,0.812
```

```
{"item": "d00001", "index": 37}
```

`test_labels.csv` and `scores.csv` (closed rounds only): the test labels, in the layout of
`dev_labels.csv`, and each submission's test accuracy.

```
submission,accuracy
team-k4m2,0.6948
```

Item identifiers, submission names and class codes are the registry's own and carry no meaning.
Every round has the same 120 classes and 14 families, between four and nine submissions, and the
three layouts above.

## The rescoring program

The registry runs one program over a round folder:

```
python3 /app/rescore/score_round.py ROUND_DIR OUT_CSV
```

It writes a CSV with a header row and one row per index a submission used, `submission,index,code`:
the registry class that index stands for in the submission's manifest. An index that stands for two
classes gets two rows.
