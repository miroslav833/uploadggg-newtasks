Write a program which finds, for each submission in one round of our product-photo leaderboard, the registry class that every integer index in its prediction files stands for. It is run as `python3 /app/rescore/score_round.py ROUND_DIR OUT_CSV`.

Handbook is at `/app/registry/HANDBOOK.md`. It covers the class table and its two editions, how teams make manifests and write predictions, the two splits, and each file in a round folder. Two closed rounds are in `/app/registry/rounds`, with the test labels and scores published when they closed.

OUT_CSV needs a header, then one row for each index a submission used anywhere in its files, like this

```
submission,index,code
team-k4m2,37,cx-52
```

An index from a manifest built with edition 1 can stand for both classes of a split pair. It gets two rows then, one for each class.

Checking works like this. For each submission we take the test accuracy its predictions get under your manifest (an index counts as correct when the sealed label is any class you gave it) and compare it with the accuracy under the manifest the team really used. A submission is reproduced when the two are within 0.0005, and a round is reproduced when all its submissions are. We use twenty rounds that are not in the image and at least 18 of them must be reproduced. Not all teams there built their manifests like the teams in the two closed rounds.

Each round is run on its own copy of the folder, as a normal user without root, in 60 seconds. Python is the one that comes with the image, nothing installed on top, and whatever the program needs has to be saved under `/app/rescore`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
