Recover, for one round of a fine-grained listing-classification leaderboard, every submission's training manifest: the registry class each integer index in its prediction files stands for. The program is run as `python3 /app/rescore/score_round.py ROUND_DIR OUT_CSV`.

Read `/app/registry/HANDBOOK.md` first. It covers the class table and its two editions, how teams build manifests and write their predictions, the development and test splits, and every file in a round folder. Two closed rounds are in `/app/registry/rounds`, each with its test labels and the scores published at its close.

OUT_CSV needs a header and one row per index that a submission used anywhere in its files, like this:

```
submission,index,code
team-k4m2,37,cx-52
```

An index that stands for two classes (a manifest built from edition 1, where a split pair was still one class) gets one row per class. Codes are the registry's; indices are the submission's own.

How a filing is judged: for each submission, the test accuracy its predictions reach under your manifest, with an index counted correct when the sealed label is any class you gave it, is compared with the accuracy under the manifest the team actually used. The submission is reproduced when the two agree within 0.0005, and a round is reproduced when every one of its submissions is. Twenty rounds that are not in the image are used, at least 18 must be reproduced, and their submissions do not all build their manifests the way the two closed rounds' teams did.

Each round is handed to your program as its own copy, under a 60-second limit, from a non-root account, on the image's plain Python 3 install (no third-party packages). Anything the program depends on has to live under `/app/rescore`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
