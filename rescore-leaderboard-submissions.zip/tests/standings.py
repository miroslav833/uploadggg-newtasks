"""The grader's own forward model: a submission's test accuracy under a manifest, from the sealed
test labels and the submission's test predictions. Test 1 checks the sealed figures with it under
the sealed manifests; test 2 scores the filed manifests with it."""
import csv
import json
import os


def labels(sealed_dir):
    with open(os.path.join(sealed_dir, "test_labels.csv"), newline="") as fh:
        return {r["item"]: r["code"] for r in csv.DictReader(fh)}


def predictions(round_dir, name, layout):
    path = os.path.join(round_dir, "test", name + (".jsonl" if layout == "jsonl" else ".csv"))
    out = []
    if layout == "jsonl":
        with open(path) as fh:
            for line in fh:
                if line.strip():
                    d = json.loads(line)
                    out.append((d["item"], int(d["index"])))
    else:
        with open(path, newline="") as fh:
            out.extend((r["item"], int(r["index"])) for r in csv.DictReader(fh))
    return out


def submissions(round_dir):
    with open(os.path.join(round_dir, "submissions.csv"), newline="") as fh:
        return [(r["submission"], r["layout"]) for r in csv.DictReader(fh)]


def accuracy(round_dir, sealed_dir, manifests):
    """{submission: accuracy} where manifests maps submission -> {index: iterable of codes}."""
    truth = labels(sealed_dir)
    out = {}
    for name, layout in submissions(round_dir):
        preds = predictions(round_dir, name, layout)
        man = manifests.get(name, {})
        hits = sum(1 for it, ix in preds if truth[it] in man.get(ix, ()))
        out[name] = hits / len(preds) if preds else 0.0
    return out
