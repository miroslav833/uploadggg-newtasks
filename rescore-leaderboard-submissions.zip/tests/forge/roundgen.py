#!/usr/bin/env python3
"""Builds leaderboard rounds: the registry's class table, the development labels, every submission's
development and test predictions under its own manifest, and the sealed truth (each manifest, the
test labels, the figures).

    python3 roundgen.py graded ROUND_DIR VAULT_DIR [SEED0]    the 20 graded rounds
    python3 roundgen.py samples ROUND_DIR [SEED0]             the two sample rounds (with test labels)

Standard library only; one seeded generator per round. A round is kept only when its truth is the
one reading its own evidence allows (see settled()).
"""
import csv
import json
import math
import os
import random
import string
import sys
from collections import Counter, defaultdict

K = 120
FAMILIES = 14
SPLITS = 12
DEV_N, TEST_N = 700, 9000
DEV_EXP = 1.0
AMBIGUOUS_MIN = 3
LAYOUTS = ("csv", "csv-conf", "jsonl")
GRADED = ["aspen", "birch", "cedar", "dogwood", "elm", "fir", "ginkgo", "hazel", "ironwood", "juniper",
          "katsura", "larch", "maple", "nutmeg", "oak", "pine", "quince", "rowan", "spruce", "tamarack"]
SAMPLES = ["alder", "beech"]


def numeric(code):
    return int(code.split("-")[1])


INNERS = ["registry", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc", "count-desc-code", "count-asc-code"]


def inner_key(rule):
    return {
        "registry": (lambda r: r["pos"], False),
        "registry-reversed": (lambda r: r["pos"], True),
        "code-text": (lambda r: r["code"], False),
        "code-text-desc": (lambda r: r["code"], True),
        "code-numeric": (lambda r: numeric(r["code"]), False),
        "code-numeric-desc": (lambda r: numeric(r["code"]), True),
        "family-code-text": (lambda r: (r["family"], r["code"]), False),
        "family-code-numeric": (lambda r: (r["family"], numeric(r["code"])), False),
        "count-desc-code": (lambda r: (-r["count"], r["code"]), False),
        "count-asc-code": (lambda r: (r["count"], r["code"]), False),
    }[rule]


def rule_order(rows, spec):
    """spec: a global rule name, or ("block", inners, family_order): the families in the given order,
    each family's classes inside it ordered by that family's own inner rule (inners: family -> rule)."""
    if isinstance(spec, tuple):
        _, inners, fam_order = spec
        out = []
        for f in fam_order:
            key, rev = inner_key(inners[f])
            out.extend(sorted([r for r in rows if r["family"] == f], key=key, reverse=rev))
        return out
    key, rev = inner_key(spec)
    return sorted(rows, key=key, reverse=rev)


RULES = ["registry", "registry-reversed", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc",
         "family-code-text", "family-code-numeric", "count-desc-code", "count-asc-code"]


def kept_tables(classes, n_lines):
    out = []
    for edition in (2, 1):
        rows = edition_rows(classes, edition)
        seen = set()
        for floor in [0] + sorted({r["count"] for r in rows}):
            kept = [r for r in rows if r["count"] >= floor]
            sig = tuple(r["code"] for r in kept)
            if len(kept) == n_lines and sig not in seen:
                seen.add(sig)
                out.append((edition, kept))
    return out


def block_fits(rows, strong, base, cap=40):
    fams = sorted({r["family"] for r in rows})
    size = {f: sum(1 for r in rows if r["family"] == f) for f in fams}
    within, opts = {}, {}
    for f in fams:
        within[f], opts[f] = {}, {}
        for inner in INNERS:
            key, rev = inner_key(inner)
            order = [tuple(r["members"]) for r in sorted([r for r in rows if r["family"] == f], key=key, reverse=rev)]
            within[f][inner] = order
            offs = {strong[c] - k for k, mem in enumerate(order) for c in mem if c in strong}
            if len(offs) <= 1:
                opts[f][inner] = offs.pop() if offs else None
    found, nodes = [], [0]

    def walk(at, left, chosen):
        nodes[0] += 1
        if len(found) >= cap or nodes[0] > 20000:
            return
        if not left:
            found.append(list(chosen))
            return
        for f in left:
            for inner, start in opts[f].items():
                if start is None or start == at:
                    chosen.append((f, inner, at))
                    walk(at + size[f], [g for g in left if g != f], chosen)
                    chosen.pop()

    walk(base, fams, [])
    return [{at + k: tuple(mem) for f, inner, at in chosen for k, mem in enumerate(within[f][inner])} for chosen in found]


def candidates(classes, strong, base, n_lines):
    """Every manifest of n_lines lines (either edition, any floor, ten global rules or family blocks
    with a rule of their own per block) that agrees with the settled classes. The reference's search."""
    found = {}
    for edition, rows in kept_tables(classes, n_lines):
        held = {m for r in rows for m in r["members"]}
        if any(c not in held for c in strong):
            continue
        for rule in RULES:
            man = {i + base: tuple(r["members"]) for i, r in enumerate(rule_order(rows, rule))}
            pos = {m: ix for ix, mem in man.items() for m in mem}
            if all(pos.get(c) == ix for c, ix in strong.items()):
                found[tuple(sorted(man.items()))] = ("global", rule)
        for man in block_fits(rows, strong, base):
            found[tuple(sorted(man.items()))] = ("block",)
    return found


def edition_rows(classes, edition):
    """The class table of an edition: edition 2 is the registry table; edition 1 groups each split pair
    under its edition-1 code, with the pair's summed count and the position of its first member."""
    if edition == 2:
        return [dict(code=c["code"], family=c["family"], count=c["count"], pos=i, members=[c["code"]])
                for i, c in enumerate(classes)]
    groups = {}
    for i, c in enumerate(classes):
        g = groups.setdefault(c["e1"], dict(code=c["e1"], family=c["family"], count=0, pos=i, members=[]))
        g["count"] += c["count"]
        g["members"].append(c["code"])
    return list(groups.values())


def draw_items(rng, probs, n, prefix):
    codes = list(probs)
    w = [probs[c] for c in codes]
    labels = rng.choices(codes, w, k=n)
    return [("%s%05d" % (prefix, i + 1), lab) for i, lab in enumerate(labels)]


def predict(rng, truth, acc, mates, allcodes, mult):
    if rng.random() < acc * mult[truth]:
        return truth
    if rng.random() < 0.7 and mates[truth]:
        return rng.choice(mates[truth])
    return rng.choice(allcodes)


def build(name, seed, out_dir, vault_dir=None, sample=False, tries=60, redraws=30):
    """Draws a world, then redraws the submissions that keep it from being settled until it is."""
    for t in range(tries):
        rng = random.Random(seed * 1000 + t)
        world = make_world(rng, sample)
        for r in range(redraws):
            verdict = settled(world, sample)
            if verdict is None:
                write(world, name, out_dir, vault_dir, sample)
                return world
            reason, names = verdict
            if names is None:
                break
            if reason.startswith("solves_"):
                world["tstar"] = rng.choice([i for i in INNERS if i != world["tstar"]])
            for j, s in enumerate(world["subs"]):
                if s["name"] in names:
                    world["subs"][j] = make_sub(rng, j, s["name"], s["edition"], sample, world["classes"], world["dev"],
                                                world["test"], world["mates"], world["allcodes"], world["mult"],
                                                world["dark"], world["tstar"])
    raise RuntimeError("no settled world for %s" % name)


def make_world(rng, sample):
    numbers = list(range(1, K + 1))
    rng.shuffle(numbers)
    fam_names = ["fam-%s" % ch for ch in string.ascii_lowercase[:FAMILIES]]
    sizes = [K // FAMILIES] * FAMILIES
    for i in range(K - sum(sizes)):
        sizes[i] += 1
    for _ in range(10):                       # uneven families
        a, b = rng.sample(range(FAMILIES), 2)
        if sizes[a] > 6:
            sizes[a] -= 1
            sizes[b] += 1
    fams = [f for f, s in zip(fam_names, sizes) for _ in range(s)]
    rng.shuffle(fams)
    ranks = list(range(K))
    rng.shuffle(ranks)
    classes = []
    for i in range(K):
        count = max(40, int(4000 * (ranks[i] + 1) ** -0.8 * rng.uniform(0.85, 1.15)))
        classes.append(dict(code="cx-%d" % numbers[i], family=fams[i], count=count, e1=None))
    # edition-1 split pairs: within a family, both members distinct, the pair's code is the first member's
    by_fam = defaultdict(list)
    for i, c in enumerate(classes):
        by_fam[c["family"]].append(i)
    pairs = []
    pool = [f for f in fam_names if len(by_fam[f]) >= 4]
    while len(pairs) < SPLITS:
        f = rng.choice(pool)
        cand = [i for i in by_fam[f] if classes[i]["e1"] is None]
        if len(cand) < 2:
            continue
        a, b = sorted(rng.sample(cand, 2))
        classes[a]["e1"] = classes[a]["code"]
        classes[b]["e1"] = classes[a]["code"]
        pairs.append((a, b))
    for c in classes:
        if c["e1"] is None:
            c["e1"] = c["code"]
    order_by_count = sorted(classes, key=lambda c: -c["count"])
    mult = {c["code"]: (1.0 if sample else 0.6 + 0.4 * (1.0 - i / (K - 1.0)) ** 2.0) for i, c in enumerate(order_by_count)}
    allcodes = [c["code"] for c in classes]
    mates = {c["code"]: [d["code"] for d in classes if d["family"] == c["family"] and d is not c] for c in classes}
    # splits; one family of rare classes draws no development item in a graded round
    fam_count = defaultdict(int)
    for c in classes:
        fam_count[c["family"]] += c["count"]
    dark = None if sample else min(fam_count, key=fam_count.get)
    dev_p = {c["code"]: c["count"] ** (0.75 if sample else DEV_EXP) for c in classes}
    dev_n = DEV_N
    dev = draw_items(rng, dev_p, dev_n, "d")
    if dark:
        dark_codes = {c["code"] for c in classes if c["family"] == dark}
        for _ in range(200):
            if not any(lab in dark_codes for _, lab in dev):
                break
            dev = draw_items(rng, dev_p, dev_n, "d")
        else:
            dev = [(it, lab) for it, lab in dev if lab not in dark_codes]
    tstar = rng.choice(INNERS)
    test_p = {c["code"]: c["count"] ** 0.6 for c in classes}
    test_n = 3000 if sample else TEST_N
    test = draw_items(rng, test_p, test_n, "t")
    # submissions
    n_sub = 4 if sample else rng.randint(7, 9)
    names = []
    while len(names) < n_sub:
        nm = "team-" + "".join(rng.choice(string.ascii_lowercase + string.digits) for _ in range(4))
        if nm not in names and nm[5].isalpha():
            names.append(nm)
    e1_subs = {3} if sample else set(rng.sample(range(n_sub), rng.randint(3, 4)))
    subs = []
    for j, nm in enumerate(names):
        edition = 1 if j in e1_subs else 2
        subs.append(make_sub(rng, j, nm, edition, sample, classes, dev, test, mates, allcodes, mult, dark, tstar))
    return dict(classes=classes, dev=dev, test=test, subs=subs, pairs=pairs, mates=mates, allcodes=allcodes, mult=mult,
                dark=dark, tstar=tstar)


def make_sub(rng, j, nm, edition, sample, classes, dev, test, mates, allcodes, mult, dark=None, tstar=None):
    """One submission: its manifest (layout, edition, floor, base) and its predictions on both splits."""
    dev_n, test_n = len(dev), len(test)
    if sample:
        # the closed rounds show the table's own order, and one team that lays families out as blocks
        one = rng.choice(["code-numeric", "count-desc-code", "code-text"])
        fam_list = sorted({c["family"] for c in classes})
        rule = ("block", {f: rng.choice(["code-numeric", "count-desc-code", "code-text"]) for f in fam_list}, tuple(rng.sample(fam_list, FAMILIES))) if j == 1 else "registry"
        if j == 3:
            # one closed-round team per round sorts the edition-1 table by training count, counting from 1
            rule = rng.choice(["count-desc-code", "count-asc-code"])
    elif rng.random() < 0.8:
        fam_order = sorted({c["family"] for c in classes})
        rng.shuffle(fam_order)
        if rng.random() < 0.5:
            one = rng.choice(INNERS)
            inners = {f: one for f in fam_order}
        else:
            inners = {f: rng.choice(INNERS) for f in fam_order}
        if dark:
            inners[dark] = tstar        # the pipelines in a round share their default for this family
        rule = ("block", inners, tuple(fam_order))
    else:
        rule = rng.choice(RULES)
    base = (1 if j == 3 else 0) if sample else rng.choice([0, 1])
    layout = LAYOUTS[j % 3 if sample else rng.randrange(3)]
    acc = rng.uniform(0.7, 0.9) if sample else rng.uniform(0.74, 0.93)
    rows = edition_rows(classes, edition)
    floor = 0
    if (not sample and rng.random() < 0.4) or (sample and j == 2):
        floor = sorted(r["count"] for r in rows)[rng.randint(3, 12)]
    rows = [r for r in rows if r["count"] >= floor]
    manifest = rule_order(rows, rule)
    kept_codes = [m for r in manifest for m in r["members"]]
    index_of = {}
    for i, r in enumerate(manifest):
        for m in r["members"]:
            index_of[m] = i + base
    truth_map = {i + base: list(r["members"]) for i, r in enumerate(manifest)}
    def guess(lab):
        g = predict(rng, lab, acc, mates, allcodes, mult)
        return g if g in index_of else rng.choice(kept_codes)
    dev_pred = [(it, index_of[guess(lab)]) for it, lab in dev]
    test_pred = [(it, index_of[guess(lab)]) for it, lab in test]
    dev_acc = sum(lab in truth_map[ix] for (it, lab), (_, ix) in zip(dev, dev_pred)) / dev_n
    test_acc = sum(lab in truth_map[ix] for (it, lab), (_, ix) in zip(test, test_pred)) / test_n
    return dict(name=nm, edition=edition, rule=rule, base=base, layout=layout, acc=acc, floor=floor,
                manifest=truth_map, dev_pred=dev_pred, test_pred=test_pred,
                dev_acc=dev_acc, test_acc=test_acc)



def strong_classes(preds, labels, pairs_of, min_items=6, share=0.5, margin=3):
    """class -> index for every class with enough labelled items whose predictions are dominated by
    one index (the row view of the confusion). Two classes claiming one index are kept only when
    they are an edition-1 split pair; otherwise the smaller class is left open."""
    rows = defaultdict(Counter)
    for it, ix in preds:
        lab = labels.get(it)
        if lab is not None:
            rows[lab][ix] += 1
    cand = {}
    for c, cnt in rows.items():
        n = sum(cnt.values())
        (top, k), second = cnt.most_common(1)[0], (cnt.most_common(2)[1][1] if len(cnt) > 1 else 0)
        if n >= min_items and k >= share * n and k >= second + margin:
            cand[c] = (top, k)
    by_ix = defaultdict(list)
    for c, (ix, k) in cand.items():
        by_ix[ix].append((k, c))
    out = {}
    for ix, lst in by_ix.items():
        lst.sort(reverse=True)
        keep = [lst[0]]
        for k, c in lst[1:]:
            if pairs_of.get(c) == lst[0][1]:
                keep.append((k, c))
        for k, c in keep:
            out[c] = ix
    return out


def resolve(classes, dev_labels, subs, min_items=6, share=0.5, margin=3, rounds=8, propagate=True,
            votes="all", test_thresholds=None):
    """The reference reading. subs: name -> (dev_pred, test_pred). Each submission's own development
    evidence settles some classes and leaves the manifests that agree with them; a submission with one
    such manifest is placed, and the placed submissions' test predictions label the test items for the
    rest, whose settled part grows until one manifest is left. Returns name -> (manifest, n_dev_fits)."""
    pairs_of = {}
    groups = defaultdict(list)
    for c in classes:
        groups[c["e1"]].append(c["code"])
    for mem in groups.values():
        if len(mem) == 2:
            pairs_of[mem[0]], pairs_of[mem[1]] = mem[1], mem[0]
    data = {}
    for name, (dev, test) in subs.items():
        used = {ix for _, ix in dev} | {ix for _, ix in test}
        base = min(used)
        strong = strong_classes(dev, dev_labels, pairs_of, min_items, share, margin)
        fits = candidates(classes, strong, base, max(used) - base + 1)
        data[name] = dict(dev=dev, test=test, base=base, n=max(used) - base + 1, strong=strong, fits=fits, n_dev=len(fits))
    placed = {}
    for _ in range(rounds):
        changed = False
        for name, d in data.items():
            if name not in placed and len(d["fits"]) == 1:
                placed[name] = next(iter(d["fits"]))
                changed = True
        if len(placed) == len(data) or not propagate:
            break
        votes_ = defaultdict(Counter)
        for name, d in data.items():
            if votes == "placed" and name not in placed:
                continue
            man = dict(placed[name]) if name in placed else {}
            if not man and votes.startswith("guess") and d["fits"]:
                fits = list(d["fits"])
                if votes == "guess-first":
                    man = dict(fits[0])
                elif votes == "guess-last":
                    man = dict(fits[-1])
                else:
                    def dev_right(f):
                        m = dict(f)
                        return sum(1 for it, ix in d["dev"] if dev_labels.get(it) in m.get(ix, ()))
                    man = dict(max(fits, key=dev_right))
            if not man:
                for c, ix in d["strong"].items():
                    man.setdefault(ix, ())
                    man[ix] = man[ix] + (c,)
            for it, ix in d["test"]:
                mem = man.get(ix, ())
                for m in mem:
                    votes_[it][m] += 1.0 / len(mem)
        pseudo = {it: v.most_common(1)[0][0] for it, v in votes_.items()}
        tmi, tsh, tma = test_thresholds or (min_items, share, margin)
        for name, d in data.items():
            if name in placed:
                continue
            more = strong_classes(d["test"], pseudo, pairs_of, tmi, tsh, tma)
            ext = dict(d["strong"])
            taken = set(ext.values())
            for c, ix in more.items():
                if c not in ext and ix not in taken:
                    ext[c] = ix
                    taken.add(ix)
            if ext != d["strong"]:
                d["strong"] = ext
                d["fits"] = candidates(classes, ext, d["base"], d["n"])
                changed = True
        if not changed:
            break
    out = {}
    for name, d in data.items():
        if name in placed:
            out[name] = (dict(placed[name]), d["n_dev"])
        elif d["fits"]:
            votes = defaultdict(Counter)
            for other, man in placed.items():
                for it, ix in data[other]["test"]:
                    for m in dict(man).get(ix, ()):
                        votes[it][m] += 1
            pseudo = {it: v.most_common(1)[0][0] for it, v in votes.items()}
            def agreement(man):
                m = dict(man)
                return sum(1 for it, ix in d["test"] if pseudo.get(it) in m.get(ix, ()))
            best = max(d["fits"], key=agreement)
            out[name] = (dict(best), d["n_dev"])
        else:
            man = {}
            for c, ix in d["strong"].items():
                man[ix] = man.get(ix, ()) + (c,)
            out[name] = (man, d["n_dev"])
    return out


def settled(world, sample):
    """None when the round's truth is the one reading its evidence allows under every sound reading
    and own-evidence fitting alone does not give it; otherwise (reason, submissions to redraw)."""
    classes, subs = world["classes"], world["subs"]
    dev_labels = dict(world["dev"])
    test_labels = dict(world["test"])
    tc = Counter(test_labels.values())
    if min(tc.get(c["code"], 0) for c in classes) < (5 if sample else 12):
        return ("test_min", None)
    feed = {s["name"]: (s["dev_pred"], s["test_pred"]) for s in subs}
    truth = {s["name"]: {ix: tuple(mem) for ix, mem in s["manifest"].items()} for s in subs}
    bad = [s["name"] for s in subs if len({ix for _, ix in s["test_pred"]}) != len(s["manifest"])]
    if bad:
        return ("used", bad)
    checks = [("rule", {}), ("firm_rule", dict(min_items=7, share=0.55, margin=4)),
              ("loose_rule", dict(min_items=5)), ("placed_votes", dict(votes="placed")),
              ("strict_test", dict(test_thresholds=(8, 0.6, 4)))]
    got = None
    for reason, kw in checks:
        res = resolve(classes, dev_labels, feed, **kw)
        if got is None:
            got = res
        wrong = [n for n in truth if res[n][0] != truth[n]]
        if wrong:
            return (reason, wrong)
    ambiguous = [n for n in got if got[n][1] != 1]
    if sample and ambiguous:
        return ("sample_ambiguous", ambiguous)
    if not sample and len(ambiguous) < AMBIGUOUS_MIN:
        return ("too_plain", [n for n in got if n not in ambiguous][:2])
    if not sample:
        alone = resolve(classes, dev_labels, feed, propagate=False)
        if not [n for n in truth if alone[n][0] != truth[n]]:
            return ("alone_solves", ambiguous[:2])
        blocks = [s["name"] for s in subs if isinstance(s["rule"], tuple)]
        for how in ("guess-first", "guess-last", "guess-dev"):
            res = resolve(classes, dev_labels, feed, votes=how)
            if not [n for n in truth if res[n][0] != truth[n]]:
                return ("solves_" + how, blocks)
    return None


def write(world, name, out_dir, vault_dir, sample):
    classes, subs = world["classes"], world["subs"]
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "classes.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["code", "family", "train_count", "edition1_code"])
        for c in classes:
            w.writerow([c["code"], c["family"], c["count"], c["e1"]])
    with open(os.path.join(out_dir, "submissions.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["submission", "layout"])
        for s in subs:
            w.writerow([s["name"], s["layout"]])
    with open(os.path.join(out_dir, "dev_labels.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["item", "code"])
        w.writerows(world["dev"])
    rng = random.Random(name)
    for split, key in (("dev", "dev_pred"), ("test", "test_pred")):
        os.makedirs(os.path.join(out_dir, split), exist_ok=True)
        for s in subs:
            preds = s[key]
            ext = "jsonl" if s["layout"] == "jsonl" else "csv"
            with open(os.path.join(out_dir, split, s["name"] + "." + ext), "w", newline="") as fh:
                if s["layout"] == "jsonl":
                    for it, ix in preds:
                        fh.write(json.dumps({"item": it, "index": ix}) + "\n")
                else:
                    w = csv.writer(fh)
                    if s["layout"] == "csv":
                        w.writerow(["item", "index"])
                        w.writerows(preds)
                    else:
                        w.writerow(["item", "index", "confidence"])
                        for it, ix in preds:
                            w.writerow([it, ix, "%.3f" % rng.uniform(0.35, 0.99)])
    figures = {s["name"]: s["test_acc"] for s in subs}
    if sample:
        with open(os.path.join(out_dir, "test_labels.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["item", "code"])
            w.writerows(world["test"])
        with open(os.path.join(out_dir, "scores.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["submission", "accuracy"])
            for s in subs:
                w.writerow([s["name"], "%.4f" % s["test_acc"]])
    if vault_dir:
        os.makedirs(vault_dir, exist_ok=True)
        with open(os.path.join(vault_dir, "test_labels.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["item", "code"])
            w.writerows(world["test"])
        with open(os.path.join(vault_dir, "manifests.json"), "w") as fh:
            json.dump({s["name"]: {str(ix): mem for ix, mem in s["manifest"].items()} for s in subs}, fh)
        with open(os.path.join(vault_dir, "figures.json"), "w") as fh:
            json.dump(figures, fh, indent=1)
        with open(os.path.join(vault_dir, "profile.json"), "w") as fh:
            json.dump(dict(name=name, pairs=world["pairs"], dark=world.get("dark"), tstar=world.get("tstar"),
                           subs=[{k: (str(s[k]) if k == "rule" else s[k]) for k in ("name", "edition", "rule", "base", "layout", "acc", "dev_acc", "floor")}
                                 for s in subs]), fh, indent=1)


def _build_one(args):
    name, seed, out_dir, vault_dir = args
    build(name, seed, out_dir, vault_dir)
    return name


def build_graded(round_dir, vault_dir, seed0=20261022, workers=4):
    from multiprocessing import Pool
    jobs = [(name, seed0 * 100 + i, os.path.join(round_dir, name), os.path.join(vault_dir, name))
            for i, name in enumerate(GRADED)]
    with Pool(workers) as pool:
        for name in pool.imap_unordered(_build_one, jobs):
            print("forged", name, flush=True)


def build_samples(round_dir, seed0=7022):
    for i, name in enumerate(SAMPLES):
        build(name, seed0 * 100 + i, os.path.join(round_dir, name), sample=True)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "graded":
        build_graded(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 20261022)
    elif len(sys.argv) >= 3 and sys.argv[1] == "samples":
        build_samples(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 7022)
    else:
        print(__doc__)
        sys.exit(2)
