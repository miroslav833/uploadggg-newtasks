#!/usr/bin/env python3
"""Builds leaderboard rounds: the registry's class table, the development labels, every submission's
development and test predictions under its own manifest, and the sealed truth (each manifest, the
test labels, the figures).

    python3 roundgen.py graded ROUND_DIR VAULT_DIR [SEED0]    the 20 graded rounds
    python3 roundgen.py samples ROUND_DIR [SEED0]             the two sample rounds (with test labels)

Standard library only; one seeded generator per round. A round is kept only when its truth is the
one reading its own evidence allows (see settled()).
"""
import csv
import json
import math
import os
import random
import string
import sys
from collections import Counter, defaultdict

K = 120
FAMILIES = 14
SPLITS = 12
DEV_N, TEST_N = 4200, 6000
DEV_EXP = 1.0
LAYOUTS = ("csv", "csv-conf", "jsonl")
GRADED = ["aspen", "birch", "cedar", "dogwood", "elm", "fir", "ginkgo", "hazel", "ironwood", "juniper",
          "katsura", "larch", "maple", "nutmeg", "oak", "pine", "quince", "rowan", "spruce", "tamarack"]
SAMPLES = ["alder", "beech"]


def numeric(code):
    return int(code.split("-")[1])


INNERS = ["registry", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc", "count-desc-code", "count-asc-code"]


def inner_key(rule):
    return {
        "registry": (lambda r: r["pos"], False),
        "registry-reversed": (lambda r: r["pos"], True),
        "code-text": (lambda r: r["code"], False),
        "code-text-desc": (lambda r: r["code"], True),
        "code-numeric": (lambda r: numeric(r["code"]), False),
        "code-numeric-desc": (lambda r: numeric(r["code"]), True),
        "family-code-text": (lambda r: (r["family"], r["code"]), False),
        "family-code-numeric": (lambda r: (r["family"], numeric(r["code"])), False),
        "count-desc-code": (lambda r: (-r["count"], r["code"]), False),
        "count-asc-code": (lambda r: (r["count"], r["code"]), False),
    }[rule]


def rule_order(rows, spec):
    """spec: a global rule name, or ("block", inner, family_order): the families in the given order,
    each family's classes inside it ordered by the inner rule."""
    if isinstance(spec, tuple):
        _, inner, fam_order = spec
        key, rev = inner_key(inner)
        out = []
        for f in fam_order:
            out.extend(sorted([r for r in rows if r["family"] == f], key=key, reverse=rev))
        return out
    key, rev = inner_key(spec)
    return sorted(rows, key=key, reverse=rev)


RULES = ["registry", "registry-reversed", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc",
         "family-code-text", "family-code-numeric", "count-desc-code", "count-asc-code"]


def candidates(rows, strong, base):
    """Every manifest (as {index: members}) consistent with the settled classes: the ten global
    rules, and family blocks whose order is read off the settled classes."""
    found = {}
    for rule in RULES:
        man = {i + base: tuple(r["members"]) for i, r in enumerate(rule_order(rows, rule))}
        pos = {m: ix for ix, mem in man.items() for m in mem}
        if all(pos.get(c) == ix for c, ix in strong.items()):
            found[tuple(sorted(man.items()))] = ("global", rule)
    fams = sorted({r["family"] for r in rows})
    size = {f: sum(1 for r in rows if r["family"] == f) for f in fams}
    for inner in INNERS:
        key, rev = inner_key(inner)
        within = {f: [m for r in sorted([r for r in rows if r["family"] == f], key=key, reverse=rev) for m in [tuple(r["members"])]]
                  for f in fams}
        start = {}
        ok = True
        for f in fams:
            offs = set()
            for k, mem in enumerate(within[f]):
                for c in mem:
                    if c in strong:
                        offs.add(strong[c] - k)
            if len(offs) > 1:
                ok = False
                break
            if offs:
                start[f] = offs.pop()
        if not ok or set(start) != set(fams):
            continue
        order = sorted(fams, key=lambda f: start[f])
        at = base
        good = True
        for f in order:
            if start[f] != at:
                good = False
                break
            at += size[f]
        if not good:
            continue
        man = {}
        for f in order:
            for k, mem in enumerate(within[f]):
                man[start[f] + k] = mem
        found[tuple(sorted(man.items()))] = ("block", inner)
    return found


def edition_rows(classes, edition):
    """The class table of an edition: edition 2 is the registry table; edition 1 groups each split pair
    under its edition-1 code, with the pair's summed count and the position of its first member."""
    if edition == 2:
        return [dict(code=c["code"], family=c["family"], count=c["count"], pos=i, members=[c["code"]])
                for i, c in enumerate(classes)]
    groups = {}
    for i, c in enumerate(classes):
        g = groups.setdefault(c["e1"], dict(code=c["e1"], family=c["family"], count=0, pos=i, members=[]))
        g["count"] += c["count"]
        g["members"].append(c["code"])
    return list(groups.values())


def draw_items(rng, probs, n, prefix):
    codes = list(probs)
    w = [probs[c] for c in codes]
    labels = rng.choices(codes, w, k=n)
    return [("%s%05d" % (prefix, i + 1), lab) for i, lab in enumerate(labels)]


def predict(rng, truth, acc, mates, allcodes, mult):
    if rng.random() < acc * mult[truth]:
        return truth
    if rng.random() < 0.7 and mates[truth]:
        return rng.choice(mates[truth])
    return rng.choice(allcodes)


def build(name, seed, out_dir, vault_dir=None, sample=False, tries=400):
    for t in range(tries):
        rng = random.Random(seed * 1000 + t)
        world = make_world(rng, sample)
        if settled(world, sample) is None:
            write(world, name, out_dir, vault_dir, sample)
            return world
    raise RuntimeError("no settled world for %s" % name)


def make_world(rng, sample):
    numbers = list(range(1, K + 1))
    rng.shuffle(numbers)
    fam_names = ["fam-%s" % ch for ch in string.ascii_lowercase[:FAMILIES]]
    sizes = [K // FAMILIES] * FAMILIES
    for i in range(K - sum(sizes)):
        sizes[i] += 1
    for _ in range(10):                       # uneven families
        a, b = rng.sample(range(FAMILIES), 2)
        if sizes[a] > 6:
            sizes[a] -= 1
            sizes[b] += 1
    fams = [f for f, s in zip(fam_names, sizes) for _ in range(s)]
    rng.shuffle(fams)
    ranks = list(range(K))
    rng.shuffle(ranks)
    classes = []
    for i in range(K):
        count = max(40, int(4000 * (ranks[i] + 1) ** -0.8 * rng.uniform(0.85, 1.15)))
        classes.append(dict(code="cx-%d" % numbers[i], family=fams[i], count=count, e1=None))
    # edition-1 split pairs: within a family, both members distinct, the pair's code is the first member's
    by_fam = defaultdict(list)
    for i, c in enumerate(classes):
        by_fam[c["family"]].append(i)
    pairs = []
    pool = [f for f in fam_names if len(by_fam[f]) >= 4]
    while len(pairs) < SPLITS:
        f = rng.choice(pool)
        cand = [i for i in by_fam[f] if classes[i]["e1"] is None]
        if len(cand) < 2:
            continue
        a, b = sorted(rng.sample(cand, 2))
        classes[a]["e1"] = classes[a]["code"]
        classes[b]["e1"] = classes[a]["code"]
        pairs.append((a, b))
    for c in classes:
        if c["e1"] is None:
            c["e1"] = c["code"]
    order_by_count = sorted(classes, key=lambda c: -c["count"])
    mult = {c["code"]: (1.0 if sample else 0.35 + 0.65 * (1.0 - i / (K - 1.0)) ** 1.5) for i, c in enumerate(order_by_count)}
    allcodes = [c["code"] for c in classes]
    mates = {c["code"]: [d["code"] for d in classes if d["family"] == c["family"] and d is not c] for c in classes}
    # splits
    dev_p = {c["code"]: c["count"] ** (0.75 if sample else DEV_EXP) for c in classes}
    dev_n = DEV_N
    dev = draw_items(rng, dev_p, dev_n, "d")
    test_p = {c["code"]: c["count"] ** 0.6 for c in classes}
    test_n = 3000 if sample else TEST_N
    test = draw_items(rng, test_p, test_n, "t")
    # submissions
    n_sub = 4 if sample else rng.randint(7, 9)
    names = []
    while len(names) < n_sub:
        nm = "team-" + "".join(rng.choice(string.ascii_lowercase + string.digits) for _ in range(4))
        if nm not in names and nm[5].isalpha():
            names.append(nm)
    e1_subs = set() if sample else set(rng.sample(range(n_sub), rng.randint(3, 4)))
    subs = []
    for j, nm in enumerate(names):
        edition = 1 if j in e1_subs else 2
        if sample:
            # the closed rounds show the table's own order, and one team that lays families out as blocks
            rule = ("block", rng.choice(["code-numeric", "count-desc-code", "code-text"]), tuple(rng.sample(sorted({c["family"] for c in classes}), FAMILIES))) if j == 1 else "registry"
        elif rng.random() < 0.72:
            fam_order = sorted({c["family"] for c in classes})
            rng.shuffle(fam_order)
            rule = ("block", rng.choice(INNERS), tuple(fam_order))
        else:
            rule = rng.choice(RULES)
        base = 0 if sample else rng.choice([0, 1])
        layout = LAYOUTS[j % 3 if sample else rng.randrange(3)]
        acc = rng.uniform(0.7, 0.9) if sample else rng.uniform(0.72, 0.94)
        rows = edition_rows(classes, edition)
        manifest = rule_order(rows, rule)
        index_of = {}
        for i, r in enumerate(manifest):
            for m in r["members"]:
                index_of[m] = i + base
        truth_map = {i + base: list(r["members"]) for i, r in enumerate(manifest)}
        dev_pred = [(it, index_of[predict(rng, lab, acc, mates, allcodes, mult)]) for it, lab in dev]
        test_pred = [(it, index_of[predict(rng, lab, acc, mates, allcodes, mult)]) for it, lab in test]
        dev_acc = sum(lab in truth_map[ix] for (it, lab), (_, ix) in zip(dev, dev_pred)) / dev_n
        test_acc = sum(lab in truth_map[ix] for (it, lab), (_, ix) in zip(test, test_pred)) / test_n
        subs.append(dict(name=nm, edition=edition, rule=rule, base=base, layout=layout, acc=acc,
                         manifest=truth_map, dev_pred=dev_pred, test_pred=test_pred,
                         dev_acc=dev_acc, test_acc=test_acc))
    return dict(classes=classes, dev=dev, test=test, subs=subs, pairs=pairs)


def strong_classes(sub, dev_labels, pairs_of, min_items=6, share=0.5, margin=3):
    """class -> index for every class with enough development items whose predictions are dominated
    by one index (the row view of the confusion). Two classes claiming one index are kept only when
    they are an edition-1 split pair; otherwise the smaller class is left open."""
    rows = defaultdict(Counter)
    for it, ix in sub["dev_pred"]:
        rows[dev_labels[it]][ix] += 1
    cand = {}
    for c, cnt in rows.items():
        n = sum(cnt.values())
        (top, k), second = cnt.most_common(1)[0], (cnt.most_common(2)[1][1] if len(cnt) > 1 else 0)
        if n >= min_items and k >= share * n and k >= second + margin:
            cand[c] = (top, k)
    by_ix = defaultdict(list)
    for c, (ix, k) in cand.items():
        by_ix[ix].append((k, c))
    out = {}
    for ix, lst in by_ix.items():
        lst.sort(reverse=True)
        keep = [lst[0]]
        for k, c in lst[1:]:
            if pairs_of.get(c) == lst[0][1]:
                keep.append((k, c))
        for k, c in keep:
            out[c] = ix
    return out


def settled(world, sample):
    classes, subs = world["classes"], world["subs"]
    dev_labels = dict(world["dev"])
    test_labels = dict(world["test"])
    tc = Counter(test_labels.values())
    if min(tc.get(c["code"], 0) for c in classes) < (5 if sample else 12):
        return "test_min"
    votes = defaultdict(Counter)
    for s in subs:
        for it, ix in s["test_pred"]:
            mem = s["manifest"][ix]
            for m in mem:
                votes[it][m] += 1.0 / len(mem)
    pseudo = {it: votes[it].most_common(1)[0][0] for it in test_labels}
    per_class = Counter(pseudo.values())
    pairs_of = {}
    for a, b in world["pairs"]:
        pairs_of[classes[a]["code"]] = classes[b]["code"]
        pairs_of[classes[b]["code"]] = classes[a]["code"]
    for s in subs:
        index_of = {m: ix for ix, mem in s["manifest"].items() for m in mem}
        strong = strong_classes(s, dev_labels, pairs_of if s["edition"] == 1 else {})
        for c, ix in strong.items():
            if ix != index_of[c]:
                return "strong_wrong"
        claimed = set(strong.values())
        open_ix = [ix for ix in s["manifest"] if ix not in claimed]
        if not sample and not (8 <= len(open_ix) <= 85):
            return "n_open"
        rows = edition_rows(classes, s["edition"])
        found = candidates(rows, strong, s["base"])
        truth_key = tuple(sorted((ix, tuple(mem)) for ix, mem in s["manifest"].items()))
        if len(found) != 1 or truth_key not in found:
            return "rule"
        if not (len(strong) >= 35):
            return "few_strong"
        # a solver who asks for more evidence still settles the manifest: at stricter thresholds the
        # settled classes still fit one manifest and every family keeps at least one of them
        firm = strong_classes(s, dev_labels, pairs_of if s["edition"] == 1 else {}, min_items=7, share=0.55, margin=4)
        fam_of = {c["code"]: c["family"] for c in classes}
        per_fam = Counter(fam_of[c] for c in firm)
        if any(per_fam.get(f, 0) < 1 for f in {c["family"] for c in classes}):
            return "firm_families"
        firm_found = candidates(rows, firm, s["base"])
        if len(firm_found) != 1 or truth_key not in firm_found:
            return "firm_rule"
        used = {ix for _, ix in s["test_pred"]}
        if len(used) != len(s["manifest"]):
            return "used"
    return None


def write(world, name, out_dir, vault_dir, sample):
    classes, subs = world["classes"], world["subs"]
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "classes.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["code", "family", "train_count", "edition1_code"])
        for c in classes:
            w.writerow([c["code"], c["family"], c["count"], c["e1"]])
    with open(os.path.join(out_dir, "submissions.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["submission", "layout"])
        for s in subs:
            w.writerow([s["name"], s["layout"]])
    with open(os.path.join(out_dir, "dev_labels.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["item", "code"])
        w.writerows(world["dev"])
    rng = random.Random(name)
    for split, key in (("dev", "dev_pred"), ("test", "test_pred")):
        os.makedirs(os.path.join(out_dir, split), exist_ok=True)
        for s in subs:
            preds = s[key]
            ext = "jsonl" if s["layout"] == "jsonl" else "csv"
            with open(os.path.join(out_dir, split, s["name"] + "." + ext), "w", newline="") as fh:
                if s["layout"] == "jsonl":
                    for it, ix in preds:
                        fh.write(json.dumps({"item": it, "index": ix}) + "\n")
                else:
                    w = csv.writer(fh)
                    if s["layout"] == "csv":
                        w.writerow(["item", "index"])
                        w.writerows(preds)
                    else:
                        w.writerow(["item", "index", "confidence"])
                        for it, ix in preds:
                            w.writerow([it, ix, "%.3f" % rng.uniform(0.35, 0.99)])
    figures = {s["name"]: s["test_acc"] for s in subs}
    if sample:
        with open(os.path.join(out_dir, "test_labels.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["item", "code"])
            w.writerows(world["test"])
        with open(os.path.join(out_dir, "scores.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["submission", "accuracy"])
            for s in subs:
                w.writerow([s["name"], "%.4f" % s["test_acc"]])
    if vault_dir:
        os.makedirs(vault_dir, exist_ok=True)
        with open(os.path.join(vault_dir, "test_labels.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["item", "code"])
            w.writerows(world["test"])
        with open(os.path.join(vault_dir, "manifests.json"), "w") as fh:
            json.dump({s["name"]: {str(ix): mem for ix, mem in s["manifest"].items()} for s in subs}, fh)
        with open(os.path.join(vault_dir, "figures.json"), "w") as fh:
            json.dump(figures, fh, indent=1)
        with open(os.path.join(vault_dir, "profile.json"), "w") as fh:
            json.dump(dict(name=name, pairs=world["pairs"],
                           subs=[{k: (str(s[k]) if k == "rule" else s[k]) for k in ("name", "edition", "rule", "base", "layout", "acc", "dev_acc")}
                                 for s in subs]), fh, indent=1)


def build_graded(round_dir, vault_dir, seed0=20261022):
    for i, name in enumerate(GRADED):
        build(name, seed0 * 100 + i, os.path.join(round_dir, name), os.path.join(vault_dir, name))


def build_samples(round_dir, seed0=7022):
    for i, name in enumerate(SAMPLES):
        build(name, seed0 * 100 + i, os.path.join(round_dir, name), sample=True)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "graded":
        build_graded(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 20261022)
    elif len(sys.argv) >= 3 and sys.argv[1] == "samples":
        build_samples(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 7022)
    else:
        print(__doc__)
        sys.exit(2)
