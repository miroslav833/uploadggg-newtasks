#!/usr/bin/env bash
# Seals the reward folder, then grades the uploaded program on the vault.
# /logs/verifier becomes root-only before anything of the solver's runs; every reward-shaped file in
# it is removed and reward.txt starts at 0. The program itself runs as an unprivileged account
# (tests/arena.py). At the end only reward.txt is written: 1 when both tests passed.
set -u
LOGS=/logs/verifier
NOTES=/run/grader

mkdir -p "$LOGS"
was="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

scrub() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
reward() {
    scrub
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
done_() {
    chmod "$was" "$LOGS" 2>/dev/null
    exit 0
}

reward 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "grader: $LOGS is not root-only; nothing is run" >&2
    done_
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$NOTES" && chown 0:0 "$NOTES" && chmod 700 "$NOTES"
chmod -R a+rX /app/rescore 2>/dev/null

passed=0
if ( cd /tests && python3 -m pytest test_rounds.py -q -p no:cacheprovider --ctrf "$NOTES/ctrf.json" ); then
    passed=1
fi

reward "$passed"
for f in ctrf.json rounds.json; do
    [ -f "$NOTES/$f" ] && (umask 022; cp "$NOTES/$f" "$LOGS/$f")
done
done_
