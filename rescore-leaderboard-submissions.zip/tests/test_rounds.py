"""Two tests: the sealed figures follow the grader's forward model under the sealed manifests, and
the uploaded program's manifests reproduce enough rounds."""
import json
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import arena       # noqa: E402
import standings   # noqa: E402

ROUNDS = 20
TOLERANCE = 0.0005     # a submission counts when its accuracy under the filed manifest is this close; printed in instruction.md
MARK = 17              # rounds that must count, of 20; printed in instruction.md


def sealed(name):
    base = os.path.join(arena.VAULT, "sealed", name)
    with open(os.path.join(base, "figures.json")) as fh:
        figures = json.load(fh)
    with open(os.path.join(base, "manifests.json")) as fh:
        manifests = {s: {int(ix): codes for ix, codes in m.items()} for s, m in json.load(fh).items()}
    return base, figures, manifests


def counts(name, filed):
    base, figures, _ = sealed(name)
    got = standings.accuracy(os.path.join(arena.VAULT, "rounds", name), base, filed)
    for sub, want in figures.items():
        have = got.get(sub)
        if have is None or not math.isfinite(have) or not math.isfinite(want):
            return False
        if abs(have - want) > TOLERANCE:
            return False
    return True


@pytest.fixture(scope="module")
def filed():
    uid = arena.spare_uid()
    out = {name: arena.run(name, uid) for name in arena.rounds()}
    verdict = {name: counts(name, out[name]) for name in out}
    with open(os.path.join(arena.NOTES, "rounds.json"), "w") as fh:
        json.dump(verdict, fh, indent=1)
    print(json.dumps(verdict))
    return verdict


def test_sealed_figures_follow_the_forward_model():
    names = arena.rounds()
    assert len(names) == ROUNDS
    for name in names:
        base, figures, manifests = sealed(name)
        model = standings.accuracy(os.path.join(arena.VAULT, "rounds", name), base, manifests)
        assert set(model) == set(figures), name
        for sub in figures:
            assert math.isfinite(model[sub]) and math.isfinite(figures[sub]), (name, sub)
            assert abs(model[sub] - figures[sub]) < 1e-9, (name, sub)


def test_enough_rounds_reproduced(filed):
    n = sum(1 for v in filed.values() if v)
    assert n >= MARK, "%d of %d rounds reproduced (%s); %d needed" % (n, ROUNDS, filed, MARK)
