"""Runs the uploaded program once per graded round and reads the manifest it filed.

Each run: a fresh copy of the round folder, a numeric account that owns nothing else, a new session,
address-space and file-size limits, a wall-clock budget. Every process of that account is stopped
before the output is opened; the output is read through a non-following descriptor under a size cap
and parsed as text. Nothing in it is executed.
"""
import csv
import io
import os
import resource
import shutil
import signal
import subprocess
import time
from collections import defaultdict

VAULT = "/tests/vault"
NOTES = "/run/grader"
ARENA = "/var/tmp/arena"
PROGRAM = "/app/rescore/score_round.py"
BUDGET_S = 60
CAP_BYTES = 512 * 1024


def spare_uid():
    busy = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                busy.add(os.stat("/proc/" + d).st_uid)
            except FileNotFoundError:
                pass
    uid = 52001
    while uid in busy:
        uid += 1
    return uid


def quiet(uid):
    for _ in range(200):
        found = []
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    found.append(int(d))
            except FileNotFoundError:
                pass
        if not found:
            return
        for p in found:
            try:
                os.kill(p, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def rounds():
    return sorted(os.listdir(os.path.join(VAULT, "rounds")))


def run(name, uid):
    box = os.path.join(ARENA, name)
    shutil.rmtree(box, ignore_errors=True)
    os.makedirs(box, mode=0o755)
    src, out, home = (os.path.join(box, x) for x in ("round", "out", "home"))
    shutil.copytree(os.path.join(VAULT, "rounds", name), src, symlinks=False)
    os.makedirs(out)
    os.makedirs(home)
    for base, dirs, files in os.walk(box):
        for x in dirs + files:
            os.lchown(os.path.join(base, x), uid, uid)
    os.chown(box, uid, uid)

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    target = os.path.join(out, "manifest.csv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8"}
    with open(os.path.join(NOTES, name + ".log"), "wb") as log:
        proc = subprocess.Popen(["python3", PROGRAM, src, target], stdin=subprocess.DEVNULL,
                                stdout=log, stderr=log, cwd=home, env=env, preexec_fn=drop)
        try:
            proc.wait(timeout=BUDGET_S)
        except subprocess.TimeoutExpired:
            pass
    quiet(uid)
    filed = read_manifest(target)
    shutil.rmtree(box, ignore_errors=True)
    return filed


def read_manifest(path):
    """{submission: {index: set(codes)}} from the filed CSV; rows that do not parse are dropped."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        return {}
    try:
        st = os.fstat(fd)
        if not os.path.stat.S_ISREG(st.st_mode) or st.st_size > CAP_BYTES:
            return {}
        raw = os.read(fd, CAP_BYTES)
    finally:
        os.close(fd)
    out = defaultdict(lambda: defaultdict(set))
    try:
        for row in csv.DictReader(io.StringIO(raw.decode("utf-8", "replace"))):
            name = (row.get("submission") or "").strip()
            code = (row.get("code") or "").strip()
            try:
                ix = int((row.get("index") or "").strip())
            except ValueError:
                continue
            if name and code:
                out[name][ix].add(code)
    except csv.Error:
        return {}
    return out
