#!/usr/bin/env python3
"""Recovers each submission's training manifest for one leaderboard round.

    python3 score_round.py ROUND_DIR OUT_CSV

Writes `submission,index,code` rows: the registry class each of a submission's indices stands for
(two rows for an index of an edition-1 manifest that still covers a split pair).

How: the development labels give, for each class with enough labelled items, the index the
submission writes for it (the row view of the confusion; two classes claiming one index are an
edition-1 pair when the class table lists them under one edition-1 code, otherwise the smaller
claim is left open). Every manifest the handbook allows is then tried against those settled
classes: either edition, any training-count floor that leaves the manifest's line count, the ten
whole-table orders and the family-block layouts, where the settled classes fix where each block
starts under each inner order and the blocks must tile the index range. A submission with one
manifest left is placed. The small development split leaves several manifests for many
submissions; the placed submissions' test predictions then label the test items, each remaining
submission's settled part grows from them, and its manifests are tried again, until one is left.
"""
import csv
import json
import os
import sys
from collections import Counter, defaultdict

MIN_ITEMS, SHARE, MARGIN = 6, 0.5, 3
INNER = ["registry", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc",
         "count-desc-code", "count-asc-code"]
GLOBAL = INNER + ["registry-reversed", "family-code-text", "family-code-numeric"]


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def read_preds(folder, name, layout):
    path = os.path.join(folder, name + (".jsonl" if layout == "jsonl" else ".csv"))
    out = []
    if layout == "jsonl":
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    d = json.loads(line)
                    out.append((d["item"], int(d["index"])))
    else:
        for r in read_csv(path):
            out.append((r["item"], int(r["index"])))
    return out


def numeric(code):
    return int(code.split("-")[1])


def order_key(rule):
    return {
        "registry": (lambda r: r["pos"], False),
        "registry-reversed": (lambda r: r["pos"], True),
        "code-text": (lambda r: r["code"], False),
        "code-text-desc": (lambda r: r["code"], True),
        "code-numeric": (lambda r: numeric(r["code"]), False),
        "code-numeric-desc": (lambda r: numeric(r["code"]), True),
        "family-code-text": (lambda r: (r["family"], r["code"]), False),
        "family-code-numeric": (lambda r: (r["family"], numeric(r["code"])), False),
        "count-desc-code": (lambda r: (-r["count"], r["code"]), False),
        "count-asc-code": (lambda r: (r["count"], r["code"]), False),
    }[rule]


def table(classes, edition):
    """The class table of an edition as rows (code, family, count, registry position, members)."""
    if edition == 2:
        return [dict(code=c["code"], family=c["family"], count=int(c["train_count"]), pos=i, members=(c["code"],))
                for i, c in enumerate(classes)]
    rows = {}
    for i, c in enumerate(classes):
        g = rows.setdefault(c["edition1_code"], dict(code=c["edition1_code"], family=c["family"], count=0, pos=i, members=()))
        g["count"] += int(c["train_count"])
        g["members"] = g["members"] + (c["code"],)
    return list(rows.values())


def kept_tables(classes, n_lines):
    """The tables a manifest of n_lines lines can come from: either edition, with the classes under
    some training-count floor left out."""
    out = []
    for edition in (2, 1):
        rows = table(classes, edition)
        seen = set()
        for floor in [0] + sorted({r["count"] for r in rows}):
            kept = [r for r in rows if r["count"] >= floor]
            sig = tuple(r["code"] for r in kept)
            if len(kept) == n_lines and sig not in seen:
                seen.add(sig)
                out.append(kept)
    return out


def settled_classes(preds, labels, pair_of):
    """class -> index for every class with enough labelled items whose predictions one index
    dominates. Two classes on one index stay only as an edition-1 pair."""
    rows = defaultdict(Counter)
    for it, ix in preds:
        lab = labels.get(it)
        if lab is not None:
            rows[lab][ix] += 1
    cand = {}
    for c, cnt in rows.items():
        n = sum(cnt.values())
        (top, k), second = cnt.most_common(1)[0], (cnt.most_common(2)[1][1] if len(cnt) > 1 else 0)
        if n >= MIN_ITEMS and k >= SHARE * n and k >= second + MARGIN:
            cand[c] = (top, k)
    by_ix = defaultdict(list)
    for c, (ix, k) in cand.items():
        by_ix[ix].append((k, c))
    out = {}
    for ix, lst in by_ix.items():
        lst.sort(reverse=True)
        for k, c in [lst[0]] + [(k, c) for k, c in lst[1:] if pair_of.get(c) == lst[0][1]]:
            out[c] = ix
    return out


def block_layouts(rows, strong, base, cap=40):
    """Family blocks in an order of the tooling's own, each block under an inner order of its own:
    the settled classes fix where a block can start under each inner order, and the blocks must
    tile the index range exactly."""
    fams = sorted({r["family"] for r in rows})
    size = {f: sum(1 for r in rows if r["family"] == f) for f in fams}
    within, opts = {}, {}
    for f in fams:
        within[f], opts[f] = {}, {}
        for inner in INNER:
            key, rev = order_key(inner)
            order = [r["members"] for r in sorted([r for r in rows if r["family"] == f], key=key, reverse=rev)]
            within[f][inner] = order
            offs = {strong[c] - k for k, mem in enumerate(order) for c in mem if c in strong}
            if len(offs) <= 1:
                opts[f][inner] = offs.pop() if offs else None
    found, nodes = [], [0]

    def walk(at, left, chosen):
        nodes[0] += 1
        if len(found) >= cap or nodes[0] > 20000:
            return
        if not left:
            found.append(list(chosen))
            return
        for f in left:
            for inner, start in opts[f].items():
                if start is None or start == at:
                    chosen.append((f, inner, at))
                    walk(at + size[f], [g for g in left if g != f], chosen)
                    chosen.pop()

    walk(base, fams, [])
    return [{at + k: mem for f, inner, at in chosen for k, mem in enumerate(within[f][inner])} for chosen in found]


def layouts(classes, strong, base, n_lines):
    """Every manifest of n_lines lines that agrees with the settled classes, each once."""
    found = {}
    for rows in kept_tables(classes, n_lines):
        held = {m for r in rows for m in r["members"]}
        if any(c not in held for c in strong):
            continue
        for rule in GLOBAL:
            key, rev = order_key(rule)
            man = {i + base: r["members"] for i, r in enumerate(sorted(rows, key=key, reverse=rev))}
            pos = {m: ix for ix, mem in man.items() for m in mem}
            if all(pos.get(c) == ix for c, ix in strong.items()):
                found[tuple(sorted(man.items()))] = man
        for man in block_layouts(rows, strong, base):
            found[tuple(sorted(man.items()))] = man
    return list(found.values())


def pseudo_labels(data, placed):
    """Each test item's majority class over the placed submissions' manifests and the others'
    settled parts."""
    votes = defaultdict(Counter)
    for name, d in data.items():
        man = placed.get(name)
        if man is None:
            man = {}
            for c, ix in d["strong"].items():
                man[ix] = man.get(ix, ()) + (c,)
        for it, ix in d["test"]:
            mem = man.get(ix, ())
            for m in mem:
                votes[it][m] += 1.0 / len(mem)
    return {it: v.most_common(1)[0][0] for it, v in votes.items()}


def recover(round_dir):
    classes = read_csv(os.path.join(round_dir, "classes.csv"))
    subs = read_csv(os.path.join(round_dir, "submissions.csv"))
    dev_labels = {r["item"]: r["code"] for r in read_csv(os.path.join(round_dir, "dev_labels.csv"))}
    groups = defaultdict(list)
    for c in classes:
        groups[c["edition1_code"]].append(c["code"])
    pair_of = {}
    for mem in groups.values():
        if len(mem) == 2:
            pair_of[mem[0]], pair_of[mem[1]] = mem[1], mem[0]

    data = {}
    for s in subs:
        name, layout = s["submission"], s["layout"]
        dev = read_preds(os.path.join(round_dir, "dev"), name, layout)
        test = read_preds(os.path.join(round_dir, "test"), name, layout)
        used = {ix for _, ix in dev} | {ix for _, ix in test}
        base, n_lines = min(used), max(used) - min(used) + 1
        strong = settled_classes(dev, dev_labels, pair_of)
        data[name] = dict(dev=dev, test=test, base=base, n=n_lines, strong=strong,
                          fits=layouts(classes, strong, base, n_lines))

    placed = {}
    for _ in range(8):
        for name, d in data.items():
            if name not in placed and len(d["fits"]) == 1:
                placed[name] = d["fits"][0]
        if len(placed) == len(data):
            break
        pseudo = pseudo_labels(data, placed)
        changed = False
        for name, d in data.items():
            if name in placed:
                continue
            ext = dict(d["strong"])
            taken = set(ext.values())
            for c, ix in settled_classes(d["test"], pseudo, pair_of).items():
                if c not in ext and ix not in taken:
                    ext[c] = ix
                    taken.add(ix)
            if ext != d["strong"]:
                d["strong"] = ext
                d["fits"] = layouts(classes, ext, d["base"], d["n"])
                changed = True
        if not changed:
            break

    pseudo = pseudo_labels(data, placed)
    out = {}
    for name, d in data.items():
        if name in placed:
            out[name] = placed[name]
        elif d["fits"]:
            out[name] = max(d["fits"], key=lambda man: sum(1 for it, ix in d["test"] if pseudo.get(it) in man.get(ix, ())))
        else:
            man = {}
            for c, ix in d["strong"].items():
                man[ix] = man.get(ix, ()) + (c,)
            out[name] = man
    return out


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    manifests = recover(argv[1])
    with open(argv[2], "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["submission", "index", "code"])
        for name in sorted(manifests):
            for ix in sorted(manifests[name]):
                for code in manifests[name][ix]:
                    w.writerow([name, ix, code])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
