#!/usr/bin/env python3
"""Recovers each submission's training manifest for one leaderboard round.

    python3 score_round.py ROUND_DIR OUT_CSV

Writes `submission,index,code` rows: the registry class each of a submission's indices stands for
(two rows for an index of an edition-1 manifest that still covers a split pair).

How: the development labels give, for every class with enough labelled items, the index the
submission writes for it (the row view of the confusion; two classes claiming one index are an
edition-1 pair when the class table lists them as one, otherwise the smaller claim is left open).
That settled part identifies which of the ways a manifest can be sorted produced this manifest,
and the sorted table then places every index, including those no development item exercised. The
placement is checked against the other submissions' agreement on the test items.
"""
import csv
import json
import os
import sys
from collections import Counter, defaultdict

MIN_ITEMS, SHARE = 6, 0.5


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def read_preds(folder, name, layout):
    path = os.path.join(folder, name + (".jsonl" if layout == "jsonl" else ".csv"))
    out = []
    if layout == "jsonl":
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    d = json.loads(line)
                    out.append((d["item"], int(d["index"])))
    else:
        for r in read_csv(path):
            out.append((r["item"], int(r["index"])))
    return out


def numeric(code):
    return int(code.split("-")[1])


def sort_rules():
    return {
        "registry": (lambda r: r["pos"], False),
        "registry-reversed": (lambda r: r["pos"], True),
        "code-text": (lambda r: r["code"], False),
        "code-text-desc": (lambda r: r["code"], True),
        "code-numeric": (lambda r: numeric(r["code"]), False),
        "code-numeric-desc": (lambda r: numeric(r["code"]), True),
        "family-code-text": (lambda r: (r["family"], r["code"]), False),
        "family-code-numeric": (lambda r: (r["family"], numeric(r["code"])), False),
        "count-desc-code": (lambda r: (-r["count"], r["code"]), False),
        "count-asc-code": (lambda r: (r["count"], r["code"]), False),
    }


def table(classes, edition):
    """The class table of an edition as rows (code, family, count, registry position, members)."""
    if edition == 2:
        return [dict(code=c["code"], family=c["family"], count=int(c["train_count"]), pos=i, members=[c["code"]])
                for i, c in enumerate(classes)]
    rows = {}
    for i, c in enumerate(classes):
        g = rows.setdefault(c["edition1_code"], dict(code=c["edition1_code"], family=c["family"], count=0, pos=i, members=[]))
        g["count"] += int(c["train_count"])
        g["members"].append(c["code"])
    return list(rows.values())


def strong_part(dev_pred, dev_labels, pair_of):
    rows = defaultdict(Counter)
    for it, ix in dev_pred:
        if it in dev_labels:
            rows[dev_labels[it]][ix] += 1
    cand = {}
    for c, cnt in rows.items():
        n = sum(cnt.values())
        (top, k), second = cnt.most_common(1)[0], (cnt.most_common(2)[1][1] if len(cnt) > 1 else 0)
        if n >= MIN_ITEMS and k >= SHARE * n and k >= second + 3:
            cand[c] = (top, k)
    by_ix = defaultdict(list)
    for c, (ix, k) in cand.items():
        by_ix[ix].append((k, c))
    out = {}
    for ix, lst in by_ix.items():
        lst.sort(reverse=True)
        keep = [lst[0][1]] + [c for k, c in lst[1:] if pair_of.get(c) == lst[0][1]]
        for c in keep:
            out[c] = ix
    return out


def manifest_for(rows, rule, base):
    key, rev = sort_rules()[rule]
    ordered = sorted(rows, key=key, reverse=rev)
    return {i + base: list(r["members"]) for i, r in enumerate(ordered)}


INNER = ["registry", "code-text", "code-text-desc", "code-numeric", "code-numeric-desc",
         "count-desc-code", "count-asc-code"]


def block_manifests(rows, strong, base):
    """Manifests in which the families are blocks in an order of the tooling's own and each block is
    sorted by one of the inner rules: the settled classes fix every block's start, and the blocks
    must tile the index range exactly."""
    fams = sorted({r["family"] for r in rows})
    size = {f: sum(1 for r in rows if r["family"] == f) for f in fams}
    out = []
    for inner in INNER:
        key, rev = sort_rules()[inner]
        within = {f: [tuple(r["members"]) for r in sorted([r for r in rows if r["family"] == f], key=key, reverse=rev)]
                  for f in fams}
        start = {}
        for f in fams:
            offs = {strong[c] - k for k, mem in enumerate(within[f]) for c in mem if c in strong}
            if len(offs) > 1:
                break
            if offs:
                start[f] = offs.pop()
        else:
            if set(start) == set(fams):
                at = base
                for f in sorted(fams, key=lambda f: start[f]):
                    if start[f] != at:
                        break
                    at += size[f]
                else:
                    out.append(("block-" + inner, {start[f] + k: list(mem) for f in fams for k, mem in enumerate(within[f])}))
    return out


def recover(round_dir):
    classes = read_csv(os.path.join(round_dir, "classes.csv"))
    subs = read_csv(os.path.join(round_dir, "submissions.csv"))
    dev_labels = {r["item"]: r["code"] for r in read_csv(os.path.join(round_dir, "dev_labels.csv"))}
    pair_of = {}
    groups = defaultdict(list)
    for c in classes:
        groups[c["edition1_code"]].append(c["code"])
    for mem in groups.values():
        if len(mem) == 2:
            pair_of[mem[0]], pair_of[mem[1]] = mem[1], mem[0]
    K = len(classes)
    K1 = len(groups)

    data = {}
    for s in subs:
        name, layout = s["submission"], s["layout"]
        dev = read_preds(os.path.join(round_dir, "dev"), name, layout)
        test = read_preds(os.path.join(round_dir, "test"), name, layout)
        used = {ix for _, ix in dev} | {ix for _, ix in test}
        base = min(used)
        edition = 1 if len(used) <= (K + K1) // 2 else 2
        strong = strong_part(dev, dev_labels, pair_of if edition == 1 else {})
        rows = table(classes, edition)
        fits = []
        for rule in sort_rules():
            man = manifest_for(rows, rule, base)
            pos = {m: ix for ix, mem in man.items() for m in mem}
            if all(pos.get(c) == ix for c, ix in strong.items()):
                fits.append((rule, man))
        fits.extend(block_manifests(rows, strong, base))
        seen, unique = set(), []
        for rule, man in fits:                       # two rules can give the same manifest
            sig = tuple(sorted((ix, tuple(mem)) for ix, mem in man.items()))
            if sig not in seen:
                seen.add(sig)
                unique.append((rule, man))
        fits = unique
        data[name] = dict(dev=dev, test=test, base=base, edition=edition, strong=strong, rows=rows, fits=fits)

    # settle each submission: a unique sort rule places every index; otherwise the other
    # submissions' agreement on the test items decides the open indices
    manifests = {}
    pending = list(data)
    for name in list(pending):
        if len(data[name]["fits"]) == 1:
            manifests[name] = data[name]["fits"][0][1]
            pending.remove(name)
    for _ in range(3):
        if not pending:
            break
        votes = defaultdict(Counter)
        for name in data:
            # a placed submission votes with its whole manifest, a pending one with its settled part
            man = manifests.get(name)
            if man is None:
                man = {}
                for c, ix in data[name]["strong"].items():
                    man.setdefault(ix, []).append(c)
            for it, ix in data[name]["test"]:
                for m in man.get(ix, []):
                    votes[it][m] += 1.0 / len(man[ix])
        pseudo = {it: v.most_common(1)[0][0] for it, v in votes.items()}
        per_class = Counter(pseudo.values())
        for name in list(pending):
            d = data[name]
            man = {}
            for c, ix in d["strong"].items():
                man.setdefault(ix, []).append(c)
            claimed = {m for mem in man.values() for m in mem}
            if d["edition"] == 1:
                for ix, mem in list(man.items()):
                    for m in mem:
                        if pair_of.get(m) and pair_of[m] not in mem:
                            mem.append(pair_of[m])
                            claimed.add(pair_of[m])
            open_rows = [r for r in d["rows"] if not any(m in claimed for m in r["members"])]
            used = {ix for _, ix in d["test"]}
            open_ix = sorted(ix for ix in used if ix not in man)
            for ix in open_ix:
                hits = Counter(pseudo.get(it) for it, j in d["test"] if j == ix)
                best = max(open_rows, key=lambda r: sum(hits.get(m, 0) / per_class[m] for m in r["members"] if per_class.get(m)))
                man[ix] = list(best["members"])
                open_rows.remove(best)
            manifests[name] = man
            pending.remove(name)
    return manifests


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    manifests = recover(argv[1])
    with open(argv[2], "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["submission", "index", "code"])
        for name in sorted(manifests):
            for ix in sorted(manifests[name]):
                for code in manifests[name][ix]:
                    w.writerow([name, ix, code])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
