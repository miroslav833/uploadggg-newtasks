#!/usr/bin/env bash
# Installs the reference program and recovers the manifests of the two sample rounds.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/rescore
cp "$HERE/rescore/score_round.py" /app/rescore/score_round.py
for r in /app/registry/rounds/*/; do
  python3 /app/rescore/score_round.py "$r" "/tmp/$(basename "$r")-manifest.csv"
  wc -l "/tmp/$(basename "$r")-manifest.csv"
done
