# Pattern desk style sheet

This sheet is what our pattern writers follow and what the chart desk reads when it expands a
written pattern row by row. Every garment in the queue is written to it, and every garment comes
with the test knitter's Back.

## 1. What a garment comes with

- `NAME.txt`, the written pattern (section 2).
- `NAME.back.csv`, the row list of the Back as the test knitter worked it from the pattern, in the
  row-list format of section 5. The test knitter works the designer's own methods (section 3).

## 2. The written pattern

A garment file is plain text. It opens with two header lines, then the stitch patterns, then one
block per piece. Blank lines separate the blocks.

```
GARMENT: Fenwick Cardigan
GAUGE: 22 sts and 30 rows = 10 cm
```

The gauge is measured over the main fabric, and every length in the file is read against it.

### Stitch patterns

The `STITCH PATTERNS` section lists each pattern used in the garment. A pattern is headed by its
name and either its multiple (an allover pattern, worked over any whole number of repeats) or its
width (a panel, always worked over exactly that many stitches). Its rows follow, numbered from 1;
Row 1 is a right-side row and the rows alternate sides. A row is written in working order, which
is right to left as the chart shows it on right-side rows and left to right on wrong-side rows. An
allover row is written as one repeat between an asterisk and `rep from *`.

```
Rib (mult of 4)
Row 1 (RS): *K2, p2; rep from *.
Row 2: *K2, p2; rep from *.

Cable Panel (over 10 sts)
Row 1 (RS): P2, k6, p2.
Row 2: K2, p6, k2.
Row 3: P2, C6F, p2.
Row 4: As Row 2.
```

`Knit.` is a row knitted across, `Purl.` a row purled across, and `As Row 2.` repeats an earlier
row of the same side. A pattern's rows are worked in order and begin again after the last. In a
lace pattern a yarn-over is always written beside the decrease that pays for it, and a `cdd` has
a yarn-over on each side.

### Pieces

A piece block is headed `PIECE:` and its name, followed by the instructions in the order they are
worked, one sentence to a line. A line may begin with a label such as `Shape armholes:` that names
what the sentence does. The sentences below are the whole house vocabulary.

```
PIECE: Right Front
Cast on 46 sts.
Row 1 (RS): Work 1 selvedge st, work Row 1 of Rib over next 44 sts, work 1 selvedge st.
Cont in patt as established until piece measures 4 cm, ending with a WS row.
Next row (RS): Work 1 selvedge st, work Row 1 of Mesh over next 44 sts, work 1 selvedge st.
Work 5 rows in patt as established.
Shape waist: Dec 1 st at side edge of next RS row and every foll 6th row 2 times more. (43 sts)
Work 9 rows in patt as established.
Inc 1 st at side edge of next RS row and every foll 8th row 2 times more. (46 sts)
Cont in patt as established until piece measures 31 cm, ending with a WS row.
Shape armhole: Bind off 5 sts at beg of next WS row. (41 sts)
Dec 1 st at armhole edge of next RS row and every foll RS row 3 times more.
AT THE SAME TIME, when piece measures 33 cm, ending with a WS row, shape neck as folls:
Dec 1 st at neck edge of next RS row and every foll 4th row 8 times more. (28 sts)
Cont in patt as established until piece measures 50 cm, ending with a WS row.
Shape shoulder: Bind off 8 sts at beg of next 2 WS rows. (12 sts)
Work 1 row.
Bind off rem sts.

PIECE: Left Front
Work as for Right Front, reversing all shaping.
```

- `Row 1 (RS):` and `Next row (RS):` set the stitch patterns over the stitches on the needle: one
  selvedge stitch at each edge, and each pattern's Row 1 over the stitches named for it (a panel
  over its own width). It is a right-side row, and the patterns it names begin at their Row 1 on
  that row. The second set-up row of a piece ends its border (the hem or cuff).
- `Cont in patt as established` carries the fabric on: every stitch keeps the pattern column it
  was set up in and the patterns run on through their rows. It runs `for N rows` or `until piece
  measures N cm, ending with a WS row`; a length reached on a right-side row carries on to the next
  wrong-side row (and `ending with a RS row` likewise). How a designer measures is in section 3.
- `Work N rows even.` and `Work 1 row.` work rows in pattern as established.
- `Dec 1 st at each end of next RS row and every foll 4th row 4 times more.` shapes the next
  right-side row (any wrong-side row before it is worked in pattern) and then every fourth row,
  counted from the row just worked, four times more, the rows between in pattern. `every foll RS
  row` is every second row. `Inc` adds a stitch in the same places. `at each end` shapes both edges
  of the row; `at side edge`, `at armhole edge` and `at neck edge` shape one. On a Right Front, as
  it is knitted, the neck edge is at the beginning of right-side rows and the side and armhole
  edge at their end. All shaping sits inside the selvedge stitch.
- `Bind off N sts at beg of next row.` binds off at the beginning of the next row, whichever side
  it is; `at beg of next 2 rows` at the beginning of each of the next two rows; `next WS row` and
  `next 2 WS rows` at the beginning of the next one or two wrong-side rows. `then M sts at beg of
  foll 2 rows` continues the sentence with the rows that follow. The stitch left on the needle
  after the bind-off is worked plain (knit on a right-side row, purl on a wrong-side row) and is the
  new selvedge; the rest of the row is worked in pattern.
- `AT THE SAME TIME, when piece measures N cm, ending with a WS row, shape neck as folls:` starts
  a second shaping, written on the next line, that runs over the same rows as the shaping before
  it, from the length it names. Where both fall on one row, that row is shaped at both edges.
- `Bind off rem sts.` binds off every stitch on the next row and ends the piece.
- `Work as for Right Front, reversing all shaping.` writes a piece that is the mirror image of the
  piece named: it is worked from the same instructions with every shaping at the opposite edge of
  the fabric. A bind-off can only begin a row, so each bind-off of the mirrored piece is worked on
  the first row, counted from the row the mirrored piece has reached when it comes to that
  sentence, that begins at the opposite edge. Where the Right Front binds off at the beginning of
  the next WS row, the Left Front binds off at the beginning of the next RS row; where the Right
  Front binds off at the beginning of the next row and that row is a RS row, the Left Front works
  that row and binds off at the beginning of the WS row after it.

A stitch count in parentheses states the stitches on the needle once the sentence before it, and
any shaping running at the same time with it, is complete.

## 3. Designers' methods

Our contributors knit and measure in their own ways, and the pattern text does not say which. The
test knitter's Back is worked by the designer's methods, and the chart desk works every piece of
the garment by those same methods. The house methods, which our staff designers use, come first
in each list.

- **Selvedge.** *Plain*: the selvedge stitch is knit on right-side rows and purled on wrong-side
  rows. *Slipped*: the first stitch of every row is slipped (`sl1`) and the last is worked plain.
  *Garter*: the first and last stitch of every row are knit.
- **Paired decreases.** *Mirrored*: `ssk` at the beginning of a row and `k2tog` at its end.
  *Reversed*: `k2tog` at the beginning and `ssk` at the end. Either way the decrease is worked on the
  two stitches inside the selvedge.
- **Increases.** *Made*: an `m1` worked between the selvedge and the next stitch. *Bar*: a `kfb`
  worked into the stitch next to the selvedge, the extra stitch lying on the selvedge side. The new
  stitch takes the next place of the pattern repeat outward, and is worked in pattern or plain as
  the designer's method for broken repeats decides.
- **Stitches used by shaping.** On the row a shaping is worked, the stitches it uses (the two
  stitches of a decrease, the stitch a `kfb` is worked into, the stitches bound off) are not worked
  in pattern, and a pattern unit or repeat that loses one of them to the shaping is broken on that
  row. The stitch a decrease leaves takes the place of the inner of its two stitches, and a stitch
  worked by `kfb` keeps its own place.
- **Broken repeats.** When shaping leaves part of a pattern repeat at an edge, whether decreases
  or bind-offs have cut into it or increases have begun a new one: *by unit*, every
  yarn-over with its decrease, `cdd` with its yarn-overs, cable and plain stitch that still has all
  its stitches is worked in pattern and the stitches of a broken unit are worked plain; *by repeat*,
  every stitch of a repeat that is not whole on the needle is worked plain (a panel counts as one
  repeat) until the repeat is whole again.
- **Measuring.** Lengths are measured *from the cast-on edge*, or *from the top of the border* (the
  row before the second set-up row). The border's own length is measured from the cast-on edge.
- **Reaching a length.** At the *nearest* whole row, or at the *first* whole row that reaches it.
  No length in the queue falls on a half row.

## 4. Abbreviations

| token | meaning | stitches used | stitches made |
|---|---|---|---|
| `k` | knit | 1 | 1 |
| `p` | purl | 1 | 1 |
| `sl1` | slip one stitch | 1 | 1 |
| `yo` | yarn over | 0 | 1 |
| `k2tog` | knit two together | 2 | 1 |
| `ssk` | slip, slip, knit | 2 | 1 |
| `p2tog` | purl two together | 2 | 1 |
| `cdd` | central double decrease | 3 | 1 |
| `m1` | make one | 0 | 1 |
| `kfb` | knit into the front and back of a stitch | 1 | 2 |
| `bo` | bind off one stitch | 1 | 0 |
| `C4F`, `C4B` | cable four, front or back | 4 | 4 |
| `C6F`, `C6B` | cable six, front or back | 6 | 6 |

In the written pattern `K3` means three knit stitches and `p2` two purl stitches; the first token
of a row is capitalised. `sts` is stitches, `patt` pattern, `rem` remaining, `foll` following,
`beg` beginning, `cont` continue, `dec` decrease, `inc` increase, `RS` and `WS` the right and
wrong sides.

## 5. The row list

A row list is a CSV with a header row and one row per knitted row of every piece:

```
piece,row,side,stitches,count
Back,7,RS,k yo ssk k k yo ssk k k yo ssk k k yo ssk k k yo ssk k k yo ssk k k k,26
Sleeve,40,RS,sl1 kfb k k k k k k k k k k k k k k k k k k k k k k kfb k,28
Right Front,63,WS,bo bo bo bo bo p p p p p p p p p p p p p p p p p p k,19
```

`piece` is the name from the `PIECE:` heading, `row` counts from 1 at the first row after the
cast-on, `side` is `RS` or `WS`, `stitches` is every token of the row in working order separated by
single spaces, and `count` is the number of stitches on the needle after the row. Bound-off
stitches are listed as `bo`, one token each, and a row that binds off every stitch has count 0.
