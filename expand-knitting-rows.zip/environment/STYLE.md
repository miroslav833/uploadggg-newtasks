# Pattern desk style sheet

This sheet is what our pattern writers follow, and what the chart desk reads when it expands a
written pattern row by row. Every garment file in the queue is written to it.

## 1. The garment file

A garment file is plain text. It opens with two header lines, then the stitch patterns, then one
block per piece. Blank lines separate the blocks.

```
GARMENT: Fenwick Cardigan
GAUGE: 22 sts and 30 rows = 10 cm
```

The gauge is measured over the main fabric and every length in the file is read against it.

### Stitch patterns

The `STITCH PATTERNS` section lists each pattern used in the garment. A pattern is headed by its
name and either its multiple (an allover pattern, worked over any number of stitches that is a
whole number of repeats) or its width (a panel, always worked over exactly that many stitches).
Its rows follow, numbered from 1; Row 1 is a right-side row and the rows alternate sides. A row
is written in working order, which is right to left as the chart shows it on right-side rows and
left to right on wrong-side rows. An allover row is written as one repeat between an asterisk
and `rep from *`.

```
Rib (mult of 4)
Row 1 (RS): *K2, p2; rep from *.
Row 2: *K2, p2; rep from *.

Cable Panel (over 10 sts)
Row 1 (RS): P2, k6, p2.
Row 2: K2, p6, k2.
Row 3: P2, C6F, p2.
Row 4: As Row 2.
```

`Knit.` is a row knitted across, `Purl.` a row purled across, and `As Row 2.` repeats an earlier
row of the same side. The pattern's rows are worked in order and begin again after the last.

### Pieces

A piece block is headed `PIECE:` and its name, then the instructions in the order they are
worked, one sentence or row to a line. The sentences below are the whole house vocabulary; a
line may begin with a label such as `Shape armholes:` that names what the sentence does.

```
PIECE: Back
Cast on 90 sts.
Row 1 (RS): K1, work Row 1 of Rib over next 88 sts, k1.
Cont in patt as established until piece measures 4 cm, ending with a WS row.
Next row (RS): K1, work Row 1 of Mesh over next 39 sts, work Row 1 of Cable Panel, work Row 1 of Mesh over next 39 sts, k1.
Work 7 rows in patt as established.
Shape armholes: Bind off 5 sts at beg of next 2 rows. (80 sts)
Dec row (RS): K1, ssk, work in patt to last 3 sts, k2tog, k1. (78 sts)
Rep Dec row every 4th row 4 times more. (70 sts)
AT THE SAME TIME, when piece measures 34 cm, ending with a WS row, shape neck as folls:
Neck dec row (RS): Work in patt to last 3 sts, k2tog, k1.
Rep Neck dec row every RS row 9 times more. (26 sts)
Work 1 row.
Shape shoulders: Bind off 6 sts at beg of next 2 RS rows, then 5 sts at beg of foll RS row. (9 sts)
Bind off rem sts.
```

```
PIECE: Left Front
Work as for Right Front, reversing all shaping.
```

- `Row 1 (RS):` and `Next row (RS):` set the stitch patterns over the stitches on the needle.
  A set-up row always reads `K1`, then each pattern's Row 1 over the stitches named for it, then
  `k1`; a panel is worked over its own width. It is a right-side row, and the patterns it names
  begin at their Row 1 on that row.
- `Cont in patt as established` carries the fabric on: every stitch keeps the pattern it was set
  up in and the patterns run on through their rows. `for N rows` or `until piece measures N cm,
  ending with a WS row` says how long. Lengths are measured from the cast-on edge and are
  reached at the nearest whole row; `ending with a WS row` carries on to the next wrong-side row
  if the length is reached on a right-side row, and `ending with a RS row` likewise.
- `Work N rows even.` and `Work 1 row.` work rows in pattern as established.
- `Bind off N sts at beg of next row.` binds off at the beginning of the next row, whichever side
  it is; `at beg of next 2 rows` does so at the beginning of each of the next two rows, and `next
  2 RS rows` at the beginning of each of the next two right-side rows. `then M sts at beg of
  foll 2 rows` continues the sentence with the rows that follow. The rest of each such row is
  worked in pattern.
- A named row such as `Dec row (RS):` or `Inc row (RS):` is written out once. It is worked on
  the next right-side row, with any wrong-side row before it worked in pattern. `Rep Dec row every
  4th row 4 times more.` works it again every fourth row, counted from the row just worked, with
  the rows between in pattern; `every RS row` means every second row, `every 6th row` every sixth.
- `AT THE SAME TIME, when piece measures N cm, ending with a WS row, shape neck as folls:` starts
  a second shaping that runs over the same rows as the shaping before it, from the length it
  names, with its own named row and repeat.
- `Bind off rem sts.` binds off every stitch on the next row and ends the piece.
- `Work as for Right Front, reversing all shaping.` writes a piece that is the mirror image of
  the piece named: it is worked from the same instructions with every shaping at the opposite
  edge of the fabric.

A stitch count in parentheses states the stitches on the needle once the sentence before it,
and any shaping running at the same time with it, is complete.

### House conventions

- The first and last stitch of every row is a selvedge stitch and is worked plain: knit on a
  right-side row, purl on a wrong-side row. Decreases and increases are worked inside it, and after
  a bind-off the stitch next to the bound-off stitches is the new selvedge.
- A decrease at the beginning of a row is `ssk` and at the end `k2tog`; an increase is `m1` on
  either side.
- In a lace pattern a yarn-over is always written beside the decrease that pays for it; a `cdd`
  has a yarn-over on each side. When a pair, a `cdd` with its yarn-overs, or a cable does not have
  all its stitches on the needle, the stitches that are there are worked plain.
- Increased stitches are worked into the pattern as the repeat continues outward.

## 2. Abbreviations

| token | meaning | stitches used | stitches made |
|---|---|---|---|
| `k` | knit | 1 | 1 |
| `p` | purl | 1 | 1 |
| `yo` | yarn over | 0 | 1 |
| `k2tog` | knit two together | 2 | 1 |
| `ssk` | slip, slip, knit | 2 | 1 |
| `p2tog` | purl two together | 2 | 1 |
| `cdd` | central double decrease | 3 | 1 |
| `m1` | make one | 0 | 1 |
| `bo` | bind off one stitch | 1 | 0 |
| `C4F`, `C4B` | cable four, front or back | 4 | 4 |
| `C6F`, `C6B` | cable six, front or back | 6 | 6 |

In the written pattern `K3` means three knit stitches and `p2` two purl stitches; the first
token of a row is capitalised. `sts` is stitches, `patt` pattern, `rem` remaining, `foll`
following, `beg` beginning, `cont` continue, `RS` and `WS` the right and wrong sides.

## 3. The row list

The chart desk's row list is a CSV with a header row and one row per knitted row of every piece:

```
piece,row,side,stitches,count
Back,7,RS,k yo ssk k k yo ssk k k yo ssk k k yo ssk k k yo ssk k k yo ssk k k,26
```

`piece` is the name from the `PIECE:` heading, `row` counts from 1 at the first row after the
cast-on, `side` is `RS` or `WS`, `stitches` is every token of the row in working order separated
by single spaces, and `count` is the number of stitches on the needle after the row. Bound-off
stitches are listed as `bo`, one token each, and a row that binds off every stitch has count 0.
