"""The verifier's own expansion of a garment's sealed structured instructions into its row list.

A garment is sealed as a JSON document: the gauge, the designer's working methods, the stitch
patterns (each row as units of tokens in column order) and, per piece, the instruction list the
written pattern denotes. This module knits those instructions and emits every row: the stitches
in working order and the count after the row. It never reads the written pattern text; test 1
checks that the sealed row list equals this reckoning.
"""
import json
import math

# token -> (stitches consumed, stitches produced)
TOKENS = {
    "k": (1, 1), "p": (1, 1), "sl1": (1, 1), "yo": (0, 1), "k2tog": (2, 1), "ssk": (2, 1),
    "p2tog": (2, 1), "cdd": (3, 1), "m1": (0, 1), "kfb": (1, 2), "bo": (1, 0),
    "k1tbl": (1, 1), "p1tbl": (1, 1), "skpo": (2, 1), "k2togtbl": (2, 1),
    "C4F": (4, 4), "C4B": (4, 4), "C6F": (6, 6), "C6B": (6, 6),
}

DEFAULT_METHODS = {"selvedge": "plain", "lean": "mirrored", "slant": "ssk", "position": "edge",
                   "increase": "m1", "broken": "unit", "measure": "cast-on", "reach": "nearest"}
METHOD_OPTIONS = {"selvedge": ("plain", "slip", "garter", "chain"), "lean": ("mirrored", "reversed"),
                  "slant": ("ssk", "skpo", "k2togtbl"), "position": ("edge", "inset", "inset2"),
                  "increase": ("m1", "kfb", "yo", "eyelet"), "broken": ("unit", "repeat"),
                  "measure": ("cast-on", "border"), "reach": ("nearest", "first", "last")}
INSET = {"edge": 0, "inset": 1, "inset2": 2}


def is_tbl(a):
    """A stitch made by a yarn-over increase, to be worked through the back loop on the next row."""
    return isinstance(a, tuple) and len(a) == 2 and a[0] == "tbl"


class Differs(Exception):
    """The knitting has left the rows it was asked to reproduce."""


def unit_width(unit):
    return sum(TOKENS[t][0] for t in unit)


class Pattern:
    def __init__(self, name, spec):
        self.name = name
        self.kind = spec["kind"]                       # "allover" (a multiple) or "panel" (fixed width)
        self.rows = [[list(u) for u in row] for row in spec["rows"]]   # units in column order
        self.width = unit_width([t for u in self.rows[0] for t in u])
        for row in self.rows:
            assert unit_width([t for u in row for t in u]) == self.width, name
        self.unit_widths = [[unit_width(u) for u in row] for row in self.rows]
        self.index = []         # per row: column in the repeat -> (unit number, offset in the unit)
        for row in self.rows:
            d, c = {}, 0
            for u, unit in enumerate(row):
                for off in range(unit_width(unit)):
                    d[c + off] = (u, off)
                c += unit_width(unit)
            self.index.append(d)

    def row_at(self, n, start):
        return (n - start) % len(self.rows)


def length_rows(cm, gauge_rows, reach):
    x = cm * gauge_rows / 10.0
    if reach == "nearest":
        return int(x + 0.5)
    if reach == "last":
        return int(math.floor(x + 1e-9))
    return int(math.ceil(x - 1e-9))


class PieceRun:
    """Knits one piece. A column is None (a plain stitch) or (pattern name, segment, absolute column):
    the segment is the place of the pattern's span in its set-up row (the same pattern may be set up
    over two spans) and the absolute column is counted from the first stitch of that span. `mirror` swaps the
    edges of every shaping and makes each partial bind-off wait for the row that begins at the
    swapped edge; `bo_edges` carries the edges the unmirrored run used for each bind-off."""

    def __init__(self, patterns, gauge_rows, methods, mirror=False, bo_edges=None):
        self.patterns = patterns
        self.gauge_rows = gauge_rows
        self.m = methods
        self.mirror = mirror
        self.bo_edges = bo_edges
        self.cols = []
        self.start = {}
        self.border_end = 0       # last row before the main set-up row
        self.rows = []
        self.counts = []
        self.used_edges = []
        self.check = None          # rows to reproduce: knitting stops at the first that differs

    def next_row(self):
        return len(self.rows) + 1

    @staticmethod
    def is_rs(n):
        return n % 2 == 1

    def edge_of_row(self, n):
        return "A" if self.is_rs(n) else "B"

    def target_row(self, cm, end):
        base = self.border_end if self.m["measure"] == "border" else 0
        r = base + length_rows(cm, self.gauge_rows, self.m["reach"])
        if end == "WS" and r % 2 == 1:
            r += 1
        if end == "RS" and r % 2 == 0:
            r += 1
        return r

    def outward(self, a, step):
        if a is None or is_tbl(a):
            return None
        pat, seg, ab = a
        if self.patterns[pat].kind != "allover":
            return None
        return (pat, seg, ab + step)

    def live(self, work):
        """Columns worked in pattern under the designer's rule for broken repeats."""
        if self.m["broken"] == "unit":
            return None
        present = set(c for c in work if c is not None and not is_tbl(c))
        ok = set()
        for c in present:
            pat, seg, ab = c
            size = self.patterns[pat].width
            base = (ab // size) * size
            if all((pat, seg, base + t) in present for t in range(size)):
                ok.add(c)
        return ok

    def patt_tokens(self, work, n):
        rs = self.is_rs(n)
        plain = "k" if rs else "p"
        alive = self.live(work)
        out, j = [], 0
        while j < len(work):
            a = work[j]
            if is_tbl(a):
                out.append("k1tbl" if rs else "p1tbl")
                j += 1
                continue
            if a is None or (alive is not None and a not in alive):
                out.append(plain)
                j += 1
                continue
            pat, seg, ab = a
            P = self.patterns[pat]
            prow = P.row_at(n, self.start[pat])
            u, off = P.index[prow][ab % P.width]
            unit = P.rows[prow][u]
            width = P.unit_widths[prow][u]
            head = 0 if rs else width - 1
            complete = (off == head and j + width <= len(work)
                        and all(work[j + t] == (pat, seg, ab + (t if rs else -t)) for t in range(width)))
            if complete:
                out.extend(unit if rs else list(reversed(unit)))
                j += width
            else:
                out.append(plain)
                j += 1
        return out

    def selvedge(self, rs, first):
        s = self.m["selvedge"]
        if s in ("slip", "chain") and first:
            return "sl1"
        if s in ("garter", "chain"):
            return "k"
        return "k" if rs else "p"

    def emit(self, beg=None, end=None):
        """Work the next row with an operation at its beginning and/or end: None, 'dec', 'inc' or
        ('bo', n). Shaping falls on right-side rows only; bind-offs on either side."""
        n = self.next_row()
        rs = self.is_rs(n)
        plain = "k" if rs else "p"
        work = list(self.cols) if rs else list(reversed(self.cols))
        W = len(work)
        left = self.m["slant"]          # the designer's left-leaning decrease
        lean_beg, lean_end = (left, "k2tog") if self.m["lean"] == "mirrored" else ("k2tog", left)
        inset = INSET[self.m["position"]]
        inc = self.m["increase"]
        made_tok = "yo" if inc in ("yo", "eyelet") else inc
        if isinstance(beg, tuple):
            nb = beg[1]
            assert nb + 1 < W
            left = work[nb]          # the stitch left after the bind-off is worked plain (tbl if new)
            toks = ["bo"] * nb + [("k1tbl" if rs else "p1tbl") if is_tbl(left) else plain]
            head = [None]
            i = nb + 1
        else:
            toks, head, i = [self.selvedge(rs, True)], [None], 1
            if beg in ("dec", "inc"):
                assert rs
                if inset:            # the stitches inside the selvedge are worked plain, and stay plain
                    toks += [plain] * inset
                    head += [None] * inset
                    i = 1 + inset
                if beg == "dec":
                    toks.append(lean_beg)
                    head.append(work[i + 1])
                    i += 2
                elif inc == "kfb":
                    toks.append("kfb")
                    head += [self.outward(work[i], -1), work[i]]
                    i += 1
                else:
                    new = self.outward(work[i], -1)
                    toks.append(made_tok)
                    head.append(("tbl", new) if inc == "yo" else new)
        k = W - 1                    # the selvedge at the end of the row
        tail_t, tail, border_t, border = [], [], [], []
        j = k
        if end in ("dec", "inc"):
            assert rs
            if inset:
                border_t, border = [plain] * inset, [None] * inset
                k -= inset
                j = k
            if end == "dec":
                tail_t, tail = [lean_end], [work[k - 2]]
                j = k - 2
            elif inc == "kfb":
                tail_t, tail = ["kfb"], [work[k - 1], self.outward(work[k - 1], +1)]
                j = k - 1
            else:
                new = self.outward(work[k - 1], +1)
                tail_t, tail = [made_tok], [("tbl", new) if inc == "yo" else new]
        elif isinstance(end, tuple):
            raise ValueError("a bind-off never ends a row")
        assert i <= j
        middle = work[i:j]
        toks += self.patt_tokens(middle, n) + tail_t + border_t + [self.selvedge(rs, False)]
        middle = [m[1] if is_tbl(m) else m for m in middle]
        produced = head + middle + tail + border + [None]
        self.cols = produced if rs else list(reversed(produced))
        count = sum(TOKENS[t][1] for t in toks)
        assert count == len(self.cols), (n, count, len(self.cols))
        assert sum(TOKENS[t][0] for t in toks) == W, (n, toks)
        self.rows.append((n, "RS" if rs else "WS", toks, count))
        if self.check is not None and (len(self.rows) > len(self.check) or self.rows[-1] != self.check[len(self.rows) - 1]):
            raise Differs()

    def bind_off_all(self):
        n = self.next_row()
        self.rows.append((n, "RS" if self.is_rs(n) else "WS", ["bo"] * len(self.cols), 0))
        self.cols = []
        if self.check is not None and self.rows != self.check[:len(self.rows)]:
            raise Differs()

    def patt_until_side(self, side):
        while ("RS" if self.is_rs(self.next_row()) else "WS") != side:
            self.emit()

    def run(self, instructions):
        bo_k = 0
        for ins in instructions:
            op = ins["op"]
            if op == "cast_on":
                self.cols = [None] * ins["n"]
            elif op == "setup":
                self.setup(ins)
            elif op in ("cont_rows", "work_even"):
                for _ in range(ins["n"]):
                    self.emit()
            elif op == "cont_until":
                target = self.target_row(ins["cm"], ins["end"])
                while self.next_row() <= target:
                    self.emit()
            elif op == "bind_off":
                self.bind_off(ins, bo_k)
                bo_k += 1
            elif op == "schedule":
                self.schedule(ins)
            elif op == "bind_off_rem":
                self.bind_off_all()
            else:
                raise ValueError(op)
            self.counts.append(len(self.cols))
        return self.rows

    def setup(self, ins):
        n = self.next_row()
        assert self.is_rs(n)
        if n > 1:
            self.border_end = n - 1
        cols = [None]
        for si, seg in enumerate(ins["segments"]):
            P = self.patterns[seg["pat"]]
            over = seg.get("over", P.width)
            assert over % P.width == 0
            cols += [(seg["pat"], si, c) for c in range(over)]
            self.start[seg["pat"]] = n
        cols.append(None)
        assert len(cols) == len(self.cols), (len(cols), len(self.cols))
        self.cols = cols
        self.emit()

    def bind_off(self, ins, k):
        edges = []
        for j in range(ins["rows"]):
            if self.mirror:
                want = {"A": "B", "B": "A"}[self.bo_edges[k][j]]
                self.patt_until_side("RS" if want == "A" else "WS")
            elif ins.get("side"):
                self.patt_until_side(ins["side"])
            edges.append(self.edge_of_row(self.next_row()))
            self.emit(beg=("bo", ins["n"]))
        self.used_edges.append(edges)

    def schedule(self, ins):
        events = {}

        def add(row, r):
            beg, end = r.get("beg"), r.get("end")
            if self.mirror:
                beg, end = end, beg
            e = events.setdefault(row, {"beg": None, "end": None})
            assert (beg is None or e["beg"] is None) and (end is None or e["end"] is None), row
            if beg:
                e["beg"] = beg
            if end:
                e["end"] = end

        first = self.next_row() if self.is_rs(self.next_row()) else self.next_row() + 1
        for i in range(ins["times"] + 1):
            add(first + ins["every"] * i, ins["row"])
        st = ins.get("same_time")
        if st:
            t = self.target_row(st["cm"], st["end"])
            f2 = t + 1 if self.is_rs(t + 1) else t + 2
            assert f2 >= first, (f2, first)
            for i in range(st["times"] + 1):
                add(f2 + st["every"] * i, st["row"])
        last = max(events)
        while self.next_row() <= last:
            e = events.get(self.next_row())
            if e:
                self.emit(beg=e["beg"], end=e["end"])
            else:
                self.emit()


def expand(garment, methods=None):
    """-> {piece name: [(row, side, tokens, count)]}, {piece name: counts after each instruction}."""
    methods = methods or garment["methods"]
    patterns = {name: Pattern(name, p) for name, p in garment["patterns"].items()}
    g = garment["gauge"]["rows"]
    rows, counts, runs = {}, {}, {}
    by_name = {p["name"]: p for p in garment["pieces"]}
    for piece in garment["pieces"]:
        if piece.get("mirror_of"):
            src = runs[piece["mirror_of"]]
            run = PieceRun(patterns, g, methods, mirror=True, bo_edges=src.used_edges)
            run.run(by_name[piece["mirror_of"]]["instructions"])
        else:
            run = PieceRun(patterns, g, methods)
            run.run(piece["instructions"])
        runs[piece["name"]] = run
        rows[piece["name"]] = run.rows
        counts[piece["name"]] = run.counts
    return rows, counts


def back_matches(garment, methods, back_rows):
    """Whether the Back knitted under `methods` reproduces `back_rows` exactly (stops at the first row
    that differs)."""
    patterns = {name: Pattern(name, p) for name, p in garment["patterns"].items()}
    piece = [p for p in garment["pieces"] if p["name"] == "Back"][0]
    run = PieceRun(patterns, garment["gauge"]["rows"], methods)
    run.check = [(n, side, list(t), c) for n, side, t, c in back_rows]
    try:
        run.run(piece["instructions"])
    except (Differs, AssertionError, ValueError, KeyError, IndexError):
        return False
    return run.rows == run.check


def load_rows(path):
    """A row-list file read as text -> {(piece, row): (side, tokens tuple, count)}."""
    import csv
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out[(r["piece"], int(r["row"]))] = (r["side"], tuple(r["stitches"].split()), int(r["count"]))
    return out


def write_rows(path, rows, only=None):
    import csv
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["piece", "row", "side", "stitches", "count"])
        for piece, rr in rows.items():
            if only and piece not in only:
                continue
            for n, side, tokens, count in rr:
                w.writerow([piece, n, side, " ".join(tokens), count])


if __name__ == "__main__":
    import sys
    g = json.load(open(sys.argv[1]))
    rows, counts = expand(g)
    for piece, rr in rows.items():
        print(piece, len(rr), "rows; counts", counts[piece])
