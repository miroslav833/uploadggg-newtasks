"""The verifier's own expansion of a garment's sealed structured instructions into its row list.

A garment is sealed as a JSON document: the gauge, the stitch patterns (each row as units of tokens
in column order) and, per piece, the instruction list the written pattern denotes. This module walks
those instructions and emits every row: the stitches in working order and the count after the row.
It never reads the written pattern text; test 1 checks that the sealed row list equals this reckoning.
"""
import json

# token -> (stitches consumed, stitches produced)
TOKENS = {
    "k": (1, 1), "p": (1, 1), "yo": (0, 1), "k2tog": (2, 1), "ssk": (2, 1), "p2tog": (2, 1),
    "cdd": (3, 1), "m1": (0, 1), "bo": (1, 0),
    "C4F": (4, 4), "C4B": (4, 4), "C6F": (6, 6), "C6B": (6, 6),
}


def unit_width(unit):
    return sum(TOKENS[t][0] for t in unit)


class Pattern:
    def __init__(self, name, spec):
        self.name = name
        self.kind = spec["kind"]                       # "allover" (a multiple) or "panel" (fixed width)
        self.rows = [[list(u) for u in row] for row in spec["rows"]]   # units in column order
        self.width = unit_width([t for u in self.rows[0] for t in u])
        for row in self.rows:
            assert unit_width([t for u in row for t in u]) == self.width, name
        # per row: column index -> (unit number, offset inside the unit)
        self.index = []
        for row in self.rows:
            d, c = {}, 0
            for u, unit in enumerate(row):
                for off in range(unit_width(unit)):
                    d[c + off] = (u, off)
                c += unit_width(unit)
            self.index.append(d)

    def row_at(self, n, start):
        return (n - start) % len(self.rows)


def rows_for(cm, gauge_rows, end=None):
    """Rows a length comes to: the nearest whole row, then on to the stated side's row."""
    x = cm * gauge_rows / 10.0
    r = int(x + 0.5)
    if end == "WS" and r % 2 == 1:
        r += 1
    if end == "RS" and r % 2 == 0:
        r += 1
    return r


class PieceRun:
    """Executes one piece's instruction list. `mirror` swaps the edges of every shaping operation
    and makes each partial bind-off wait for the row that begins at the swapped edge; `bo_edges`
    carries the edges the unmirrored run used for each bind-off instruction."""

    def __init__(self, patterns, gauge_rows, mirror=False, bo_edges=None):
        self.patterns = patterns
        self.gauge_rows = gauge_rows
        self.mirror = mirror
        self.bo_edges = bo_edges
        self.cols = []            # assignment per column: None (plain) or (pattern name, column index)
        self.start = {}           # pattern name -> row number on which its Row 1 was worked
        self.rows = []            # (row number, side, tokens, count)
        self.counts = []          # stitch count after each instruction, in order
        self.used_edges = []      # per bind-off instruction, the edge of each of its rows

    # -- rows ---------------------------------------------------------------------------------
    def next_row(self):
        return len(self.rows) + 1

    @staticmethod
    def is_rs(n):
        return n % 2 == 1

    def edge_of_row(self, n):
        """Which fabric edge a row begins at: 'A' for right-side rows, 'B' for wrong-side rows."""
        return "A" if self.is_rs(n) else "B"

    def continue_outward(self, a, step):
        if a is None:
            return None
        pat, idx = a
        P = self.patterns[pat]
        if P.kind != "allover":
            return None
        return (pat, (idx + step) % P.width)

    def patt_tokens(self, work, n):
        """Tokens of `work` (assignments in working order) on row n, units degraded to plain where
        their columns are not all present in order."""
        rs = self.is_rs(n)
        plain = "k" if rs else "p"
        out, j = [], 0
        while j < len(work):
            a = work[j]
            if a is None:
                out.append(plain)
                j += 1
                continue
            pat, idx = a
            P = self.patterns[pat]
            prow = P.row_at(n, self.start[pat])
            units = P.rows[prow]
            u, off = P.index[prow][idx]
            width = unit_width(units[u])
            head = 0 if rs else width - 1
            complete = (off == head and j + width <= len(work)
                        and all(work[j + t] == (pat, idx + (t if rs else -t)) for t in range(width)))
            if complete:
                out.extend(units[u] if rs else list(reversed(units[u])))
                j += width
            else:
                out.append(plain)
                j += 1
        return out

    def emit(self, beg=None, end=None):
        """Work the next row with an operation at its beginning and/or end. An op is None, 'dec',
        'inc' or ('bo', n). Shaping ops only fall on right-side rows; bind-offs on either."""
        n = self.next_row()
        rs = self.is_rs(n)
        plain = "k" if rs else "p"
        order = list(range(len(self.cols))) if rs else list(range(len(self.cols) - 1, -1, -1))
        work = [self.cols[i] for i in order]
        W = len(work)
        tokens, head_out, tail_out = [], [], []
        i, tail = 0, 0
        if isinstance(beg, tuple):
            nb = beg[1]
            assert nb < W
            tokens += ["bo"] * nb
            i = nb
            work[i] = None                      # the stitch after the bind-off is the new selvedge
        elif beg == "dec":
            assert rs
            tokens += ["k", "ssk"]
            head_out = [None, work[2]]
            i = 3
        elif beg == "inc":
            assert rs
            tokens += ["k", "m1"]
            head_out = [None, self.continue_outward(work[1], -1)]
            i = 1
        if end == "dec":
            assert rs
            tail_out = [work[W - 3], None]
            tail = 3
        elif end == "inc":
            assert rs
            tail_out = [self.continue_outward(work[W - 2], +1), None]
            tail = 1
        elif isinstance(end, tuple):
            raise ValueError("a bind-off never ends a row")
        middle = work[i:W - tail]
        tokens += self.patt_tokens(middle, n)
        if end == "dec":
            tokens += ["k2tog", "k"]
        elif end == "inc":
            tokens += ["m1", "k"]
        produced = head_out + middle + tail_out
        if produced:
            produced[0] = None
            produced[-1] = None
        self.cols = produced if rs else list(reversed(produced))
        count = sum(TOKENS[t][1] for t in tokens)
        assert count == len(self.cols), (n, count, len(self.cols))
        self.rows.append((n, "RS" if rs else "WS", tokens, count))

    def bind_off_all(self):
        n = self.next_row()
        tokens = ["bo"] * len(self.cols)
        self.cols = []
        self.rows.append((n, "RS" if self.is_rs(n) else "WS", tokens, 0))

    def patt_until_side(self, side):
        while ("RS" if self.is_rs(self.next_row()) else "WS") != side:
            self.emit()

    # -- instructions ---------------------------------------------------------------------------
    def run(self, instructions):
        bo_k = 0
        for ins in instructions:
            op = ins["op"]
            if op == "cast_on":
                self.cols = [None] * ins["n"]
            elif op == "setup":
                self.setup(ins["segments"])
            elif op == "cont_rows":
                for _ in range(ins["n"]):
                    self.emit()
            elif op == "cont_until":
                target = rows_for(ins["cm"], self.gauge_rows, ins["end"])
                while self.next_row() <= target:
                    self.emit()
            elif op == "work_even":
                for _ in range(ins["n"]):
                    self.emit()
            elif op == "bind_off":
                self.bind_off(ins, bo_k)
                bo_k += 1
            elif op == "schedule":
                self.schedule(ins)
            elif op == "bind_off_rem":
                self.bind_off_all()
            else:
                raise ValueError(op)
            self.counts.append(len(self.cols))
        return self.rows

    def setup(self, segments):
        n = self.next_row()
        assert self.is_rs(n)
        cols = [None]
        for seg in segments:
            P = self.patterns[seg["pat"]]
            over = seg.get("over", P.width)
            assert over % P.width == 0
            cols += [(seg["pat"], c % P.width) for c in range(over)]
            self.start[seg["pat"]] = n
        cols.append(None)
        assert len(cols) == len(self.cols), (len(cols), len(self.cols))
        self.cols = cols
        self.emit()

    def bind_off(self, ins, k):
        """ins: {"n": sts, "rows": K, "side": None|"RS"|"WS"}. Unmirrored: each of the K rows is the
        next row (or the next row of the stated side). Mirrored: each falls on the next row that
        begins at the edge opposite to the one the unmirrored run used."""
        edges = []
        for j in range(ins["rows"]):
            if self.mirror:
                want = {"A": "B", "B": "A"}[self.bo_edges[k][j]]
                self.patt_until_side("RS" if want == "A" else "WS")
            elif ins.get("side"):
                self.patt_until_side(ins["side"])
            edges.append(self.edge_of_row(self.next_row()))
            self.emit(beg=("bo", ins["n"]))
        self.used_edges.append(edges)

    def schedule(self, ins):
        """ins: {"row": {"beg": op|None, "end": op|None}, "every": k, "times": t,
                 "same_time": None | {"cm": x, "end": "WS", "row": {...}, "every": k, "times": t}}.
        The row is worked on the next right-side row and again every k rows t times more; a
        same-time block's row is first worked on the right-side row after its length is reached."""
        events = {}

        def add(row, r):
            beg, end = r.get("beg"), r.get("end")
            if self.mirror:
                beg, end = end, beg
            e = events.setdefault(row, {"beg": None, "end": None})
            assert (beg is None or e["beg"] is None) and (end is None or e["end"] is None), row
            if beg:
                e["beg"] = beg
            if end:
                e["end"] = end

        first = self.next_row() if self.is_rs(self.next_row()) else self.next_row() + 1
        for i in range(ins["times"] + 1):
            add(first + ins["every"] * i, ins["row"])
        st = ins.get("same_time")
        if st:
            t = rows_for(st["cm"], self.gauge_rows, st["end"])
            f2 = t + 1 if self.is_rs(t + 1) else t + 2
            assert f2 >= first, (f2, first)
            for i in range(st["times"] + 1):
                add(f2 + st["every"] * i, st["row"])
        last = max(events)
        while self.next_row() <= last:
            e = events.get(self.next_row())
            if e:
                self.emit(beg=e["beg"], end=e["end"])
            else:
                self.emit()


def expand(garment):
    """-> {piece name: [(row, side, tokens, count)]} and {piece name: counts after each instruction}."""
    patterns = {name: Pattern(name, p) for name, p in garment["patterns"].items()}
    g = garment["gauge"]["rows"]
    rows, counts, runs = {}, {}, {}
    for piece in garment["pieces"]:
        if piece.get("mirror_of"):
            src = runs[piece["mirror_of"]]
            run = PieceRun(patterns, g, mirror=True, bo_edges=src.used_edges)
            run.run(garment["pieces"][[p["name"] for p in garment["pieces"]].index(piece["mirror_of"])]["instructions"])
        else:
            run = PieceRun(patterns, g)
            run.run(piece["instructions"])
        runs[piece["name"]] = run
        rows[piece["name"]] = run.rows
        counts[piece["name"]] = run.counts
    return rows, counts


def load_rows(path):
    """A row-list file read as text -> {(piece, row): (side, tokens tuple, count)}."""
    import csv
    out = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            out[(r["piece"], int(r["row"]))] = (r["side"], tuple(r["stitches"].split()), int(r["count"]))
    return out


def write_rows(path, rows):
    import csv
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["piece", "row", "side", "stitches", "count"])
        for piece, rr in rows.items():
            for n, side, tokens, count in rr:
                w.writerow([piece, n, side, " ".join(tokens), count])


if __name__ == "__main__":
    import sys
    g = json.load(open(sys.argv[1]))
    rows, counts = expand(g)
    for piece, rr in rows.items():
        print(piece, len(rr), "rows; counts", counts[piece])
