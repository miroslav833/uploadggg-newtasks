#!/bin/bash
# Grades the chart desk. The reward folder is taken by root and closed before the solver's program
# runs; when the grading is over it holds reward.txt and the report and nothing else.
umask 077
R=/logs/verifier
mkdir -p /logs/verifier
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier
if [ "$(stat -c %u:%a /logs/verifier)" != "0:700" ]; then
    echo "reward folder not closed; grading abandoned" >&2
    exit 0
fi
find "$R" -mindepth 1 -exec rm -rf {} + 2>/dev/null
echo 0 > "$R/reward.txt"
SCRATCH=$(mktemp -d /run/chartdesk-XXXXXX)
cd /tests || exit 0
passed=0
python3 -m pytest -q -rA -p no:cacheprovider -s --ctrf "$SCRATCH/report.json" test_garments.py && passed=1
find "$R" -mindepth 1 ! -user 0 -exec rm -rf {} + 2>/dev/null
rm -f "$R/reward.json"
cp "$SCRATCH/report.json" "$R/ctrf.json" 2>/dev/null
echo "$passed" > "$R/reward.txt"
find "$R" -mindepth 1 -type f -exec chmod 644 {} +
chmod 755 "$R"
exit 0
