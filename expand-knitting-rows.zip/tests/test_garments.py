import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rowmodel        # noqa: E402
import run_chartdesk   # noqa: E402

VAULT = run_chartdesk.VAULT


def test_sealed_row_lists_follow_from_the_sealed_instructions():
    names = run_chartdesk.garments()
    assert len(names) == 20
    for name in names:
        garment = json.load(open(os.path.join(VAULT, name + ".garment.json")))
        rebuilt, _counts = rowmodel.expand(garment)
        key = run_chartdesk.sealed_rows(name)
        flat = {(piece, n): (side, tokens, count)
                for piece, rows in rebuilt.items() for n, side, tokens, count in rows}
        assert set(flat) == set(key), name
        for k, v in flat.items():
            assert key[k] == v, (name, k, v, key[k])
        for piece, rows in rebuilt.items():
            assert rows[-1][3] == 0, (name, piece)          # every piece ends bound off


def test_chart_desk_counts_enough_garments():
    assert os.path.isfile(run_chartdesk.PROGRAM), "no /app/chartdesk/rows.py"
    wrong = run_chartdesk.run_program()
    counted = [g for g, w in wrong.items() if w <= run_chartdesk.ROWS_ALLOWED]
    print("garments counted %d of %d (wrong rows: %s)"
          % (len(counted), len(wrong), ", ".join("%s %d" % kv for kv in sorted(wrong.items()))))
    assert len(counted) >= run_chartdesk.GARMENTS_NEEDED, \
        "%d of 20 garments counted; %d needed" % (len(counted), run_chartdesk.GARMENTS_NEEDED)
