"""Runs the solver's chart desk once over the sealed garments and counts the rows it gets wrong.

The garment texts are copied, without their row lists or structured forms, into a root-owned
folder anyone can read. The output folder belongs to a numeric account no user or process holds.
The program runs under that account in its own session with memory, file-size and wall-clock
limits; every process of the account is killed before anything is read. Each output is opened
through O_NOFOLLOW, accepted only as a regular file of at most 8 MiB, read as text and never run.
"""
import csv
import os
import pwd
import resource
import shutil
import signal
import subprocess
import time

VAULT = "/tests/vault"
PROGRAM = "/app/chartdesk/rows.py"
STAGE = "/var/tmp/chartdesk"
WALL_S = 300            # the program's budget for all garments
ROWS_ALLOWED = 1        # rows a garment may have wrong and still count
GARMENTS_NEEDED = 18    # of 20
BYTES_CAP = 8 << 20


def garments():
    return sorted(n[:-4] for n in os.listdir(VAULT) if n.endswith(".txt"))


def busy(uid):
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    return True
            except FileNotFoundError:
                pass
    return False


def free_uid(start=62100):
    taken = {p.pw_uid for p in pwd.getpwall()}
    uid = start
    while uid in taken or busy(uid):
        uid += 1
    return uid


def reap(uid):
    for _ in range(300):
        found = False
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    found = True
                    os.kill(int(d), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError):
                pass
        if not found:
            return
        time.sleep(0.05)


def sealed_rows(name):
    key = {}
    with open(os.path.join(VAULT, name + ".rows.csv"), newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            key[(r["piece"], int(r["row"]))] = (r["side"], r["stitches"].split(), int(r["count"]))
    return key


def filed_rows(path):
    """The program's row list read as text; rows that do not parse are dropped."""
    out = {}
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOCTTY)
    except OSError:
        return out
    try:
        st = os.fstat(fd)
        if not os.path.stat.S_ISREG(st.st_mode) or st.st_size > BYTES_CAP:
            return out
        data = os.read(fd, BYTES_CAP).decode("utf-8", errors="replace")
    finally:
        os.close(fd)
    for r in csv.DictReader(data.splitlines()):
        try:
            out[(r["piece"], int(r["row"]))] = (r["side"], r["stitches"].split(), int(r["count"]))
        except (KeyError, TypeError, ValueError):
            continue
    return out


def wrong_rows(key, filed):
    return sum(1 for k in set(key) | set(filed) if key.get(k) != filed.get(k))


def run_program():
    """-> {garment: wrong rows}"""
    uid = free_uid()
    shutil.rmtree(STAGE, ignore_errors=True)
    inp, outp = os.path.join(STAGE, "in"), os.path.join(STAGE, "out")
    os.makedirs(inp)
    os.makedirs(outp)
    for name in garments():
        shutil.copyfile(os.path.join(VAULT, name + ".txt"), os.path.join(inp, name + ".txt"))
    os.chmod(STAGE, 0o755)
    os.chmod(inp, 0o755)
    for n in os.listdir(inp):
        os.chmod(os.path.join(inp, n), 0o644)
    os.chown(outp, uid, uid)
    os.chmod(outp, 0o700)

    def limits():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        os.setgid(uid)
        os.setuid(uid)

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": outp, "LANG": "C.UTF-8",
           "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        subprocess.run(["python3", "-I", PROGRAM, inp, outp], cwd=outp, env=env,
                       preexec_fn=limits, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=WALL_S)
    except subprocess.TimeoutExpired:
        pass
    finally:
        reap(uid)
    result = {}
    for name in garments():
        result[name] = wrong_rows(sealed_rows(name), filed_rows(os.path.join(outp, name + ".rows.csv")))
    return result
