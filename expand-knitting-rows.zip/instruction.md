The pattern desk needs a program that turns a written knitting pattern into the row list its chart is drawn from. Put it at `/app/chartdesk/rows.py`; the desk calls it with two folder paths:

```
python3 /app/chartdesk/rows.py IN_DIR OUT_DIR
```

IN_DIR holds two files per garment. `NAME.txt` is the pattern, written to the style sheet in `/app/STYLE.md` (gauge line, stitch patterns, then the pieces in the house vocabulary). `NAME.back.csv` is the test knitter's row list for that garment's Back, in the row-list format the style sheet describes. For each garment the program writes `NAME.rows.csv` into OUT_DIR. That file has a header and then one line per knitted row of every piece, the Back included, in this form:

```
piece,row,side,stitches,count
Sleeve,12,WS,p p p p p p p p p p p p p p p p p p p p p p p p,24
```

Here `piece` repeats the name from the piece's heading; `row` is 1 for the first row worked after casting on and goes up by one per row; `side` is `RS` or `WS`; `stitches` gives the row's tokens in working order, drawn from the style sheet's abbreviation table, one space between them, with `bo` for each bound-off stitch; `count` is how many stitches are on the needle once the row is finished. The last row of a piece binds off whatever is left and has count 0. A piece the pattern describes as the mirror of another is written out in full under its own name. Every piece of a garment is worked by the methods its designer used, as the style sheet explains.

Four garments sit in `/app/samples`, each with its Back and the full row list the desk made for it. Twenty further garments, written to the same style sheet, are used for grading; their designers, fabrics, panels, shaping and lengths go beyond what the four samples happen to show.

A row is correct only if its side, its tokens and its count all match the desk's row. A garment passes if no more than 1 of its rows is wrong, where a missing row or a row that should not be there is wrong. Grading passes the task when 18 or more of the 20 garments pass. The program gets one run over the folder, under an unprivileged account, with the image's python3 and the standard library only, and has 300 seconds to finish; nothing outside `/app/chartdesk` will be available to it.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
