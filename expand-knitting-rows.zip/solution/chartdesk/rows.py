#!/usr/bin/env python3
"""Chart desk: expands every garment file in IN_DIR into a row list in OUT_DIR.

    python3 rows.py IN_DIR OUT_DIR

The written pattern is parsed into the house vocabulary (set-up rows, lengths, shaping sentences
and their repeats, bind-offs, shaping at the same time, mirrored pieces). The designer's working
methods are found as the one combination under which the Back knits exactly as the test knitter's
Back (NAME.back.csv), and every piece is then knitted by them on a model needle: every stitch is a
column that remembers the pattern and the repeat position it was set up in.
"""
import csv
import math
import os
import re
import sys

MADE = {"k": 1, "p": 1, "sl1": 1, "kfb": 2, "yo": 1, "k2tog": 1, "ssk": 1, "p2tog": 1, "cdd": 1, "m1": 1, "bo": 0,
        "k1tbl": 1, "p1tbl": 1, "skpo": 1, "k2togtbl": 1, "C4F": 4, "C4B": 4, "C6F": 6, "C6B": 6}
USED = {"k": 1, "p": 1, "sl1": 1, "kfb": 1, "yo": 0, "k2tog": 2, "ssk": 2, "p2tog": 2, "cdd": 3, "m1": 0, "bo": 1,
        "k1tbl": 1, "p1tbl": 1, "skpo": 2, "k2togtbl": 2, "C4F": 4, "C4B": 4, "C6F": 6, "C6B": 6}
DECS = {"k2tog", "ssk", "p2tog", "cdd"}
ORDINAL = {"RS row": 2, "2nd row": 2, "4th row": 4, "6th row": 6, "8th row": 8, "10th row": 10}


# ------------------------------------------------------------------ the written pattern
def tokens_of(text):
    """'K3, yo, ssk, p2' -> ['k','k','k','yo','ssk','p','p']"""
    out = []
    for part in text.split(","):
        part = part.strip().rstrip(".")
        if not part:
            continue
        m = re.fullmatch(r"([KkPp])(\d*)", part)
        if m:
            out += [m.group(1).lower()] * (int(m.group(2) or 1))
        elif re.fullmatch(r"C\d[FB]", part):
            out.append(part)
        else:
            out.append(part.lower())
    return out


def units_of(cols):
    """Column-order tokens -> units: a yarn-over with the decrease beside it (a cdd with both),
    everything else on its own."""
    units, i = [], 0
    while i < len(cols):
        t = cols[i]
        nxt = cols[i + 1] if i + 1 < len(cols) else None
        nxt2 = cols[i + 2] if i + 2 < len(cols) else None
        if t == "yo" and nxt == "cdd" and nxt2 == "yo":
            units.append(["yo", "cdd", "yo"])
            i += 3
        elif t == "yo" and nxt in DECS:
            units.append(["yo", nxt])
            i += 2
        elif t in DECS and nxt == "yo":
            units.append([t, "yo"])
            i += 2
        else:
            units.append([t])
            i += 1
    return units


class Pattern:
    def __init__(self, name, kind, size):
        self.name, self.kind, self.size = name, kind, size
        self.rows = []         # per row: list of units in column order
        self.lookup = []       # per row: column -> (unit no, offset)

    def add_row(self, n, body):
        rs = n % 2 == 1
        if body.startswith("As Row"):
            k = int(re.search(r"\d+", body).group())
            cols = [t for u in self.rows[k - 1] for t in u]
        elif body == "Knit.":
            cols = ["k"] * self.size
        elif body == "Purl.":
            cols = ["p"] * self.size
        else:
            body = body.strip().rstrip(".")
            if body.startswith("*"):
                body = body[1:].split(";")[0]
            cols = tokens_of(body)
            if not rs:
                cols = list(reversed(cols))
        units = units_of(cols)
        assert sum(USED[t] for u in units for t in u) == self.size, (self.name, n)
        self.rows.append(units)
        d, c = {}, 0
        for u, unit in enumerate(units):
            w = sum(USED[t] for t in unit)
            for off in range(w):
                d[c + off] = (u, off)
            c += w
        self.lookup.append(d)


def parse_patterns(lines):
    pats, cur = {}, None
    for line in lines:
        m = re.match(r"^(.+?) \((?:mult of (\d+)|over (\d+) sts)\)$", line)
        if m:
            kind = "allover" if m.group(2) else "panel"
            cur = Pattern(m.group(1), kind, int(m.group(2) or m.group(3)))
            pats[cur.name] = cur
            continue
        m = re.match(r"^Row (\d+)(?: \(RS\))?: (.*)$", line)
        if m and cur:
            cur.add_row(int(m.group(1)), m.group(2))
    return pats


SHAPING = re.compile(r"^(Dec|Inc) 1 st at (each end|side edge|armhole edge|neck edge) of next RS row"
                     r"(?: and every foll (\w+ row) (\d+) times? more)?\.$")
AT_SAME = re.compile(r"^AT THE SAME TIME, when piece measures ([\d.]+) cm, ending with a (RS|WS) row, .*:$")


def shaping_of(m):
    """A matched shaping sentence -> {"row": {"beg", "end"}, "every", "times"}. On a Right Front the
    neck edge begins right-side rows and the side and armhole edge ends them."""
    op = m.group(1).lower()
    where = m.group(2)
    row = {"beg": None, "end": None}
    if where == "each end":
        row = {"beg": op, "end": op}
    elif where == "neck edge":
        row["beg"] = op
    else:
        row["end"] = op
    every = ORDINAL[m.group(3)] if m.group(3) else 0
    return {"row": row, "every": every, "times": int(m.group(4) or 0)}


def parse_piece(lines):
    """-> {"mirror_of": name} or {"instructions": [...]}"""
    lines = [l.strip() for l in lines if l.strip()]
    ins = []
    k = 0
    while k < len(lines):
        line = re.sub(r"^Shape [a-z ]+: ", "", lines[k])
        line = re.sub(r" \(\d+ sts\)$", "", line)
        k += 1
        m = re.match(r"^Work as for (.+?), reversing all shaping\.$", line)
        if m:
            return {"mirror_of": m.group(1)}
        m = re.match(r"^Cast on (\d+) sts\.$", line)
        if m:
            ins.append({"op": "cast_on", "n": int(m.group(1))})
            continue
        m = re.match(r"^(?:Row 1|Next row) \(RS\): Work 1 selvedge st, (.*), work 1 selvedge st\.$", line)
        if m:
            segs = []
            for part in m.group(1).split(", "):
                mm = re.match(r"work Row 1 of (.+?)(?: over next (\d+) sts)?$", part)
                segs.append({"pat": mm.group(1), "over": int(mm.group(2)) if mm.group(2) else None})
            ins.append({"op": "setup", "segments": segs})
            continue
        m = re.match(r"^Work (\d+) rows in patt as established\.$", line)
        if m:
            ins.append({"op": "rows", "n": int(m.group(1))})
            continue
        m = re.match(r"^Cont in patt as established until piece measures ([\d.]+) cm, ending with a (RS|WS) row\.$", line)
        if m:
            ins.append({"op": "until", "cm": float(m.group(1)), "end": m.group(2)})
            continue
        m = re.match(r"^Work (\d+) rows?(?: even)?$", line.rstrip("."))
        if m:
            ins.append({"op": "rows", "n": int(m.group(1))})
            continue
        if line == "Bind off rem sts.":
            ins.append({"op": "bind_off_all"})
            continue
        if line.startswith("Bind off "):
            for part in line.rstrip(".").split(", then "):
                mm = re.match(r"^(?:Bind off )?(\d+) sts at beg of (?:next|foll) (?:(\d+) )?(?:(RS|WS) )?rows?$", part)
                ins.append({"op": "bind_off", "n": int(mm.group(1)), "rows": int(mm.group(2) or 1),
                            "side": mm.group(3)})
            continue
        m = SHAPING.match(line)
        if m:
            sched = dict(shaping_of(m), op="schedule", same_time=None)
            if k < len(lines):
                mm = AT_SAME.match(lines[k])
                if mm:
                    m2 = SHAPING.match(re.sub(r" \(\d+ sts\)$", "", lines[k + 1]))
                    sched["same_time"] = dict(shaping_of(m2), cm=float(mm.group(1)), end=mm.group(2))
                    k += 2
            ins.append(sched)
            continue
        raise ValueError("unrecognised line: %r" % line)
    return {"instructions": ins}


def parse_garment(text):
    lines = text.splitlines()
    gauge = None
    blocks, cur = [], None
    for line in lines:
        m = re.match(r"^GAUGE: (\d+) sts and (\d+) rows = 10 cm$", line)
        if m:
            gauge = int(m.group(2))
        if line.startswith("STITCH PATTERNS"):
            cur = ("patterns", [])
            blocks.append(cur)
        elif line.startswith("PIECE: "):
            cur = (line[7:].strip(), [])
            blocks.append(cur)
        elif cur:
            cur[1].append(line)
    patterns = parse_patterns(blocks[0][1])
    pieces = [(name, parse_piece(body)) for name, body in blocks[1:]]
    return gauge, patterns, pieces


# ------------------------------------------------------------------ the designer's methods
METHODS = {
    "selvedge": ("plain", "slip", "garter", "chain"),  # the first and last stitch of every row
    "lean": ("mirrored", "reversed"),          # the left-leaning decrease first and k2tog last, or the other way
    "slant": ("ssk", "skpo", "k2togtbl"),      # the designer's left-leaning decrease
    "position": ("edge", "inset", "inset2"),   # shaping beside the selvedge, or one or two plain stitches in
    "increase": ("m1", "kfb", "yo", "eyelet"),  # made, bar, yarn-over twisted next row, open eyelet
    "broken": ("unit", "repeat"),              # what of a cut repeat is still worked in pattern
    "measure": ("cast-on", "border"),          # where lengths are measured from
    "reach": ("nearest", "first", "last"),     # nearest row, first row reaching it, last row short of it
}


def all_methods():
    combos = [{}]
    for dim, opts in METHODS.items():
        combos = [dict(c, **{dim: o}) for c in combos for o in opts]
    return combos


# ------------------------------------------------------------------ the model needle
class Needle:
    """Columns are None (a plain stitch) or {"pat": name, "seg": the span's place in its set-up row,
    "ab": column from the first stitch of that span}; the repeat position is ab modulo the pattern's
    size, and a repeat is whole only when all its columns of the same span are on the needle."""

    def __init__(self, patterns, gauge_rows, methods, mirror=False, edges=None):
        self.patterns = patterns
        self.gauge_rows = gauge_rows
        self.m = methods
        self.mirror = mirror
        self.edges = edges
        self.cols = []
        self.first_row = {}
        self.border = 0
        self.out = []
        self.bo_sides = []
        self.check = None          # rows the knitting must reproduce, when searching the methods

    def row_no(self):
        return len(self.out) + 1

    @staticmethod
    def side(n):
        return "RS" if n % 2 else "WS"

    def length_row(self, cm, end):
        x = cm * self.gauge_rows / 10.0
        how = self.m["reach"]
        n = int(x + 0.5) if how == "nearest" else int(math.floor(x + 1e-9)) if how == "last" else int(math.ceil(x - 1e-9))
        if self.m["measure"] == "border":
            n += self.border
        if end == "WS" and n % 2:
            n += 1
        if end == "RS" and n % 2 == 0:
            n += 1
        return n

    def beside(self, col, step):
        if col is None or "tbl" in col or self.patterns[col["pat"]].kind != "allover":
            return None
        return {"pat": col["pat"], "seg": col["seg"], "ab": col["ab"] + step}

    def whole_repeats(self, work):
        if self.m["broken"] == "unit":
            return None
        have = {(c["pat"], c["seg"], c["ab"]) for c in work if c and "tbl" not in c}
        ok = set()
        for pat, seg, ab in have:
            size = self.patterns[pat].size
            lo = ab - ab % size
            if all((pat, seg, lo + t) in have for t in range(size)):
                ok.add((pat, seg, ab))
        return ok

    def fabric_tokens(self, work, n):
        rs = n % 2 == 1
        plain = "k" if rs else "p"
        ok = self.whole_repeats(work)
        toks, j = [], 0
        while j < len(work):
            col = work[j]
            if col is not None and "tbl" in col:      # a yarn-over increase, twisted on this row
                toks.append("k1tbl" if rs else "p1tbl")
                j += 1
                continue
            if col is None or (ok is not None and (col["pat"], col["seg"], col["ab"]) not in ok):
                toks.append(plain)
                j += 1
                continue
            P = self.patterns[col["pat"]]
            r = (n - self.first_row[col["pat"]]) % len(P.rows)
            pos = col["ab"] % P.size
            u, off = P.lookup[r][pos]
            unit = P.rows[r][u]
            w = sum(USED[t] for t in unit)
            want = [col["ab"] + (t if rs else -t) for t in range(w)]
            here = [c["ab"] if c and c.get("pat") == col["pat"] and c.get("seg") == col["seg"] else None
                    for c in work[j:j + w]]
            if off == (0 if rs else w - 1) and here == want:
                toks += unit if rs else unit[::-1]
                j += w
            else:
                toks.append(plain)
                j += 1
        return toks

    def edge_st(self, rs, first):
        s = self.m["selvedge"]
        if first and s in ("slip", "chain"):
            return "sl1"
        if s in ("garter", "chain"):
            return "k"
        return "k" if rs else "p"

    def made(self, col, step):
        """The column an increase makes beside `col`, outward; a yarn-over's stitch is marked to be
        twisted on the next row."""
        new = self.beside(col, step)
        return {"tbl": new} if self.m["increase"] == "yo" else new     # an eyelet stays open, worked plain

    def knit(self, beg=None, end=None):
        n = self.row_no()
        rs = n % 2 == 1
        plain = "k" if rs else "p"
        work = list(self.cols) if rs else self.cols[::-1]
        W = len(work)
        slant = self.m["slant"]
        d_beg, d_end = (slant, "k2tog") if self.m["lean"] == "mirrored" else ("k2tog", slant)
        inset = {"edge": 0, "inset": 1, "inset2": 2}[self.m["position"]]
        how = self.m["increase"]
        made_tok = "yo" if how in ("yo", "eyelet") else how
        if beg and beg[0] == "bo":
            left = work[beg[1]]
            twist = left is not None and "tbl" in left
            toks = ["bo"] * beg[1] + [("k1tbl" if rs else "p1tbl") if twist else plain]
            lead, a = [None], beg[1] + 1
        else:
            toks, lead, a = [self.edge_st(rs, True)], [None], 1
            if beg in ("dec", "inc") and inset:
                toks += [plain] * inset
                lead += [None] * inset
                a = 1 + inset
            if beg == "dec":
                toks.append(d_beg)
                lead.append(work[a + 1])
                a += 2
            elif beg == "inc":
                if how == "kfb":
                    toks.append("kfb")
                    lead += [self.beside(work[a], -1), work[a]]
                    a += 1
                else:
                    toks.append(made_tok)
                    lead.append(self.made(work[a], -1))
        e = W - 1                       # where the end selvedge sits
        end_toks, trail, border_t, border = [], [], [], []
        if end in ("dec", "inc") and inset:
            border_t, border = [plain] * inset, [None] * inset
            e -= inset
        z = e
        if end == "dec":
            end_toks, trail, z = [d_end], [work[e - 2]], e - 2
        elif end == "inc":
            if how == "kfb":
                end_toks, trail, z = ["kfb"], [work[e - 1], self.beside(work[e - 1], 1)], e - 1
            else:
                end_toks, trail = [made_tok], [self.made(work[e - 1], 1)]
        mid = work[a:z]
        toks += self.fabric_tokens(mid, n) + end_toks + border_t + [self.edge_st(rs, False)]
        mid = [c["tbl"] if c is not None and "tbl" in c else c for c in mid]
        cols = lead + mid + trail + border + [None]
        self.cols = cols if rs else cols[::-1]
        self.out.append((n, self.side(n), toks, sum(MADE[t] for t in toks)))
        if self.check is not None and (len(self.out) > len(self.check) or self.out[-1] != self.check[len(self.out) - 1]):
            raise ValueError("differs from the Back")

    def knit_to_side(self, side):
        while self.side(self.row_no()) != side:
            self.knit()

    def run(self, instructions):
        bo_no = 0
        for ins in instructions:
            op = ins["op"]
            if op == "cast_on":
                self.cols = [None] * ins["n"]
            elif op == "setup":
                n = self.row_no()
                if n > 1:
                    self.border = n - 1
                cols = [None]
                for si, seg in enumerate(ins["segments"]):
                    P = self.patterns[seg["pat"]]
                    over = seg["over"] if seg["over"] is not None else P.size
                    cols += [{"pat": seg["pat"], "seg": si, "ab": c} for c in range(over)]
                    self.first_row[seg["pat"]] = n
                cols.append(None)
                if len(cols) != len(self.cols):
                    raise ValueError("set-up does not span the row")
                self.cols = cols
                self.knit()
            elif op == "rows":
                for _ in range(ins["n"]):
                    self.knit()
            elif op == "until":
                target = self.length_row(ins["cm"], ins["end"])
                while self.row_no() <= target:
                    self.knit()
            elif op == "bind_off":
                sides = []
                for j in range(ins["rows"]):
                    if self.mirror:
                        twin = self.edges[bo_no][j]
                        self.knit_to_side("WS" if twin == "RS" else "RS")
                    elif ins["side"]:
                        self.knit_to_side(ins["side"])
                    sides.append(self.side(self.row_no()))
                    self.knit(beg=("bo", ins["n"]))
                self.bo_sides.append(sides)
                bo_no += 1
            elif op == "schedule":
                self.schedule(ins)
            elif op == "bind_off_all":
                n = self.row_no()
                self.out.append((n, self.side(n), ["bo"] * len(self.cols), 0))
                self.cols = []
                if self.check is not None and self.out != self.check:
                    raise ValueError("differs from the Back")

    def schedule(self, ins):
        plan = {}

        def place(row, shaping):
            beg, end = shaping["beg"], shaping["end"]
            if self.mirror:
                beg, end = end, beg
            e = plan.setdefault(row, [None, None])
            if beg:
                e[0] = beg
            if end:
                e[1] = end

        n = self.row_no()
        first = n if n % 2 else n + 1
        for i in range(ins["times"] + 1):
            place(first + i * ins["every"], ins["row"])
        st = ins["same_time"]
        if st:
            t = self.length_row(st["cm"], st["end"]) + 1
            f2 = t if t % 2 else t + 1
            for i in range(st["times"] + 1):
                place(f2 + i * st["every"], st["row"])
        last = max(plan)
        while self.row_no() <= last:
            e = plan.get(self.row_no())
            if e:
                self.knit(beg=e[0], end=e[1])
            else:
                self.knit()


def knit_garment(gauge, patterns, pieces, methods, only=None):
    runs, result = {}, []
    for name, piece in pieces:
        if only and name not in only:
            continue
        if "mirror_of" in piece:
            twin = runs[piece["mirror_of"]]
            nd = Needle(patterns, gauge, methods, mirror=True, edges=twin.bo_sides)
            nd.run(twin.instructions)
        else:
            nd = Needle(patterns, gauge, methods)
            nd.instructions = piece["instructions"]
            nd.run(piece["instructions"])
        runs[name] = nd
        result.append((name, nd.out))
    return result


def read_rows(path):
    with open(path, newline="", encoding="utf-8") as f:
        return [(r["piece"], int(r["row"]), r["side"], r["stitches"].split(), int(r["count"]))
                for r in csv.DictReader(f)]


def plausible(back):
    """The method combinations the Back's own tokens allow: a selvedge, decrease form and increase
    that leave tokens the Back does not have (or miss ones it has) are not tried."""
    seen = {t for n, side, toks, count in back for t in toks}
    first = {toks[0] for n, side, toks, count in back if "bo" not in toks}
    out = []
    for m in all_methods():
        if ("sl1" in first) != (m["selvedge"] in ("slip", "chain")):
            continue
        if m["slant"] != "ssk" and m["slant"] not in seen:
            continue
        if m["increase"] == "kfb" and "kfb" not in seen or m["increase"] == "m1" and "m1" not in seen:
            continue
        if m["increase"] == "yo" and not ({"p1tbl", "k1tbl"} & seen):
            continue
        out.append(m)
    return out


def find_methods(gauge, patterns, pieces, back_rows):
    """The designer's methods: the combination under which the Back knits exactly as the test
    knitter's Back. Combinations are tried in a fixed order; the first match is taken."""
    want = [(n, side, toks, count) for piece, n, side, toks, count in back_rows if piece == "Back"]
    back = dict(pieces)["Back"]
    for methods in plausible(want):
        nd = Needle(patterns, gauge, methods)
        nd.check = want
        try:
            nd.run(back["instructions"])
        except (IndexError, KeyError, ValueError, AssertionError):
            continue
        if nd.out == want:
            return methods
    raise ValueError("no combination of methods knits the Back as given")


def expand(text, back_rows):
    gauge, patterns, pieces = parse_garment(text)
    methods = find_methods(gauge, patterns, pieces, back_rows)
    return knit_garment(gauge, patterns, pieces, methods)


def main(in_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for fn in sorted(os.listdir(in_dir)):
        if not fn.endswith(".txt"):
            continue
        name = fn[:-4]
        text = open(os.path.join(in_dir, fn), encoding="utf-8").read()
        rows = expand(text, read_rows(os.path.join(in_dir, name + ".back.csv")))
        with open(os.path.join(out_dir, name + ".rows.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["piece", "row", "side", "stitches", "count"])
            for piece, out in rows:
                for n, side, toks, count in out:
                    w.writerow([piece, n, side, " ".join(toks), count])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
