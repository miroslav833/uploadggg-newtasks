#!/usr/bin/env python3
"""Chart desk: expands every garment file in IN_DIR into a row list in OUT_DIR.

    python3 rows.py IN_DIR OUT_DIR

The written pattern is parsed into the house vocabulary (set-up rows, lengths, named shaping
rows and their repeats, bind-offs, shaping at the same time, mirrored pieces), then each piece is
knitted on a model needle: every stitch is a column that remembers the pattern and the repeat
position it was set up in, and each row is produced from those columns.
"""
import csv
import os
import re
import sys

MADE = {"k": 1, "p": 1, "yo": 1, "k2tog": 1, "ssk": 1, "p2tog": 1, "cdd": 1, "m1": 1, "bo": 0,
        "C4F": 4, "C4B": 4, "C6F": 6, "C6B": 6}
USED = {"k": 1, "p": 1, "yo": 0, "k2tog": 2, "ssk": 2, "p2tog": 2, "cdd": 3, "m1": 0, "bo": 1,
        "C4F": 4, "C4B": 4, "C6F": 6, "C6B": 6}
DECS = {"k2tog", "ssk", "p2tog", "cdd"}
ORDINAL = {"RS row": 2, "2nd row": 2, "4th row": 4, "6th row": 6, "8th row": 8, "10th row": 10}


# ------------------------------------------------------------------ the written pattern
def tokens_of(text):
    """'K3, yo, ssk, p2' -> ['k','k','k','yo','ssk','p','p']"""
    out = []
    for part in text.split(","):
        part = part.strip().rstrip(".")
        if not part:
            continue
        m = re.fullmatch(r"([KkPp])(\d*)", part)
        if m:
            out += [m.group(1).lower()] * (int(m.group(2) or 1))
        elif re.fullmatch(r"C\d[FB]", part):
            out.append(part)
        else:
            out.append(part.lower())
    return out


def units_of(cols):
    """Column-order tokens -> units: a yarn-over with the decrease beside it (a cdd with both),
    everything else on its own."""
    units, i = [], 0
    while i < len(cols):
        t = cols[i]
        nxt = cols[i + 1] if i + 1 < len(cols) else None
        nxt2 = cols[i + 2] if i + 2 < len(cols) else None
        if t == "yo" and nxt == "cdd" and nxt2 == "yo":
            units.append(["yo", "cdd", "yo"])
            i += 3
        elif t == "yo" and nxt in DECS:
            units.append(["yo", nxt])
            i += 2
        elif t in DECS and nxt == "yo":
            units.append([t, "yo"])
            i += 2
        else:
            units.append([t])
            i += 1
    return units


class Pattern:
    def __init__(self, name, kind, size):
        self.name, self.kind, self.size = name, kind, size
        self.rows = []         # per row: list of units in column order
        self.lookup = []       # per row: column -> (unit no, offset)

    def add_row(self, n, body):
        rs = n % 2 == 1
        if body.startswith("As Row"):
            k = int(re.search(r"\d+", body).group())
            cols = [t for u in self.rows[k - 1] for t in u]
        elif body == "Knit.":
            cols = ["k"] * self.size
        elif body == "Purl.":
            cols = ["p"] * self.size
        else:
            body = body.strip().rstrip(".")
            if body.startswith("*"):
                body = body[1:].split(";")[0]
            cols = tokens_of(body)
            if not rs:
                cols = list(reversed(cols))
        units = units_of(cols)
        assert sum(USED[t] for u in units for t in u) == self.size, (self.name, n)
        self.rows.append(units)
        d, c = {}, 0
        for u, unit in enumerate(units):
            w = sum(USED[t] for t in unit)
            for off in range(w):
                d[c + off] = (u, off)
            c += w
        self.lookup.append(d)


def parse_patterns(lines):
    pats, cur = {}, None
    for line in lines:
        m = re.match(r"^(.+?) \((?:mult of (\d+)|over (\d+) sts)\)$", line)
        if m:
            kind = "allover" if m.group(2) else "panel"
            cur = Pattern(m.group(1), kind, int(m.group(2) or m.group(3)))
            pats[cur.name] = cur
            continue
        m = re.match(r"^Row (\d+)(?: \(RS\))?: (.*)$", line)
        if m and cur:
            cur.add_row(int(m.group(1)), m.group(2))
    return pats


def parse_shaping_row(body):
    body = body.strip().rstrip(".")
    low = body.lower()
    beg = end = None
    if low.startswith("k1, ssk"):
        beg = "dec"
    elif low.startswith("k1, m1"):
        beg = "inc"
    if low.endswith("k2tog, k1"):
        end = "dec"
    elif low.endswith("m1, k1"):
        end = "inc"
    return {"beg": beg, "end": end}


def parse_piece(lines):
    """-> {"mirror_of": name} or {"instructions": [...]}"""
    ins = []
    k = 0
    while k < len(lines):
        line = lines[k].strip()
        k += 1
        if not line:
            continue
        m = re.match(r"^Work as for (.+?), reversing all shaping\.$", line)
        if m:
            return {"mirror_of": m.group(1)}
        line = re.sub(r"^Shape [a-z ]+: ", "", line)
        line = re.sub(r" \(\d+ sts\)$", "", line)
        m = re.match(r"^Cast on (\d+) sts\.$", line)
        if m:
            ins.append({"op": "cast_on", "n": int(m.group(1))})
            continue
        m = re.match(r"^(?:Row 1|Next row) \(RS\): K1, (.*), k1\.$", line)
        if m:
            segs = []
            for part in m.group(1).split(", "):
                mm = re.match(r"work Row 1 of (.+?)(?: over next (\d+) sts)?$", part)
                segs.append({"pat": mm.group(1), "over": int(mm.group(2)) if mm.group(2) else None})
            ins.append({"op": "setup", "segments": segs})
            continue
        m = re.match(r"^Work (\d+) rows in patt as established\.$", line)
        if m:
            ins.append({"op": "rows", "n": int(m.group(1))})
            continue
        m = re.match(r"^Cont in patt as established until piece measures ([\d.]+) cm, ending with a (RS|WS) row\.$", line)
        if m:
            ins.append({"op": "until", "cm": float(m.group(1)), "end": m.group(2)})
            continue
        m = re.match(r"^Work (\d+) rows?(?: even)?$", line.rstrip("."))
        if m:
            ins.append({"op": "rows", "n": int(m.group(1))})
            continue
        if line == "Bind off rem sts.":
            ins.append({"op": "bind_off_all"})
            continue
        if line.startswith("Bind off "):
            for part in line.rstrip(".").split(", then "):
                mm = re.match(r"^(?:Bind off )?(\d+) sts at beg of (?:next|foll) (?:(\d+) )?(?:(RS|WS) )?rows?$", part)
                ins.append({"op": "bind_off", "n": int(mm.group(1)), "rows": int(mm.group(2) or 1),
                            "side": mm.group(3)})
            continue
        m = re.match(r"^([A-Z][a-z ]+?) \(RS\): (.*)$", line)
        if m:
            sched = {"op": "schedule", "name": m.group(1), "row": parse_shaping_row(m.group(2)),
                     "every": 0, "times": 0, "same_time": None}
            # the repeat line, if any, then a block at the same time
            if k < len(lines):
                mm = re.match(r"^Rep %s every (\w+ row) (\d+) times? more\." % re.escape(sched["name"]),
                              lines[k].strip())
                if mm:
                    sched["every"], sched["times"] = ORDINAL[mm.group(1)], int(mm.group(2))
                    k += 1
            if k < len(lines):
                mm = re.match(r"^AT THE SAME TIME, when piece measures ([\d.]+) cm, ending with a (RS|WS) row, (.*):$",
                              lines[k].strip())
                if mm:
                    k += 1
                    m2 = re.match(r"^([A-Z][a-z ]+?) \(RS\): (.*)$", re.sub(r" \(\d+ sts\)$", "", lines[k].strip()))
                    st = {"cm": float(mm.group(1)), "end": mm.group(2), "name": m2.group(1),
                          "row": parse_shaping_row(m2.group(2)), "every": 0, "times": 0}
                    k += 1
                    if k < len(lines):
                        m3 = re.match(r"^Rep %s every (\w+ row) (\d+) times? more\." % re.escape(st["name"]),
                                      lines[k].strip())
                        if m3:
                            st["every"], st["times"] = ORDINAL[m3.group(1)], int(m3.group(2))
                            k += 1
                    sched["same_time"] = st
            ins.append(sched)
            continue
        raise ValueError("unrecognised line: %r" % line)
    return {"instructions": ins}


def parse_garment(text):
    lines = text.splitlines()
    gauge = None
    blocks, cur = [], None
    for line in lines:
        m = re.match(r"^GAUGE: (\d+) sts and (\d+) rows = 10 cm$", line)
        if m:
            gauge = int(m.group(2))
        if line.startswith("STITCH PATTERNS"):
            cur = ("patterns", [])
            blocks.append(cur)
        elif line.startswith("PIECE: "):
            cur = (line[7:].strip(), [])
            blocks.append(cur)
        elif cur:
            cur[1].append(line)
    patterns = parse_patterns(blocks[0][1])
    pieces = [(name, parse_piece(body)) for name, body in blocks[1:]]
    return gauge, patterns, pieces


# ------------------------------------------------------------------ the model needle
class Needle:
    """Columns are dicts {pat, pos} or None for a plain stitch."""

    def __init__(self, patterns, gauge_rows, mirror=False, edges=None):
        self.patterns = patterns
        self.gauge_rows = gauge_rows
        self.mirror = mirror
        self.edges = edges             # mirrored run: per bind-off sentence, its twin's row sides
        self.cols = []
        self.first_row = {}            # pattern name -> row its Row 1 fell on
        self.out = []                  # (row, side, tokens, count)
        self.bo_sides = []

    def row_no(self):
        return len(self.out) + 1

    @staticmethod
    def side(n):
        return "RS" if n % 2 else "WS"

    def length_row(self, cm, end):
        n = int(cm * self.gauge_rows / 10.0 + 0.5)
        if end == "WS" and n % 2:
            n += 1
        if end == "RS" and n % 2 == 0:
            n += 1
        return n

    def beside(self, col, step):
        """The column the repeat continues into, outward from `col`."""
        if col is None or self.patterns[col["pat"]].kind != "allover":
            return None
        return {"pat": col["pat"], "pos": (col["pos"] + step) % self.patterns[col["pat"]].size}

    def fabric_tokens(self, work, n):
        rs = n % 2 == 1
        plain = "k" if rs else "p"
        toks, j = [], 0
        while j < len(work):
            col = work[j]
            if col is None:
                toks.append(plain)
                j += 1
                continue
            P = self.patterns[col["pat"]]
            r = (n - self.first_row[col["pat"]]) % len(P.rows)
            u, off = P.lookup[r][col["pos"]]
            unit = P.rows[r][u]
            w = sum(USED[t] for t in unit)
            want = [(col["pos"] - off + (t if rs else w - 1 - t)) for t in range(w)]
            here = [c["pos"] if c and c["pat"] == col["pat"] else None for c in work[j:j + w]]
            if off == (0 if rs else w - 1) and here == want:
                toks += unit if rs else unit[::-1]
                j += w
            else:
                toks.append(plain)
                j += 1
        return toks

    def knit(self, beg=None, end=None):
        n = self.row_no()
        rs = n % 2 == 1
        work = self.cols if rs else self.cols[::-1]
        W = len(work)
        toks, lead, trail = [], [], []
        a, z = 0, W
        if beg and beg[0] == "bo":
            toks += ["bo"] * beg[1]
            a = beg[1]
            work = list(work)
            work[a] = None
        elif beg == "dec":
            toks += ["k", "ssk"]
            lead = [None, work[2]]
            a = 3
        elif beg == "inc":
            toks += ["k", "m1"]
            lead = [None, self.beside(work[1], -1)]
            a = 1
        if end == "dec":
            trail = [work[W - 3], None]
            z = W - 3
        elif end == "inc":
            trail = [self.beside(work[W - 2], 1), None]
            z = W - 1
        mid = work[a:z]
        toks += self.fabric_tokens(mid, n)
        if end == "dec":
            toks += ["k2tog", "k"]
        elif end == "inc":
            toks += ["m1", "k"]
        cols = lead + mid + trail
        if cols:
            cols[0] = cols[-1] = None
        self.cols = cols if rs else cols[::-1]
        self.out.append((n, self.side(n), toks, sum(MADE[t] for t in toks)))

    def knit_to_side(self, side):
        while self.side(self.row_no()) != side:
            self.knit()

    def run(self, instructions):
        bo_no = 0
        for ins in instructions:
            op = ins["op"]
            if op == "cast_on":
                self.cols = [None] * ins["n"]
            elif op == "setup":
                n = self.row_no()
                cols = [None]
                for seg in ins["segments"]:
                    P = self.patterns[seg["pat"]]
                    over = seg["over"] if seg["over"] is not None else P.size
                    cols += [{"pat": seg["pat"], "pos": c % P.size} for c in range(over)]
                    self.first_row[seg["pat"]] = n
                cols.append(None)
                assert len(cols) == len(self.cols)
                self.cols = cols
                self.knit()
            elif op == "rows":
                for _ in range(ins["n"]):
                    self.knit()
            elif op == "until":
                target = self.length_row(ins["cm"], ins["end"])
                while self.row_no() <= target:
                    self.knit()
            elif op == "bind_off":
                sides = []
                for j in range(ins["rows"]):
                    if self.mirror:
                        twin = self.edges[bo_no][j]
                        self.knit_to_side("WS" if twin == "RS" else "RS")
                    elif ins["side"]:
                        self.knit_to_side(ins["side"])
                    sides.append(self.side(self.row_no()))
                    self.knit(beg=("bo", ins["n"]))
                self.bo_sides.append(sides)
                bo_no += 1
            elif op == "schedule":
                self.schedule(ins)
            elif op == "bind_off_all":
                n = self.row_no()
                self.out.append((n, self.side(n), ["bo"] * len(self.cols), 0))
                self.cols = []

    def schedule(self, ins):
        plan = {}

        def place(row, shaping):
            beg, end = shaping["beg"], shaping["end"]
            if self.mirror:
                beg, end = end, beg
            e = plan.setdefault(row, [None, None])
            if beg:
                e[0] = beg
            if end:
                e[1] = end

        n = self.row_no()
        first = n if n % 2 else n + 1
        for i in range(ins["times"] + 1):
            place(first + i * ins["every"], ins["row"])
        st = ins["same_time"]
        if st:
            t = self.length_row(st["cm"], st["end"]) + 1
            f2 = t if t % 2 else t + 1
            for i in range(st["times"] + 1):
                place(f2 + i * st["every"], st["row"])
        last = max(plan)
        while self.row_no() <= last:
            e = plan.get(self.row_no())
            if e:
                self.knit(beg=e[0], end=e[1])
            else:
                self.knit()


def expand(text):
    gauge, patterns, pieces = parse_garment(text)
    runs, result = {}, []
    for name, piece in pieces:
        if "mirror_of" in piece:
            twin = runs[piece["mirror_of"]]
            nd = Needle(patterns, gauge, mirror=True, edges=twin.bo_sides)
            nd.run(twin.instructions)
        else:
            nd = Needle(patterns, gauge)
            nd.instructions = piece["instructions"]
            nd.run(piece["instructions"])
        runs[name] = nd
        result.append((name, nd.out))
    return result


def main(in_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    for fn in sorted(os.listdir(in_dir)):
        if not fn.endswith(".txt"):
            continue
        text = open(os.path.join(in_dir, fn), encoding="utf-8").read()
        rows = expand(text)
        with open(os.path.join(out_dir, fn[:-4] + ".rows.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["piece", "row", "side", "stitches", "count"])
            for name, out in rows:
                for n, side, toks, count in out:
                    w.writerow([name, n, side, " ".join(toks), count])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
