#!/bin/bash
# Installs the chart desk under /app/chartdesk and checks it against the four sample row lists.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/chartdesk
cp "$HERE/chartdesk/rows.py" /app/chartdesk/rows.py
if [ -d /app/samples ]; then
    OUT=$(mktemp -d)
    python3 /app/chartdesk/rows.py /app/samples "$OUT"
    for f in /app/samples/*.rows.csv; do
        name=$(basename "$f")
        if cmp -s "$f" "$OUT/$name"; then echo "sample $name: matches"; else echo "sample $name: DIFFERS"; fi
    done
    rm -rf "$OUT"
fi
