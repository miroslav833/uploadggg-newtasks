#!/usr/bin/env python3
"""Reference: the painted extent of every icon placement, from the shipped sprite, stylesheet and
placement list only.  Writes /app/out/icons.csv.

    python3 outline_icons.py [/app]

The painted extent of a placement is the box of everything the symbol's fills and strokes cover
once the symbol is laid out in its container by viewBox and preserveAspectRatio:
  * a fill covers its geometry;
  * a stroke covers the path offset by half its width to each side, with the declared join at
    each corner (a miter reaches (w/2)/sin(theta/2) past the vertex along the bisector unless
    1/sin(theta/2) exceeds stroke-miterlimit, when the join is a bevel), and the declared cap at
    each open end (butt: nothing; square: half the width along the path; round: a half-disc);
  * a stroke with vector-effect="non-scaling-stroke" has its width in container pixels, so it is
    stroked after the viewBox scaling; any other stroke scales with the geometry.

The module also exposes `solve(root, **options)` with switches that leave parts of this out, for the
readings recorded in the metadata (none of them is the honest path).
"""
import csv
import math
import os
import re
import sys
import xml.etree.ElementTree as ET

SVG = "{http://www.w3.org/2000/svg}"
# one-at-a-time ablation switches for the measured readings (gen/readings.py); all off for the answer
ABL = {}
XLINK = "{http://www.w3.org/1999/xlink}"
NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
TOKEN = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?|[A-Za-z]")


# ------------------------------------------------------------------------------------------------
# transforms
# ------------------------------------------------------------------------------------------------
def mat_mul(p, q):
    a1, b1, c1, d1, e1, f1 = p
    a2, b2, c2, d2, e2, f2 = q
    return (a1 * a2 + c1 * b2, b1 * a2 + d1 * b2, a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
            a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1)


def mat_apply(m, x, y):
    return (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])


def parse_transform(text):
    m = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    if not text:
        return m
    for name, body in re.findall(r"(\w+)\s*\(([^)]*)\)", text):
        v = [float(t) for t in NUM.findall(body)]
        if name == "translate":
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0.0)
        elif name == "scale":
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "rotate":
            a = math.radians(v[0])
            ca, sa = math.cos(a), math.sin(a)
            t = (ca, sa, -sa, ca, 0, 0)
            if len(v) == 3:
                t = mat_mul(mat_mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == "matrix":
            t = tuple(v[:6])
        elif name == "skewX":
            t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == "skewY":
            t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else:
            continue
        m = mat_mul(m, t)
    return m


# ------------------------------------------------------------------------------------------------
# path data -> absolute commands -> flattened subpaths
# ------------------------------------------------------------------------------------------------
def parse_path(d):
    """Absolute commands: ('M', x, y) ('L', x, y) ('C', ...6) ('Q', ...4) ('A', rx, ry, phi, large, sweep, x, y) ('Z',)."""
    toks = TOKEN.findall(d)
    i = 0
    cmd = None
    cx = cy = 0.0
    sx = sy = 0.0
    last_c = last_q = None
    out = []

    def nums(k):
        nonlocal i
        v = [float(toks[i + j]) for j in range(k)]
        i += k
        return v

    while i < len(toks):
        t = toks[i]
        if t.isalpha():
            cmd = t
            i += 1
            if cmd in "Zz":
                out.append(("Z",))
                cx, cy = sx, sy
                last_c = last_q = None
                continue
        elif cmd is None:
            raise ValueError("path data starts with a number")
        rel = cmd.islower()
        c = cmd.upper()
        if c == "M":
            x, y = nums(2)
            if rel:
                x, y = cx + x, cy + y
            out.append(("M", x, y))
            cx, cy = sx, sy = x, y
            cmd = "l" if rel else "L"       # implicit lineto after moveto
            last_c = last_q = None
        elif c == "L":
            x, y = nums(2)
            if rel:
                x, y = cx + x, cy + y
            out.append(("L", x, y))
            cx, cy = x, y
            last_c = last_q = None
        elif c == "H":
            (x,) = nums(1)
            if rel:
                x = cx + x
            out.append(("L", x, cy))
            cx = x
            last_c = last_q = None
        elif c == "V":
            (y,) = nums(1)
            if rel:
                y = cy + y
            out.append(("L", cx, y))
            cy = y
            last_c = last_q = None
        elif c == "C":
            v = nums(6)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(6)]
            out.append(("C",) + tuple(v))
            last_c, last_q = (v[2], v[3]), None
            cx, cy = v[4], v[5]
        elif c == "S":
            v = nums(4)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(4)]
            x1, y1 = (2 * cx - last_c[0], 2 * cy - last_c[1]) if (last_c and not ABL.get("no_reflect")) else (cx, cy)
            out.append(("C", x1, y1, v[0], v[1], v[2], v[3]))
            last_c, last_q = (v[0], v[1]), None
            cx, cy = v[2], v[3]
        elif c == "Q":
            v = nums(4)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(4)]
            out.append(("Q",) + tuple(v))
            last_q, last_c = (v[0], v[1]), None
            cx, cy = v[2], v[3]
        elif c == "T":
            v = nums(2)
            if rel:
                v = [v[0] + cx, v[1] + cy]
            x1, y1 = (2 * cx - last_q[0], 2 * cy - last_q[1]) if (last_q and not ABL.get("no_reflect")) else (cx, cy)
            out.append(("Q", x1, y1, v[0], v[1]))
            last_q, last_c = (x1, y1), None
            cx, cy = v[0], v[1]
        elif c == "A":
            v = nums(7)
            x, y = v[5], v[6]
            if rel:
                x, y = cx + x, cy + y
            out.append(("A", abs(v[0]), abs(v[1]), v[2], int(v[3] != 0), int(v[4] != 0), x, y))
            cx, cy = x, y
            last_c = last_q = None
        else:
            raise ValueError("unknown path command %r" % cmd)
    return out


def arc_center(x1, y1, rx, ry, phi_deg, large, sweep, x2, y2):
    """SVG implementation notes F.6.5.  Returns (cx, cy, rx, ry, phi, theta1, dtheta) in radians."""
    phi = math.radians(0.0 if ABL.get("arc_phi0") else phi_deg)
    cp, sp = math.cos(phi), math.sin(phi)
    dx, dy = (x1 - x2) / 2.0, (y1 - y2) / 2.0
    x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if lam > 1 and not ABL.get("arc_noscale"):
        rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    k = math.sqrt(max(0.0, num / den)) if den > 0 else 0.0
    if large == sweep:
        k = -k
    cxp, cyp = k * rx * y1p / ry, -k * ry * x1p / rx
    cx = cp * cxp - sp * cyp + (x1 + x2) / 2.0
    cy = sp * cxp + cp * cyp + (y1 + y2) / 2.0

    def ang(ux, uy, vx, vy):
        d = max(-1.0, min(1.0, (ux * vx + uy * vy) / (math.hypot(ux, uy) * math.hypot(vx, vy))))
        a = math.acos(d)
        return -a if ux * vy - uy * vx < 0 else a

    t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and dt > 0:
        dt -= 2 * math.pi
    elif sweep and dt < 0:
        dt += 2 * math.pi
    return cx, cy, rx, ry, phi, t1, dt


def flatten(cmds, steps):
    """[(points, corner_flags, closed)] -- curve samples are not corners; command end points are."""
    subs = []
    pts, flags = [], []
    cur = (0.0, 0.0)
    start = (0.0, 0.0)

    def close_sub(closed):
        nonlocal pts, flags
        clean, cf = [], []
        for p, f in zip(pts, flags):
            if clean and math.hypot(p[0] - clean[-1][0], p[1] - clean[-1][1]) < 1e-9:
                cf[-1] = cf[-1] or f
                continue
            clean.append(p)
            cf.append(f)
        if closed and len(clean) > 1 and math.hypot(clean[0][0] - clean[-1][0], clean[0][1] - clean[-1][1]) < 1e-9:
            clean.pop()
            cf.pop()
        if len(clean) >= 2:
            subs.append((clean, cf, closed))
        elif len(clean) == 1 and not closed:
            subs.append((clean, cf, closed))
        pts, flags = [], []

    for c in cmds:
        k = c[0]
        if k == "M":
            if pts:
                close_sub(False)
            cur = start = (c[1], c[2])
            pts, flags = [cur], [True]
        elif k == "L":
            cur = (c[1], c[2])
            pts.append(cur)
            flags.append(True)
        elif k == "C":
            x0, y0 = cur
            x1, y1, x2, y2, x3, y3 = c[1:]
            for s in range(1, steps + 1):
                t = s / steps
                u = 1 - t
                pts.append((u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3,
                            u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3))
                flags.append(s == steps)
            cur = (x3, y3)
        elif k == "Q":
            x0, y0 = cur
            x1, y1, x2, y2 = c[1:]
            for s in range(1, steps + 1):
                t = s / steps
                u = 1 - t
                pts.append((u * u * x0 + 2 * u * t * x1 + t * t * x2, u * u * y0 + 2 * u * t * y1 + t * t * y2))
                flags.append(s == steps)
            cur = (x2, y2)
        elif k == "A":
            rx, ry, phi_deg, large, sweep, x2, y2 = c[1:]
            x1, y1 = cur
            if (rx == 0 or ry == 0) or (abs(x1 - x2) < 1e-12 and abs(y1 - y2) < 1e-12):
                pts.append((x2, y2))
                flags.append(True)
            else:
                cx, cy, rx, ry, phi, t1, dt = arc_center(x1, y1, rx, ry, phi_deg, large, sweep, x2, y2)
                cp, sp = math.cos(phi), math.sin(phi)
                for s in range(1, steps + 1):
                    a = t1 + dt * s / steps
                    ex, ey = rx * math.cos(a), ry * math.sin(a)
                    pts.append((cx + cp * ex - sp * ey, cy + sp * ex + cp * ey) if s < steps else (x2, y2))
                    flags.append(s == steps)
            cur = (x2, y2)
        elif k == "Z":
            close_sub(True)
            cur = start
    if pts:
        close_sub(False)
    return subs


# ------------------------------------------------------------------------------------------------
# the stroked outline's extreme points
# ------------------------------------------------------------------------------------------------
def perp(d):
    return (-d[1], d[0])


def norm(x, y):
    n = math.hypot(x, y)
    return (x / n, y / n) if n > 1e-12 else (0.0, 0.0)


def disc(p, h, poly):
    if poly:
        return [(p[0] + h * math.cos(2 * math.pi * k / poly), p[1] + h * math.sin(2 * math.pi * k / poly))
                for k in range(poly)]
    return [(p[0] - h, p[1] - h), (p[0] + h, p[1] + h)]


def stroke_extremes(pts, flags, closed, h, join, cap, limit, *, always_miter=False, caps_ignored=False,
                    poly=0, limit_inclusive=False, discs=None):
    """Extreme points of the stroke band; round joins and caps go to `discs` (centres) when given."""
    n = len(pts)
    out = []
    put = disc
    if discs is not None:
        def put(p, hh, _poly):           # collect the centre; the caller maps the disc
            discs.append(p)
            return []
    if n == 1:
        # a lone point paints only with round or square caps
        if cap == "round" or caps_ignored:
            out += put(pts[0], h, poly)
        elif cap == "square":
            out += [(pts[0][0] - h, pts[0][1] - h), (pts[0][0] + h, pts[0][1] + h)]
        return out
    seg = [(i, i + 1) for i in range(n - 1)] + ([(n - 1, 0)] if closed else [])
    d = {}
    for a, b in seg:
        d[(a, b)] = norm(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1])
        nx, ny = perp(d[(a, b)])
        for p in (pts[a], pts[b]):
            out.append((p[0] + h * nx, p[1] + h * ny))
            out.append((p[0] - h * nx, p[1] - h * ny))
    for i in range(n):
        if not flags[i]:
            continue
        if closed:
            din, dout = d[((i - 1) % n, i)], d[(i, (i + 1) % n)]
        elif 0 < i < n - 1:
            din, dout = d[(i - 1, i)], d[(i, i + 1)]
        else:
            continue
        v = pts[i]
        if join == "round":
            out += put(v, h, poly)
        elif join == "miter" or join == "miter-clip":
            cosang = max(-1.0, min(1.0, din[0] * dout[0] + din[1] * dout[1]))
            half = math.sqrt(max(0.0, (1.0 + cosang) / 2.0))       # sin(theta / 2)
            if half < 1e-9:
                continue
            ratio = 1.0 / half
            keep = ratio < limit if limit_inclusive else ratio <= limit
            if keep or always_miter:
                bx, by = norm(din[0] - dout[0], din[1] - dout[1])
                out.append((v[0] + h * ratio * bx, v[1] + h * ratio * by))
    if not closed:
        for p, dv in ((pts[0], (-d[(0, 1)][0], -d[(0, 1)][1])), (pts[-1], d[(n - 2, n - 1)])):
            if caps_ignored or cap == "round":
                out += put(p, h, poly)
            elif cap == "square":
                nx, ny = perp(dv)
                out.append((p[0] + h * dv[0] + h * nx, p[1] + h * dv[1] + h * ny))
                out.append((p[0] + h * dv[0] - h * nx, p[1] + h * dv[1] - h * ny))
    return out


# ------------------------------------------------------------------------------------------------
# the sprite
# ------------------------------------------------------------------------------------------------
def style_of(el, inherited):
    st = dict(inherited)
    st.pop("display", None)          # display is not inherited; a 'none' stops the walk instead
    for k in ("fill", "stroke", "stroke-width", "stroke-linejoin", "stroke-linecap", "stroke-miterlimit",
              "vector-effect", "stroke-dasharray", "stroke-dashoffset", "visibility", "display"):
        if el.get(k) is not None:
            st[k] = el.get(k)
    for part in (el.get("style") or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            st[k.strip()] = v.strip()
    return st


def element_cmds(el):
    tag = el.tag.replace(SVG, "")
    g = lambda k, dflt=0.0: float(el.get(k, dflt))
    if tag == "path":
        return parse_path(el.get("d", ""))
    if tag == "rect":
        x, y, w, h = g("x"), g("y"), g("width"), g("height")
        rx = None if ABL.get("rect_square") else el.get("rx")
        ry = None if ABL.get("rect_square") else el.get("ry")
        rx = float(rx) if rx is not None else (float(ry) if ry is not None else 0.0)
        ry = float(ry) if ry is not None else rx
        if rx <= 0 or ry <= 0:
            return [("M", x, y), ("L", x + w, y), ("L", x + w, y + h), ("L", x, y + h), ("Z",)]
        rx, ry = min(rx, w / 2), min(ry, h / 2)
        return [("M", x + rx, y), ("L", x + w - rx, y), ("A", rx, ry, 0, 0, 1, x + w, y + ry),
                ("L", x + w, y + h - ry), ("A", rx, ry, 0, 0, 1, x + w - rx, y + h), ("L", x + rx, y + h),
                ("A", rx, ry, 0, 0, 1, x, y + h - ry), ("L", x, y + ry), ("A", rx, ry, 0, 0, 1, x + rx, y), ("Z",)]
    if tag == "circle":
        cx, cy, r = g("cx"), g("cy"), g("r")
        return [("M", cx + r, cy), ("A", r, r, 0, 0, 1, cx, cy + r), ("A", r, r, 0, 0, 1, cx - r, cy),
                ("A", r, r, 0, 0, 1, cx, cy - r), ("A", r, r, 0, 0, 1, cx + r, cy), ("Z",)]
    if ABL.get("no_shapes") and tag in ("ellipse", "line", "polyline", "polygon"):
        return None
    if tag == "ellipse":
        cx, cy, rx, ry = g("cx"), g("cy"), g("rx"), g("ry")
        return [("M", cx + rx, cy), ("A", rx, ry, 0, 0, 1, cx, cy + ry), ("A", rx, ry, 0, 0, 1, cx - rx, cy),
                ("A", rx, ry, 0, 0, 1, cx, cy - ry), ("A", rx, ry, 0, 0, 1, cx + rx, cy), ("Z",)]
    if tag == "line":
        return [("M", g("x1"), g("y1")), ("L", g("x2"), g("y2"))]
    if tag in ("polyline", "polygon"):
        v = [float(t) for t in NUM.findall(el.get("points", ""))]
        cmds = [("M", v[0], v[1])] + [("L", v[k], v[k + 1]) for k in range(2, len(v) - 1, 2)]
        if tag == "polygon":
            cmds.append(("Z",))
        return cmds
    return None


XLINK_HREF = "{http://www.w3.org/1999/xlink}href"
WALK = {"idmap": {}, "paint_defs": False, "paint_hidden": False, "follow_use": True, "depth": 0}


def walk(el, m, st, steps, out):
    """Collect (matrix, style, cmds) for every element under el that the browser paints."""
    tag = el.tag.replace(SVG, "")
    if tag in ("defs", "clipPath", "mask", "symbol", "linearGradient", "radialGradient", "pattern", "marker") \
            and not WALK["paint_defs"]:
        return                                    # never rendered where it stands
    m2 = mat_mul(m, parse_transform(el.get("transform")))
    st2 = style_of(el, st)
    if st2.get("display", "").strip() == "none" and not WALK["paint_hidden"]:
        return
    if tag in ("g", "defs"):
        for ch in el:
            walk(ch, m2, st2, steps, out)
        return
    if tag == "use":
        if not WALK["follow_use"] or WALK["depth"] > 8:
            return
        ref = (el.get("href") or el.get(XLINK_HREF) or "").lstrip("#")
        target = WALK["idmap"].get(ref)
        if target is None:
            return
        m3 = mat_mul(m2, (1.0, 0.0, 0.0, 1.0, float(el.get("x", 0)), float(el.get("y", 0))))
        WALK["depth"] += 1
        walk(target, m3, st2, steps, out)
        WALK["depth"] -= 1
        return
    cmds = element_cmds(el)
    if cmds is not None:
        if st2.get("visibility", "visible").strip() in ("hidden", "collapse") and not WALK["paint_hidden"]:
            return
        if el.get("pathLength") is not None:
            st2 = dict(st2, _pathLength=el.get("pathLength"))
        out.append((m2, st2, cmds))


def read_sprite(path, steps, last_id_wins=False):
    root = ET.parse(path).getroot()
    symbols = {}
    idmap = {}
    for node in root.iter():
        if node.get("id"):
            if last_id_wins or ABL.get("last_id"):
                idmap[node.get("id")] = node
            else:
                idmap.setdefault(node.get("id"), node)      # a document resolves an id to its first element
    WALK["idmap"] = idmap
    for sym in (n for n in root.iter(SVG + "symbol") if idmap.get(n.get("id")) is n):
        vb = [float(t) for t in NUM.findall(sym.get("viewBox", "0 0 100 100"))]
        par = (sym.get("preserveAspectRatio") or "xMidYMid meet").split()
        align = par[0]
        mos = par[1] if len(par) > 1 else "meet"
        drawn = []
        for ch in sym:
            walk(ch, (1.0, 0.0, 0.0, 1.0, 0.0, 0.0), {}, steps, drawn)
        elements = []
        for m, st, cmds in drawn:
            subs = flatten(cmds, steps)          # in the element's own user space; m maps it to the symbol
            fill = st.get("fill", "black").strip().lower() != "none"
            stroke = st.get("stroke", "none").strip().lower() != "none"
            sw = st.get("stroke-width")
            dash = st.get("stroke-dasharray")
            dash_set = dash is not None                  # 'none' on the element also stops inheritance
            dash = [float(v) for v in NUM.findall(dash)] if dash and dash.strip() != "none" else None
            elements.append({
                "fill": fill, "stroke": stroke,
                # None: not set on the element or its groups, so inherited from the host <svg>
                "width": sw.strip() if sw else None,
                "join": st["stroke-linejoin"].strip() if "stroke-linejoin" in st else None,
                "cap": st["stroke-linecap"].strip() if "stroke-linecap" in st else None,
                "limit": float(st["stroke-miterlimit"]) if "stroke-miterlimit" in st else None,
                "nss": st.get("vector-effect", "none").strip() == "non-scaling-stroke",
                "dash": dash if dash and sum(dash) > 0 else None,
                "dash_set": dash_set,
                "offset_set": "stroke-dashoffset" in st,
                "dashoffset": float(NUM.search(st.get("stroke-dashoffset", "0")).group(0)),
                "pathLength": float(st["_pathLength"]) if "_pathLength" in st else None,
                "subpaths": subs,
                "matrix": m,
            })
        symbols[sym.get("id")] = {"viewBox": vb, "align": align, "mos": mos, "elements": elements}
    return symbols


INHERITED = ("stroke-width", "stroke-linejoin", "stroke-linecap", "stroke-miterlimit", "stroke-dasharray",
             "stroke-dashoffset")
INITIAL = {"stroke-width": "1", "stroke-linejoin": "miter", "stroke-linecap": "butt", "stroke-miterlimit": "4"}


def read_css(path):
    """Per class: its declarations.  Size classes are the ones that set a width and a height."""
    text = re.sub(r"/\*.*?\*/", "", open(path, encoding="utf-8").read(), flags=re.S)
    rules = {}
    for cls, body in re.findall(r"\.([\w-]+)\s*\{([^}]*)\}", text):
        decl = rules.setdefault(cls, {})
        for part in body.split(";"):
            if ":" in part:
                k, v = part.split(":", 1)
                decl[k.strip()] = v.strip()
    return rules


def read_rules(path):
    """Ordered (selector compounds, declarations) from the stylesheet."""
    text = re.sub(r"/\*.*?\*/", "", open(path, encoding="utf-8").read(), flags=re.S)
    out = []
    for sel, body in re.findall(r"([^{}]+)\{([^}]*)\}", text):
        for one in sel.split(","):
            comps = [re.findall(r"\.([\w-]+)", c) for c in one.split()]
            decl = {}
            for part in body.split(";"):
                if ":" in part:
                    k, v = part.split(":", 1)
                    decl[k.strip()] = v.strip()
            out.append((comps, decl))
    return out


def _matches(comps, chain):
    """chain: class sets from the element outward (element first).  Descendant combinators only."""
    if not comps or not set(comps[-1]) <= chain[0]:
        return False
    i = 1
    for comp in reversed(comps[:-1]):
        while i < len(chain) and not set(comp) <= chain[i]:
            i += 1
        if i == len(chain):
            return False
        i += 1
    return True


IMPORTANT = re.compile(r"\s*!\s*important\s*$", re.I)
VAR = re.compile(r"var\(\s*(--[\w-]+)\s*(?:,\s*([^()]*(?:\([^()]*\)[^()]*)*))?\)")


def cascaded(rules, chain, specificity=True):
    """Winning declaration per property for the element at chain[0]: important beats normal, then
    specificity, then source order.  Values are returned without their !important."""
    best = {}
    for order, (comps, decl) in enumerate(rules):
        if not _matches(comps, chain):
            continue
        spec = sum(len(c) for c in comps) if specificity else 0
        for k, v in decl.items():
            imp = 1 if (IMPORTANT.search(v) and not ABL.get("no_important")) else 0
            key = (imp, spec, order)
            if k not in best or key >= best[k][0]:
                best[k] = (key, IMPORTANT.sub("", v).strip())
    return {k: v for k, (_, v) in best.items()}


def length_px(value, font_px):
    m = re.match(r"\s*([-+]?\d*\.?\d+)\s*(px|em|pt)?\s*$", value)
    if not m:
        return None
    v = float(m.group(1))
    unit = m.group(2) or "px"
    return v * {"px": 1.0, "em": font_px, "pt": 4.0 / 3.0}[unit]


def _substitute(value, custom):
    """Resolve var() references against the element's custom properties; None if one cannot be."""
    for _ in range(8):
        m = VAR.search(value)
        if not m:
            return value
        name, fallback = m.group(1), m.group(2)
        if name in custom and not (ABL.get("var_fallback") and fallback is not None):
            rep = custom[name]
        elif fallback is not None:
            rep = fallback.strip()
        else:
            return None
        value = value[:m.start()] + rep + value[m.end():]
    return value


STROKE_PROPS = ("stroke-width", "stroke-linejoin", "stroke-linecap", "stroke-miterlimit", "stroke-dasharray",
                "stroke-dashoffset")


def computed(rules, chain, parent, specificity=True, em_parent=False):
    """Computed font-size, custom properties and stroke properties of the element at chain[0], given its
    parent's computed values.  Stroke properties and custom properties inherit; 'inherit' takes the
    parent's computed value; an unresolvable var() makes the declaration act as 'unset' (inherit)."""
    decl = cascaded(rules, chain, specificity)
    out = {"custom": dict(parent.get("custom", {}))}
    for k, v in decl.items():
        if k.startswith("--"):
            out["custom"][k] = v.strip()
    pfont = parent.get("font-size", 16.0)
    font = pfont
    if "font-size" in decl:
        v = _substitute(decl["font-size"], out["custom"])
        if v is not None and v.strip() != "inherit":
            font = length_px(v, pfont) or pfont
    out["font-size"] = font
    for prop in STROKE_PROPS:
        if prop not in decl:
            if prop in parent:
                out[prop] = parent[prop]
            continue
        v = _substitute(decl[prop], out["custom"])
        if v is None or v.strip() in ("inherit", "unset"):
            if prop in parent:
                out[prop] = parent[prop]
            continue
        if v.strip() == "initial":
            continue
        if prop == "stroke-width":
            px = length_px(v, pfont if em_parent else font)
            if px is not None:
                out[prop] = repr(px)
        else:
            out[prop] = v.strip()
    return out


def host_style(rules, svg_classes, context, specificity=True, em_from_context=False):
    """Computed stroke properties on <div class=context><svg class=...> -- what the symbol inherits."""
    root = {"font-size": 16.0, "custom": {}}
    div = computed(rules, [{context}], root, specificity)
    svg = computed(rules, [set(svg_classes), {context}], div, specificity, em_parent=em_from_context)
    return {k: svg[k] for k in STROKE_PROPS if k in svg}


def element_width(text, view_box, pt_as_px=False, pct_of_width=False):
    """A stroke-width presentation attribute in the symbol's user units."""
    m = re.match(r"\s*([-+]?\d*\.?\d+)\s*(px|pt|%)?\s*$", str(text))
    v, unit = float(m.group(1)), m.group(2) or "px"
    if unit == "pt":
        return v if pt_as_px else v * 4.0 / 3.0
    if unit == "%":
        vw, vh = view_box[2], view_box[3]
        base = vw if pct_of_width else math.sqrt((vw * vw + vh * vh) / 2.0)
        return v / 100.0 * base
    return v


def read_sizes(path):
    sizes = {}
    for cls, decl in read_css(path).items():
        w = re.search(r"([\d.]+)px", decl.get("width", ""))
        h = re.search(r"([\d.]+)px", decl.get("height", ""))
        if w and h:
            sizes[cls] = (float(w.group(1)), float(h.group(1)))
    return sizes


def dash_cut(pts, flags, closed, arr, off):
    """The dashes of one flattened subpath, as open (pts, flags) runs."""
    if len(arr) % 2 and not ABL.get("odd_no_repeat"):
        arr = arr * 2
    if ABL.get("neg_offset_zero"):
        off = max(off, 0.0)
    period = sum(arr)
    ring = pts + ([pts[0]] if closed else [])
    rflags = flags + ([False] if closed else [])
    pos = off % period
    k = 0
    while pos >= arr[k]:
        pos -= arr[k]
        k = (k + 1) % len(arr)
    remain = arr[k] - pos
    drawing = k % 2 == 0
    starts_on = drawing
    runs, run, rf = [], ([ring[0]] if drawing else []), ([False] if drawing else [])
    for idx in range(len(ring) - 1):
        a, b = ring[idx], ring[idx + 1]
        seg = math.hypot(b[0] - a[0], b[1] - a[1])
        done = 0.0
        while seg - done > remain:
            done += remain
            f = done / seg
            cut = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
            if drawing:
                run.append(cut); rf.append(False)
                runs.append((run, rf))
            run, rf = ([cut], [False]) if not drawing else ([], [])
            k = (k + 1) % len(arr)
            drawing = (k % 2 == 0) if ABL.get("odd_no_repeat") else (not drawing)
            remain = arr[k]
        remain -= seg - done
        if drawing:
            last = idx + 1 == len(ring) - 1
            run.append(b); rf.append(False if last else rflags[idx + 1])
    if drawing and len(run) >= 2:
        runs.append((run, rf))
    runs = [(r, f) for r, f in runs if len(r) >= 2]
    # a closed contour whose pattern is on at both its start and its end: the last dash continues into the
    # first through the start vertex, which is then a join, not two caps
    if closed and runs and len(runs) > 1 and starts_on and drawing:
        last_r, last_f = runs[-1]
        first_r, first_f = runs[0]
        if math.hypot(last_r[-1][0] - first_r[0][0], last_r[-1][1] - first_r[0][1]) < 1e-9:
            merged = (last_r + first_r[1:], last_f[:-1] + [flags[0]] + first_f[1:])
            runs = [merged] + runs[1:-1]
    return runs


def viewport_map(vb, align, mos, W, H):
    vx, vy, vw, vh = vb
    if align == "none":
        sx, sy = W / vw, H / vh
        return sx, sy, -vx * sx, -vy * sy
    s = min(W / vw, H / vh) if mos == "meet" else max(W / vw, H / vh)
    cw, ch = vw * s, vh * s
    ox = {"xMin": 0.0, "xMid": (W - cw) / 2.0, "xMax": W - cw}[align[:4]]
    oy = {"YMin": 0.0, "YMid": (H - ch) / 2.0, "YMax": H - ch}[align[4:]]
    return s, s, ox - vx * s, oy - vy * s


# ------------------------------------------------------------------------------------------------
# the answer
# ------------------------------------------------------------------------------------------------
def extent(sym, W, H, *, host_props=None, nss=True, dashes=True, path_length=True, host_space=False):
    """Painted box of a symbol placed in a W x H box.  A stroke is built in the element's own user space
    and then mapped by the element's full matrix (so a non-uniform or skewing transform gives an
    elliptical pen); a non-scaling stroke is built after the mapping, in container pixels."""
    sx, sy, tx, ty = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)
    view = (sx, 0.0, 0.0, sy, tx, ty)
    hstyle = host_props or {}

    def pick(own, prop):
        return own if own is not None else hstyle.get(prop, INITIAL[prop])

    xs, ys = [], []

    def add_pt(p):
        xs.append(p[0]); ys.append(p[1])

    for el in sym["elements"]:
        M = mat_mul(view, el["matrix"])
        if el["width"] is not None:
            width = element_width(el["width"], sym["viewBox"])
        else:
            width = float(NUM.search(str(pick(None, "stroke-width"))).group(0))
        join = pick(el["join"], "stroke-linejoin")
        cap = pick(el["cap"], "stroke-linecap")
        limit = float(pick(el["limit"], "stroke-miterlimit"))
        subpaths = el["subpaths"]
        if el["fill"]:
            for pts, _, _ in subpaths:
                for x, y in pts:
                    add_pt(mat_apply(M, x, y))
        if not el["stroke"]:
            continue
        dash, off0 = el["dash"], el["dashoffset"]
        if not el.get("dash_set") and hstyle.get("stroke-dasharray", "none").strip() != "none":
            dash = [float(v) for v in NUM.findall(hstyle["stroke-dasharray"])] or None
        if not el.get("offset_set") and "stroke-dashoffset" in hstyle:
            off0 = float(NUM.search(hstyle["stroke-dashoffset"]).group(0))
        if dash and sum(dash) <= 0:
            dash = None
        if dash and dashes:
            arr, off = dash, off0
            if el.get("pathLength") and path_length:
                total = 0.0
                for pts, _, closed in subpaths:
                    ring = pts + ([pts[0]] if closed else [])
                    total += sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(ring, ring[1:]))
                k = total / el["pathLength"]
                arr, off = [v * k for v in arr], off * k
            subpaths = [(r, f, False) for pts, flags, closed in subpaths for r, f in dash_cut(pts, flags, closed, arr, off)]
        if (el["nss"] and nss) or host_space or ABL.get("host_space"):
            # stroke in container pixels: map first, then band
            h = (width if (el["nss"] and nss) else width * math.sqrt(abs(M[0] * M[3] - M[1] * M[2]))) / 2.0
            for pts, flags, closed in subpaths:
                host = [mat_apply(M, x, y) for x, y in pts]
                for p in stroke_extremes(host, flags, closed, h, join, cap, limit):
                    add_pt(p)
            continue
        h = width / 2.0
        ex = h * math.hypot(M[0], M[2])
        ey = h * math.hypot(M[1], M[3])
        for pts, flags, closed in subpaths:
            discs = []
            for x, y in stroke_extremes(pts, flags, closed, h, join, cap, limit, discs=discs):
                add_pt(mat_apply(M, x, y))
            for x, y in discs:
                cx, cy = mat_apply(M, x, y)
                add_pt((cx - ex, cy - ey)); add_pt((cx + ex, cy + ey))
    if not xs:
        return [0.0, 0.0, 0.0, 0.0]
    return [min(xs), min(ys), max(xs), max(ys)]


def read_png(path):
    """Grey value (red channel) of every pixel of an 8-bit RGB or RGBA PNG."""
    import struct, zlib
    data = open(path, "rb").read()
    i, idat = 8, b""
    while i < len(data):
        n, = struct.unpack(">I", data[i:i + 4]); kind = data[i + 4:i + 8]; chunk = data[i + 8:i + 8 + n]
        if kind == b"IHDR":
            w, h, depth, ctype = struct.unpack(">IIBB", chunk[:10])
        elif kind == b"IDAT":
            idat += chunk
        i += 12 + n
    bpp = {2: 3, 6: 4, 0: 1, 4: 2}[ctype]
    raw = zlib.decompress(idat)
    stride = w * bpp
    prev = bytearray(stride)
    rows, p = [], 0
    for _ in range(h):
        f = raw[p]; line = bytearray(raw[p + 1:p + 1 + stride]); p += 1 + stride
        for x in range(stride):
            a = line[x - bpp] if x >= bpp else 0
            b = prev[x]
            c = prev[x - bpp] if x >= bpp else 0
            if f == 1:
                line[x] = (line[x] + a) & 255
            elif f == 2:
                line[x] = (line[x] + b) & 255
            elif f == 3:
                line[x] = (line[x] + (a + b) // 2) & 255
            elif f == 4:
                pp = a + b - c; pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        rows.append([line[x * bpp] for x in range(w)])
        prev = line
    return rows


THEME_MODE = "exact"
LINEAR = True


def coverage(v):
    """Ink coverage of a grey thumbnail pixel (2 x 2 average of the screenshot, written through gamma 1.8)."""
    if not LINEAR:
        return (255 - v) / 255.0
    return 1.0 - (v / 255.0) ** 1.8           # undo the display transfer curve the thumbnail was written through


def ring_widths(root, rules, symbols, sizes, largest_only=False, shape_rules=()):
    """Recover the production theme's stroke widths from the QA captures of the test rings.
    A ring's ink is its stroke area, 2 pi r w, so each capture gives the stroke weight the page passed
    down; it is expressed in the unit of the context's shipped rule and appended after icons.css."""
    qa = os.path.join(root, "qa")
    img = read_png(os.path.join(qa, "captures.png"))
    found = {}
    shape_caps = []
    for r in csv.DictReader(open(os.path.join(qa, "captures.csv"), newline="")):
        sym = symbols[r["symbol"]]
        el = sym["elements"][0]
        if not el["subpaths"][0][2] or len(el["subpaths"][0][0]) < 40:
            shape_caps.append(r)          # an open test shape: its join and cap are read after the widths
            continue
        pts, flags, closed = el["subpaths"][0]
        cx = sum(x for x, _ in pts) / len(pts); cy = sum(y for _, y in pts) / len(pts)
        R = sum(math.hypot(x - cx, y - cy) for x, y in pts) / len(pts)
        W, H = sizes[r["size_class"]]
        sx, sy, tx, ty = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)
        # the painted dashes: total length on the ring and how many there are (each carries two cap ends)
        ring_len = 2 * math.pi * R
        if el.get("dash"):
            k = ring_len / el["pathLength"] if el.get("pathLength") else 1.0
            arr = [v * k for v in el["dash"]] * (2 if len(el["dash"]) % 2 else 1)
            period = sum(arr)
            runs = dash_cut(pts, flags, closed, arr, el["dashoffset"] * k)
            n_dash = len(runs)
            on_len = sum(sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(rr, rr[1:])) for rr, _ in runs)
        else:
            n_dash, on_len = 0, ring_len
        x0, y0 = int(r["left_px"]), int(r["top_px"])
        ink = 0.0
        for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
            row = img[yy]
            for xx in range(max(0, x0 - 12), min(len(row), x0 + int(W) + 12)):
                ink += coverage(row[xx])
        ctx = r["context"]
        svg = cascaded(rules, [{"icon", r["size_class"]}, {ctx}])
        cap = cascaded(list(rules) + list(shape_rules), [{"icon", r["size_class"]}, {ctx}]).get("stroke-linecap", "butt")
        # ink (px^2) = on_len * w + caps * w^2, lengths in px: square caps add w^2 per dash, round pi w^2 / 4
        Lpx = on_len * sx
        kc = {"square": 1.0, "round": math.pi / 4}.get(cap, 0.0) * n_dash
        if THEME_MODE == "ring":
            w_px = ink / (2 * math.pi * R * sx)
        elif THEME_MODE == "nocaps" or kc == 0:
            w_px = ink / Lpx
        else:
            w_px = (-Lpx + math.sqrt(Lpx * Lpx + 4 * kc * ink)) / (2 * kc)
        w_user = w_px / sx
        root = {"font-size": 16.0, "custom": {}}
        dctx = computed(rules + list(shape_rules), [{ctx}], root)
        scomp = computed(rules + list(shape_rules), [{"icon", r["size_class"]}, {ctx}], dctx)
        font = scomp["font-size"]
        w_now = float(scomp.get("stroke-width", "1"))
        found.setdefault(ctx, []).append((w_user, font, w_now))
    out = []
    for ctx, vals in found.items():
        if all(abs(w - now) <= 0.1 * now for w, _, now in vals):
            continue                      # the captures agree with the page's own stylesheet here
        px = sorted(w for w, _, _ in vals)
        em = sorted(w / f for w, f, _ in vals)
        spread = lambda v: (v[-1] - v[0]) / max(1e-9, v[len(v) // 2])
        if spread(em) < spread(px):
            val = "%.4fem" % em[len(em) // 2]
        else:
            val = "%.4fpx" % px[len(px) // 2]
        out.append(([[ctx], ["icon"]], {"stroke-width": val + " !important"}))
    return out, img, shape_caps


def _kind(sym):
    el = sym["elements"][0]
    pts, _, closed = el["subpaths"][0]
    if closed and len(pts) > 40:
        return "ring"
    if len(pts) > 2:
        return "zigzag"
    return "bar_solid" if el.get("dash_set") else "bar_dash"


def theme_rules(root, rules, symbols, sizes, largest_only=False):
    """Recover the page's theme from its QA captures, each property from the shape that isolates it:
    the cap from the solid bar's ink (its weight is its own), the weight from the dashed rings (their
    dashes are their own) given that cap, the join and miter limit tip by tip from the zigzag (tips of
    many angles), and inherited dashes from the bar that takes them from the page."""
    qa = os.path.join(root, "qa")
    if not os.path.isdir(qa):
        return []
    img = read_png(os.path.join(qa, "captures.png"))
    rows = list(csv.DictReader(open(os.path.join(qa, "captures.csv"), newline="")))
    by_kind = {}
    for r in rows:
        by_kind.setdefault(_kind(symbols[r["symbol"]]), []).append(r)
    out = []
    # 1. caps
    cap_of = {}
    errs = {}
    for r in by_kind.get("bar_solid", []):
        sym = symbols[r["symbol"]]
        W, H = sizes[r["size_class"]]
        _, _, _, ink = _cell(img, r, W, H)
        sx = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)[0]
        el = sym["elements"][0]
        w = element_width(el["width"], sym["viewBox"]) * sx
        pts = el["subpaths"][0][0]
        L = math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]) * sx
        for c, extra in (("butt", 0.0), ("square", w * w), ("round", math.pi * w * w / 4)):
            errs.setdefault(r["context"], {}).setdefault(c, 0.0)
            errs[r["context"]][c] += abs(ink - (L * w + extra))
    for ctx, e in errs.items():
        cap_of[ctx] = min(e, key=e.get)
        if cap_of[ctx] != host_style(rules, ["icon"], ctx).get("stroke-linecap", INITIAL["stroke-linecap"]):
            out.append(([[ctx], ["icon"]], {"stroke-linecap": cap_of[ctx] + " !important"}))
    # 2. weights from the rings, given the caps
    if THEME_SHAPES:
        widths = ring_widths(root, rules, symbols, sizes, largest_only, list(out))[0]
    else:
        return ring_widths(root, rules, symbols, sizes, largest_only)[0]
    out += widths
    # 3. join and miter limit, tip by tip
    zj = zigzag_joins(img, rules + out, symbols, sizes, by_kind.get("zigzag", []))
    if ABL.get("theme_basic"):         # a fit of weight, cap and join only
        zj = [(c, {k: v for k, v in d.items() if k != "stroke-miterlimit"}) for c, d in zj]
        zj = [(c, d) for c, d in zj if d]
    out += zj
    # 4. dashes the page passes down
    if not ABL.get("theme_basic"):
        out += bar_dashes(img, rules + out, symbols, sizes, by_kind.get("bar_dash", []))
    return out


def _cell(img, r, W, H):
    x0, y0 = int(r["left_px"]), int(r["top_px"])
    ys, ink = [], 0.0
    for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
        row = img[yy]
        for xx in range(max(0, x0 - 12), min(len(row), x0 + int(W) + 12)):
            c = coverage(row[xx])
            ink += c
            if c > 0.01:
                ys.append(yy)
    return x0, y0, ys, ink


def bar_errors(img, rules, symbols, sizes, rows):
    """Per context: |measured ink - predicted ink| of the straight test bar, ink = L w + cap area."""
    out = {}
    for r in rows:
        sym = symbols[r["symbol"]]
        pts = sym["elements"][0]["subpaths"][0][0]
        if len(pts) != 2:
            continue
        W, H = sizes[r["size_class"]]
        _, _, _, ink = _cell(img, r, W, H)
        host = host_style(rules, ["icon", r["size_class"]], r["context"])
        sx = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)[0]
        own = sym["elements"][0]["width"]
        w = (element_width(own, sym["viewBox"]) if own is not None else float(host.get("stroke-width", "1"))) * sx
        L = math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]) * sx
        extra = {"butt": 0.0, "square": w * w, "round": math.pi * w * w / 4}[host.get("stroke-linecap", INITIAL["stroke-linecap"])]
        out[r["context"]] = out.get(r["context"], 0.0) + abs(ink - (L * w + extra))
    return out


def _tips(pts):
    """Interior vertices of an open polyline with their miter ratio 1/sin(theta/2)."""
    out = []
    for i in range(1, len(pts) - 1):
        a, v, b = pts[i - 1], pts[i], pts[i + 1]
        din = norm(v[0] - a[0], v[1] - a[1]); dout = norm(b[0] - v[0], b[1] - v[1])
        cosang = max(-1.0, min(1.0, din[0] * dout[0] + din[1] * dout[1]))
        half = math.sqrt(max(1e-12, (1.0 + cosang) / 2.0))
        out.append((i, 1.0 / half))
    return out


def zigzag_joins(img, rules, symbols, sizes, rows):
    """Per context: for every zigzag tip, which of miter, bevel or round its inked extent matches; then the
    join, and for a miter join the miter limit, placed between the sharpest mitered and the bluntest
    bevelled tip."""
    calls = {}
    for r in rows:
        sym = symbols[r["symbol"]]
        el = sym["elements"][0]
        pts = el["subpaths"][0][0]
        W, H = sizes[r["size_class"]]
        sx, sy, tx, ty = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)
        h = element_width(el["width"], sym["viewBox"]) / 2.0
        x0, y0 = int(r["left_px"]), int(r["top_px"])
        for i, ratio in _tips(pts):
            v = pts[i]
            up = v[1] < pts[i - 1][1]
            preds = {}
            for j in ("miter", "bevel", "round"):
                cand = stroke_extremes(pts[i - 1:i + 2], [True, True, True], False, h, j, "butt", 1e9)
                near = [p for p in cand if math.hypot(p[0] - v[0], p[1] - v[1]) < 3.5 * h * max(1.0, ratio) and abs(p[0] - v[0]) < 1.6 * h]
                if j == "round":
                    near.append((v[0], v[1] - h if up else v[1] + h))
                ys = [p[1] for p in near]
                preds[j] = (min(ys) if up else max(ys)) * sy + ty
            # measured: the extreme inked row in a narrow column window over the tip, refined by coverage
            cx = v[0] * sx + tx
            best = None
            for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
                row = img[yy]
                cov = max(coverage(row[xx]) for xx in range(max(0, x0 + int(cx - 0.6 * h * sx) - 1), x0 + int(cx + 0.6 * h * sx) + 2))
                if cov > 0.02:
                    edge = (yy + 1 - cov - y0) if up else (yy + cov - y0)
                    if up:
                        best = edge if best is None else min(best, edge)
                    else:
                        best = edge if best is None else max(best, edge)
            if best is None:
                continue
            pick = min(preds, key=lambda j: abs(preds[j] - best))
            calls.setdefault(r["context"], []).append((ratio, pick))
    out = []
    for ctx, cs in calls.items():
        votes = {}
        for _, j in cs:
            votes[j] = votes.get(j, 0) + 1
        now = host_style(rules, ["icon"], ctx)
        now_join = now.get("stroke-linejoin", INITIAL["stroke-linejoin"])
        now_limit = float(now.get("stroke-miterlimit", INITIAL["stroke-miterlimit"]))
        if votes.get("round", 0) > len(cs) / 2:
            join, limit = "round", None
        else:
            mitered = sorted(rt for rt, j in cs if j == "miter")
            bevelled = sorted(rt for rt, j in cs if j == "bevel")
            if not mitered:
                join, limit = "bevel", None
            else:
                join = "miter"
                hi = min(bevelled) if bevelled else None
                lo = max(mitered)
                if hi is None:
                    limit = max(now_limit, lo) if now_join == "miter" else max(4.0, lo)
                else:
                    limit = (lo + hi) / 2.0
        decl = {}
        if join != now_join:
            decl["stroke-linejoin"] = join + " !important"
        if join == "miter" and limit is not None and abs(limit - now_limit) > 1e-6:
            # only a change the captures force: keep the page's own limit when it already splits the tips
            ok = all((rt <= now_limit) == (j == "miter") for rt, j in cs)
            if not ok or join != now_join:
                decl["stroke-miterlimit"] = "%.4f !important" % limit
        if decl:
            out.append(([[ctx], ["icon"]], decl))
    return out


def bar_dashes(img, rules, symbols, sizes, rows):
    """Per context: the dash pattern a thin bar takes from the page, from its ink runs: each run's ink less
    its two caps is the dash length times the weight, its centre is the dash's centre, and consecutive
    centres give the period."""
    found = {}
    for r in rows:
        sym = symbols[r["symbol"]]
        el = sym["elements"][0]
        pts = el["subpaths"][0][0]
        W, H = sizes[r["size_class"]]
        sx, sy, tx, ty = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)
        w = element_width(el["width"], sym["viewBox"]) * sx
        x0, y0 = int(r["left_px"]), int(r["top_px"])
        cap = el["cap"] or host_style(rules, ["icon", r["size_class"]], r["context"]).get("stroke-linecap", INITIAL["stroke-linecap"])
        capA = {"butt": 0.0, "square": w * w, "round": math.pi * w * w / 4}[cap]
        ext = 0.0 if cap == "butt" else w / 2
        cols = []
        for xx in range(max(0, x0 - 12), x0 + int(W) + 12):
            c = 0.0
            for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
                if xx < len(img[yy]):
                    c += coverage(img[yy][xx])
            cols.append((xx - x0 + 0.5, c))
        runs, cur = [], []
        for x, c in cols:
            if c > 0.01:
                cur.append((x, c))
            elif cur:
                runs.append(cur); cur = []
        if cur:
            runs.append(cur)
        start_px, end_px = pts[0][0] * sx + tx, pts[-1][0] * sx + tx
        full = []
        for run in runs:
            ink = sum(c for _, c in run)
            cen = sum(x * c for x, c in run) / ink
            lo, hi = run[0][0] - 0.5, run[-1][0] + 0.5
            if lo <= start_px - ext + 0.3 or hi >= end_px + ext - 0.3:
                continue                          # a dash cut by the bar's end
            full.append(((ink - capA) / w / sx, (cen - start_px) / sx))
        if len(full) < 2:
            if len(runs) == 1 and len(full) == 0:
                found.setdefault(r["context"], []).append(None)     # solid: no dashes
            continue
        full.sort(key=lambda d: d[1])
        period = (full[-1][1] - full[0][1]) / (len(full) - 1)
        dash = sum(d[0] for d in full) / len(full)
        # the phase as a circular mean of every dash centre
        ang = [2 * math.pi * ((dash / 2 - c) % period) / period for _, c in full]
        off = (math.atan2(sum(math.sin(a) for a in ang), sum(math.cos(a) for a in ang)) % (2 * math.pi)) * period / (2 * math.pi)
        found.setdefault(r["context"], []).append((dash, period - dash, off, sx * len(full)))
    out = []
    for ctx, vals in found.items():
        vals = [v for v in vals if v is not None]
        if not vals:
            continue
        wsum = sum(v[3] for v in vals)
        d = sum(v[0] * v[3] for v in vals) / wsum
        g = sum(v[1] * v[3] for v in vals) / wsum
        P = d + g
        ang = [(2 * math.pi * v[2] / P, v[3]) for v in vals]
        o = (math.atan2(sum(math.sin(a) * w for a, w in ang), sum(math.cos(a) * w for a, w in ang)) % (2 * math.pi)) * P / (2 * math.pi)
        out.append(([[ctx], ["icon"]], {"stroke-dasharray": "%.4f %.4f !important" % (d, g),
                                        "stroke-dashoffset": "%.4f !important" % o}))
    return out


THEME_SHAPES = True
CONTEXTS_SEEN = []


def theme_shapes(img, rules, symbols, sizes, caps_rows):
    """Join and cap per context, from the open test shapes: each candidate is rendered by the model and
    compared with the capture -- the zigzag's tip extent for the join, the bar's ink for the cap."""
    votes = {}
    for r in caps_rows:
        sym = symbols[r["symbol"]]
        el = sym["elements"][0]
        pts = el["subpaths"][0][0]
        W, H = sizes[r["size_class"]]
        x0, y0 = int(r["left_px"]), int(r["top_px"])
        ys, ink = [], 0.0
        for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
            row = img[yy]
            for xx in range(max(0, x0 - 12), min(len(row), x0 + int(W) + 12)):
                v = row[xx]
                ink += (255 - v) / 255.0
                if v < 128:
                    ys.append(yy)
        ctx = r["context"]
        kind = "join" if len(pts) > 2 else "cap"
        prop = "stroke-linejoin" if kind == "join" else "stroke-linecap"
        cands = ("miter", "round", "bevel") if kind == "join" else ("butt", "round", "square")
        best = None
        for c in cands:
            host = host_style(rules + [([[ctx], ["icon"]], {prop: c})], ["icon", r["size_class"]], ctx)
            if kind == "join":
                box = extent(sym, W, H, host_props=host)
                err = abs((min(ys) - y0) - box[1]) + abs((max(ys) + 1 - y0) - box[3]) if ys else 9e9
            else:
                sx = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)[0]
                w = float(host["stroke-width"]) * sx
                L = math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]) * sx
                extra = {"butt": 0.0, "square": w * w, "round": math.pi * w * w / 4}[c]
                err = abs(ink - (L * w + extra))
            if best is None or err < best[0]:
                best = (err, c)
        votes.setdefault((ctx, prop), []).append(best[1])
    out = []
    for (ctx, prop), vs in votes.items():
        pick = max(set(vs), key=vs.count)
        shipped = host_style(rules, ["icon"], ctx).get(prop, INITIAL[prop])
        if pick != shipped:
            out.append(([[ctx], ["icon"]], {prop: pick + " !important"}))
    return out


def solve(root="/app", steps=200, specificity=True, em_from_context=False, last_id_wins=False, paint_defs=False,
          paint_hidden=False, follow_use=True, **options):
    WALK.update(paint_defs=paint_defs, paint_hidden=paint_hidden, follow_use=follow_use)
    sprite = os.path.join(root, "sprite")
    symbols = read_sprite(os.path.join(sprite, "icons.svg"), steps, last_id_wins)
    sizes = read_sizes(os.path.join(sprite, "icons.css"))
    rules = read_rules(os.path.join(sprite, "icons.css"))
    largest = options.pop("theme_largest_only", False)
    global THEME_MODE
    THEME_MODE = options.pop("theme_mode", "exact")
    global THEME_SHAPES, LINEAR
    THEME_SHAPES = options.pop("theme_shapes", True)
    LINEAR = options.pop("linear_light", True)
    if not options.pop("shipped_css", False):
        rules = rules + theme_rules(root, rules, symbols, sizes, largest)
    out = {}
    with open(os.path.join(sprite, "placements.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            W, H = sizes[row["size_class"]]
            host = host_style(rules, ["icon", row["size_class"]], row["context"], specificity, em_from_context)
            out[row["placement"]] = extent(symbols[row["symbol"]], W, H, host_props=host, **options)
    return out


def write_csv(boxes, path, decimals=2):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["placement", "left", "top", "right", "bottom"])
        for pc in sorted(boxes, key=lambda k: (len(k), k)):
            w.writerow([pc] + [("%.*f" % (decimals, v)) for v in boxes[pc]])


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "/app"
    write_csv(solve(root), os.path.join(root, "out", "icons.csv"))
