#!/usr/bin/env python3
"""Painted extents for one page folder.

    python3 extent.py PAGE_DIR OUT_FILE

PAGE_DIR holds icons.svg, icons.css, placements.csv and qa/ (captures.png, captures.csv).  The page's
theme stylesheet is not in the folder; whatever it changes is recovered from the QA captures and
applied after icons.css.  OUT_FILE gets placement,left,top,right,bottom for every placement."""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine as E   # noqa: E402


def page_extents(page, steps=200):
    rules = E.read_rules(os.path.join(page, "icons.css"))
    symbols = E.read_sprite(os.path.join(page, "icons.svg"), steps)
    sizes = E.read_sizes(os.path.join(page, "icons.css"))
    if not E.ABL.get("no_theme"):
        rules = rules + E.theme_rules(page, rules, symbols, sizes, E.ABL.get("largest_only", False))
    out = {}
    for r in csv.DictReader(open(os.path.join(page, "placements.csv"), newline="")):
        W, H = sizes[r["size_class"]]
        host = E.host_style(rules, ["icon", r["size_class"]], r["context"])
        out[r["placement"]] = E.extent(symbols[r["symbol"]], W, H, host_props=host)
    return out


def main():
    page, dest = sys.argv[1], sys.argv[2]
    boxes = page_extents(page)
    with open(dest, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["placement", "left", "top", "right", "bottom"])
        for pc in sorted(boxes):
            w.writerow([pc] + ["%.2f" % v for v in boxes[pc]])


if __name__ == "__main__":
    main()
