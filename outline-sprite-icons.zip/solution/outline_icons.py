#!/usr/bin/env python3
"""Reference: the painted extent of every icon placement, from the shipped sprite, stylesheet and
placement list only.  Writes /app/out/icons.csv.

    python3 outline_icons.py [/app]

The painted extent of a placement is the box of everything the symbol's fills and strokes cover
once the symbol is laid out in its container by viewBox and preserveAspectRatio:
  * a fill covers its geometry;
  * a stroke covers the path offset by half its width to each side, with the declared join at
    each corner (a miter reaches (w/2)/sin(theta/2) past the vertex along the bisector unless
    1/sin(theta/2) exceeds stroke-miterlimit, when the join is a bevel), and the declared cap at
    each open end (butt: nothing; square: half the width along the path; round: a half-disc);
  * a stroke with vector-effect="non-scaling-stroke" has its width in container pixels, so it is
    stroked after the viewBox scaling; any other stroke scales with the geometry.

The module also exposes `solve(root, **options)` with switches that leave parts of this out, for the
readings recorded in the metadata (none of them is the honest path).
"""
import csv
import math
import os
import re
import sys
import xml.etree.ElementTree as ET

SVG = "{http://www.w3.org/2000/svg}"
XLINK = "{http://www.w3.org/1999/xlink}"
NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
TOKEN = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?|[A-Za-z]")


# ------------------------------------------------------------------------------------------------
# transforms
# ------------------------------------------------------------------------------------------------
def mat_mul(p, q):
    a1, b1, c1, d1, e1, f1 = p
    a2, b2, c2, d2, e2, f2 = q
    return (a1 * a2 + c1 * b2, b1 * a2 + d1 * b2, a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
            a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1)


def mat_apply(m, x, y):
    return (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])


def parse_transform(text):
    m = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
    if not text:
        return m
    for name, body in re.findall(r"(\w+)\s*\(([^)]*)\)", text):
        v = [float(t) for t in NUM.findall(body)]
        if name == "translate":
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0.0)
        elif name == "scale":
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "rotate":
            a = math.radians(v[0])
            ca, sa = math.cos(a), math.sin(a)
            t = (ca, sa, -sa, ca, 0, 0)
            if len(v) == 3:
                t = mat_mul(mat_mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == "matrix":
            t = tuple(v[:6])
        elif name == "skewX":
            t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == "skewY":
            t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else:
            continue
        m = mat_mul(m, t)
    return m


# ------------------------------------------------------------------------------------------------
# path data -> absolute commands -> flattened subpaths
# ------------------------------------------------------------------------------------------------
def parse_path(d):
    """Absolute commands: ('M', x, y) ('L', x, y) ('C', ...6) ('Q', ...4) ('A', rx, ry, phi, large, sweep, x, y) ('Z',)."""
    toks = TOKEN.findall(d)
    i = 0
    cmd = None
    cx = cy = 0.0
    sx = sy = 0.0
    last_c = last_q = None
    out = []

    def nums(k):
        nonlocal i
        v = [float(toks[i + j]) for j in range(k)]
        i += k
        return v

    while i < len(toks):
        t = toks[i]
        if t.isalpha():
            cmd = t
            i += 1
            if cmd in "Zz":
                out.append(("Z",))
                cx, cy = sx, sy
                last_c = last_q = None
                continue
        elif cmd is None:
            raise ValueError("path data starts with a number")
        rel = cmd.islower()
        c = cmd.upper()
        if c == "M":
            x, y = nums(2)
            if rel:
                x, y = cx + x, cy + y
            out.append(("M", x, y))
            cx, cy = sx, sy = x, y
            cmd = "l" if rel else "L"       # implicit lineto after moveto
            last_c = last_q = None
        elif c == "L":
            x, y = nums(2)
            if rel:
                x, y = cx + x, cy + y
            out.append(("L", x, y))
            cx, cy = x, y
            last_c = last_q = None
        elif c == "H":
            (x,) = nums(1)
            if rel:
                x = cx + x
            out.append(("L", x, cy))
            cx = x
            last_c = last_q = None
        elif c == "V":
            (y,) = nums(1)
            if rel:
                y = cy + y
            out.append(("L", cx, y))
            cy = y
            last_c = last_q = None
        elif c == "C":
            v = nums(6)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(6)]
            out.append(("C",) + tuple(v))
            last_c, last_q = (v[2], v[3]), None
            cx, cy = v[4], v[5]
        elif c == "S":
            v = nums(4)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(4)]
            x1, y1 = (2 * cx - last_c[0], 2 * cy - last_c[1]) if last_c else (cx, cy)
            out.append(("C", x1, y1, v[0], v[1], v[2], v[3]))
            last_c, last_q = (v[0], v[1]), None
            cx, cy = v[2], v[3]
        elif c == "Q":
            v = nums(4)
            if rel:
                v = [v[k] + (cx if k % 2 == 0 else cy) for k in range(4)]
            out.append(("Q",) + tuple(v))
            last_q, last_c = (v[0], v[1]), None
            cx, cy = v[2], v[3]
        elif c == "T":
            v = nums(2)
            if rel:
                v = [v[0] + cx, v[1] + cy]
            x1, y1 = (2 * cx - last_q[0], 2 * cy - last_q[1]) if last_q else (cx, cy)
            out.append(("Q", x1, y1, v[0], v[1]))
            last_q, last_c = (x1, y1), None
            cx, cy = v[0], v[1]
        elif c == "A":
            v = nums(7)
            x, y = v[5], v[6]
            if rel:
                x, y = cx + x, cy + y
            out.append(("A", abs(v[0]), abs(v[1]), v[2], int(v[3] != 0), int(v[4] != 0), x, y))
            cx, cy = x, y
            last_c = last_q = None
        else:
            raise ValueError("unknown path command %r" % cmd)
    return out


def arc_center(x1, y1, rx, ry, phi_deg, large, sweep, x2, y2):
    """SVG implementation notes F.6.5.  Returns (cx, cy, rx, ry, phi, theta1, dtheta) in radians."""
    phi = math.radians(phi_deg)
    cp, sp = math.cos(phi), math.sin(phi)
    dx, dy = (x1 - x2) / 2.0, (y1 - y2) / 2.0
    x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry)
    if lam > 1:
        rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    k = math.sqrt(max(0.0, num / den)) if den > 0 else 0.0
    if large == sweep:
        k = -k
    cxp, cyp = k * rx * y1p / ry, -k * ry * x1p / rx
    cx = cp * cxp - sp * cyp + (x1 + x2) / 2.0
    cy = sp * cxp + cp * cyp + (y1 + y2) / 2.0

    def ang(ux, uy, vx, vy):
        d = max(-1.0, min(1.0, (ux * vx + uy * vy) / (math.hypot(ux, uy) * math.hypot(vx, vy))))
        a = math.acos(d)
        return -a if ux * vy - uy * vx < 0 else a

    t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and dt > 0:
        dt -= 2 * math.pi
    elif sweep and dt < 0:
        dt += 2 * math.pi
    return cx, cy, rx, ry, phi, t1, dt


def flatten(cmds, steps):
    """[(points, corner_flags, closed)] -- curve samples are not corners; command end points are."""
    subs = []
    pts, flags = [], []
    cur = (0.0, 0.0)
    start = (0.0, 0.0)

    def close_sub(closed):
        nonlocal pts, flags
        clean, cf = [], []
        for p, f in zip(pts, flags):
            if clean and math.hypot(p[0] - clean[-1][0], p[1] - clean[-1][1]) < 1e-9:
                cf[-1] = cf[-1] or f
                continue
            clean.append(p)
            cf.append(f)
        if closed and len(clean) > 1 and math.hypot(clean[0][0] - clean[-1][0], clean[0][1] - clean[-1][1]) < 1e-9:
            clean.pop()
            cf.pop()
        if len(clean) >= 2:
            subs.append((clean, cf, closed))
        elif len(clean) == 1 and not closed:
            subs.append((clean, cf, closed))
        pts, flags = [], []

    for c in cmds:
        k = c[0]
        if k == "M":
            if pts:
                close_sub(False)
            cur = start = (c[1], c[2])
            pts, flags = [cur], [True]
        elif k == "L":
            cur = (c[1], c[2])
            pts.append(cur)
            flags.append(True)
        elif k == "C":
            x0, y0 = cur
            x1, y1, x2, y2, x3, y3 = c[1:]
            for s in range(1, steps + 1):
                t = s / steps
                u = 1 - t
                pts.append((u * u * u * x0 + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3,
                            u * u * u * y0 + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3))
                flags.append(s == steps)
            cur = (x3, y3)
        elif k == "Q":
            x0, y0 = cur
            x1, y1, x2, y2 = c[1:]
            for s in range(1, steps + 1):
                t = s / steps
                u = 1 - t
                pts.append((u * u * x0 + 2 * u * t * x1 + t * t * x2, u * u * y0 + 2 * u * t * y1 + t * t * y2))
                flags.append(s == steps)
            cur = (x2, y2)
        elif k == "A":
            rx, ry, phi_deg, large, sweep, x2, y2 = c[1:]
            x1, y1 = cur
            if (rx == 0 or ry == 0) or (abs(x1 - x2) < 1e-12 and abs(y1 - y2) < 1e-12):
                pts.append((x2, y2))
                flags.append(True)
            else:
                cx, cy, rx, ry, phi, t1, dt = arc_center(x1, y1, rx, ry, phi_deg, large, sweep, x2, y2)
                cp, sp = math.cos(phi), math.sin(phi)
                for s in range(1, steps + 1):
                    a = t1 + dt * s / steps
                    ex, ey = rx * math.cos(a), ry * math.sin(a)
                    pts.append((cx + cp * ex - sp * ey, cy + sp * ex + cp * ey) if s < steps else (x2, y2))
                    flags.append(s == steps)
            cur = (x2, y2)
        elif k == "Z":
            close_sub(True)
            cur = start
    if pts:
        close_sub(False)
    return subs


# ------------------------------------------------------------------------------------------------
# the stroked outline's extreme points
# ------------------------------------------------------------------------------------------------
def perp(d):
    return (-d[1], d[0])


def norm(x, y):
    n = math.hypot(x, y)
    return (x / n, y / n) if n > 1e-12 else (0.0, 0.0)


def disc(p, h, poly):
    if poly:
        return [(p[0] + h * math.cos(2 * math.pi * k / poly), p[1] + h * math.sin(2 * math.pi * k / poly))
                for k in range(poly)]
    return [(p[0] - h, p[1] - h), (p[0] + h, p[1] + h)]


def stroke_extremes(pts, flags, closed, h, join, cap, limit, *, always_miter=False, caps_ignored=False,
                    poly=0, limit_inclusive=False):
    n = len(pts)
    out = []
    if n == 1:
        # a lone point paints only with round or square caps
        if cap == "round" or caps_ignored:
            out += disc(pts[0], h, poly)
        elif cap == "square":
            out += [(pts[0][0] - h, pts[0][1] - h), (pts[0][0] + h, pts[0][1] + h)]
        return out
    seg = [(i, i + 1) for i in range(n - 1)] + ([(n - 1, 0)] if closed else [])
    d = {}
    for a, b in seg:
        d[(a, b)] = norm(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1])
        nx, ny = perp(d[(a, b)])
        for p in (pts[a], pts[b]):
            out.append((p[0] + h * nx, p[1] + h * ny))
            out.append((p[0] - h * nx, p[1] - h * ny))
    for i in range(n):
        if not flags[i]:
            continue
        if closed:
            din, dout = d[((i - 1) % n, i)], d[(i, (i + 1) % n)]
        elif 0 < i < n - 1:
            din, dout = d[(i - 1, i)], d[(i, i + 1)]
        else:
            continue
        v = pts[i]
        if join == "round":
            out += disc(v, h, poly)
        elif join == "miter" or join == "miter-clip":
            cosang = max(-1.0, min(1.0, din[0] * dout[0] + din[1] * dout[1]))
            half = math.sqrt(max(0.0, (1.0 + cosang) / 2.0))       # sin(theta / 2)
            if half < 1e-9:
                continue
            ratio = 1.0 / half
            keep = ratio < limit if limit_inclusive else ratio <= limit
            if keep or always_miter:
                bx, by = norm(din[0] - dout[0], din[1] - dout[1])
                out.append((v[0] + h * ratio * bx, v[1] + h * ratio * by))
    if not closed:
        for p, dv in ((pts[0], (-d[(0, 1)][0], -d[(0, 1)][1])), (pts[-1], d[(n - 2, n - 1)])):
            if caps_ignored or cap == "round":
                out += disc(p, h, poly)
            elif cap == "square":
                nx, ny = perp(dv)
                out.append((p[0] + h * dv[0] + h * nx, p[1] + h * dv[1] + h * ny))
                out.append((p[0] + h * dv[0] - h * nx, p[1] + h * dv[1] - h * ny))
    return out


# ------------------------------------------------------------------------------------------------
# the sprite
# ------------------------------------------------------------------------------------------------
def style_of(el, inherited):
    st = dict(inherited)
    st.pop("display", None)          # display is not inherited; a 'none' stops the walk instead
    for k in ("fill", "stroke", "stroke-width", "stroke-linejoin", "stroke-linecap", "stroke-miterlimit",
              "vector-effect", "stroke-dasharray", "stroke-dashoffset", "visibility", "display"):
        if el.get(k) is not None:
            st[k] = el.get(k)
    for part in (el.get("style") or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            st[k.strip()] = v.strip()
    return st


def element_cmds(el):
    tag = el.tag.replace(SVG, "")
    g = lambda k, dflt=0.0: float(el.get(k, dflt))
    if tag == "path":
        return parse_path(el.get("d", ""))
    if tag == "rect":
        x, y, w, h = g("x"), g("y"), g("width"), g("height")
        rx = el.get("rx")
        ry = el.get("ry")
        rx = float(rx) if rx is not None else (float(ry) if ry is not None else 0.0)
        ry = float(ry) if ry is not None else rx
        if rx <= 0 or ry <= 0:
            return [("M", x, y), ("L", x + w, y), ("L", x + w, y + h), ("L", x, y + h), ("Z",)]
        rx, ry = min(rx, w / 2), min(ry, h / 2)
        return [("M", x + rx, y), ("L", x + w - rx, y), ("A", rx, ry, 0, 0, 1, x + w, y + ry),
                ("L", x + w, y + h - ry), ("A", rx, ry, 0, 0, 1, x + w - rx, y + h), ("L", x + rx, y + h),
                ("A", rx, ry, 0, 0, 1, x, y + h - ry), ("L", x, y + ry), ("A", rx, ry, 0, 0, 1, x + rx, y), ("Z",)]
    if tag == "circle":
        cx, cy, r = g("cx"), g("cy"), g("r")
        return [("M", cx + r, cy), ("A", r, r, 0, 0, 1, cx, cy + r), ("A", r, r, 0, 0, 1, cx - r, cy),
                ("A", r, r, 0, 0, 1, cx, cy - r), ("A", r, r, 0, 0, 1, cx + r, cy), ("Z",)]
    if tag == "ellipse":
        cx, cy, rx, ry = g("cx"), g("cy"), g("rx"), g("ry")
        return [("M", cx + rx, cy), ("A", rx, ry, 0, 0, 1, cx, cy + ry), ("A", rx, ry, 0, 0, 1, cx - rx, cy),
                ("A", rx, ry, 0, 0, 1, cx, cy - ry), ("A", rx, ry, 0, 0, 1, cx + rx, cy), ("Z",)]
    if tag == "line":
        return [("M", g("x1"), g("y1")), ("L", g("x2"), g("y2"))]
    if tag in ("polyline", "polygon"):
        v = [float(t) for t in NUM.findall(el.get("points", ""))]
        cmds = [("M", v[0], v[1])] + [("L", v[k], v[k + 1]) for k in range(2, len(v) - 1, 2)]
        if tag == "polygon":
            cmds.append(("Z",))
        return cmds
    return None


XLINK_HREF = "{http://www.w3.org/1999/xlink}href"
WALK = {"idmap": {}, "paint_defs": False, "paint_hidden": False, "follow_use": True, "depth": 0}


def walk(el, m, st, steps, out):
    """Collect (matrix, style, cmds) for every element under el that the browser paints."""
    tag = el.tag.replace(SVG, "")
    if tag in ("defs", "clipPath", "mask", "symbol", "linearGradient", "radialGradient", "pattern", "marker") \
            and not WALK["paint_defs"]:
        return                                    # never rendered where it stands
    m2 = mat_mul(m, parse_transform(el.get("transform")))
    st2 = style_of(el, st)
    if st2.get("display", "").strip() == "none" and not WALK["paint_hidden"]:
        return
    if tag in ("g", "defs"):
        for ch in el:
            walk(ch, m2, st2, steps, out)
        return
    if tag == "use":
        if not WALK["follow_use"] or WALK["depth"] > 8:
            return
        ref = (el.get("href") or el.get(XLINK_HREF) or "").lstrip("#")
        target = WALK["idmap"].get(ref)
        if target is None:
            return
        m3 = mat_mul(m2, (1.0, 0.0, 0.0, 1.0, float(el.get("x", 0)), float(el.get("y", 0))))
        WALK["depth"] += 1
        walk(target, m3, st2, steps, out)
        WALK["depth"] -= 1
        return
    cmds = element_cmds(el)
    if cmds is not None:
        if st2.get("visibility", "visible").strip() in ("hidden", "collapse") and not WALK["paint_hidden"]:
            return
        if el.get("pathLength") is not None:
            st2 = dict(st2, _pathLength=el.get("pathLength"))
        out.append((m2, st2, cmds))


def read_sprite(path, steps, last_id_wins=False):
    root = ET.parse(path).getroot()
    symbols = {}
    idmap = {}
    for node in root.iter():
        if node.get("id"):
            if last_id_wins:
                idmap[node.get("id")] = node
            else:
                idmap.setdefault(node.get("id"), node)      # a document resolves an id to its first element
    WALK["idmap"] = idmap
    for sym in (n for n in root.iter(SVG + "symbol") if idmap.get(n.get("id")) is n):
        vb = [float(t) for t in NUM.findall(sym.get("viewBox", "0 0 100 100"))]
        par = (sym.get("preserveAspectRatio") or "xMidYMid meet").split()
        align = par[0]
        mos = par[1] if len(par) > 1 else "meet"
        drawn = []
        for ch in sym:
            walk(ch, (1.0, 0.0, 0.0, 1.0, 0.0, 0.0), {}, steps, drawn)
        elements = []
        for m, st, cmds in drawn:
            subs = [([mat_apply(m, x, y) for x, y in pts], flags, closed) for pts, flags, closed in flatten(cmds, steps)]
            fill = st.get("fill", "black").strip().lower() != "none"
            stroke = st.get("stroke", "none").strip().lower() != "none"
            sw = st.get("stroke-width")
            dash = st.get("stroke-dasharray")
            dash = [float(v) for v in NUM.findall(dash)] if dash and dash.strip() != "none" else None
            elements.append({
                "fill": fill, "stroke": stroke,
                # None: not set on the element or its groups, so inherited from the host <svg>
                "width": sw.strip() if sw else None,
                "join": st["stroke-linejoin"].strip() if "stroke-linejoin" in st else None,
                "cap": st["stroke-linecap"].strip() if "stroke-linecap" in st else None,
                "limit": float(st["stroke-miterlimit"]) if "stroke-miterlimit" in st else None,
                "nss": st.get("vector-effect", "none").strip() == "non-scaling-stroke",
                "dash": dash if dash and sum(dash) > 0 else None,
                "dashoffset": float(NUM.search(st.get("stroke-dashoffset", "0")).group(0)),
                "pathLength": float(st["_pathLength"]) if "_pathLength" in st else None,
                "subpaths": subs,
            })
        symbols[sym.get("id")] = {"viewBox": vb, "align": align, "mos": mos, "elements": elements}
    return symbols


INHERITED = ("stroke-width", "stroke-linejoin", "stroke-linecap", "stroke-miterlimit", "stroke-dasharray",
             "stroke-dashoffset")
INITIAL = {"stroke-width": "1", "stroke-linejoin": "miter", "stroke-linecap": "butt", "stroke-miterlimit": "4"}


def read_css(path):
    """Per class: its declarations.  Size classes are the ones that set a width and a height."""
    text = re.sub(r"/\*.*?\*/", "", open(path, encoding="utf-8").read(), flags=re.S)
    rules = {}
    for cls, body in re.findall(r"\.([\w-]+)\s*\{([^}]*)\}", text):
        decl = rules.setdefault(cls, {})
        for part in body.split(";"):
            if ":" in part:
                k, v = part.split(":", 1)
                decl[k.strip()] = v.strip()
    return rules


def read_rules(path):
    """Ordered (selector compounds, declarations) from the stylesheet."""
    text = re.sub(r"/\*.*?\*/", "", open(path, encoding="utf-8").read(), flags=re.S)
    out = []
    for sel, body in re.findall(r"([^{}]+)\{([^}]*)\}", text):
        for one in sel.split(","):
            comps = [re.findall(r"\.([\w-]+)", c) for c in one.split()]
            decl = {}
            for part in body.split(";"):
                if ":" in part:
                    k, v = part.split(":", 1)
                    decl[k.strip()] = v.strip()
            out.append((comps, decl))
    return out


def _matches(comps, chain):
    """chain: class sets from the element outward (element first).  Descendant combinators only."""
    if not comps or not set(comps[-1]) <= chain[0]:
        return False
    i = 1
    for comp in reversed(comps[:-1]):
        while i < len(chain) and not set(comp) <= chain[i]:
            i += 1
        if i == len(chain):
            return False
        i += 1
    return True


def cascaded(rules, chain, specificity=True):
    """Winning declaration per property for the element at chain[0]."""
    best = {}
    for order, (comps, decl) in enumerate(rules):
        if not _matches(comps, chain):
            continue
        spec = sum(len(c) for c in comps) if specificity else 0
        for k, v in decl.items():
            if k not in best or (spec, order) >= best[k][0]:
                best[k] = ((spec, order), v)
    return {k: v for k, (_, v) in best.items()}


def length_px(value, font_px):
    m = re.match(r"\s*([-+]?\d*\.?\d+)\s*(px|em|pt)?\s*$", value)
    if not m:
        return None
    v = float(m.group(1))
    unit = m.group(2) or "px"
    return v * {"px": 1.0, "em": font_px, "pt": 4.0 / 3.0}[unit]


def host_style(rules, svg_classes, context, specificity=True, em_from_context=False):
    """Computed inherited stroke properties on <div class=context><svg class=...>."""
    div = cascaded(rules, [{context}], specificity)
    svg = cascaded(rules, [set(svg_classes), {context}], specificity)
    div_font = length_px(div.get("font-size", "16px"), 16.0) or 16.0
    own_font = length_px(svg["font-size"], div_font) if "font-size" in svg else div_font
    font = div_font if em_from_context else own_font
    st = {}
    for k in INHERITED:
        if k in svg:
            st[k] = svg[k]
    if "stroke-width" in st:
        st["stroke-width"] = "%r" % length_px(st["stroke-width"], font)
    return st


def element_width(text, view_box, pt_as_px=False, pct_of_width=False):
    """A stroke-width presentation attribute in the symbol's user units."""
    m = re.match(r"\s*([-+]?\d*\.?\d+)\s*(px|pt|%)?\s*$", str(text))
    v, unit = float(m.group(1)), m.group(2) or "px"
    if unit == "pt":
        return v if pt_as_px else v * 4.0 / 3.0
    if unit == "%":
        vw, vh = view_box[2], view_box[3]
        base = vw if pct_of_width else math.sqrt((vw * vw + vh * vh) / 2.0)
        return v / 100.0 * base
    return v


def read_sizes(path):
    sizes = {}
    for cls, decl in read_css(path).items():
        w = re.search(r"([\d.]+)px", decl.get("width", ""))
        h = re.search(r"([\d.]+)px", decl.get("height", ""))
        if w and h:
            sizes[cls] = (float(w.group(1)), float(h.group(1)))
    return sizes


def dash_cut(pts, flags, closed, arr, off):
    """The dashes of one flattened subpath, as open (pts, flags) runs."""
    if len(arr) % 2:
        arr = arr * 2
    period = sum(arr)
    ring = pts + ([pts[0]] if closed else [])
    rflags = flags + ([False] if closed else [])
    pos = off % period
    k = 0
    while pos >= arr[k]:
        pos -= arr[k]
        k = (k + 1) % len(arr)
    remain = arr[k] - pos
    drawing = k % 2 == 0
    runs, run, rf = [], ([ring[0]] if drawing else []), ([False] if drawing else [])
    for idx in range(len(ring) - 1):
        a, b = ring[idx], ring[idx + 1]
        seg = math.hypot(b[0] - a[0], b[1] - a[1])
        done = 0.0
        while seg - done > remain:
            done += remain
            f = done / seg
            cut = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
            if drawing:
                run.append(cut); rf.append(False)
                runs.append((run, rf))
            run, rf = ([cut], [False]) if not drawing else ([], [])
            drawing = not drawing
            k = (k + 1) % len(arr)
            remain = arr[k]
        remain -= seg - done
        if drawing:
            last = idx + 1 == len(ring) - 1
            run.append(b); rf.append(False if last else rflags[idx + 1])
    if drawing and len(run) >= 2:
        runs.append((run, rf))
    return [(r, f) for r, f in runs if len(r) >= 2]


def viewport_map(vb, align, mos, W, H):
    vx, vy, vw, vh = vb
    if align == "none":
        sx, sy = W / vw, H / vh
        return sx, sy, -vx * sx, -vy * sy
    s = min(W / vw, H / vh) if mos == "meet" else max(W / vw, H / vh)
    cw, ch = vw * s, vh * s
    ox = {"xMin": 0.0, "xMid": (W - cw) / 2.0, "xMax": W - cw}[align[:4]]
    oy = {"YMin": 0.0, "YMid": (H - ch) / 2.0, "YMax": H - ch}[align[4:]]
    return s, s, ox - vx * s, oy - vy * s


# ------------------------------------------------------------------------------------------------
# the answer
# ------------------------------------------------------------------------------------------------
def extent(sym, W, H, *, host_props=None, nss=True, joins=True, always_miter=False, caps_ignored=False,
           par_default=False, geometry_only=False, poly=0, limit_inclusive=False, user_space=False,
           inherit=True, dashes=True, pt_as_px=False, pct_of_width=False, path_length=True):
    align, mos = ("xMidYMid", "meet") if par_default else (sym["align"], sym["mos"])
    sx, sy, tx, ty = viewport_map(sym["viewBox"], align, mos, W, H)
    s = sx
    cand = []
    hstyle = host_props if (host_props and inherit) else {}

    def pick(own, prop):
        if own is not None:
            return own
        return hstyle.get(prop, INITIAL[prop])

    for el in sym["elements"]:
        if el["width"] is not None:
            width = element_width(el["width"], sym["viewBox"], pt_as_px, pct_of_width)
        else:
            width = float(NUM.search(str(pick(None, "stroke-width"))).group(0))
        join = pick(el["join"], "stroke-linejoin")
        cap = pick(el["cap"], "stroke-linecap")
        limit = float(pick(el["limit"], "stroke-miterlimit"))
        el = dict(el, width=width, join=join, cap=cap, limit=limit)
        subpaths = el["subpaths"]
        if el["stroke"] and el["dash"] and dashes:
            arr, off = el["dash"], el["dashoffset"]
            if el.get("pathLength") and path_length:
                total = 0.0
                for pts, _, closed in subpaths:
                    ring = pts + ([pts[0]] if closed else [])
                    total += sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(ring, ring[1:]))
                k = total / el["pathLength"]
                arr, off = [v * k for v in arr], off * k
            stroked = [(r, f, False) for pts, flags, closed in subpaths
                       for r, f in dash_cut(pts, flags, closed, arr, off)]
            if el["fill"]:
                cand += [(x * sx + tx, y * sy + ty) for pts, _, _ in subpaths for x, y in pts]
                el = dict(el, fill=False)
            subpaths = stroked
        wpx = el["width"] * (1.0 if (el["nss"] and nss) else s)
        for pts, flags, closed in subpaths:
            if user_space and not (el["nss"] and nss):
                # stroke in user units, then map the points (same answer under a uniform scale)
                loc = []
                h = el["width"] / 2.0
                if el["fill"]:
                    loc += pts
                if el["stroke"]:
                    if geometry_only:
                        loc += pts
                    elif not joins:
                        for p in pts:
                            loc += [(p[0] - h, p[1] - h), (p[0] + h, p[1] + h)]
                    else:
                        loc += stroke_extremes(pts, flags, closed, h, el["join"], el["cap"], el["limit"],
                                               always_miter=always_miter, caps_ignored=caps_ignored, poly=poly,
                                               limit_inclusive=limit_inclusive)
                cand += [(x * sx + tx, y * sy + ty) for x, y in loc]
                continue
            host = [(x * sx + tx, y * sy + ty) for x, y in pts]
            h = wpx / 2.0
            if el["fill"]:
                cand += host
            if el["stroke"]:
                if geometry_only:
                    cand += host
                elif not joins:
                    for p in host:
                        cand += [(p[0] - h, p[1] - h), (p[0] + h, p[1] + h)]
                else:
                    cand += stroke_extremes(host, flags, closed, h, el["join"], el["cap"], el["limit"],
                                            always_miter=always_miter, caps_ignored=caps_ignored, poly=poly,
                                            limit_inclusive=limit_inclusive)
    xs = [p[0] for p in cand]
    ys = [p[1] for p in cand]
    return [min(xs), min(ys), max(xs), max(ys)]


def read_png(path):
    """Grey value (red channel) of every pixel of an 8-bit RGB or RGBA PNG."""
    import struct, zlib
    data = open(path, "rb").read()
    i, idat = 8, b""
    while i < len(data):
        n, = struct.unpack(">I", data[i:i + 4]); kind = data[i + 4:i + 8]; chunk = data[i + 8:i + 8 + n]
        if kind == b"IHDR":
            w, h, depth, ctype = struct.unpack(">IIBB", chunk[:10])
        elif kind == b"IDAT":
            idat += chunk
        i += 12 + n
    bpp = {2: 3, 6: 4, 0: 1, 4: 2}[ctype]
    raw = zlib.decompress(idat)
    stride = w * bpp
    prev = bytearray(stride)
    rows, p = [], 0
    for _ in range(h):
        f = raw[p]; line = bytearray(raw[p + 1:p + 1 + stride]); p += 1 + stride
        for x in range(stride):
            a = line[x - bpp] if x >= bpp else 0
            b = prev[x]
            c = prev[x - bpp] if x >= bpp else 0
            if f == 1:
                line[x] = (line[x] + a) & 255
            elif f == 2:
                line[x] = (line[x] + b) & 255
            elif f == 3:
                line[x] = (line[x] + (a + b) // 2) & 255
            elif f == 4:
                pp = a + b - c; pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        rows.append([line[x * bpp] for x in range(w)])
        prev = line
    return rows


THEME_MODE = "exact"


def theme_rules(root, rules, symbols, sizes, largest_only=False):
    """Recover the production theme's stroke widths from the QA captures of the test rings.
    A ring's ink is its stroke area, 2 pi r w, so each capture gives the stroke weight the page passed
    down; it is expressed in the unit of the context's shipped rule and appended after icons.css."""
    qa = os.path.join(root, "qa")
    if not os.path.isdir(qa):
        return []
    img = read_png(os.path.join(qa, "captures.png"))
    found = {}
    for r in csv.DictReader(open(os.path.join(qa, "captures.csv"), newline="")):
        sym = symbols[r["symbol"]]
        el = sym["elements"][0]
        pts, flags, closed = el["subpaths"][0]
        cx = sum(x for x, _ in pts) / len(pts); cy = sum(y for _, y in pts) / len(pts)
        R = sum(math.hypot(x - cx, y - cy) for x, y in pts) / len(pts)
        W, H = sizes[r["size_class"]]
        sx, sy, tx, ty = viewport_map(sym["viewBox"], sym["align"], sym["mos"], W, H)
        # the painted dashes: total length on the ring and how many there are (each carries two cap ends)
        ring_len = 2 * math.pi * R
        if el.get("dash"):
            k = ring_len / el["pathLength"] if el.get("pathLength") else 1.0
            arr = [v * k for v in el["dash"]] * (2 if len(el["dash"]) % 2 else 1)
            period = sum(arr)
            runs = dash_cut(pts, flags, closed, arr, el["dashoffset"] * k)
            n_dash = len(runs)
            on_len = sum(sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(rr, rr[1:])) for rr, _ in runs)
        else:
            n_dash, on_len = 0, ring_len
        x0, y0 = int(r["left_px"]), int(r["top_px"])
        ink = 0.0
        for yy in range(max(0, y0 - 12), min(len(img), y0 + int(H) + 12)):
            row = img[yy]
            for xx in range(max(0, x0 - 12), min(len(row), x0 + int(W) + 12)):
                ink += (255 - row[xx]) / 255.0
        ctx = r["context"]
        svg = cascaded(rules, [{"icon", r["size_class"]}, {ctx}])
        cap = svg.get("stroke-linecap", "butt")
        # ink (px^2) = on_len * w + caps * w^2, lengths in px: square caps add w^2 per dash, round pi w^2 / 4
        Lpx = on_len * sx
        kc = {"square": 1.0, "round": math.pi / 4}.get(cap, 0.0) * n_dash
        if THEME_MODE == "ring":
            w_px = ink / (2 * math.pi * R * sx)
        elif THEME_MODE == "nocaps" or kc == 0:
            w_px = ink / Lpx
        else:
            w_px = (-Lpx + math.sqrt(Lpx * Lpx + 4 * kc * ink)) / (2 * kc)
        w_user = w_px / sx
        div = cascaded(rules, [{ctx}])
        div_font = length_px(div.get("font-size", "16px"), 16.0) or 16.0
        font = length_px(svg["font-size"], div_font) if "font-size" in svg else div_font
        if largest_only and r["size_class"] != max(sizes, key=lambda c: sizes[c][0]):
            continue
        shipped = svg.get("stroke-width", "")
        if shipped.endswith("em"):
            found.setdefault(ctx, []).append((w_user / font, "em", length_px(shipped, 1.0)))
        else:
            found.setdefault(ctx, []).append((w_user, "px", length_px(shipped, 1.0) if shipped else None))
    out = []
    for ctx, vals in found.items():
        vs = sorted(v for v, _, _ in vals)
        med = vs[len(vs) // 2]
        shipped_value = vals[0][2]
        if shipped_value and abs(med - shipped_value) <= 0.1 * shipped_value:
            continue                      # the captures agree with icons.css: no override for this context
        out.append(([[ctx], ["icon"]], {"stroke-width": "%.4f%s" % (med, vals[0][1])}))
    return out


def solve(root="/app", steps=200, specificity=True, em_from_context=False, last_id_wins=False, paint_defs=False,
          paint_hidden=False, follow_use=True, **options):
    WALK.update(paint_defs=paint_defs, paint_hidden=paint_hidden, follow_use=follow_use)
    sprite = os.path.join(root, "sprite")
    symbols = read_sprite(os.path.join(sprite, "icons.svg"), steps, last_id_wins)
    sizes = read_sizes(os.path.join(sprite, "icons.css"))
    rules = read_rules(os.path.join(sprite, "icons.css"))
    largest = options.pop("theme_largest_only", False)
    global THEME_MODE
    THEME_MODE = options.pop("theme_mode", "exact")
    if not options.pop("shipped_css", False):
        rules = rules + theme_rules(root, rules, symbols, sizes, largest)
    out = {}
    with open(os.path.join(sprite, "placements.csv"), newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            W, H = sizes[row["size_class"]]
            host = host_style(rules, ["icon", row["size_class"]], row["context"], specificity, em_from_context)
            out[row["placement"]] = extent(symbols[row["symbol"]], W, H, host_props=host, **options)
    return out


def write_csv(boxes, path, decimals=2):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["placement", "left", "top", "right", "bottom"])
        for pc in sorted(boxes, key=lambda k: (len(k), k)):
            w.writerow([pc] + [("%.*f" % (decimals, v)) for v in boxes[pc]])


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else "/app"
    write_csv(solve(root), os.path.join(root, "out", "icons.csv"))
