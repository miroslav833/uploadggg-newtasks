#!/bin/bash
python3 "$(dirname "$0")/outline_icons.py" /app
