#!/bin/bash
set -e
mkdir -p /app/painter
cp "$(dirname "$0")/painter/engine.py" "$(dirname "$0")/painter/extent.py" /app/painter/
