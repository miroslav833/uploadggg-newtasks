# Sprite export notes

`icons.svg` is the product icon sprite as exported from the design file for the
next release. Each artboard became one `<symbol>` whose `viewBox` is the
artboard's bounds; where the designer changed the artboard's fit setting from
the default, the symbol carries a `preserveAspectRatio` attribute. Shapes were
written as `<path>`, `<circle>` and `<rect>` elements with their paint carried
as presentation attributes on the element itself: `fill`, `stroke`,
`stroke-width`, `stroke-linejoin`, `stroke-linecap`, and `stroke-miterlimit`
where the layer set one. A stroke weight, join or cap that a layer left at the
library default was not written: the library defaults are set once, in
`icons.css`, on the icon element, with the stroke weight chosen per size class.
A stroke weight is written in the unit the layer was given in the design
file (user units, points or per cent). Dashed layers carry `stroke-dasharray`
and `stroke-dashoffset`; layers whose dashes were set against a nominal path
length also carry `pathLength`. Layers whose stroke-scaling option was switched off
in the design file were written with `vector-effect="non-scaling-stroke"`.
Groups were kept with their `transform` attributes, and layers hidden in the
design file were kept in the export with their visibility settings. Parts that
several icons share are defined once in the sprite's top-level `<defs>` and
drawn in each icon with `<use>`.

The release sprite was assembled by the build script that concatenates sprites:
the core library's sprite first, then the spring campaign's sprite appended
after it, inside the same hidden `<svg>`. The campaign sprite was drawn
separately and reuses some of the core library's symbol ids. The sprite holds no
`<style>` block and no class names, and every stroke and fill colour is
`currentColor`.

The page inlines the sprite once, hidden, and places an icon with

    <svg class="icon icon--md"><use href="#sym-xxxx"/></svg>

Every icon sits inside one of the page's context containers, `toolbar`,
`menu`, `card` or `hero`, as `<div class="hero"><svg class="icon icon--md">`.

`icons.css` is the stylesheet the page loads for the icons: the context
containers, `.icon` and the three size classes. A placed icon has no
border and no padding, so its box is the width and height of its size class,
and the symbol is laid out in that box by its own `viewBox` and
`preserveAspectRatio`.

The production page loads `icons.css` and then the brand team's theme
stylesheet, which is maintained separately and is not part of this hand-off.
The QA crawl of the production page captured live placements of the campaign's
test rings in black on white at a device pixel ratio of 1: `../qa/captures.png`
is the capture sheet, and `../qa/captures.csv` gives each capture's symbol, size
class, context container and the pixel at which its icon box's top-left corner
sits in the sheet.

`placements.csv` lists the 78 placements under review before the sprite ships:
a placement code, the symbol it uses, the size class it is placed at and the
context container it sits in. Every
symbol is placed once at each of the three sizes.
