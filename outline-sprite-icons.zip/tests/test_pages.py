"""outline-sprite-icons verifier: the solver's /app/painter/extent.py is run on 20 held-out pages.
A page counts when every placement on it is within 0.10 px on all four edges; at least 18 must count."""
import hashlib, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pagecheck  # noqa: E402

KEYS = os.path.join(pagecheck.HELD, "keys.json")
KEYS_SHA256 = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys.sha256")).read().split()[0]
PAGES_NEEDED = 18
PAGES = 20


def test_held_pages_are_intact():
    data = open(KEYS, "rb").read()
    assert hashlib.sha256(data).hexdigest() == KEYS_SHA256
    assert len(json.loads(data)) == PAGES


def test_tool_reaches_the_mark():
    keys = json.load(open(KEYS))
    results = pagecheck.run_all(keys)
    with open(os.path.join(os.environ.get("PAGECHECK_RESULTS", "/run/pagecheck-results"), "pages.json"), "w") as f:
        json.dump({k: {"counts": not v, "placements_off": v} for k, v in results.items()}, f, indent=1)
    passed = sum(1 for v in results.values() if not v)
    assert passed >= PAGES_NEEDED, "%d of %d pages counted (need %d)" % (passed, PAGES, PAGES_NEEDED)
