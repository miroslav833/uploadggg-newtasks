#!/bin/bash
# Runs the solver's /app/painter on the 20 held-out pages. The reward channel is made root-only before any
# of the solver's code runs, results are written to a private root-only directory, and the reward is
# decided and written only after every process of the solver's account has been stopped.
LOGS=/logs/verifier
PRIVATE=/run/pagecheck-results

put_reward() {
  rm -f "$LOGS/reward.txt" "$LOGS/reward.json"
  (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}

mkdir -p "$LOGS"
logs_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null
find "$LOGS" -mindepth 1 -exec rm -rf {} + 2>/dev/null
put_reward 0

leave() {
  chmod "$logs_mode" "$LOGS" 2>/dev/null
  exit 0
}

if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
  echo "grading: $LOGS could not be made root-only; the painter is not run" >&2
  leave
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
if [ "$(stat -c '%u:%a' /tests 2>/dev/null)" != "0:700" ]; then
  echo "grading: /tests is not root-only; the painter is not run" >&2
  leave
fi
rm -rf "$PRIVATE"
mkdir -p "$PRIVATE"
chown 0:0 "$PRIVATE"
chmod 700 "$PRIVATE"
if [ -d /app/painter ]; then
  chown -R 0:0 /app/painter
  chmod -R u+rwX,go+rX,go-w /app/painter
fi

cd /tests || leave
PAGECHECK_RESULTS="$PRIVATE" python3 -m pytest -q -p no:cacheprovider test_pages.py --ctrf "$PRIVATE/ctrf.json"
status=$?

# nothing the painter's account owns survives into the reward channel
find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
if [ "$status" -eq 0 ]; then put_reward 1; else put_reward 0; fi
for f in ctrf.json pages.json; do
  if [ -f "$PRIVATE/$f" ] && [ ! -L "$PRIVATE/$f" ]; then
    rm -rf "$LOGS/$f"
    (umask 022; cp --no-dereference "$PRIVATE/$f" "$LOGS/$f")
  fi
done
leave
