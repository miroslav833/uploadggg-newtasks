#!/bin/bash
# Reward 0 is written first; 1 only when pytest passes on the held-out pages.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
chmod -R go-rwx /tests 2>/dev/null
if [ -d /app/painter ]; then
  chown -R 0:0 /app/painter && chmod -R u+rwX,go+rX,go-w /app/painter
fi
cd /tests || exit 0
python3 -m pytest -q -p no:cacheprovider test_pages.py --ctrf /logs/verifier/ctrf.json && echo 1 > /logs/verifier/reward.txt
exit 0
