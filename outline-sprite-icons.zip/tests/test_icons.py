"""Verifier for outline-sprite-icons.

Test 1: the sealed key equals the verifier's own forward model (tests/painter.py) over the sealed
geometry and placements.  Test 2: the filing at /app/out/icons.csv, read as text, has at least
MARK of the ITEMS placements right, each edge within TOL px (the numbers printed in instruction.md).
"""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import marking   # noqa: E402
import painter   # noqa: E402

SEALED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sealed")
FILING = "/app/out/icons.csv"
TOL = 0.10          # px per edge, as instruction.md prints it
MARK = 70           # placements right, of ITEMS
ITEMS = 78
SAME = 1e-6         # the sealed key and the painter's reckoning are the same number


def _expected():
    return json.load(open(os.path.join(SEALED, "expected.json"), encoding="utf-8"))


def test_sealed_key_is_the_painters_reckoning():
    symbols = json.load(open(os.path.join(SEALED, "symbols.json"), encoding="utf-8"))
    placements = json.load(open(os.path.join(SEALED, "placements.json"), encoding="utf-8"))
    expected = _expected()
    library = json.load(open(os.path.join(SEALED, "library.json"), encoding="utf-8"))
    got = painter.paint(symbols, placements, library)
    assert len(expected) == ITEMS
    assert set(got) == set(expected)
    for pc in expected:
        for a, b in zip(got[pc], expected[pc]):
            assert math.isfinite(a) and math.isfinite(b)
            assert abs(a - b) <= SAME, (pc, got[pc], expected[pc])


def test_filing_reaches_the_mark():
    assert os.path.exists(FILING), "no filing at %s" % FILING
    text = open(FILING, encoding="utf-8", errors="replace").read()
    right, total, detail = marking.score(text, _expected(), TOL)
    wrong = sorted(k for k, v in detail.items() if v != "right")
    assert total == ITEMS
    assert right >= MARK, "%d of %d placements right (need %d); not right: %s" % (right, total, MARK, wrong[:12])
