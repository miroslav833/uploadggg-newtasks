"""The verifier's own forward model: the painted box of every placement, rebuilt from the sealed
geometry (flattened subpaths in symbol user units, with corner flags) and the sealed placements.
It shares no code with the reference in solution/.

For each placement the symbol is laid into its square container by viewBox and preserveAspectRatio.
A fill covers its geometry.  A stroke of width w covers the offset band h = w/2 either side of the
path; at a flagged corner the band's outer edges meet as the join says: round adds a disc of radius
h, a miter adds the intersection of the two offset lines unless the miter ratio 1/sin(theta/2) is
over stroke-miterlimit (then a bevel, which adds nothing beyond the band corners); at an open end a
square cap adds h along the path, a round cap a disc, a butt cap nothing.  A non-scaling stroke is
banded after the viewBox scaling with h = w/2 in container pixels; every other stroke scales with
the geometry.
"""
import math


def _layout(view_box, par, size):
    vx, vy, vw, vh = view_box
    align, mode = par
    scale = (min if mode == "meet" else max)(size / vw, size / vh)
    free_x, free_y = size - vw * scale, size - vh * scale
    fx = {"xMin": 0.0, "xMid": 0.5, "xMax": 1.0}[align[:4]] * free_x
    fy = {"YMin": 0.0, "YMid": 0.5, "YMax": 1.0}[align[4:]] * free_y
    return scale, fx - vx * scale, fy - vy * scale


def _dir(a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy)
    return (dx / L, dy / L)


def _band_points(sub, h, join, cap, limit):
    """Every point that can be an extreme of the stroked band of one subpath."""
    P, C, closed = sub["pts"], sub["corner"], sub["closed"]
    n = len(P)
    extremes = []
    edges = list(range(n - 1)) + ([n - 1] if closed else [])      # edge k runs P[k] -> P[(k+1) % n]
    tangent = {}
    for k in edges:
        a, b = P[k], P[(k + 1) % n]
        t = _dir(a, b)
        tangent[k] = t
        ox, oy = -t[1] * h, t[0] * h
        extremes += [(a[0] + ox, a[1] + oy), (a[0] - ox, a[1] - oy), (b[0] + ox, b[1] + oy), (b[0] - ox, b[1] - oy)]
    for i in range(n):
        if not C[i]:
            continue
        if closed:
            t_in, t_out = tangent[(i - 1) % n], tangent[i]
        elif 1 <= i <= n - 2:
            t_in, t_out = tangent[i - 1], tangent[i]
        else:
            continue
        v = P[i]
        if join == "round":
            extremes += [(v[0] - h, v[1] - h), (v[0] + h, v[1] + h)]
        elif join == "miter":
            # outward direction of the corner, and the outer offset normals
            ox, oy = t_in[0] - t_out[0], t_in[1] - t_out[1]
            L = math.hypot(ox, oy)
            if L < 1e-9:
                continue
            ox, oy = ox / L, oy / L
            n_in = (-t_in[1], t_in[0])
            if n_in[0] * ox + n_in[1] * oy < 0:
                n_in = (-n_in[0], -n_in[1])
            n_out = (-t_out[1], t_out[0])
            if n_out[0] * ox + n_out[1] * oy < 0:
                n_out = (-n_out[0], -n_out[1])
            dot = n_in[0] * n_out[0] + n_in[1] * n_out[1]            # cos(phi), phi the turn angle
            cos_half = math.sqrt(max(0.0, (1.0 + dot) / 2.0))        # cos(phi/2) = sin(theta/2)
            if cos_half < 1e-9:
                continue
            if 1.0 / cos_half <= limit:
                # intersection of the two outer offset lines
                sx, sy = n_in[0] + n_out[0], n_in[1] + n_out[1]
                f = h / (1.0 + dot)
                extremes.append((v[0] + f * sx, v[1] + f * sy))
    if not closed:
        t0 = tangent[0]
        t1 = tangent[n - 2]
        for p, out_dir in ((P[0], (-t0[0], -t0[1])), (P[-1], t1)):
            if cap == "round":
                extremes += [(p[0] - h, p[1] - h), (p[0] + h, p[1] + h)]
            elif cap == "square":
                nx, ny = -out_dir[1], out_dir[0]
                base = (p[0] + h * out_dir[0], p[1] + h * out_dir[1])
                extremes += [(base[0] + h * nx, base[1] + h * ny), (base[0] - h * nx, base[1] - h * ny)]
    return extremes


def _arc_lengths(P, closed):
    ring = P + ([P[0]] if closed else [])
    acc = [0.0]
    for a, b in zip(ring, ring[1:]):
        acc.append(acc[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return ring, acc


def _point_at(ring, acc, s):
    lo, hi = 0, len(acc) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if acc[mid] <= s:
            lo = mid
        else:
            hi = mid
    span = acc[hi] - acc[lo]
    f = 0.0 if span == 0 else (s - acc[lo]) / span
    a, b = ring[lo], ring[hi]
    return (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f), lo


def _dashes(sub, pattern, offset):
    """Intervals of arc length that the dash pattern paints, each turned into an open run."""
    pattern = list(pattern) * (1 if len(pattern) % 2 == 0 else 2)
    period = sum(pattern)
    ring, acc = _arc_lengths(sub["pts"], sub["closed"])
    flags = sub["corner"] + ([False] if sub["closed"] else [])
    total = acc[-1]
    on_intervals = []
    start = -(offset % period)
    while start < total:
        t = start
        for k, length in enumerate(pattern):
            if k % 2 == 0:
                a, b = max(t, 0.0), min(t + length, total)
                if b > a:
                    on_intervals.append((a, b))
            t += length
        start += period
    runs = []
    for a, b in on_intervals:
        pa, ia = _point_at(ring, acc, a)
        pb, ib = _point_at(ring, acc, b)
        pts = [pa] + [ring[i] for i in range(ia + 1, ib + 1) if a < acc[i] < b] + [pb]
        crn = [False] + [flags[i] for i in range(ia + 1, ib + 1) if a < acc[i] < b] + [False]
        clean, cf = [], []
        for q, c in zip(pts, crn):
            if clean and math.hypot(q[0] - clean[-1][0], q[1] - clean[-1][1]) < 1e-12:
                continue
            clean.append(q); cf.append(c)
        if len(clean) >= 2:
            runs.append({"pts": clean, "corner": cf, "closed": False})
    return runs


def _resolved(el, host):
    """An element's own value where it has one, else the value the host svg passes down."""
    width = el["width"] if el["width"] is not None else host["width"]
    join = el["join"] if el["join"] is not None else host["join"]
    cap = el["cap"] if el["cap"] is not None else host["cap"]
    return width, join, cap


def paint_one(symbol, size, host):
    scale, tx, ty = _layout(symbol["viewBox"], symbol["par"], size)
    xs, ys = [], []
    for el in symbol["elements"]:
        width, join, cap = _resolved(el, host)
        band = (width if el["nss"] else width * scale) / 2.0
        subs = el["subpaths"]
        if el["fill"]:
            for sub in subs:
                xs += [x * scale + tx for x, _ in sub["pts"]]
                ys += [y * scale + ty for _, y in sub["pts"]]
        if el["stroke"] and el.get("dash"):
            subs = [run for sub in subs for run in _dashes(sub, el["dash"], el.get("dashoffset", 0.0))]
        for sub in subs:
            placed = {"pts": [(x * scale + tx, y * scale + ty) for x, y in sub["pts"]],
                      "corner": sub["corner"], "closed": sub["closed"]}
            if el["stroke"]:
                for x, y in _band_points(placed, band, join, cap, el["limit"]):
                    xs.append(x)
                    ys.append(y)
    return [min(xs), min(ys), max(xs), max(ys)]


def paint(symbols, placements, library):
    by_id = {s["id"]: s for s in symbols}
    return {p["placement"]: paint_one(by_id[p["symbol"]], p["size_px"], p["host"]) for p in placements}
