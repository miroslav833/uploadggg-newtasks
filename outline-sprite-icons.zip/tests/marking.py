"""Reads a filing as text and counts the placements it gets right.  Nothing in the filing is run.

A placement is right when it is filed exactly once, all four edges parse as finite numbers, and
each edge is within `tol` pixels of the key.  A missing, duplicated or non-finite placement is wrong.
"""
import csv
import io
import math

EDGES = ("left", "top", "right", "bottom")


def parse(text):
    rows = {}
    reader = csv.DictReader(io.StringIO(text))
    for row in reader:
        if row is None:
            continue
        pc = (row.get("placement") or "").strip()
        if not pc:
            continue
        rows.setdefault(pc, []).append(row)
    return rows


def score(text, expected, tol):
    rows = parse(text)
    right = 0
    detail = {}
    for pc, key in expected.items():
        filed = rows.get(pc, [])
        if len(filed) != 1:
            detail[pc] = "missing" if not filed else "duplicated"
            continue
        ok = True
        for name, want in zip(EDGES, key):
            raw = (filed[0].get(name) or "").strip()
            try:
                got = float(raw)
            except ValueError:
                ok = False
                break
            if not math.isfinite(got):
                ok = False
                break
            if abs(got - want) > tol:
                ok = False
                break
        detail[pc] = "right" if ok else "wrong"
        right += ok
    return right, len(expected), detail
