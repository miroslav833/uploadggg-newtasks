"""Runs the solver's tool on each held-out page and decides, page by page, whether every placement's
painted extent is within TOL px of the key.  Nothing the tool writes is executed; its output is read as
text from a regular file of bounded size after every process of the tool's account has been stopped."""
import csv, io, json, math, os, resource, shutil, signal, subprocess, time

HELD = "/tests/held"
TOOL = "/app/painter/extent.py"
TOL = 0.10            # px, every edge of every placement
RUN_UID = 61473       # a numeric account with no passwd entry, no groups
SECONDS = 120
MAX_OUT = 1 << 16


def _limits():
    os.setsid()
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
    resource.setrlimit(resource.RLIMIT_CPU, (SECONDS, SECONDS))
    resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
    os.setgroups([])
    os.setgid(RUN_UID)
    os.setuid(RUN_UID)


def _stop_account():
    for _ in range(3):
        for pid in os.listdir("/proc"):
            if pid.isdigit():
                try:
                    if os.stat("/proc/" + pid).st_uid == RUN_UID:
                        os.kill(int(pid), signal.SIGKILL)
                except (FileNotFoundError, ProcessLookupError, PermissionError):
                    pass
        time.sleep(0.2)


def _read_output(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return None
    try:
        st = os.fstat(fd)
        if not (st.st_mode & 0o170000 == 0o100000) or st.st_size > MAX_OUT:
            return None
        return os.read(fd, MAX_OUT).decode("utf-8", "replace")
    finally:
        os.close(fd)


def judge(text, key):
    rows = {}
    for row in csv.DictReader(io.StringIO(text or "")):
        pc = (row.get("placement") or "").strip()
        if pc:
            rows.setdefault(pc, []).append(row)
    misses = []
    for pc, want in key.items():
        got = rows.get(pc, [])
        if len(got) != 1:
            misses.append(pc); continue
        try:
            vals = [float(got[0][k]) for k in ("left", "top", "right", "bottom")]
        except (KeyError, TypeError, ValueError):
            misses.append(pc); continue
        if not all(math.isfinite(v) for v in vals) or any(abs(v - w) > TOL for v, w in zip(vals, want)):
            misses.append(pc)
    return misses


def run_all(keys):
    results = {}
    for name in sorted(keys):
        work = "/run/pagecheck/" + name
        shutil.rmtree(work, ignore_errors=True)
        shutil.copytree(os.path.join(HELD, name), work + "/page")
        os.makedirs(work + "/out")
        os.chown(work + "/out", RUN_UID, RUN_UID)
        os.chmod("/run/pagecheck", 0o711)
        for root, dirs, files in os.walk(work):
            os.chmod(root, 0o755)
            for f in files:
                os.chmod(os.path.join(root, f), 0o644)
        out = work + "/out/extents.csv"
        try:
            subprocess.run(["python3", TOOL, work + "/page", out], preexec_fn=_limits, cwd=work + "/out",
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=SECONDS, env={"PATH": "/usr/local/bin:/usr/bin:/bin"})
        except subprocess.TimeoutExpired:
            pass
        _stop_account()
        misses = judge(_read_output(out), keys[name])
        results[name] = misses
        os.chmod("/run/pagecheck", 0o700)
    return results
