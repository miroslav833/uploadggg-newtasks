Write a program that, for any production page of our icon system, gives the painted extent of every icon placed on it, so the design team can audit pages for clipped strokes before they ship. It should run as

```
python3 /app/painter/extent.py PAGE_DIR OUT_FILE
```

where PAGE_DIR is one page folder as the page-audit export writes it. `/app/pages/README.md` describes a page folder, how the page places an icon and what the QA captures in it are. Four sample pages are in `/app/pages`, each with an `expected.csv` holding its reviewed extents.

OUT_FILE must be a CSV with a header row and one row per placement in the page's `placements.csv`:

```
placement,left,top,right,bottom
P00,-1.25,3.50,17.25,12.50
```

`left`, `top`, `right` and `bottom` are the edges, in CSS pixels from the placement's icon box's top-left corner (x to the right, y down), of the smallest axis-aligned box containing every pixel the symbol's fills and strokes paint on the production page, as a browser renders SVG and CSS. No clipping applies: neither the container's overflow nor the symbol's own viewport cuts the paint, so an edge may be negative or beyond the box. Lengths are CSS pixels at a device pixel ratio of 1. Give each edge to two decimals.

Grading runs your program on 20 other pages that are not in `/app/pages`; they are written the same way but use parts of SVG and CSS the four samples do not. A page counts when every placement on it is filed exactly once with all four edges within 0.10 px of the reference; a missing, repeated or non-numeric row fails the page. At least 17 of the 20 pages must count. For grading, each page is a fresh copy, the program runs as an unprivileged user under the image's python3 with the standard library only, and it gets 120 seconds per page. Anything the program needs must be in `/app/painter`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
