For each of the 78 icon placements listed in `/app/sprite/placements.csv`, file the painted extent of the icon inside its container as the production page renders it.

`/app/sprite/icons.svg` is an SVG sprite of 26 `<symbol>` elements, each with a `viewBox` and some with `preserveAspectRatio`, holding `<path>`, `<circle>` and `<rect>` elements with presentation attributes, in places inside `<g transform>` groups. `/app/sprite/icons.css` is the stylesheet the page loads for the icons: the context containers, `.icon` and three size classes. `/app/sprite/placements.csv` has one row per placement: `placement`, `symbol` (the symbol id), `size_class` and `context`. `/app/qa/captures.png` and `/app/qa/captures.csv` are the QA crawl's captures of live placements on the production page, with each capture's symbol, size class, context and pixel position. `/app/sprite/export-notes.md` says how the sprite was exported and how the page places a symbol: `<div class="hero"><svg class="icon icon--md"><use href="#id"/></svg></div>`, with the placement's context as the container's class.

Write `/app/out/icons.csv` with a header row and one row per placement:

```
placement,left,top,right,bottom
P00,-1.25,3.50,17.25,12.50
```

`left`, `top`, `right` and `bottom` are the edges, in CSS pixels from the container's top-left corner (x to the right, y down), of the smallest axis-aligned box that contains every pixel the symbol's fills and strokes paint when the page places it at that size class, as a browser renders SVG. No clipping applies: neither the container's overflow nor the symbol's own viewport cuts the paint, so an edge may be negative or beyond the container's size. Lengths are CSS pixels on a display with a device pixel ratio of 1. Give each edge to two decimals. A row is right when all four edges are within 0.10 px of the reference; a placement that is missing, filed twice or has a non-numeric edge is wrong. At least 70 of the 78 rows must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
