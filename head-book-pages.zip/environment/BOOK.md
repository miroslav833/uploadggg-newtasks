# Book files

Production exports every paginated book as a text file, `NAME.book`. The pages are final:
the book has been made up and nothing will move. All that is left is to set the folio
(page number) and the running head on each page. Every book comes with `NAME.proof.csv`,
which is the designer's proof of a handful of its pages, showing the running heads as the
book's design wants them.

For page make-up the house follows *The Chicago Manual of Style*, 17th edition. That covers
how pages are numbered, which pages carry a folio or a running head, how endnote pages are
headed, and how a range of pages is written. The running-head design is chosen book by book.

## NAME.book

One statement per line. Blank lines and lines starting with `#` are ignored. Quoted values
are written in double quotes.

```
book b07
title Broken Bridges of the Adriatic
runningtitle Broken Bridges
author Vera Ruiz
div F2 preface "Preface"
div P1 part "Quiet Harbours" label "Part One"
div C3 chapter "Narrow Glassworks of the Highlands" number "3" part "P1" short "Narrow Glassworks"
div C3.2 sub "Ancient Lighthouses" chapter "C3"
div N notes "Notes"
page 1 halftitle
page 9 opener F2
page 41 text C3 top=C3.1 starts=C3.2
page 44 figure C3 top=C3.2
page 212 text N cites=118,118,121,126
```

- `title`, `runningtitle`, `author`: the book's full title, the shortened title the design uses
  in running heads, and the author's name as it appears in heads.
- `div ID KIND "TITLE" [key "value" ...]` declares a division. Kinds:
  - **Front matter:** `contents`, `illustrations`, `foreword`, `preface`, `acknowledgments`,
    `abbreviations`.
  - **Text:** `intro` (an introduction belonging to the text), `part`, `chapter`, `sub` (a
    first-level subhead within a chapter).
  - **Back matter:** `appendix`, `notes` (endnotes), `bibliography`, `index`.

  Optional keys: `short` (the shortened form of the title for running heads), `label`
  (a part's label), `number` (a chapter's number), `part` (the part a chapter belongs to),
  `chapter` (the chapter a subhead belongs to).
- `page N KIND [DIV] [top=SUB] [starts=SUB,SUB] [cites=P,P,...]` is one page. N counts every
  physical page from the first leaf, and odd N is a recto. Kinds:
  - `halftitle`, `series` (a series page), `title`, `copyright`, `dedication`, `epigraph`.
  - `halftitle2`: a second half title before the text.
  - `blank`.
  - `part`: a part-title page; DIV is the part.
  - `opener`: the opening page of DIV.
  - `text`: a page of running text in DIV.
  - `figure` or `table`: a page holding nothing but an illustration or a table, in DIV.

  On chapter pages, `top=` names the subhead in force at the top of the page (`-` when the
  chapter's first subhead has not yet come), and `starts=` lists the subheads that begin on
  the page, in order. On endnote pages, `cites=` gives, for each note on the page in order, the
  page N of the text page where that note's reference number appears.

## The running-head design

Each book's design makes one choice on each of the following, and the house's designs differ
on all of them:

- **What the verso heads of the text name:** the running title, the author, the part (the
  running title on pages outside any part), or the chapter.
- **What the recto heads of the text name:** the chapter, or a subhead (the chapter on pages
  before its first subhead). If the verso names the chapter, the recto names a subhead.
- **Which subhead a recto names:** the one in force at the top of the page, the first that
  begins on the page, or the last that begins on it. Each of the last two falls back to the
  subhead in force at the top when none begins on the page.
- **Front and back matter text pages:** either the running title on versos and the section's
  name on rectos, or the section's name on both.
- **Letter case:** heads as written, or in capitals.

An introduction that belongs to the text is headed like a chapter with no part and no
subheads. A division's `short` title stands in for its title wherever a head names it.

## NAME.proof.csv

The designer's proof. There is a header line, then one line per proofed page, giving the
running head exactly as it must appear:

```
page,head
14,Broken Bridges
15,Preface
```

## NAME.heads.csv (what the desk needs)

There is a header line, then one line for every page of the book in page order:

```
page,folio,head
1,,
9,ix,
41,27,Ancient Lighthouses
```

`folio` is the number printed on the page, in lowercase roman or arabic figures. It is left
empty when no number is printed there. `head` is the running head printed on the page,
left empty when there is none. A range of pages inside a head uses an en dash (U+2013).
