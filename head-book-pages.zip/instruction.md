Our production desk has to put the folio and the running head on every page of each book before final pages go to the printer, and I need a program that does this. Put it at `/app/makeup/heads.py`. The desk will run it like this:

```
python3 /app/makeup/heads.py IN_DIR OUT_DIR
```

Each book in IN_DIR comes as two files, `NAME.book` and `NAME.proof.csv`. Both formats are explained in `/app/BOOK.md`. The first is the book's finished pagination, giving each page's kind, its division, the subheads that begin on it, and the pages its endnotes are cited from. The second is the designer's proof of a few pages, showing their running heads. For each book, write `NAME.heads.csv` to OUT_DIR, one line per page:

```
page,folio,head
41,27,Ancient Lighthouses
```

Set every page the way our house would: Chicago Manual of Style page make-up, together with the running-head design of that book, which you can read off its proof. In `/app/samples` there are four books, each with its proof and the heads file the desk produced for it. Grading uses twenty other books. They are longer, and they include features and designs that the samples don't show.

A page is wrong when its folio or head differs from the desk's, or when it is missing or extra. A book is accepted with up to 2 wrong pages, and 18 of the twenty books must be accepted. Grading runs the program a single time over a folder of the twenty books, under an unprivileged account, using the image's python3 and the standard library alone. The program can only see `/app/makeup`, and a run over 120 seconds is stopped.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
