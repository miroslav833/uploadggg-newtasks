import csv
import hashlib
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import booksetter  # noqa: E402
import bookrun     # noqa: E402

PINS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pins.json")


def test_sealed_heads_files_are_pinned():
    pins = json.load(open(PINS))
    assert sorted(pins) == bookrun.names() and len(pins) == 20
    for n, digest in pins.items():
        with open(os.path.join(bookrun.SEALED, n + ".heads.csv"), "rb") as f:
            assert hashlib.sha256(f.read()).hexdigest() == digest, n


def test_sealed_heads_follow_from_each_book_and_its_proof():
    for n in bookrun.names():
        sealed = json.load(open(os.path.join(bookrun.SEALED, n + ".json")))["book"]
        with open(os.path.join(bookrun.SEALED, n + ".proof.csv"), newline="", encoding="utf-8") as f:
            proof = [(int(r["page"]), r["head"]) for r in csv.DictReader(f)]
        rebuilt = {p: (f, h) for p, f, h in booksetter.set_book(sealed, proof)}
        assert rebuilt == bookrun.sealed_heads(n), n


def test_enough_books_set_as_the_desk_sets_them():
    assert os.path.isfile(bookrun.PROGRAM), "nothing at /app/makeup/heads.py"
    wrong = bookrun.grade()
    ok = sorted(n for n, w in wrong.items() if w <= bookrun.PAGES_ALLOWED)
    print("books accepted: %d of %d; wrong pages: %s"
          % (len(ok), len(wrong), " ".join("%s=%d" % kv for kv in sorted(wrong.items()))))
    assert len(ok) >= bookrun.BOOKS_NEEDED, "%d of 20 books accepted, %d needed" % (len(ok), bookrun.BOOKS_NEEDED)
