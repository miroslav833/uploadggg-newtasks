"""One supervised run of the solver's heads.py over the sealed books.

Only the books and their proofs are staged, in a root-owned folder anyone may read; the sealed heads files and
the structured books stay in /tests, which only root can open. The output folder belongs to
an unused numeric account, and the program runs as that account in a session of its own under
memory, file-size, process and wall-clock limits. When it returns, every process left under the
account is killed before any output is read. Outputs are opened with O_NOFOLLOW, taken only if
they are regular files no larger than 4 MiB, and parsed as text.
"""
import csv
import os
import pwd
import resource
import shutil
import signal
import subprocess
import time

SEALED = "/tests/vault"
PROGRAM = "/app/makeup/heads.py"
WORK = "/var/tmp/bookrun"
SECONDS = 120           # budget for the whole folder
PAGES_ALLOWED = 2       # wrong pages a book may have and still pass
BOOKS_NEEDED = 18       # of 20
CAP = 4 << 20


def names():
    return sorted(f[:-5] for f in os.listdir(SEALED) if f.endswith(".book"))


def holders(uid):
    pids = []
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    pids.append(int(d))
            except FileNotFoundError:
                pass
    return pids


def unused_uid(base=47311):
    known = {p.pw_uid for p in pwd.getpwall()}
    while base in known or holders(base):
        base += 1
    return base


def kill_all(uid):
    for _ in range(400):
        left = holders(uid)
        if not left:
            return
        for pid in left:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def parse_heads(text):
    """{page: (folio, head)}; a line without a whole page number is skipped, and a page given
    twice counts as given wrong."""
    out, seen = {}, set()
    for row in csv.reader(text.splitlines()[1:]):
        if len(row) != 3 or not row[0].strip().isdigit():
            continue
        page = int(row[0])
        out[page] = None if page in seen else (row[1], row[2])
        seen.add(page)
    return out


def sealed_heads(name):
    with open(os.path.join(SEALED, name + ".heads.csv"), encoding="utf-8") as f:
        return parse_heads(f.read())


def read_output(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NOCTTY)
    except OSError:
        return {}
    try:
        info = os.fstat(fd)
        if not os.path.stat.S_ISREG(info.st_mode) or info.st_size > CAP:
            return {}
        raw = os.read(fd, CAP)
    finally:
        os.close(fd)
    return parse_heads(raw.decode("utf-8", errors="replace"))


def wrong_pages(key, got):
    return sum(1 for p in set(key) | set(got) if key.get(p) != got.get(p))


def grade():
    """-> {book: wrong pages}"""
    uid = unused_uid()
    shutil.rmtree(WORK, ignore_errors=True)
    src, dst = os.path.join(WORK, "books"), os.path.join(WORK, "heads")
    os.makedirs(src)
    os.makedirs(dst)
    for n in names():
        for ext in (".book", ".proof.csv"):
            shutil.copyfile(os.path.join(SEALED, n + ext), os.path.join(src, n + ext))
            os.chmod(os.path.join(src, n + ext), 0o644)
    os.chmod(WORK, 0o755)
    os.chmod(src, 0o755)
    os.chown(dst, uid, uid)
    os.chmod(dst, 0o700)

    def drop():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        os.setgid(uid)
        os.setuid(uid)

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": dst, "LANG": "C.UTF-8",
           "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        # called as the instruction documents: python3 heads.py IN_DIR OUT_DIR
        subprocess.run(["python3", PROGRAM, src, dst], cwd=dst, env=env, preexec_fn=drop,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=SECONDS)
    except subprocess.TimeoutExpired:
        pass
    finally:
        kill_all(uid)
    return {n: wrong_pages(sealed_heads(n), read_output(os.path.join(dst, n + ".heads.csv")))
            for n in names()}
