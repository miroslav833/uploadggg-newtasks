"""The verifier's own page make-up, written apart from any solver code.

set_book(book, proof) -> [(page, folio, head), ...] for a book in its structured form
(divisions and pages as the generator sealed them) and its proof [(page, head), ...].
"""
import itertools

DISPLAY = ("halftitle", "series", "title", "copyright", "dedication", "epigraph", "blank", "halftitle2", "part")
HEADLESS = DISPLAY + ("opener", "figure", "table")
MATTER_KINDS = ("contents", "foreword", "preface", "acknowledgments", "abbreviations", "illustrations",
                "appendix", "bibliography", "index")
ROMAN = (("m", 1000), ("cm", 900), ("d", 500), ("cd", 400), ("c", 100), ("xc", 90), ("l", 50),
         ("xl", 40), ("x", 10), ("ix", 9), ("v", 5), ("iv", 4), ("i", 1))


def to_roman(n):
    s = []
    for sym, val in ROMAN:
        q, n = divmod(n, val)
        s.append(sym * q)
    return "".join(s)


def page_range(a, b):
    """Chicago 9.61: all digits under 100 or from a multiple of 100; changed digits only from
    x01-x09; at least two digits otherwise."""
    if a == b:
        return str(a)
    x, y = str(a), str(b)
    if a < 100 or a % 100 == 0 or len(x) != len(y):
        return "%s–%s" % (x, y)
    first_diff = min(i for i in range(len(x)) if x[i] != y[i])
    tail = y[first_diff:] if a % 100 <= 9 else y[min(first_diff, len(y) - 2):]
    return "%s–%s" % (x, tail)


def numbering(book):
    divs = book["divs"]
    text_start = next(p["n"] for p in book["pages"]
                      if p["kind"] in ("halftitle2", "part")
                      or (p["kind"] == "opener" and divs[p["div"]]["kind"] in ("chapter", "intro")))
    return {p["n"]: (to_roman(p["n"]) if p["n"] < text_start else str(p["n"] - text_start + 1))
            for p in book["pages"]}


def label(d):
    return d.get("short") or d["title"]


def running_head(book, p, design, number):
    verso_names, recto_names, which_sub, matter, capitals = design
    if p["kind"] in HEADLESS:
        return ""
    divs = book["divs"]
    d = divs[p["div"]]
    on_recto = p["n"] % 2 == 1
    if d["kind"] == "notes":
        lo = int(number[min(p["cites"])])
        hi = int(number[max(p["cites"])])
        text = "Notes to Page %d" % lo if lo == hi else "Notes to Pages %s" % page_range(lo, hi)
    elif d["kind"] in MATTER_KINDS:
        text = label(d) if on_recto or matter == "section-section" else book["runningtitle"]
    elif not on_recto:
        if verso_names == "book":
            text = book["runningtitle"]
        elif verso_names == "author":
            text = book["author"]
        elif verso_names == "part":
            pid = d.get("part")
            text = label(divs[pid]) if pid else book["runningtitle"]
        else:
            text = label(d)
    elif recto_names == "chapter" or d["kind"] == "intro":
        text = label(d)
    else:
        chosen = p.get("top")
        if p.get("starts") and which_sub != "top":
            chosen = p["starts"][0] if which_sub == "first" else p["starts"][-1]
        text = label(divs[chosen]) if chosen else label(d)
    return text.upper() if capitals == "capitals" else text


def designs():
    for v, r, w, m, c in itertools.product(("chapter", "part", "author", "book"), ("subhead", "chapter"),
                                           ("last", "first", "top"), ("section-section", "title-section"),
                                           ("capitals", "as-set")):
        if (v == "chapter" and r == "chapter") or (r == "chapter" and w != "top"):
            continue
        yield v, r, w, m, c


def set_book(book, proof):
    number = numbering(book)
    pages = {p["n"]: p for p in book["pages"]}
    design = next(x for x in designs() if all(running_head(book, pages[n], x, number) == h for n, h in proof))
    out = []
    for p in book["pages"]:
        folio = "" if p["kind"] in DISPLAY else number[p["n"]]
        out.append((p["n"], folio, running_head(book, p, design, number)))
    return out
