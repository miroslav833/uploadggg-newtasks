#!/bin/bash
# Grading entry point. Root takes /logs/verifier and shuts it (700) before the solver's program
# can run; afterwards the folder holds the reward and the test report only.
umask 077
OUT=/logs/verifier
mkdir -p /logs/verifier
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier
if [ "$(stat -c %u:%a /logs/verifier)" != "0:700" ]; then
    echo "could not shut $OUT; not grading" >&2
    exit 0
fi
find "$OUT" -mindepth 1 -exec rm -rf {} + 2>/dev/null
echo 0 > "$OUT/reward.txt"
TMPD=$(mktemp -d /run/books-XXXXXX)
cd /tests || exit 0
verdict=0
python3 -m pytest -q -rA -p no:cacheprovider -s --ctrf "$TMPD/ctrf.json" test_books.py && verdict=1
find "$OUT" -mindepth 1 ! -user 0 -exec rm -rf {} + 2>/dev/null
rm -f "$OUT/reward.json"
cp "$TMPD/ctrf.json" "$OUT/ctrf.json" 2>/dev/null
echo "$verdict" > "$OUT/reward.txt"
find "$OUT" -mindepth 1 -type f -exec chmod 644 {} +
chmod 755 "$OUT"
exit 0
