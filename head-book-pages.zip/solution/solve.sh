#!/bin/bash
# Installs the reference page make-up and checks it on the four sample books.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/makeup
cp "$HERE/makeup/heads.py" /app/makeup/heads.py
CHECK=$(mktemp -d)
INP=$(mktemp -d)
cp /app/samples/*.book /app/samples/*.proof.csv "$INP"/
python3 /app/makeup/heads.py "$INP" "$CHECK"
for f in /app/samples/*.heads.csv; do
    cmp -s "$f" "$CHECK/$(basename "$f")" || { echo "sample differs: $(basename "$f")"; exit 1; }
done
echo "heads.py sets all $(ls /app/samples/*.heads.csv | wc -l) sample books as the desk did"
