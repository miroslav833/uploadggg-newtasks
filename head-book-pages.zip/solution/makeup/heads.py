#!/usr/bin/env python3
"""Folios and running heads for paginated books, set as the house sets them.

Usage: python3 heads.py IN_DIR OUT_DIR

For every NAME.book in IN_DIR (with NAME.proof.csv beside it) writes NAME.heads.csv.
Page practice follows the Chicago Manual of Style: roman folios from the half title, arabic
page 1 at the first page of the text proper, blind folios on display and blank pages, no
running heads on openers, display, blank, figure and table pages, endnote heads reading
"Notes to Pages" with the cited text folios in CMS inclusive-number style. The running-head
scheme of each book is the one of the design dimensions that reproduces its proof.
"""
import csv
import itertools
import os
import shlex
import sys

FRONT = {"contents", "foreword", "preface", "acknowledgments", "abbreviations", "illustrations"}
BACK = {"appendix", "bibliography", "index"}
BLIND = {"halftitle", "series", "title", "copyright", "dedication", "epigraph", "blank", "halftitle2", "part"}
NO_HEAD = BLIND | {"opener", "figure", "table"}

VERSO = ("book", "author", "part", "chapter")
RECTO = ("chapter", "subhead")
PICK = ("top", "first", "last")
MATTER = ("title-section", "section-section")
CASE = ("as-set", "capitals")


def roman(n):
    out = ""
    for v, s in ((1000, "m"), (900, "cm"), (500, "d"), (400, "cd"), (100, "c"), (90, "xc"),
                 (50, "l"), (40, "xl"), (10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")):
        while n >= v:
            out += s
            n -= v
    return out


def inclusive(a, b):
    """CMS 9.61 inclusive numbers."""
    if a == b:
        return str(a)
    sa, sb = str(a), str(b)
    if a < 100 or a % 100 == 0 or len(sa) != len(sb):
        return sa + "–" + sb
    i = next(k for k in range(len(sa)) if sa[k] != sb[k])
    if a % 100 < 10:
        return sa + "–" + sb[i:]
    keep = max(2, len(sb) - i)
    return sa + "–" + sb[-keep:]


def read_book(path):
    book = {"divs": {}, "pages": []}
    for raw in open(path, encoding="utf-8"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        w = shlex.split(line)
        key = w[0]
        if key in ("book", "title", "runningtitle", "author"):
            book[key] = " ".join(w[1:])
        elif key == "div":
            d = {"id": w[1], "kind": w[2], "title": w[3]}
            rest = w[4:]
            for j in range(0, len(rest), 2):
                d[rest[j]] = rest[j + 1]
            book["divs"][d["id"]] = d
        elif key == "page":
            p = {"n": int(w[1]), "kind": w[2], "div": None, "top": None, "starts": [], "cites": []}
            for tok in w[3:]:
                if "=" in tok:
                    k, v = tok.split("=", 1)
                    if k == "top":
                        p["top"] = None if v == "-" else v
                    elif k == "starts":
                        p["starts"] = [x for x in v.split(",") if x]
                    elif k == "cites":
                        p["cites"] = [int(x) for x in v.split(",") if x]
                else:
                    p["div"] = tok
            book["pages"].append(p)
    return book


def folios(book):
    pages = book["pages"]
    start = None
    for p in pages:
        d = book["divs"].get(p["div"]) if p["div"] else None
        if p["kind"] in ("halftitle2", "part") or (p["kind"] == "opener" and d and d["kind"] in ("intro", "chapter")):
            start = p["n"]
            break
    out = {}
    for p in pages:
        num = roman(p["n"]) if p["n"] < start else str(p["n"] - start + 1)
        out[p["n"]] = (num, "" if p["kind"] in BLIND else num)
    return out


def short(d):
    return d.get("short", d["title"])


def head(book, p, scheme, fol):
    if p["kind"] in NO_HEAD:
        return ""
    verso_s, recto_s, pick, matter, case = scheme
    divs = book["divs"]
    d = divs[p["div"]]
    recto = p["n"] % 2 == 1
    if d["kind"] == "notes":
        lo, hi = min(p["cites"]), max(p["cites"])
        a, b = int(fol[lo][0]), int(fol[hi][0])
        h = ("Notes to Page %d" % a) if a == b else ("Notes to Pages " + inclusive(a, b))
    elif d["kind"] in FRONT or d["kind"] in BACK:
        h = short(d) if (recto or matter == "section-section") else book["runningtitle"]
    else:
        part = divs.get(d.get("part")) if d["kind"] == "chapter" else None
        if not recto:
            h = {"book": book["runningtitle"], "author": book["author"],
                 "part": short(part) if part else book["runningtitle"], "chapter": short(d)}[verso_s]
        elif recto_s == "chapter" or d["kind"] == "intro":
            h = short(d)
        else:
            sub = p["top"]
            if pick == "first" and p["starts"]:
                sub = p["starts"][0]
            elif pick == "last" and p["starts"]:
                sub = p["starts"][-1]
            h = short(divs[sub]) if sub else short(d)
    return h.upper() if case == "capitals" else h


def schemes():
    for s in itertools.product(VERSO, RECTO, PICK, MATTER, CASE):
        if s[0] == "chapter" and s[1] == "chapter":
            continue
        if s[1] == "chapter" and s[2] != "top":
            continue
        yield s


def fit(book, proof):
    fol = folios(book)
    bypage = {p["n"]: p for p in book["pages"]}
    for s in schemes():
        if all(head(book, bypage[n], s, fol) == h for n, h in proof):
            return s
    return ("book", "chapter", "top", "title-section", "as-set")


def read_proof(path):
    with open(path, newline="", encoding="utf-8") as f:
        return [(int(r["page"]), r["head"]) for r in csv.DictReader(f)]


def setting(book, scheme):
    fol = folios(book)
    return [(p["n"], fol[p["n"]][1], head(book, p, scheme, fol)) for p in book["pages"]]


def main():
    src, dst = sys.argv[1], sys.argv[2]
    os.makedirs(dst, exist_ok=True)
    for fn in sorted(os.listdir(src)):
        if not fn.endswith(".book"):
            continue
        name = fn[:-5]
        book = read_book(os.path.join(src, fn))
        scheme = fit(book, read_proof(os.path.join(src, name + ".proof.csv")))
        with open(os.path.join(dst, name + ".heads.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, lineterminator="\n")
            w.writerow(["page", "folio", "head"])
            w.writerows(setting(book, scheme))


if __name__ == "__main__":
    main()
