#!/usr/bin/env python3
"""Predicts the colour every artwork patch of a press run prints at, from the run's own strip.

    python3 predict.py RUN_DIR OUT_CSV

The run is characterised from its strip alone:
  * ink strength by zone: each ink's solids give its absorbance spectrum (log of solid over paper);
    their sizes across the zones are fitted with a straight line along the sheet;
  * unit order and trap: each two-ink solid overprint is split into its two inks' absorbances
    (scaled to that patch's zone); the ink that keeps its whole film went down first, the other
    took its own trap share; the pairwise firsts give the unit order, and each ink's trap is the
    mean of its shares over the overprints where it went down second;
  * the stock's optical spread and each ink's tone curve: the tints are a Yule-Nielsen mixture of
    paper and the zone's solid; the spread factor is the one under which every tint is best
    explained, and each ink's effective coverages give its tone value increase curve, whose size
    grows with the ink's film in the zone to one power for the press (tints sit in two zones);
then every patch is the Yule-Nielsen spectral Neugebauer mixture of its Demichel primaries, each
primary built from the inks' absorbances in unit order with the trap.  Colour: CIELAB from the
instrument's weighting table, which every run folder carries (weights.csv).
"""
import csv
import itertools
import os
import sys

import numpy as np

INKS = "CMYK"


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def load(run_dir):
    run = {r["key"]: r["value"] for r in read_csv(os.path.join(run_dir, "run.csv"))}
    strip = []
    for r in read_csv(os.path.join(run_dir, "strip.csv")):
        nm = sorted((int(k[1:]), k) for k in r if k.startswith("r") and k[1:].isdigit())
        spec = np.array([float(r[k]) for _, k in nm])
        cov = {k: float(r[k]) / 100.0 for k in INKS}
        strip.append(dict(zone=int(r["zone"]) - 1, cov=cov, spec=spec))
    art = []
    for r in read_csv(os.path.join(run_dir, "artwork.csv")):
        art.append(dict(patch=r["patch"], zone=int(r["zone"]) - 1, cov={k: float(r[k]) / 100.0 for k in INKS}))
    return run, strip, art


def weights_for(run_dir):
    rows = read_csv(os.path.join(run_dir, "weights.csv"))
    return np.array([[float(r["wx"]), float(r["wy"]), float(r["wz"])] for r in rows])


def to_lab(spec, W):
    X, Y, Z = spec @ W
    Xn, Yn, Zn = W.sum(axis=0)

    def f(t):
        return np.cbrt(t) if t > (6 / 29) ** 3 else t / (3 * (6 / 29) ** 2) + 4 / 29
    fx, fy, fz = f(X / Xn), f(Y / Yn), f(Z / Zn)
    return 116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)


def kind(cov):
    inks = [k for k in INKS if cov[k] > 0]
    solid = all(cov[k] >= 0.999 for k in inks)
    return inks, solid


# ----------------------------------------------------------------------------- characterisation
def characterise(strip):
    paper = np.mean([p["spec"] for p in strip if not kind(p["cov"])[0]], axis=0)
    # ink absorbance by zone: A = film(zone) * D
    D, film = {}, {}
    for k in INKS:
        sol = [p for p in strip if kind(p["cov"]) == ([k], True)]
        A = np.array([-np.log(np.clip(p["spec"], 1e-6, None) / paper) for p in sol])
        z = np.array([p["zone"] for p in sol], float)
        base = A.mean(axis=0)                       # the ink's absorbance at its mean film
        size = A @ base / (base @ base)             # each solid's film relative to that
        c1, c0 = np.polyfit(z, size, 1)
        D[k] = base
        film[k] = lambda zz, c0=c0, c1=c1: c0 + c1 * zz
    # unit order and trap from the two-ink overprints
    first, traps = {}, {k: [] for k in INKS}
    for p in strip:
        inks, solid = kind(p["cov"])
        if len(inks) != 2 or not solid:
            continue
        a, b = inks
        A = -np.log(np.clip(p["spec"], 1e-6, None) / paper)
        M = np.stack([film[a](p["zone"]) * D[a], film[b](p["zone"]) * D[b]], axis=1)
        ma, mb = np.linalg.lstsq(M, A, rcond=None)[0]
        if ma >= mb:
            first[(a, b)] = a
            traps[b].append(mb / ma)
        else:
            first[(a, b)] = b
            traps[a].append(ma / mb)
    trap = {k: float(np.mean(v)) if v else 1.0 for k, v in traps.items()}
    wins = {k: 0 for k in INKS}
    for (a, b), w in first.items():
        wins[w] += 1
    order = "".join(sorted(INKS, key=lambda k: -wins[k]))
    return dict(paper=paper, D=D, film=film, order=order, trap=trap)


def primary(ch, inks, z):
    tot = np.zeros_like(ch["paper"])
    for j, k in enumerate([k for k in ch["order"] if k in inks]):
        tot += ch["film"][k](z) * ch["D"][k] * (1.0 if j == 0 else ch["trap"][k])
    return ch["paper"] * np.exp(-tot)


def spread_and_curves(ch, strip):
    """The stock's spread factor and each ink's tone curve (G, s), from the single-ink tints."""
    tints = [p for p in strip if len(kind(p["cov"])[0]) == 1 and not kind(p["cov"])[1]]

    def coverage(p, n):
        k = kind(p["cov"])[0][0]
        P = primary(ch, [k], p["zone"])
        w0, w1 = ch["paper"] ** (1 / n), P ** (1 / n)
        y = np.clip(p["spec"], 1e-6, None) ** (1 / n)
        d = w1 - w0
        ae = float(d @ (y - w0) / (d @ d))
        res = float(np.sum((w0 + ae * d - y) ** 2) / np.sum(y ** 2))
        return ae, res

    grid = np.arange(1.0, 3.5001, 0.01)
    errs = [sum(coverage(p, n)[1] for p in tints) for n in grid]
    n = float(grid[int(np.argmin(errs))])
    lo, hi = n - 0.01, n + 0.01
    for _ in range(40):
        m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
        e1 = sum(coverage(p, m1)[1] for p in tints)
        e2 = sum(coverage(p, m2)[1] for p in tints)
        lo, hi = (lo, m2) if e1 < e2 else (m1, hi)
    n = 0.5 * (lo + hi)
    # each ink's tone value increase, scaled in every zone by its film there (relative to its mean
    # film) to one power for the press; the power is the one that best explains all tints at once
    pts = {k: [] for k in INKS}
    for p in tints:
        k = kind(p["cov"])[0][0]
        a = p["cov"][k]
        rel = ch["film"][k](p["zone"]) / ch["film"][k](5.5)
        pts[k].append((a, coverage(p, n)[0], rel))

    def fit(power):
        out, err = {}, 0.0
        for k, rows in pts.items():
            a = np.array([r[0] for r in rows]); ae = np.array([r[1] for r in rows])
            rel = np.array([r[2] for r in rows]) ** power
            u = 4 * a * (1 - a) * rel
            X = np.stack([u, u * (1 - 2 * a)], axis=1)
            coef, *_ = np.linalg.lstsq(X, ae - a, rcond=None)
            err += float(np.sum((X @ coef - (ae - a)) ** 2))
            g, gs = coef
            out[k] = (g, gs / g if g else 0.0)
        return err, out

    powers = np.arange(0.0, 4.0001, 0.02)
    best = min(powers, key=lambda q: fit(q)[0])
    curves = fit(best)[1]
    ch["gain_power"] = float(best)
    return n, curves


def predict(ch, n, curves, cov, z):
    ae = {}
    for k in INKS:
        a = cov[k]
        G, s = curves[k]
        G = G * (ch["film"][k](z) / ch["film"][k](5.5)) ** ch.get("gain_power", 0.0)
        ae[k] = a + G * 4 * a * (1 - a) * (1 + s * (1 - 2 * a)) if a > 0 else 0.0
    acc = np.zeros_like(ch["paper"])
    for bits in itertools.product((0, 1), repeat=4):
        w = 1.0
        for b, k in zip(bits, INKS):
            w *= ae[k] if b else 1 - ae[k]
        if w <= 0:
            continue
        inks = [k for b, k in zip(bits, INKS) if b]
        P = primary(ch, inks, z) if inks else ch["paper"]
        acc += w * P ** (1 / n)
    return acc ** n


def run(run_dir):
    _, strip, art = load(run_dir)
    W = weights_for(run_dir)
    ch = characterise(strip)
    n, curves = spread_and_curves(ch, strip)
    return {p["patch"]: to_lab(predict(ch, n, curves, p["cov"], p["zone"]), W) for p in art}


def main(argv):
    if len(argv) != 3:
        sys.stderr.write("usage: predict.py RUN_DIR OUT_CSV\n")
        return 2
    out = run(argv[1])
    with open(argv[2], "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["patch", "L", "a", "b"])
        for k in sorted(out):
            w.writerow([k] + ["%.2f" % v for v in out[k]])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
