#!/bin/bash
# Installs the proofer and checks its colours on the four sample runs against the colours their
# artwork printed at.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/proofer
cp "$SRC/proofer/predict.py" /app/proofer/predict.py
for run in /app/runs/*/; do
  code="$(basename "$run")"
  python3 /app/proofer/predict.py "$run" "/tmp/${code}.csv"
  python3 - "$run/printed.csv" "/tmp/${code}.csv" "$code" <<'PY'
import csv, math, sys
want = {r["patch"]: [float(r[c]) for c in "Lab"] for r in csv.DictReader(open(sys.argv[1]))}
got = {r["patch"]: [float(r[c]) for c in "Lab"] for r in csv.DictReader(open(sys.argv[2]))}
off = [p for p in want if p not in got or math.dist(got[p], want[p]) > 1.5]
print("%s: %d of %d patches within 1.5 delta E" % (sys.argv[3], len(want) - len(off), len(want)))
PY
done
