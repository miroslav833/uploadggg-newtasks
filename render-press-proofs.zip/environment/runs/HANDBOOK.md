# Press runs: what the proofing archive holds

The house proofs every job before it goes to press: each artwork patch is proofed at the colour it
will print at on the press that runs the job, and the press is approved against that proof. A
press's behaviour changes from run to run, so every run starts with a control strip printed across
the sheet and measured, and the proof for that run's job is made from the run's own strip. This
archive holds runs as they were exported for proofing.

## The instrument

Every patch is measured with the house spectrophotometer: reflectance factor from 380 nm to 730 nm
in 10 nm steps, the paper backed by a white backing. A run folder carries the instrument's
tristimulus weighting table, `weights.csv`, one row per wavelength, with the X, Y and Z weights the
instrument uses for illuminant D50 and the 2 degree observer:

    nm,wx,wy,wz
    550,4.102955,9.399104,0.083429

The instrument's CIELAB values are the standard CIELAB of the tristimulus values these weights give,
with the perfect reflecting diffuser (reflectance 1 at every wavelength) as the white.

## A run folder

`run.csv` holds the run sheet:

    key,value
    run,PR-4107
    stock,coated
    zones,12

`stock` is `coated` or `uncoated`. `zones` is the number of ink-key zones across the sheet.

`strip.csv` holds the measured strip, one row per patch: its code, the ink-key zone it sits in
(1 to 12, numbered from the operator's side), the nominal coverage of each process ink in per cent
as the plate carries it, and the measured reflectance at each wavelength:

    patch,zone,C,M,Y,K,r380,r390,...,r730
    S02,1,100,0,0,0,0.6786,0.6450,...,0.2076

A row with all four coverages 0 is unprinted paper. A strip carries paper, solids of each ink in
several zones, tints of each ink, and overprints of solids; which overprints a strip carries depends
on the press's strip layout and differs between presses.

`artwork.csv` lists the job's patches to proof: code, zone and the four coverages, as above.

    patch,zone,C,M,Y,K
    A02,8,83,18,17,39

The four sample runs also carry `printed.csv`, the CIELAB colour each artwork patch was measured at
on the printed sheet:

    patch,L,a,b
    A02,36.38,-9.42,-25.44

## How the presses are run

The four process inks are printed wet on wet, one printing unit per ink, in the press's unit order.
The order is set when a press is built or rebuilt, it differs between the house's presses, and it is
not on the run sheet. How fully an ink takes on an ink still wet beneath it depends on the ink and the
press, and the house keeps no record of it. Ink film is set by the ink keys, zone by zone across the sheet; the operator
sets the keys for the job, so an ink need not carry the same film in every zone. Plates are made on
the house plate curve, the same for every press; what the sheet shows of a plate's tone depends on
the press, the ink and the stock. The stock is coated or uncoated paper of the house's usual weights.
Screens are conventional amplitude-modulated screens at the usual angles, so the inks' dots fall
independently of one another.
