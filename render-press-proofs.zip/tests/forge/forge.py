#!/usr/bin/env python3
"""Builds the twenty held-out press runs inside the verifier image from the accepted seeds.

    python3 forge.py VAULT_DIR

Writes VAULT_DIR/<code>/ (weights.csv, run.csv, strip.csv, artwork.csv), VAULT_DIR/keys.json (each
artwork patch's CIELAB colour) and VAULT_DIR/params.json (the press parameters each colour was
reckoned from).  The Dockerfile deletes this folder once the vault is built."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import press  # noqa: E402


def main(vault):
    weights = press.weighting_table()
    seeds = json.load(open(os.path.join(HERE, "seeds.json")))
    keys, params = {}, {}
    for code, entry in sorted(seeds.items()):
        p, strip, art, rng = press.make_run(entry["seed"], entry["cfg"], code)
        press.write_run(os.path.join(vault, code), code, p, strip, art, rng, weights)
        keys[code] = {k: list(v) for k, v in press.truth_lab(p, art, weights).items()}
        params[code] = dict(p, artwork=[[z, cov] for z, cov in art], weights=weights)
    json.dump(keys, open(os.path.join(vault, "keys.json"), "w"), indent=1, sort_keys=True)
    json.dump(params, open(os.path.join(vault, "params.json"), "w"), sort_keys=True)
    print("forged %d runs" % len(keys))


if __name__ == "__main__":
    main(sys.argv[1])
