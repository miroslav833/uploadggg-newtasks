"""The press room's runs, drawn and printed.

A run is fixed by its paper, its four inks (absorbance spectra at unit film), the film each ink
carries in each of the twelve ink-key zones, the press's unit order and wet trap, each ink's tone
value curve, and the stock's optical spread.  A patch prints as a Yule-Nielsen spectral Neugebauer
mixture of its Demichel primaries; a primary's ink films follow the unit order (the first ink of
the primary down takes its whole film, every later one the trap share of it).  Shared by gen/make.py
(the samples) and tests/forge/forge.py (the held-out runs inside the verifier image).
"""
import csv
import itertools
import math
import os
import random

NM = list(range(380, 731, 10))
INKS = "CMYK"
ZONES = 12


def _g(l, mu, s1, s2):
    s = s1 if l < mu else s2
    return math.exp(-0.5 * ((l - mu) / s) ** 2)


def weighting_table():
    """The instrument's tristimulus weighting table: a 5003 K Planck source times analytic fits of
    the 1931 2 degree colour-matching functions, scaled so the Y weights sum to 100."""
    rows = []
    for l in NM:
        lm = l * 1e-9
        planck = 1.0 / (lm ** 5 * (math.exp(1.4388e-2 / (lm * 5003.0)) - 1.0))
        xb = 1.056 * _g(l, 599.8, 37.9, 31.0) + 0.362 * _g(l, 442.0, 16.0, 26.7) - 0.065 * _g(l, 501.1, 20.4, 26.2)
        yb = 0.821 * _g(l, 568.8, 46.9, 40.5) + 0.286 * _g(l, 530.9, 16.3, 31.1)
        zb = 1.217 * _g(l, 437.0, 11.8, 36.0) + 0.681 * _g(l, 459.0, 26.0, 13.8)
        rows.append((planck * xb, planck * yb, planck * zb))
    k = 100.0 / sum(r[1] for r in rows)
    return [(round(a * k, 6), round(b * k, 6), round(c * k, 6)) for a, b, c in rows]


def lab(spec, weights):
    X = sum(r * w[0] for r, w in zip(spec, weights))
    Y = sum(r * w[1] for r, w in zip(spec, weights))
    Z = sum(r * w[2] for r, w in zip(spec, weights))
    Xn = sum(w[0] for w in weights)
    Yn = sum(w[1] for w in weights)
    Zn = sum(w[2] for w in weights)

    def f(t):
        return t ** (1.0 / 3.0) if t > (6.0 / 29.0) ** 3 else t / (3 * (6.0 / 29.0) ** 2) + 4.0 / 29.0
    fx, fy, fz = f(X / Xn), f(Y / Yn), f(Z / Zn)
    return (116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz))


# ----------------------------------------------------------------------------- a run's truth
def draw_run(rng, cfg):
    """cfg: order (str), keys ('flat' or 'ramp'), skew (bool), stock ('coated'/'uncoated'),
    full_strip (bool)."""
    p = dict(cfg)
    if cfg["stock"] == "coated":
        base, tilt = rng.uniform(0.86, 0.90), rng.uniform(-0.02, 0.01)
        p["paper"] = [base + tilt * (l - 555) / 175 - 0.03 * _g(l, 390, 15, 15) for l in NM]
        p["n"] = rng.uniform(1.45, 1.85)
    else:
        base = rng.uniform(0.80, 0.84)
        p["paper"] = [base - 0.07 * _g(l, 390, 25, 40) + 0.01 * (l - 555) / 175 for l in NM]
        p["n"] = rng.uniform(2.1, 2.6)
    j = lambda: rng.uniform(-1.0, 1.0)
    p["absorb"] = {
        "C": [2.4 * (1 + 0.08 * j()) * _g(l, 630 + 8 * j(), 70, 90) + 0.30 * _g(l, 440, 50, 50) + 0.06 for l in NM],
        "M": [2.2 * (1 + 0.08 * j()) * _g(l, 540 + 6 * j(), 40, 35) + 0.30 * _g(l, 410, 30, 40) + 0.05 for l in NM],
        "Y": [2.3 * (1 + 0.08 * j()) * _g(l, 440 + 6 * j(), 60, 32) + 0.03 for l in NM],
        "K": [2.6 * (1 + 0.05 * j()) + 0.15 * (l - 555) / 175 for l in NM],
    }
    # one random factor per spectrum would be drawn per wavelength above; smooth them instead
    for k in INKS:
        s = rng.uniform(0.92, 1.08)
        p["absorb"][k] = [round(v * s, 5) for v in p["absorb"][k]]
    p["film"] = {}
    for k in INKS:
        c = rng.uniform(0.95, 1.05)
        if cfg["keys"] == "ramp":
            r = rng.choice([-1, 1]) * rng.uniform(0.06, 0.13)
            p["film"][k] = [c + r * (z - 5.5) / 5.5 for z in range(ZONES)]
        else:
            p["film"][k] = [c] * ZONES
    t = rng.uniform(0.70, 0.92)
    p["trap"] = {k: t for k in INKS}
    if cfg.get("pertrap"):                       # each ink takes its own share on a wet ink
        p["trap"] = {k: rng.uniform(0.60, 0.95) for k in INKS}
    # on a press whose keys vary, dot gain grows with the zone's ink film (heavier ink, fatter dots)
    p["gain_power"] = rng.uniform(1.6, 2.6) if cfg["keys"] == "ramp" else 0.0
    p["tvi"] = {}
    for k in INKS:
        G = rng.uniform(0.10, 0.20)
        s = rng.choice([-1, 1]) * rng.uniform(0.35, 0.65) if cfg["skew"] else 0.0
        p["tvi"][k] = (G, s)
    return p


def effective(a, G, s):
    return a + G * 4.0 * a * (1.0 - a) * (1.0 + s * (1.0 - 2.0 * a))


def gain_at(p, k, z):
    """An ink's tone value increase scale in zone z: its base gain times its film there, relative to
    its mean film, to the press's gain power."""
    G, s = p["tvi"][k]
    mean = sum(p["film"][k]) / len(p["film"][k])
    return G * (p["film"][k][z] / mean) ** p["gain_power"], s


def primary(p, inks, z):
    """Reflectance spectrum of the solid overprint of `inks` in zone z."""
    order = [k for k in p["order"] if k in inks]
    out = []
    for i, l in enumerate(NM):
        tot = 0.0
        for j, k in enumerate(order):
            m = 1.0 if j == 0 else p["trap"][k]
            tot += p["film"][k][z] * p["absorb"][k][i] * m
        out.append(p["paper"][i] * math.exp(-tot))
    return out


def printed(p, cov, z):
    """Reflectance spectrum of a patch with coverages cov = {ink: fraction} in zone z."""
    ae = {k: effective(cov.get(k, 0.0), *gain_at(p, k, z)) if cov.get(k, 0.0) > 0 else 0.0 for k in INKS}
    n = p["n"]
    acc = [0.0] * len(NM)
    for bits in itertools.product((0, 1), repeat=4):
        w = 1.0
        for b, k in zip(bits, INKS):
            w *= ae[k] if b else (1.0 - ae[k])
        if w <= 0.0:
            continue
        inks = [k for b, k in zip(bits, INKS) if b]
        P = primary(p, inks, z) if inks else p["paper"]
        for i in range(len(NM)):
            acc[i] += w * P[i] ** (1.0 / n)
    return [v ** n for v in acc]


# ----------------------------------------------------------------------------- the strip and the job
def strip_layout(rng, p):
    """(patch, zone, cov) rows of the run's control strip."""
    rows = []
    zs = list(range(ZONES))
    # paper in three zones
    for z in (1, 6, 10):
        rows.append((z, {}))
    # each ink's solid in six zones (two inks per zone, alternating pairs)
    for z in zs:
        pair = ("C", "M") if z % 2 == 0 else ("Y", "K")
        for k in pair:
            rows.append((z, {k: 1.0}))
    # tints 20/40/60/80 of every ink, once near each end of the sheet
    for k in INKS:
        for z in (rng.randrange(0, 4), rng.randrange(8, ZONES)):
            for a in (0.2, 0.4, 0.6, 0.8):
                rows.append((z, {k: a}))
    # every two-ink solid overprint
    for a, b in itertools.combinations(INKS, 2):
        rows.append((rng.randrange(ZONES), {a: 1.0, b: 1.0}))
    if p["full_strip"]:
        for s in itertools.combinations(INKS, 3):
            rows.append((rng.randrange(ZONES), {k: 1.0 for k in s}))
        rows.append((rng.randrange(ZONES), {k: 1.0 for k in INKS}))
    rng.shuffle(rows)
    return rows


def artwork_layout(rng):
    rows = []
    for _ in range(24):
        n_inks = rng.choice([2, 3, 3, 4, 4])
        inks = rng.sample(INKS, n_inks)
        cov = {}
        for k in inks:
            cov[k] = rng.choice([rng.uniform(0.15, 0.85), rng.uniform(0.15, 0.85), 1.0])
        rows.append((rng.randrange(ZONES), cov))
    return rows


def noisy(spec, rng, sd=0.001):
    return [max(0.0, v + rng.gauss(0.0, sd)) for v in spec]


def write_run(out_dir, code, p, strip, art, rng, weights, with_printed=False):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "weights.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["nm", "wx", "wy", "wz"])
        for l, (a, b, c) in zip(NM, weights):
            w.writerow([l, "%.6f" % a, "%.6f" % b, "%.6f" % c])
    with open(os.path.join(out_dir, "run.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["key", "value"])
        w.writerow(["run", code])
        w.writerow(["stock", p["stock"]])
        w.writerow(["zones", ZONES])
    with open(os.path.join(out_dir, "strip.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["patch", "zone", "C", "M", "Y", "K"] + ["r%d" % l for l in NM])
        for i, (z, cov) in enumerate(strip):
            spec = noisy(printed(p, cov, z), rng)
            w.writerow(["S%02d" % (i + 1), z + 1] + ["%d" % round(100 * cov.get(k, 0.0)) for k in INKS]
                       + ["%.4f" % v for v in spec])
    with open(os.path.join(out_dir, "artwork.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["patch", "zone", "C", "M", "Y", "K"])
        for i, (z, cov) in enumerate(art):
            w.writerow(["A%02d" % (i + 1), z + 1] + ["%d" % round(100 * cov.get(k, 0.0)) for k in INKS])
    if with_printed:
        with open(os.path.join(out_dir, "printed.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["patch", "L", "a", "b"])
            for i, (z, cov) in enumerate(art):
                L, a, b = lab(printed(p, _rounded(cov), z), weights)
                w.writerow(["A%02d" % (i + 1), "%.2f" % L, "%.2f" % a, "%.2f" % b])


def _rounded(cov):
    """Coverages as the artwork file states them (whole per cent)."""
    return {k: round(100 * v) / 100.0 for k, v in cov.items()}


def make_run(seed, cfg, code):
    rng = random.Random(seed)
    p = draw_run(rng, cfg)
    strip = strip_layout(rng, p)
    art = [(z, _rounded(cov)) for z, cov in artwork_layout(rng)]
    return p, strip, art, rng


# ----------------------------------------------------------------------------- the sets
def sample_cfgs():
    base = dict(order="CMYK", keys="flat", skew=False, stock="coated", full_strip=True, pertrap=False)
    return [dict(base) for _ in range(4)]


def hidden_cfgs(rng):
    while True:
        cfgs = [dict(order="CMYK", keys="flat", skew=False, stock="coated", full_strip=True, pertrap=False)
                for _ in range(20)]
        plain = rng.randrange(20)
        others = [i for i in range(20) if i != plain]
        orders = ["KCMY", "KCYM", "YMCK", "CMKY", "MCYK", "KMCY", "CYMK", "YCMK"]
        for key, n in (("order", 14), ("keys", 12), ("skew", 12), ("stock", 8), ("full_strip", 12), ("pertrap", 13)):
            rng.shuffle(others)
            for i in others[:n]:
                if key == "order":
                    cfgs[i]["order"] = rng.choice(orders)
                elif key == "keys":
                    cfgs[i]["keys"] = "ramp"
                elif key == "skew":
                    cfgs[i]["skew"] = True
                elif key == "pertrap":
                    cfgs[i]["pertrap"] = True
                elif key == "stock":
                    cfgs[i]["stock"] = "uncoated"
                else:
                    cfgs[i]["full_strip"] = False
        counts = dict(order=sum(c["order"] != "CMYK" for c in cfgs), keys=sum(c["keys"] == "ramp" for c in cfgs),
                      skew=sum(c["skew"] for c in cfgs), stock=sum(c["stock"] == "uncoated" for c in cfgs),
                      partial_strip=sum(not c["full_strip"] for c in cfgs), pertrap=sum(c["pertrap"] for c in cfgs))
        return cfgs, counts


def truth_lab(p, art, weights):
    return {"A%02d" % (i + 1): lab(printed(p, cov, z), weights) for i, (z, cov) in enumerate(art)}
