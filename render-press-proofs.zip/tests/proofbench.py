"""Puts the solver's proofer through the sealed press runs.

Each run is copied into a scratch folder that only its own throwaway account can write, the proofer
is started there as that account (new session, resource limits, a wall clock), every process the
account still owns is killed, and only then is the colour sheet read back: as text, from a regular
file of bounded size, opened without following links.  Nothing the proofer writes is ever run."""
import csv
import io
import math
import os
import resource
import shutil
import signal
import subprocess
import time

SEALED = "/tests/sealed"
PROOFER = "/app/proofer/predict.py"
BENCH = "/run/proofbench"
ACCOUNT = 61523                 # a numeric uid/gid with no passwd entry
CLOCK = 120                     # seconds per run
SHEET_CAP = 1 << 15
DELTA_E = 1.5                   # largest CIELAB distance a right patch may sit from the sealed colour
SLIPS = 1                       # wrong patches a run may carry and still count


def _confine():
    os.setsid()
    os.umask(0o077)
    for res, val in ((resource.RLIMIT_AS, 3 << 30), (resource.RLIMIT_CPU, CLOCK),
                     (resource.RLIMIT_NOFILE, 256), (resource.RLIMIT_NPROC, 64)):
        resource.setrlimit(res, (val, val))
    os.setgroups([])
    os.setgid(ACCOUNT)
    os.setuid(ACCOUNT)


def _reap():
    for _ in range(3):
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    if os.stat("/proc/" + entry).st_uid == ACCOUNT:
                        os.kill(int(entry), signal.SIGKILL)
                except (FileNotFoundError, ProcessLookupError, PermissionError):
                    pass
        time.sleep(0.2)


def _slurp(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return ""
    try:
        info = os.fstat(fd)
        if (info.st_mode & 0o170000) != 0o100000 or info.st_size > SHEET_CAP:
            return ""
        return os.read(fd, SHEET_CAP).decode("utf-8", "replace")
    finally:
        os.close(fd)


def wrong_patches(sheet_text, sealed):
    """Patch codes of one run whose filed colour is missing, repeated, non-finite or too far off."""
    filed = {}
    for row in csv.DictReader(io.StringIO(sheet_text)):
        code = (row.get("patch") or "").strip()
        if code:
            filed.setdefault(code, []).append(row)
    wrong = []
    for code, want in sealed.items():
        rows = filed.get(code, [])
        if len(rows) != 1:
            wrong.append(code)
            continue
        try:
            got = [float(rows[0][c]) for c in ("L", "a", "b")]
        except (KeyError, TypeError, ValueError):
            wrong.append(code)
            continue
        if not all(math.isfinite(v) for v in got):
            wrong.append(code)
            continue
        if math.sqrt(sum((g - w) ** 2 for g, w in zip(got, want))) > DELTA_E:
            wrong.append(code)
    return wrong


def bench(sealed_colours):
    verdicts = {}
    os.makedirs(BENCH, exist_ok=True)
    for code in sorted(sealed_colours):
        lane = os.path.join(BENCH, code)
        shutil.rmtree(lane, ignore_errors=True)
        shutil.copytree(os.path.join(SEALED, code), os.path.join(lane, "run"))
        os.makedirs(os.path.join(lane, "sheet"))
        for root, dirs, files in os.walk(lane):
            os.chmod(root, 0o755)
            for name in files:
                os.chmod(os.path.join(root, name), 0o644)
        os.chown(os.path.join(lane, "sheet"), ACCOUNT, ACCOUNT)
        sheet = os.path.join(lane, "sheet", "colours.csv")
        os.chmod(BENCH, 0o711)
        try:
            subprocess.run(["python3", PROOFER, os.path.join(lane, "run"), sheet], preexec_fn=_confine,
                           cwd=os.path.join(lane, "sheet"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=CLOCK, env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": lane, "TMPDIR": lane, "LANG": "C.UTF-8",
                                "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"})
        except (subprocess.TimeoutExpired, OSError):
            pass
        _reap()
        os.chmod(BENCH, 0o700)
        verdicts[code] = wrong_patches(_slurp(sheet), sealed_colours[code])
        shutil.rmtree(lane, ignore_errors=True)
    return verdicts
