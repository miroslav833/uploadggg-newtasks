"""The verifier's own reckoning of a held-out run's printed colours from the press parameters sealed
with it: the Yule-Nielsen spectral Neugebauer mixture of the Demichel primaries, each primary's ink
films taken in the press's unit order with each ink's own wet trap on every ink after the first.  Each ink's dot gain scales with its film in the patch's zone, relative to its mean film, to the
press's gain power.  Test 1 holds every sealed colour to this."""
import itertools
import math

INKS = "CMYK"


def _primary(par, inks, zone):
    seq = [k for k in par["order"] if k in inks]
    spec = []
    for i, w in enumerate(par["paper"]):
        dens = sum(par["film"][k][zone] * par["absorb"][k][i] * (1.0 if j == 0 else par["trap"][k])
                   for j, k in enumerate(seq))
        spec.append(w * math.exp(-dens))
    return spec


def reflectance(par, cov, zone):
    eff = {}
    for k in INKS:
        a = cov.get(k, 0.0)
        G, s = par["tvi"][k]
        films = par["film"][k]
        G = G * (films[zone] / (sum(films) / len(films))) ** par["gain_power"]
        eff[k] = a + G * 4.0 * a * (1.0 - a) * (1.0 + s * (1.0 - 2.0 * a)) if a > 0 else 0.0
    inv = 1.0 / par["n"]
    total = [0.0] * len(par["paper"])
    for mask in itertools.product((False, True), repeat=len(INKS)):
        share = 1.0
        for on, k in zip(mask, INKS):
            share *= eff[k] if on else 1.0 - eff[k]
        if share == 0.0:
            continue
        used = [k for on, k in zip(mask, INKS) if on]
        prim = _primary(par, used, zone) if used else par["paper"]
        for i, v in enumerate(prim):
            total[i] += share * v ** inv
    return [t ** par["n"] for t in total]


def cielab(spec, table):
    X, Y, Z = (sum(r * row[c] for r, row in zip(spec, table)) for c in range(3))
    Xn, Yn, Zn = (sum(row[c] for row in table) for c in range(3))
    eps = (6.0 / 29.0) ** 3

    def f(t):
        return t ** (1.0 / 3.0) if t > eps else t / (3.0 * (6.0 / 29.0) ** 2) + 4.0 / 29.0
    return 116.0 * f(Y / Yn) - 16.0, 500.0 * (f(X / Xn) - f(Y / Yn)), 200.0 * (f(Y / Yn) - f(Z / Zn))
