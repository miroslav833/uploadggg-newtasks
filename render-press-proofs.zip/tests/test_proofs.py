"""render-press-proofs verifier.

The sealed colours are first checked against the verifier's own press model (tests/press_model.py)
run on the sealed press parameters; then the solver's proofer is run on all twenty sealed runs.  A
patch is right within 1.5 delta E*ab, a run counts with at most 1 wrong patch of its 24, and 17 of the
20 runs must count."""
import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import press_model  # noqa: E402
import proofbench  # noqa: E402

RUNS = 20
MARK = 17


def _sealed():
    return json.load(open(os.path.join(proofbench.SEALED, "keys.json")))


def test_sealed_colours_follow_the_press_model():
    colours = _sealed()
    params = json.load(open(os.path.join(proofbench.SEALED, "params.json")))
    assert len(colours) == RUNS and set(colours) == set(params)
    for code, patches in colours.items():
        par = params[code]
        assert len(patches) == 24
        for idx, (zone, cov) in enumerate(par["artwork"]):
            own = press_model.cielab(press_model.reflectance(par, cov, zone), par["weights"])
            want = patches["A%02d" % (idx + 1)]
            assert all(math.isfinite(v) for v in want)
            assert max(abs(x - y) for x, y in zip(own, want)) < 1e-6, (code, idx)


def test_proofer_counts_enough_runs():
    verdicts = proofbench.bench(_sealed())
    report = os.environ.get("PROOFBENCH_REPORT", "/run/proofbench-report")
    os.makedirs(report, exist_ok=True)
    with open(os.path.join(report, "runs.json"), "w") as f:
        json.dump({c: {"counts": len(w) <= proofbench.SLIPS, "wrong": w} for c, w in verdicts.items()}, f, indent=1)
    counted = sum(1 for w in verdicts.values() if len(w) <= proofbench.SLIPS)
    assert counted >= MARK, "%d of %d runs counted, %d needed" % (counted, RUNS, MARK)
