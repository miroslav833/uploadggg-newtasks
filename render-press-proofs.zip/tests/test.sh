#!/bin/bash
# Seals the reward channel to root, runs the proofer over the sealed press runs under the test suite with its
# report kept in a root-only folder, clears anything the proofer's account left behind, and only then
# writes the reward.
REPORT=/run/proofbench-report

reward() {
  rm -f /logs/verifier/reward.txt /logs/verifier/reward.json
  (umask 022; printf '%s\n' "$1" > /logs/verifier/reward.txt)
}

mkdir -p /logs/verifier
was="$(stat -c %a /logs/verifier 2>/dev/null || echo 755)"
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier 2>/dev/null
find /logs/verifier -mindepth 1 -exec rm -rf {} + 2>/dev/null
reward 0

done_here() {
  chmod "$was" /logs/verifier 2>/dev/null
  exit 0
}

[ "$(stat -c '%u:%a' /logs/verifier 2>/dev/null)" = "0:700" ] || { echo "verifier: reward channel not sealed" >&2; done_here; }
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
[ "$(stat -c '%u:%a' /tests 2>/dev/null)" = "0:700" ] || { echo "verifier: /tests not sealed" >&2; done_here; }
rm -rf "$REPORT"; mkdir -p "$REPORT"; chown 0:0 "$REPORT"; chmod 700 "$REPORT"
if [ -d /app/proofer ]; then
  chown -R 0:0 /app/proofer
  chmod -R u+rwX,go+rX,go-w /app/proofer
fi

cd /tests || done_here
PROOFBENCH_REPORT="$REPORT" python3 -m pytest -q -p no:cacheprovider test_proofs.py --ctrf "$REPORT/ctrf.json"
outcome=$?

find /logs/verifier -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
if [ "$outcome" -eq 0 ]; then reward 1; else reward 0; fi
for f in ctrf.json runs.json; do
  if [ -f "$REPORT/$f" ] && [ ! -L "$REPORT/$f" ]; then
    rm -rf "/logs/verifier/$f"
    (umask 022; cp --no-dereference "$REPORT/$f" "/logs/verifier/$f")
  fi
done
done_here
