Build a proofing tool that predicts, for every artwork patch of an offset press run, the CIELAB colour the patch prints at on that run.

`/app/runs/HANDBOOK.md` explains the archive. Four runs sit in `/app/runs/<code>/`. In each one, `run.csv` is the run sheet (stock and number of ink-key zones), `strip.csv` is the measured control strip (one patch per row: zone, the C, M, Y and K coverages in per cent, and the reflectance from 380 to 730 nm), `artwork.csv` lists the job's patches (zone and coverages), and `weights.csv` is the spectrophotometer's tristimulus weighting table. These four runs also carry `printed.csv`, the colour each artwork patch was measured at once printed.

The tool is run as `python3 /app/proofer/predict.py RUN_DIR OUT_CSV`, where RUN_DIR holds `run.csv`, `strip.csv`, `artwork.csv` and `weights.csv` for one run, and never `printed.csv`. OUT_CSV gets a header and one row per artwork patch:

```
patch,L,a,b
A01,0.00,0.00,0.00
```

A colour is the CIELAB value the instrument would report for the printed patch: the tristimulus values from that run's `weights.csv`, with the perfect reflecting diffuser as the white. Each run is predicted from its own folder alone.

Grading feeds the tool 20 runs from other presses of the same house, and those presses do not all behave like the four sample presses. Each predicted patch is compared with the measured one by plain Euclidean CIELAB distance (delta E*ab), and a patch further off than 1.5 is wrong. One wrong patch out of a run's 24 is forgiven, a second one loses the run, and 17 of the 20 runs have to survive. The tool gets 120 seconds per run, an unprivileged account, python3, numpy 2.2.6 and nothing beyond the standard library.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
