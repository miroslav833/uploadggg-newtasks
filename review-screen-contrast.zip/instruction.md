For each of the 80 text elements on 20 exported product screens, file the WCAG 2.1 contrast ratio between the text and the colour behind it, and the conformance level that ratio earns.

Inputs:

- `/app/tokens.json`: the design system's colour tokens: `palette` hex values, `semantic` tokens whose values are hex or `{token}` references, and `themes.dark`, the overrides a dark screen applies.
- `/app/screens/<screen>.json`: one layer tree per screen, root to top in paint order. Each node has `id`, `type` (`group`, `rect`, `text`) and `box` `[x, y, width, height]`; rects have `fill` (hex or `{token}`), `opacity` and `blend` (`normal` or `multiply`); groups have `opacity` and `children`; text nodes have `color`, `size` (px) and `weight`.
- `/app/manifest.csv`: `screen`, `theme`, `color_profile`, `tool_version`, `exported`.
- `/app/audit-notes.md`: how the screens were exported.

Write `/app/out/contrast.csv` with a header row and one row per text node:

```
element,contrast,level
zz9q-t1,5.37,AA
zz9q-t2,2.80,fail
```

`contrast` is the WCAG 2.1 ratio (L1 + 0.05) / (L2 + 0.05) between the rendered text colour and the rendered colour behind it, with relative luminance defined over sRGB, rounded to two decimals. Both colours are what the tool paints: every layer whose box contains the text box, composited in paint order with its opacity and blend mode on the document's encoded values, a group rendered as the tool renders it, and the text node at its own place in that order. `level` is `AAA` at 7.00 or more, `AA` at 4.50 or more, otherwise `fail`; for large text (24 px or more, or 18.67 px or more at weight 700 or more) the bounds are 4.50 and 3.00.

A row is right when `level` matches and `contrast` is within 0.10 of the key. At least 72 of the 80 rows must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
