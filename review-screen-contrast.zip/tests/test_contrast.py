"""Test 1: the sealed key is what the verifier's own compositing model rebuilds from the sealed world.
Test 2: the filing at /app/out/contrast.csv earns at least the mark printed in the instruction."""
import math
import os

import composite
import score

HERE = os.path.dirname(os.path.abspath(__file__))
SEALED = os.path.join(HERE, "sealed")
FILING = "/app/out/contrast.csv"
MARK = 72
ELEMENTS = 80


def test_sealed_key_matches_composite_model():
    key = score.Key(os.path.join(SEALED, "key.csv"))
    rebuilt = composite.rebuild(composite.load_world(os.path.join(SEALED, "world.json")))
    assert len(key) == ELEMENTS and set(key.rows) == set(rebuilt)
    for eid, (ratio, lvl) in key.rows.items():
        model_ratio, model_level = rebuilt[eid]
        assert model_level == lvl, eid
        assert math.isfinite(ratio) and math.isfinite(model_ratio) and abs(round(model_ratio, 2) - ratio) < 1e-9, eid


def test_filed_contrasts_reach_the_mark():
    key = score.Key(os.path.join(SEALED, "key.csv"))
    report = score.Filing(FILING).tally(key)
    print("tally: %r (mark %d of %d)" % (report, MARK, ELEMENTS))
    assert report["right"] >= MARK
