#!/bin/bash
# The reward is 0 until test_contrast.py passes on the filing.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests || exit 0
python3 -m pytest -q -rA --ctrf /logs/verifier/ctrf.json test_contrast.py && echo 1 > /logs/verifier/reward.txt
exit 0
