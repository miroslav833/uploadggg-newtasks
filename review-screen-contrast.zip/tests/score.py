"""Grading of a contrast filing against the sealed key: text in, counts out, nothing executed.

A filed row earns a point when its level equals the key's and its contrast is no more than SLACK
from the key's. Rows that are missing, filed twice, unreadable or non-finite earn nothing.
"""
import csv
import math

SLACK = 0.10


class Key:
    def __init__(self, path):
        self.rows = {}
        with open(path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                self.rows[r["element"]] = (float(r["contrast"]), r["level"])

    def __len__(self):
        return len(self.rows)


class Filing:
    REQUIRED = ("element", "contrast", "level")

    def __init__(self, path):
        self.rows = {}
        self.seen_twice = set()
        self.readable = False
        try:
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                fields = reader.fieldnames or []
                if all(c in fields for c in self.REQUIRED):
                    self.readable = True
                    for r in reader:
                        eid = (r.get("element") or "").strip()
                        if eid in self.rows:
                            self.seen_twice.add(eid)
                        self.rows[eid] = ((r.get("contrast") or "").strip(), (r.get("level") or "").strip())
        except OSError:
            self.readable = False

    @staticmethod
    def earns(filed, truth):
        contrast_text, lvl = filed
        if lvl != truth[1]:
            return False
        try:
            value = float(contrast_text)
        except ValueError:
            return False
        if not math.isfinite(value):
            return False
        return abs(value - truth[0]) <= SLACK

    def tally(self, key):
        report = dict(right=0, wrong=0, missing=0, duplicated=len(self.seen_twice))
        for eid, truth in key.rows.items():
            if eid not in self.rows:
                report["missing"] += 1
            elif eid in self.seen_twice:
                report["wrong"] += 1
            elif self.earns(self.rows[eid], truth):
                report["right"] += 1
            else:
                report["wrong"] += 1
        return report
