"""The verifier's own forward model: the key rebuilt from the sealed world (tests/sealed/world.json).

Each sealed element lists, in the screen's document space, the text colour and the stack of layers
under it from the page up, with each layer's opacity, blend mode and whether it belongs to the
element's group, plus the group's opacity and whether the text sits inside the group. The model
composites the stack the way the tool paints it, converts Display P3 documents to sRGB, and applies
WCAG 2.1 luminance, ratio and level. It shares no code with the reference.
"""
import json

_P3 = ((0.4865709, 0.2656677, 0.1982173), (0.2289746, 0.6917385, 0.0792869), (0.0, 0.0451134, 1.0439444))
_SRGB = ((3.2404542, -1.5371385, -0.4985314), (-0.9692660, 1.8760108, 0.0415560), (0.0556434, -0.2040259, 1.0572252))


def load_world(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _lin(c):
    return tuple(v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in c)


def _enc(c):
    return tuple(12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055 for v in c)


def _mul(m, v):
    return tuple(sum(m[i][j] * v[j] for j in range(3)) for i in range(3))


_SRGB_XYZ = ((0.4124564, 0.3575761, 0.1804375), (0.2126729, 0.7151522, 0.0721750), (0.0193339, 0.1191920, 0.9503041))
_XYZ_P3 = ((2.4934969, -0.9313836, -0.4027108), (-0.8294890, 1.7626641, 0.0236247), (0.0358458, -0.0761724, 0.9568845))


def _to_srgb(c):
    return _enc(tuple(min(1.0, max(0.0, v)) for v in _mul(_SRGB, _mul(_P3, _lin(c)))))


def _into_p3(c):
    """An sRGB-defined token colour as the tool renders it inside a Display P3 document."""
    return _enc(tuple(min(1.0, max(0.0, v)) for v in _mul(_XYZ_P3, _mul(_SRGB_XYZ, _lin(c)))))


def _document_colour(hex_value, literal, profile):
    c = _rgb(hex_value)
    if profile == "Display P3" and not literal:
        return _into_p3(c)
    return c


def _blend(src, dst, alpha, mode):
    if mode == "multiply":
        src = tuple(s * d for s, d in zip(src, dst))
    return tuple(alpha * s + (1 - alpha) * d for s, d in zip(src, dst))


def _lum(c):
    r, g, b = _lin(c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _level(ratio, size, weight):
    large = size >= 24 or (size >= 18.67 and weight >= 700)
    aa, aaa = (3.0, 4.5) if large else (4.5, 7.0)
    if ratio >= aaa:
        return "AAA"
    return "AA" if ratio >= aa else "fail"


def rebuild(world):
    """-> {element id: (ratio, level)}"""
    key = {}
    for el in world["elements"]:
        stack = el["stack"]
        profile = el["profile"]
        page = _document_colour(stack[0]["hex"], stack[0].get("literal", False), profile)
        under = page
        group_buf, under_group, painted = None, None, False
        for layer in stack[1:]:
            c = _document_colour(layer["hex"], layer.get("literal", False), profile)
            if layer["in_group"] and el["group"] is not None:
                if group_buf is None:
                    under_group = under
                    group_buf = c if layer["opacity"] >= 1 else _blend(c, under, layer["opacity"], layer["blend"])
                else:
                    group_buf = _blend(c, group_buf, layer["opacity"], layer["blend"])
            else:
                if group_buf is not None and not painted:
                    under = _blend(group_buf, under_group, el["group"], "normal")
                    painted = True
                under = _blend(c, under, layer["opacity"], layer["blend"])
        if group_buf is not None and not painted:
            under = _blend(group_buf, under_group, el["group"], "normal")
        text = _document_colour(el["text"], el.get("text_literal", False), profile)
        if el["group"] is not None and el["text_in_group"]:
            text = _blend(text, under_group if under_group is not None else under, el["group"], "normal")
        if el["profile"] == "Display P3":
            text, under = _to_srgb(text), _to_srgb(under)
        a, b = _lum(text), _lum(under)
        ratio = (max(a, b) + 0.05) / (min(a, b) + 0.05)
        key[el["id"]] = (ratio, _level(ratio, el["size"], el["weight"]))
    return key
