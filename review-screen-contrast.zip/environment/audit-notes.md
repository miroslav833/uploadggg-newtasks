# Audit notes

The twenty screens were exported from the product's design file by the design-system team for the
release accessibility review. Each screen is one JSON layer tree, root to top, in the order the
tool paints it: later siblings paint over earlier ones, and a group's children paint inside the
group. Boxes are `[x, y, width, height]` in pixels; the screens are 1080 by 1920. Rects carry a
`fill` that is either a hex value or a `{token}` reference, an `opacity` and a `blend` mode as set
in the tool; groups carry their own `opacity`; text nodes carry their `color` (token or hex), font
`size` in px and `weight`. Image layers are exported as rects filled with the image's exported
average colour.

The export plugin was updated from 7.14.2 to 7.15.0 part-way through the review, after the first
batch of screens had been exported on 12 September; the manifest records which version exported
each screen and on which day. Nothing was re-exported.

`tokens.json` is the design system's source of truth: the palette, the semantic tokens (which may
alias other tokens) and the `dark` theme's overrides, all defined in sRGB, as the system's
documentation states. `manifest.csv` records each screen's theme, the colour profile of the
document it was exported from and the tool version. A hex value written in a screen file is the
document's own coordinates in that profile, as the tool writes them; a `{token}` reference is
written as the reference, unresolved. Nothing was resampled or converted on export.

Text boxes lie fully inside or fully outside every other box on their screen.
