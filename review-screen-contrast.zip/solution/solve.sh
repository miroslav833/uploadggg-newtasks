#!/bin/bash
python3 "$(dirname "$0")/review_contrast.py" /app
