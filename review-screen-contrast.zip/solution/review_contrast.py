#!/usr/bin/env python3
"""Reference: the WCAG 2 contrast and level of every text element on the exported screens.

Usage: review_contrast.py /app  -> /app/out/contrast.csv
"""
import csv
import json
import os
import sys

P3_TO_XYZ = ((0.4865709, 0.2656677, 0.1982173), (0.2289746, 0.6917385, 0.0792869), (0.0, 0.0451134, 1.0439444))
XYZ_TO_SRGB = ((3.2404542, -1.5371385, -0.4985314), (-0.9692660, 1.8760108, 0.0415560), (0.0556434, -0.2040259, 1.0572252))


def rgb(h):
    h = h.lstrip("#")
    return [int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]


def to_linear(c):
    return [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in c]


def to_encoded(c):
    return [12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055 for v in c]


def apply(m, v):
    return [sum(m[i][j] * v[j] for j in range(3)) for i in range(3)]


SRGB_TO_XYZ = ((0.4124564, 0.3575761, 0.1804375), (0.2126729, 0.7151522, 0.0721750), (0.0193339, 0.1191920, 0.9503041))
XYZ_TO_P3 = ((2.4934969, -0.9313836, -0.4027108), (-0.8294890, 1.7626641, 0.0236247), (0.0358458, -0.0761724, 0.9568845))


def p3_to_srgb(c):
    lin = apply(XYZ_TO_SRGB, apply(P3_TO_XYZ, to_linear(c)))
    return to_encoded([min(1.0, max(0.0, v)) for v in lin])


def srgb_to_p3(c):
    """A colour-managed token's sRGB colour, as the tool renders it in a Display P3 document."""
    lin = apply(XYZ_TO_P3, apply(SRGB_TO_XYZ, to_linear(c)))
    return to_encoded([min(1.0, max(0.0, v)) for v in lin])


def luminance(c):
    r, g, b = to_linear(c)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(c1, c2):
    a, b = luminance(c1), luminance(c2)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


class Tokens:
    def __init__(self, data):
        self.palette = data["palette"]
        self.semantic = data["semantic"]
        self.themes = data.get("themes", {})

    def resolve(self, value, theme, profile="sRGB"):
        """The colour of a fill or text value in the document's coordinates: a hex written in the
        screen is already the document's; a token resolves to its sRGB definition, which a
        colour-managed document renders converted into its own profile."""
        if not (isinstance(value, str) and value.startswith("{")):
            return rgb(value)
        for _ in range(12):
            if not (isinstance(value, str) and value.startswith("{")):
                c = rgb(value)
                return srgb_to_p3(c) if profile == "Display P3" else c
            key = value[1:-1]
            if key.startswith("palette."):
                value = self.palette[key[len("palette."):]]
            else:
                value = self.themes.get(theme, {}).get(key) or self.semantic[key]
        raise ValueError("alias loop at %s" % value)


def inside(inner, outer):
    x, y, w, h = inner
    X, Y, Wd, Hd = outer
    return x >= X and y >= Y and x + w <= X + Wd and y + h <= Y + Hd


def over(src, dst, alpha, blend):
    if blend == "multiply":
        src = [s * d for s, d in zip(src, dst)]
    return [alpha * s + (1 - alpha) * d for s, d in zip(src, dst)]


def absolutise(node):
    """Put every box on the screen's own grid. A group's children fit inside the group's box; where
    an export wrote them in the group's own coordinates (they fit the group's size but not its
    position), the group's origin is added back."""
    kids = node.get("children", [])
    if kids and node["type"] == "group":
        gx, gy, gw, gh = node["box"]
        if not all(inside(k["box"], node["box"]) for k in kids) and all(inside(k["box"], [0, 0, gw, gh]) for k in kids):
            for k in kids:
                k["box"] = [k["box"][0] + gx, k["box"][1] + gy, k["box"][2], k["box"][3]]
    for k in kids:
        absolutise(k)
    return node


def paint_order(node, group=None):
    """Every node in paint order with the group (node) it belongs to, root excluded."""
    for child in node.get("children", []):
        if child["type"] == "group":
            yield child, group
            yield from paint_order(child, child)
        else:
            yield child, group


def backdrop_and_text(root, text_node, tokens, theme, profile):
    """Composite everything painted under and over the text's box, honouring group opacity as the
    tool does: a group's children paint into the group's own buffer, which is then blended over
    what lies beneath at the group's opacity. A layer painted after the text covers the text as
    well as its backdrop. Returns (rendered text colour, backdrop colour) in document space."""
    box = text_node["box"]
    painted = list(paint_order(root))
    tc = tokens.resolve(text_node["color"], theme, profile)
    backdrop, rendered = None, tc
    seen_text = False
    i = 0
    while i < len(painted):
        node, group = painted[i]
        if node is text_node:
            seen_text = True
            i += 1
            continue
        if node["type"] == "group":
            if not inside(box, node["box"]):
                i += 1
                continue
            # paint the group's covering children into a buffer
            members = []
            j = i + 1
            while j < len(painted) and painted[j][1] is node:
                members.append(painted[j][0])
                j += 1
            buf, holds_text = None, False
            for m in members:
                if m is text_node:
                    holds_text = True
                    seen_text = True
                    continue
                if m["type"] != "rect" or not inside(box, m["box"]):
                    continue
                c = tokens.resolve(m["fill"], theme, profile)
                buf = c if buf is None else over(c, buf, m["opacity"], m["blend"])
            if buf is not None:
                below = backdrop
                backdrop = over(buf, backdrop, node["opacity"], "normal")
                if holds_text:
                    rendered = over(tc, below, node["opacity"], "normal")
                elif seen_text:
                    rendered = over(buf, rendered, node["opacity"], "normal")
            elif holds_text:
                rendered = over(tc, backdrop, node["opacity"], "normal")
            i = j
            continue
        if node["type"] == "rect" and inside(box, node["box"]):
            c = tokens.resolve(node["fill"], theme, profile)
            backdrop = c if backdrop is None else over(c, backdrop, node["opacity"], node["blend"])
            if seen_text:
                rendered = over(c, rendered, node["opacity"], node["blend"])
        i += 1
    return rendered, backdrop


def level(r, size, weight):
    large = size >= 24 or (size >= 18.67 and weight >= 700)
    aa, aaa = (3.0, 4.5) if large else (4.5, 7.0)
    return "AAA" if r >= aaa else "AA" if r >= aa else "fail"


def main(root):
    tokens = Tokens(json.load(open(os.path.join(root, "tokens.json"), encoding="utf-8")))
    with open(os.path.join(root, "manifest.csv"), newline="", encoding="utf-8") as f:
        manifest = {r["screen"]: r for r in csv.DictReader(f)}
    rows = []
    for sid in sorted(manifest):
        m = manifest[sid]
        tree = absolutise(json.load(open(os.path.join(root, "screens", sid + ".json"), encoding="utf-8")))
        texts = [n for n, _ in paint_order(tree) if n["type"] == "text"]
        for t in texts:
            text_c, back_c = backdrop_and_text(tree, t, tokens, m["theme"], m["color_profile"])
            if m["color_profile"] == "Display P3":
                text_c, back_c = p3_to_srgb(text_c), p3_to_srgb(back_c)
            r = contrast(text_c, back_c)
            rows.append((t["id"], "%.2f" % r, level(r, t["size"], t["weight"])))
    rows.sort()
    os.makedirs(os.path.join(root, "out"), exist_ok=True)
    with open(os.path.join(root, "out", "contrast.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["element", "contrast", "level"])
        w.writerows(rows)
    print("wrote %d rows" % len(rows))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/app")
