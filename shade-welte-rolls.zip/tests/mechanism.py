"""The verifier's own model of a Welte-Mignon expression regulator.

From the sealed constants it plays every roll again and checks the shipped files against it: the
measured opening (proof.csv) is exactly the model's velocities for the notes before the measured
time, and every constant is pinned by the opening, in that moving it just far enough to fail the
roll also worsens the opening's least-squares fit by a clear margin. The graded key is the model's
velocity for every later note.
"""
import math

SPLIT = 52
NAMES = ("floor", "ceiling", "middle", "slow_up", "slow_down", "fast_up", "lag")
TOLERANCE = 3          # velocity steps a note may be off and still count (instruction.md)
SHARE_WRONG = 0.03     # share of a roll's graded notes that may be off (instruction.md)
MIN_RISE = 40.0
NEAR = 1e-9


def half_of(key):
    return "bass" if key <= SPLIT else "treble"


def sweep(c, valve_changes, onsets):
    """Level of one regulator at each onset. The level is a piecewise-linear function of time;
    each piece runs from one valve change to the next, with its slope and its stop set by the
    valves then open."""
    span = c["ceiling"] - c["floor"]
    slope = {"crescendo": span / c["slow_up"], "forzando": span / c["fast_up"], "fall": -span / c["slow_down"]}
    is_open = {"crescendo": False, "forzando": False, "hook": False}
    level, caught, t_level = c["floor"], False, 0.0
    queue = sorted(valve_changes)
    result, q = [], 0

    def level_at(t):
        dt = t - t_level
        if not (math.isfinite(level) and math.isfinite(dt)):
            raise ValueError("regulator level or time is not finite")
        if is_open["forzando"]:
            return min(c["ceiling"], level + slope["forzando"] * dt), False
        if caught and is_open["hook"]:
            return level, True
        rising = is_open["crescendo"]
        if rising:
            limit = c["middle"] if (is_open["hook"] and level < c["middle"] - NEAR) else c["ceiling"]
            value = min(limit, level + slope["crescendo"] * dt)
        else:
            limit = c["middle"] if (is_open["hook"] and level > c["middle"] + NEAR) else c["floor"]
            value = max(limit, level + slope["fall"] * dt)
        return value, (limit == c["middle"] and is_open["hook"] and abs(value - limit) < NEAR)

    for t in onsets:
        while q < len(queue) and queue[q][0] <= t:
            when, valve, state = queue[q]
            level, caught = level_at(when)
            t_level = when
            is_open[valve] = state
            if valve == "forzando" and state:
                caught = False
            if valve == "hook" and not state:
                caught = False
            q += 1
        value, _ = level_at(t)
        result.append(value)
    return result


def play(c, notes, expression):
    """Unrounded level for every note id; notes are (id, time, key), expression (time, half,
    valve, state)."""
    out = {}
    for half in ("bass", "treble"):
        changes = [(t + c["lag"], v, s) for t, h, v, s in expression if h == half]
        mine = sorted((t, i) for i, t, k in notes if half_of(k) == half)
        for (t, i), lv in zip(mine, sweep(c, changes, [t for t, _ in mine])):
            out[i] = lv
    return out


def whole(x):
    return int(math.floor(x + 0.5))


def problems(sealed, notes, expression, proof):
    """Where the shipped roll disagrees with the sealed truth (empty when it agrees)."""
    out = []
    c = sealed["constants"]
    if not (c["floor"] < c["middle"] < c["ceiling"]) or c["lag"] < 0:
        return ["the sealed constants are not an instrument"]
    until = sealed["measured_until"]
    levels = play(c, notes, expression)
    opening = [i for i, t, k in notes if t < until]
    graded = [i for i, t, k in notes if t >= until]
    if proof != {i: whole(levels[i]) for i in opening}:
        out.append("proof.csv is not the instrument's velocities for the opening")
    if {i: v for i, v in sealed["key"]} != {i: whole(levels[i]) for i in graded}:
        out.append("the sealed key is not the instrument's velocities")
    base = sum((levels[i] - proof.get(i, 0)) ** 2 for i in opening)
    for name in NAMES:
        for sign in (1, -1):
            for frac in (0.005, 0.01, 0.02, 0.035, 0.05, 0.08, 0.12, 0.18, 0.25):
                moved = dict(c)
                moved[name] = c[name] * (1 + sign * frac) if name != "lag" else c[name] + sign * frac * 0.5
                if not (moved["floor"] < moved["middle"] < moved["ceiling"]) or moved["lag"] < 0:
                    break
                lv = play(moved, notes, expression)
                off = sum(abs(whole(lv[i]) - whole(levels[i])) > TOLERANCE for i in graded)
                if off > SHARE_WRONG * len(graded):
                    rise = sum((lv[i] - proof.get(i, 0)) ** 2 for i in opening) - base
                    if not math.isfinite(rise) or rise < MIN_RISE:
                        out.append("the opening does not pin %s" % name)
                    break
    return out


def key_of(sealed):
    return {i: v for i, v in sealed["key"]}
