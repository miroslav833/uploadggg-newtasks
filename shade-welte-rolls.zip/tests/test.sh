#!/usr/bin/env bash
# Verifier entry point for the roll-shading task.
#
# 1. Lock the reward channel before anything uploaded runs: /logs/verifier root-owned, mode 700,
#    reward-like files removed, reward.txt = 0.
# 2. Run the archive check and the booth check.
# 3. Clean the channel again and write reward.txt once: 1 only if both checks passed.
set -u

OUT=/logs/verifier
WORK=/run/verifier

mkdir -p "$OUT"
saved_mode="$(stat -c %a "$OUT" 2>/dev/null || echo 755)"
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier 2>/dev/null

purge() {
    find "$OUT" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
    find "$OUT" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    rm -f /logs/verifier/reward.json
}

publish() {
    purge
    (umask 022; printf '%s\n' "$1" > "$OUT/reward.txt")
}

finish() {
    chmod "$saved_mode" "$OUT" 2>/dev/null
    exit 0
}
trap finish EXIT

publish 0
if [ "$(stat -c '%u:%a' /logs/verifier 2>/dev/null)" != "0:700" ]; then
    echo "verifier: the reward channel could not be locked; not grading" >&2
    exit 0
fi

chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$WORK" && chown 0:0 "$WORK" && chmod 700 "$WORK"
mkdir -p /var/tmp/booth && chmod 755 /var/tmp/booth
chmod -R a+rX /app/rolls 2>/dev/null

passed=0
if ( cd /tests && python3 -m pytest test_rolls.py -q -p no:cacheprovider --ctrf "$WORK/ctrf.json" ); then
    passed=1
fi
publish "$passed"
for f in ctrf.json rolls.json; do
    [ -f "$WORK/$f" ] && (umask 022; cp "$WORK/$f" "$OUT/$f")
done
