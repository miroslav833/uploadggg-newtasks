"""Grading. The archive check plays every held roll again from its sealed instrument with the
verifier's own regulator model (tests/mechanism.py) and checks the shipped files against it, so
the key is what the instrument and the roll imply. The booth check runs the uploaded program on
every held roll and counts the rolls it shades within the printed bounds."""
import csv
import json
import math
import os

import pytest

import booth
import mechanism

TRUTH = "/tests/archive/truth"
HELD = 20
MARK = 18                                  # rolls that must count (instruction.md)
WRONG_ALLOWED = mechanism.SHARE_WRONG      # share of a roll's graded notes that may be off (instruction.md)


def sealed(code):
    with open(os.path.join(TRUTH, code + ".json")) as fh:
        return json.load(fh)


def roll_files(code):
    folder = os.path.join(booth.ROLLS, code)
    with open(os.path.join(folder, "notes.csv"), newline="") as fh:
        notes = [(int(r["note"]), float(r["time"]), int(r["key"])) for r in csv.DictReader(fh)]
    with open(os.path.join(folder, "expression.csv"), newline="") as fh:
        expression = [(float(r["time"]), r["half"], r["valve"], r["state"] == "on") for r in csv.DictReader(fh)]
    with open(os.path.join(folder, "proof.csv"), newline="") as fh:
        proof = {int(r["note"]): int(r["velocity"]) for r in csv.DictReader(fh)}
    return notes, expression, proof


def test_archive_matches_the_instruments():
    codes = booth.held_rolls()
    assert len(codes) == HELD
    for code in codes:
        assert mechanism.problems(sealed(code), *roll_files(code)) == [], code


@pytest.fixture(scope="session")
def booth_results():
    results = {}
    for code in booth.held_rolls():
        key = mechanism.key_of(sealed(code))
        filed = booth.shade(code)
        off = sum(1 for note, v in key.items()
                  if note not in filed or not math.isfinite(filed[note]) or abs(filed[note] - v) > mechanism.TOLERANCE)
        results[code] = {"off": off, "graded": len(key)}
    with open(os.path.join(booth.REPORTS, "rolls.json"), "w") as fh:
        json.dump(results, fh, indent=1)
    return results


def test_enough_rolls_shaded(booth_results):
    good = [c for c, r in booth_results.items() if r["off"] <= WRONG_ALLOWED * r["graded"]]
    assert len(good) >= MARK, "%d of %d rolls shaded within bounds (%s); %d needed" % (
        len(good), HELD, booth_results, MARK)
