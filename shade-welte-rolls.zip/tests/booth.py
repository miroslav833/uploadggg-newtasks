"""The listening booth: runs the uploaded shading program on one held roll at a time.

A roll is copied into a fresh directory owned by a numeric account made up for the run. The program
runs there as that account, with no supplementary groups, in a session of its own, under a shell
that limits address space, file size and core dumps, and with a time limit. Afterwards every
process of the account is killed and the result is taken back only as a regular file of bounded
size, opened without following links and parsed as text.
"""
import csv
import os
import shutil
import signal
import subprocess
import time

ROLLS = "/tests/archive/rolls"
REPORTS = "/run/verifier"
SPOOL = "/var/tmp/booth"
PROGRAM = "/app/rolls/shade.py"
TIME_LIMIT = 60
SIZE_LIMIT = 1 << 20
FIRST_ACCOUNT = 61000


def held_rolls():
    return sorted(os.listdir(ROLLS))


def pick_account():
    in_use = set()
    for name in os.listdir("/proc"):
        if name.isdigit():
            try:
                in_use.add(os.stat(os.path.join("/proc", name)).st_uid)
            except OSError:
                pass
    account = FIRST_ACCOUNT
    while account in in_use:
        account += 1
    return account


def end_all(account):
    deadline = time.time() + 10
    while time.time() < deadline:
        left = []
        for name in os.listdir("/proc"):
            if not name.isdigit():
                continue
            try:
                if os.stat(os.path.join("/proc", name)).st_uid == account:
                    left.append(int(name))
            except OSError:
                pass
        if not left:
            return
        for pid in left:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.05)


def take_back(path):
    """{note: velocity} from the filed CSV; rows that are not two integers are left out."""
    if os.path.islink(path) or not os.path.isfile(path):
        return {}
    try:
        if os.lstat(path).st_size > SIZE_LIMIT:
            return {}
        handle = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return {}
    with os.fdopen(handle, "r", encoding="utf-8", errors="replace", newline="") as fh:
        text = fh.read(SIZE_LIMIT + 1)
    if len(text) > SIZE_LIMIT:
        return {}
    filed = {}
    for row in csv.DictReader(text.splitlines()):
        note, velocity = (row.get("note") or "").strip(), (row.get("velocity") or "").strip()
        if note.isdigit() and velocity.lstrip("-").isdigit() and int(note) not in filed:
            filed[int(note)] = int(velocity)
    return filed


def shade(code):
    account = pick_account()
    room = os.path.join(SPOOL, code)
    shutil.rmtree(room, ignore_errors=True)
    os.makedirs(os.path.join(room, "home"))
    shutil.copytree(os.path.join(ROLLS, code), os.path.join(room, "roll"), symlinks=False)
    for top, dirs, files in os.walk(room):
        os.chown(top, account, account)
        for name in files:
            os.chown(os.path.join(top, name), account, account)
    result = os.path.join(room, "velocities.csv")
    script = "ulimit -v 1048576 -f 16384 -c 0; exec python3 %s %s %s" % (PROGRAM, os.path.join(room, "roll"), result)
    with open(os.path.join(REPORTS, code + ".log"), "wb") as log:
        try:
            subprocess.run(["bash", "-c", script], user=account, group=account, extra_groups=[],
                           cwd=os.path.join(room, "home"), stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                           env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": os.path.join(room, "home"),
                                "LANG": "C.UTF-8"},
                           start_new_session=True, timeout=TIME_LIMIT, check=False)
        except subprocess.TimeoutExpired:
            log.write(b"\n[stopped at the time limit]\n")
    end_all(account)
    filed = take_back(result)
    shutil.rmtree(room, ignore_errors=True)
    return filed
