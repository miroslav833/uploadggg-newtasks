#!/usr/bin/env python3
"""Cuts the rolls of the roll-restoration project: three sample rolls measured in full on the
reference instrument, and twenty held rolls on other instruments, measured for their opening
passage only, with their sealed truth.  stdlib only, seeded.

    cut.py samples OUT_DIR
    cut.py held ROLLS_DIR TRUTH_DIR

Each half of the keyboard (bass: keys up to 52; treble: 53 and up) has a regulator whose level, in
velocity units, rises at a slow rate while its crescendo valve is open, at a fast rate while its
forzando valve is open, and otherwise falls at a slow rate, never below the instrument's floor or
above its ceiling. While the mezzoforte hook is on, the level stops at the middle level when it
reaches it from either side, unless the forzando valve is open. A valve or hook acts a fixed lag
after its perforation passes the tracker bar. A note sounds at its regulator's level at its onset,
rounded to a whole velocity.
"""
import json
import math
import os
import random
import sys

SPLIT = 52                 # highest bass key
HALVES = ("bass", "treble")
VALVES = ("crescendo", "forzando", "hook")
REFERENCE = {"floor": 25.0, "ceiling": 105.0, "middle": 62.0, "slow_up": 5.0, "slow_down": 7.0,
             "fast_up": 0.8, "lag": 0.12}
LENGTH = (140.0, 170.0)    # seconds of music per roll
OPENING = 40.0             # seconds measured on a held roll's instrument
TOLERANCE_V = 3            # a note is right within this many velocity steps
SHARE_WRONG = 0.03         # a roll counts with at most this share of its graded notes wrong
EPS = 1e-9


# ------------------------------------------------------------------------- the regulator ----
def rates(c):
    span = c["ceiling"] - c["floor"]
    return span / c["slow_up"], span / c["slow_down"], span / c["fast_up"]


def levels(c, changes, times):
    """The regulator level at each time in `times` (sorted), given `changes`, a list of
    (effective time, valve, on) sorted by time, for one half."""
    up, down, fast = rates(c)
    state = {v: False for v in VALVES}
    level, caught, now = c["floor"], False, 0.0
    out, k = [], 0
    events = sorted(changes)

    def advance(level, caught, t0, t1):
        """Move the level from t0 to t1 under the current state."""
        dt = t1 - t0
        if not (math.isfinite(level) and math.isfinite(dt)):
            raise ValueError("regulator level or time is not finite")
        if dt <= 0:
            return level, caught
        if state["forzando"]:
            return min(c["ceiling"], level + fast * dt), False
        if caught and state["hook"]:
            return level, True
        if state["crescendo"]:
            target = c["ceiling"]
            if state["hook"] and level < c["middle"] - EPS:
                target = c["middle"]
            new = min(target, level + up * dt)
            return new, state["hook"] and abs(new - c["middle"]) < EPS and target == c["middle"]
        target = c["floor"]
        if state["hook"] and level > c["middle"] + EPS:
            target = c["middle"]
        new = max(target, level - down * dt)
        return new, state["hook"] and abs(new - c["middle"]) < EPS and target == c["middle"]

    for t in times:
        while k < len(events) and events[k][0] <= t:
            et, valve, on = events[k]
            level, caught = advance(level, caught, now, et)
            now = et
            state[valve] = on
            if valve == "hook" and not on:
                caught = False
            if valve == "forzando" and on:
                caught = False
            k += 1
        level, caught = advance(level, caught, now, t)
        now = t
        out.append(level)
    return out


def velocities(c, notes, expression):
    """Velocity of every note: (note id -> int)."""
    out = {}
    for half in HALVES:
        changes = [(t + c["lag"], valve, on) for t, h, valve, on in expression if h == half]
        mine = sorted((n["time"], n["id"]) for n in notes if (n["key"] <= SPLIT) == (half == "bass"))
        for (t, nid), lv in zip(mine, levels(c, changes, [t for t, _ in mine])):
            out[nid] = int(math.floor(lv + 0.5))
    return out


# --------------------------------------------------------------------------- the music ----
def draw_constants(rng):
    """An instrument's constants, each well away from the reference instrument's."""
    def away(lo, hi, ref, gap):
        while True:
            x = rng.uniform(lo, hi)
            if math.isfinite(x) and abs(x - ref) >= gap:
                return round(x, 3)
    return {"floor": away(16, 34, REFERENCE["floor"], 4), "ceiling": away(94, 120, REFERENCE["ceiling"], 5),
            "middle": away(52, 74, REFERENCE["middle"], 4), "slow_up": away(2.5, 9.0, REFERENCE["slow_up"], 1.2),
            "slow_down": away(3.5, 13.0, REFERENCE["slow_down"], 1.8), "fast_up": away(0.35, 1.6, REFERENCE["fast_up"], 0.25),
            "lag": away(0.04, 0.32, REFERENCE["lag"], 0.07)}


def draw_roll(rng, length):
    """Note onsets and expression perforations for one roll."""
    notes, t, nid = [], 0.4, 0
    while t < length:
        for _ in range(rng.choice([1, 1, 2, 2, 3])):
            half = rng.random() < 0.45
            key = rng.randint(28, SPLIT) if half else rng.randint(SPLIT + 1, 96)
            notes.append({"id": nid, "time": round(t + rng.uniform(0, 0.03), 3), "key": key})
            nid += 1
        t += rng.choice([0.12, 0.18, 0.25, 0.25, 0.35, 0.5])
    notes.sort(key=lambda n: (n["time"], n["id"]))
    for i, n in enumerate(notes):
        n["id"] = i
    expression = []
    for half in HALVES:
        t = rng.uniform(0.5, 2.0)
        hook = False
        while t < length - 2:
            kind = rng.choice(["crescendo", "crescendo", "forzando", "rest", "rest", "hook"])
            if kind == "rest":
                t += rng.uniform(1.0, 5.0)
                continue
            if kind == "hook":
                hook = not hook
                expression.append((round(t, 3), half, "hook", hook))
                t += rng.uniform(0.5, 2.0)
                continue
            dur = rng.uniform(1.5, 7.0) if kind == "crescendo" else rng.uniform(0.15, 0.9)
            expression.append((round(t, 3), half, kind, True))
            expression.append((round(t + dur, 3), half, kind, False))
            t += dur + rng.uniform(0.8, 4.0)
        if hook:
            expression.append((round(length - 1, 3), half, "hook", False))
    expression.sort()
    return notes, expression


def opening_evidence(c, notes, expression, cut):
    """Whether the measured opening shows each half's regulator in every regime: rising slowly,
    falling, rising fast, at the floor, at the ceiling and caught at the middle, with notes within
    half a second after valve changes."""
    for half in HALVES:
        changes = [(t + c["lag"], valve, on) for t, h, valve, on in expression if h == half and t < cut]
        mine = sorted(n["time"] for n in notes if (n["key"] <= SPLIT) == (half == "bass") and n["time"] < cut)
        lv = levels(c, changes, mine)
        if not all(math.isfinite(x) for x in lv):
            return False
        regimes = {"floor": 0, "ceiling": 0, "middle": 0, "moving": 0}
        for a, b in zip(lv, lv[1:]):
            if abs(b - c["floor"]) < EPS:
                regimes["floor"] += 1
            elif abs(b - c["ceiling"]) < EPS:
                regimes["ceiling"] += 1
            elif abs(b - c["middle"]) < EPS and abs(a - c["middle"]) < EPS:
                regimes["middle"] += 1
            elif abs(b - a) > 0.5:
                regimes["moving"] += 1
        fast = 0
        for t, h, v, on in expression:
            if h == half and v == "forzando" and on and t < cut:
                fast += sum(1 for x in mine if t + c["lag"] < x)
        if min(regimes["floor"], regimes["ceiling"], regimes["middle"]) < 1 or regimes["moving"] < 20 or fast < 4:
            return False
        valves = [t + c["lag"] for t, h, v, on in expression if h == half and t < cut]
        close = sum(any(0 < x - v < 0.5 for v in valves) for x in mine)
        if close < 8:
            return False
    return True


def predicted(c, notes, expression):
    """Unrounded level of every note, by id."""
    out = {}
    for half in HALVES:
        changes = [(t + c["lag"], valve, on) for t, h, valve, on in expression if h == half]
        mine = sorted((n["time"], n["id"]) for n in notes if (n["key"] <= SPLIT) == (half == "bass"))
        for (t, nid), lv in zip(mine, levels(c, changes, [t for t, _ in mine])):
            out[nid] = lv
    return out


MIN_RISE = 40.0       # rise in the opening's squared misfit that any roll-failing move of a constant must cause


def identifiable(roll):
    """Whether every constant, moved just far enough to fail the roll (more than SHARE_WRONG of its
    graded notes off by more than TOLERANCE_V), also worsens the opening's least-squares fit by
    MIN_RISE."""
    c, notes, expr, cut = roll["constants"], roll["notes"], roll["expression"], roll["measured_until"]
    vel = roll["velocities"]
    opening = [n["id"] for n in notes if n["time"] < cut]
    graded = [n["id"] for n in notes if n["time"] >= cut]

    def misfit(cc):
        p = predicted(cc, notes, expr)
        if not all(math.isfinite(x) for x in p.values()):
            return float("inf"), len(graded)
        return sum((p[i] - vel[i]) ** 2 for i in opening), sum(abs(math.floor(p[i] + 0.5) - vel[i]) > TOLERANCE_V
                                                              for i in graded)

    base, _ = misfit(c)
    for name in c:
        for sign in (1, -1):
            for frac in (0.005, 0.01, 0.02, 0.035, 0.05, 0.08, 0.12, 0.18, 0.25):
                cc = dict(c)
                cc[name] = c[name] * (1 + sign * frac) if name != "lag" else c[name] + sign * frac * 0.5
                if not (cc["floor"] < cc["middle"] < cc["ceiling"]) or cc["lag"] < 0:
                    break
                fit_, off = misfit(cc)
                if off > SHARE_WRONG * len(graded):
                    if fit_ - base < MIN_RISE:
                        return False
                    break
    return True


def build(code, seed, constants, measured_until):
    rng = random.Random(seed)
    length = rng.uniform(*LENGTH)
    notes, expression = draw_roll(rng, length)
    vel = velocities(constants, notes, expression)
    return {"code": code, "seed": seed, "constants": constants, "notes": notes, "expression": expression,
            "velocities": vel, "measured_until": measured_until}


# ----------------------------------------------------------------------------- writers ----
def write_roll(roll, out_dir):
    d = os.path.join(out_dir, roll["code"])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "notes.csv"), "w") as fh:
        fh.write("note,time,key\n")
        for n in roll["notes"]:
            fh.write("%d,%.3f,%d\n" % (n["id"], n["time"], n["key"]))
    with open(os.path.join(d, "expression.csv"), "w") as fh:
        fh.write("time,half,valve,state\n")
        for t, half, valve, on in roll["expression"]:
            fh.write("%.3f,%s,%s,%s\n" % (t, half, valve, "on" if on else "off"))
    with open(os.path.join(d, "proof.csv"), "w") as fh:
        fh.write("note,velocity\n")
        for n in roll["notes"]:
            if n["time"] < roll["measured_until"]:
                fh.write("%d,%d\n" % (n["id"], roll["velocities"][n["id"]]))


def write_sealed(roll, sealed_dir):
    os.makedirs(sealed_dir, exist_ok=True)
    with open(os.path.join(sealed_dir, roll["code"] + ".json"), "w") as fh:
        json.dump({"code": roll["code"], "seed": roll["seed"], "constants": roll["constants"],
                   "measured_until": roll["measured_until"],
                   "key": [[n["id"], roll["velocities"][n["id"]]] for n in roll["notes"]
                           if n["time"] >= roll["measured_until"]]}, fh)


SAMPLES = [("S1", 101), ("S2", 102), ("S3", 103)]
HELD = [("R%02d" % i, 2000 + i) for i in range(1, 21)]


def held_roll(spec, max_tries=500):
    code, seed = spec
    for t in range(max_tries):
        rng = random.Random(seed * 7 + t)
        c = draw_constants(rng)
        roll = build(code, seed + 100000 * t, c, OPENING)
        if opening_evidence(c, roll["notes"], roll["expression"], OPENING) and identifiable(roll):
            return roll
    raise SystemExit("%s: no roll whose opening shows the instrument in %d tries" % (code, max_tries))


def sample_roll(spec, max_tries=500):
    code, seed = spec
    for t in range(max_tries):
        roll = build(code, seed + 100000 * t, dict(REFERENCE), 1e9)
        if opening_evidence(REFERENCE, roll["notes"], roll["expression"], 1e9):
            return roll
    raise SystemExit("%s: no sample in %d tries" % (code, max_tries))


def main():
    if sys.argv[1] == "samples":
        for spec in SAMPLES:
            roll = sample_roll(spec)
            write_roll(roll, sys.argv[2])
            print(spec[0], "ok", len(roll["notes"]), "notes")
    elif sys.argv[1] == "held":
        for spec in HELD:
            roll = held_roll(spec)
            write_roll(roll, sys.argv[2])
            write_sealed(roll, sys.argv[3])
            print(spec[0], "ok", len(roll["notes"]), "notes", roll["constants"])
    else:
        raise SystemExit("cut.py samples OUT_DIR | held ROLLS_DIR TRUTH_DIR")


if __name__ == "__main__":
    main()
