Work out how loud a reproducing piano plays every note of a perforated roll. Your program is called as

```
python3 /app/rolls/shade.py ROLL_DIR OUT_CSV
```

ROLL_DIR is one Welte-Mignon roll from the restoration project: `notes.csv` (each note perforation's start time and key), `expression.csv` (the expression perforations of the bass and treble halves) and `proof.csv` (the hammer velocities measured on the roll's own instrument for the opening of the roll). `/app/archive/NOTES.md` explains the tracker bar, the expression mechanism and the files, and `/app/archive/samples/` holds three rolls measured in full on the project's reference instrument.

OUT_CSV gets a header and one row per note of the roll with the whole-number hammer velocity (1 to 127) the roll's instrument strikes it with:

```
note,velocity
0,25
1,25
```

Each roll is played on its own instrument, and the instruments are not alike; the only measurements of a roll's instrument are in its `proof.csv`.

Only the notes after the measured opening are checked. A note is right when its velocity is within 3 of ours; a missing or unreadable row is wrong. A roll is good when no more than 3 per cent of its checked notes are wrong, and the task needs 18 good rolls out of 20 held-back rolls from other instruments. Each roll is run separately with a fresh copy of its folder, as an unprivileged user, for at most 60 seconds, with python3 and its standard library only. Put anything else your program uses under `/app/rolls`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
