# Roll restoration: encoding and measurements

## The project

The project renders perforated rolls of Welte-Mignon reproducing pianos (red rolls, the T-100
scale) to MIDI for the archive. A reproducing piano plays not only the notes cut in the roll but
their loudness: expression perforations, read by the same tracker bar, work the instrument's
expression mechanism, and the hammer velocity of every note follows from it. The program this note
accompanies gives that velocity for every note of a roll.

## The tracker bar

The note perforations cover keys 28 to 96 (MIDI key numbers). The expression perforations sit at
the two edges of the tracker bar, one set for each half of the keyboard: the bass half is keys up
to 52, the treble half keys from 53. Each half has its own expression regulator and its own
perforations:

- the crescendo valve: the slow crescendo, open while its perforation runs;
- the forzando valve: the fast crescendo, open while its perforation runs;
- the mezzoforte hook, set by one perforation and released by another.

As the Welte literature describes the mechanism, the regulator of a half rises slowly while the
crescendo valve is open and sinks slowly back when it is closed; the forzando valve drives it up
quickly; between them it stays within the softest and the loudest the instrument can play, and the
mezzoforte hook catches it at the instrument's middle level. Every note sounds at the level its
half's regulator has when the note's hammer is thrown.

Restored instruments differ: each has its own softest, middle and loudest levels, its own speeds of
crescendo, decrescendo and forzando, and its own delay between a perforation passing the tracker
bar and the valve acting on the regulator.

## The files

A roll is a folder with three files. Times are seconds from the start of the roll at the roll's
playing speed.

`notes.csv`, one row per note perforation, by its start:

```
note,time,key
0,0.412,67
1,0.415,43
```

`expression.csv`, one row per expression perforation edge:

```
time,half,valve,state
0.907,treble,forzando,on
1.186,treble,forzando,off
3.050,bass,hook,on
```

`valve` is `crescendo`, `forzando` or `hook`; `state` is `on` where the valve opens (the hook is
set) and `off` where it closes (the hook is released).

`proof.csv`, the velocities measured on the roll's own instrument, note by note:

```
note,velocity
0,25
1,25
```

## The measurements

The three sample rolls in `samples/` were played in full on the project's reference instrument and
every note measured. Every other roll comes from another instrument, and its `proof.csv` holds the
velocities measured on that instrument for the roll's opening passage only, every note up to a
moment in the roll; the rest is what the program must give.
