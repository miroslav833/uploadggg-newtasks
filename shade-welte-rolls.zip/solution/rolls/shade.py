#!/usr/bin/env python3
"""Hammer velocities of a reproducing-piano roll.

    python3 shade.py ROLL_DIR OUT_CSV

Each half of the keyboard (bass up to key 52, treble from 53) has its own expression regulator.
Its level rises slowly while the crescendo valve is open, fast while the forzando valve is open,
and otherwise falls slowly, between the instrument's floor and ceiling; while the mezzoforte hook
is on, the level stops at the middle level when it reaches it from either side, unless forzando
is open. Valves act a fixed lag after their perforations. A note sounds at its half's level at
its onset.

The instrument's seven constants (floor, ceiling, middle, the times of a full slow rise, a full
slow fall and a full fast rise, and the lag) are fitted to the velocities measured for the roll's
opening (proof.csv) by least squares, and the rest of the roll is played with them.
"""
import csv
import math
import os
import sys

SPLIT = 52
NAMES = ("floor", "ceiling", "middle", "slow_up", "slow_down", "fast_up", "lag")
START = {"floor": 25.0, "ceiling": 105.0, "middle": 62.0, "slow_up": 5.0, "slow_down": 7.0, "fast_up": 0.8,
         "lag": 0.12}
BOUNDS = {"floor": (5, 60), "ceiling": (70, 127), "middle": (30, 100), "slow_up": (0.5, 20), "slow_down": (0.5, 30),
          "fast_up": (0.1, 4), "lag": (0.0, 0.6)}
TINY = 1e-9


def read(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def regulator(c, changes, times):
    """Level of one half's regulator at each of the sorted `times`; `changes` are (time, valve,
    on) as they reach the regulator."""
    span = c["ceiling"] - c["floor"]
    up, down, fast = span / c["slow_up"], span / c["slow_down"], span / c["fast_up"]
    open_ = {"crescendo": False, "forzando": False, "hook": False}
    level, held, clock = c["floor"], False, 0.0
    out, i = [], 0

    def run(level, held, dt):
        if dt <= 0:
            return level, held
        if open_["forzando"]:
            return min(c["ceiling"], level + fast * dt), False
        if held and open_["hook"]:
            return level, True
        if open_["crescendo"]:
            stop = c["middle"] if (open_["hook"] and level < c["middle"] - TINY) else c["ceiling"]
            new = min(stop, level + up * dt)
        else:
            stop = c["middle"] if (open_["hook"] and level > c["middle"] + TINY) else c["floor"]
            new = max(stop, level - down * dt)
        return new, open_["hook"] and stop == c["middle"] and abs(new - stop) < TINY

    for t in times:
        while i < len(changes) and changes[i][0] <= t:
            when, valve, on = changes[i]
            level, held = run(level, held, when - clock)
            clock = when
            open_[valve] = on
            if (valve == "hook" and not on) or (valve == "forzando" and on):
                held = False
            i += 1
        level, held = run(level, held, t - clock)
        clock = t
        out.append(level)
    return out


class Roll:
    def __init__(self, roll_dir):
        self.notes = [(int(r["note"]), float(r["time"]), int(r["key"])) for r in read(os.path.join(roll_dir, "notes.csv"))]
        self.expression = [(float(r["time"]), r["half"], r["valve"], r["state"] == "on")
                           for r in read(os.path.join(roll_dir, "expression.csv"))]
        path = os.path.join(roll_dir, "proof.csv")
        self.proof = {int(r["note"]): int(r["velocity"]) for r in read(path)} if os.path.exists(path) else {}
        self.halves = {}
        for half in ("bass", "treble"):
            mine = sorted((t, n) for n, t, k in self.notes if (k <= SPLIT) == (half == "bass"))
            self.halves[half] = ([t for t, _ in mine], [n for _, n in mine],
                                 [(t, v, on) for t, h, v, on in self.expression if h == half])
        self.bounds = dict(BOUNDS)
        self.until = max([t for n, t, k in self.notes if n in self.proof], default=-1.0) + TINY

    def play(self, c, only_proof=False):
        out = {}
        for half, (times, ids, valves) in self.halves.items():
            if only_proof:
                keep = [k for k, t in enumerate(times) if t <= self.until]
                times, ids = [times[k] for k in keep], [ids[k] for k in keep]
            changes = sorted((t + c["lag"], v, on) for t, v, on in valves)
            for nid, lv in zip(ids, regulator(c, changes, times)):
                out[nid] = lv
        return out

    def misfit(self, c):
        if not (c["floor"] < c["middle"] < c["ceiling"]):
            return float("inf")
        got = self.play(c, only_proof=True)
        return sum((got[n] - v) ** 2 for n, v in self.proof.items())


def descend(roll, c, rounds, step=None):
    """Coordinate search with shrinking steps from `c`."""
    err = roll.misfit(c)
    step = dict(step or {"floor": 1.0, "ceiling": 1.0, "middle": 1.0, "slow_up": 0.8, "slow_down": 1.2,
                         "fast_up": 0.15, "lag": 0.02})
    for _ in range(rounds):
        moved = False
        for name in NAMES:
            if not step[name]:
                continue
            for sign in (1, -1):
                trial = dict(c)
                lo, hi = roll.bounds[name]
                trial[name] = min(hi, max(lo, c[name] + sign * step[name]))
                e = roll.misfit(trial)
                if e < err - 1e-9:
                    c, err, moved = trial, e, True
                    break
        if not moved:
            if all(step[n] < 1e-4 * (1 + abs(c[n])) or step[n] == 0 for n in NAMES):
                break
            step = {n: s / 2 for n, s in step.items()}
    return err, c


def plateaus(roll):
    """Velocities one half of the opening holds unchanged for at least 0.6 seconds (chords struck
    together do not count), with how often."""
    counts = {}
    for half, (ts, ids, _) in roll.halves.items():
        seq = [(t, roll.proof[n]) for t, n in zip(ts, ids) if n in roll.proof]
        start = 0
        for k in range(1, len(seq) + 1):
            if k == len(seq) or seq[k][1] != seq[start][1]:
                if seq[k - 1][0] - seq[start][0] >= 0.6:
                    counts[seq[start][1]] = counts.get(seq[start][1], 0) + 1
                start = k
    return counts


def held_levels(roll, lo, hi):
    """Velocities between the extremes that a half of the opening repeats on consecutive notes,
    most repeated first: the places the middle level can be."""
    counts = {}
    for half, (ts, ids, _) in roll.halves.items():
        seq = [roll.proof[n] for n in ids if n in roll.proof]
        for x, y in zip(seq, seq[1:]):
            if x == y and lo + 2 < x < hi - 2:
                counts[x] = counts.get(x, 0) + 1
    return [v for v, _ in sorted(counts.items(), key=lambda kv: -kv[1])]


def fit_with_middle(roll, lo, hi, mid, pinned, lags):
    """Search with the floor and ceiling pinned to the extremes and, if `pinned`, the middle to
    `mid`: the three speeds first from a grid of lags, then all seven from the best starts."""
    roll.bounds = dict(BOUNDS)
    roll.bounds["floor"] = (lo - 0.5, lo + 0.5)
    roll.bounds["ceiling"] = (hi - 0.5, hi + 0.5)
    if pinned:
        roll.bounds["middle"] = (mid - 0.5, mid + 0.5)
    speeds = {"floor": 0.0, "ceiling": 0.0, "middle": 0.0, "slow_up": 0.8, "slow_down": 1.2, "fast_up": 0.15,
              "lag": 0.0}
    starts = []
    for lag in lags:
        for fast in (0.5, 1.1):
            c = dict(START, floor=lo, ceiling=hi, middle=mid, lag=lag, fast_up=fast)
            starts.append(descend(roll, c, 10, speeds))
    starts.sort(key=lambda x: x[0])
    best = min((descend(roll, c, 400) for _, c in starts[:4]), key=lambda x: x[0])
    return wander(roll, *best)


def fit(roll):
    """Least-squares constants. A level the regulator rests at shows itself, rounded, on every note
    struck while it rests: the floor and ceiling are the opening's extremes (it reaches both) and
    the middle its most held level between. If the best fit is still far worse than rounding
    explains (more than one squared step per measured note), every level the opening repeats is
    tried as the middle in turn and the best fit kept."""
    vals = sorted(roll.proof.values())
    if not vals:
        return dict(START)
    lo, hi = float(vals[0]), float(vals[-1])
    held = plateaus(roll)
    inner = [(n, v) for v, n in held.items() if lo + 3 < v < hi - 3]
    mid = float(max(inner)[1]) if inner else (lo + hi) / 2
    best = fit_with_middle(roll, lo, hi, mid, bool(inner), [0.02 * k for k in range(21)])
    if best[0] > len(roll.proof):
        for level in held_levels(roll, lo, hi)[:6]:
            if inner and level == mid:
                continue
            got = fit_with_middle(roll, lo, hi, float(level), True, [0.04 * k for k in range(11)])
            if got[0] < best[0]:
                best = got
            if best[0] <= len(roll.proof):
                break
    return best[1]


def wander(roll, err, c, rounds=2500):
    """Random joint moves of all seven constants with steps that shrink when moves stop paying,
    then a final coordinate search: escapes the ridges a one-constant-at-a-time search stops on."""
    import random
    rng = random.Random(7)
    scale = {"floor": 1.5, "ceiling": 1.5, "middle": 1.5, "slow_up": 0.5, "slow_down": 0.8, "fast_up": 0.12,
             "lag": 0.03}
    fails = 0
    for _ in range(rounds):
        trial = {}
        for n in NAMES:
            lo, hi = roll.bounds[n]
            trial[n] = min(hi, max(lo, c[n] + rng.gauss(0, scale[n])))
        e = roll.misfit(trial)
        if e < err:
            c, err, fails = trial, e, 0
        else:
            fails += 1
            if fails > 60:
                scale = {n: v * 0.7 for n, v in scale.items()}
                fails = 0
                if all(v < 1e-3 for v in scale.values()):
                    break
    return descend(roll, c, 200)


def solve(roll_dir):
    roll = Roll(roll_dir)
    c = fit(roll) if roll.proof else dict(START)
    levels = roll.play(c)
    out = []
    for nid, t, key in roll.notes:
        v = roll.proof.get(nid)
        if v is None:
            v = int(math.floor(levels[nid] + 0.5))
        out.append((nid, max(1, min(127, v))))
    return out


def main():
    rows = solve(sys.argv[1])
    os.makedirs(os.path.dirname(os.path.abspath(sys.argv[2])), exist_ok=True)
    with open(sys.argv[2], "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["note", "velocity"])
        for nid, v in rows:
            w.writerow([nid, v])


if __name__ == "__main__":
    main()
