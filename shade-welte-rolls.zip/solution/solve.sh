#!/bin/bash
# Installs the shading program where the grader expects it and checks it on the three sample rolls:
# each is cut back to its first 40 seconds of measurements, shaded, and compared with the full
# measurement.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/rolls /app/out
cp "$HERE/rolls/shade.py" /app/rolls/shade.py
for roll in /app/archive/samples/*/; do
    code="$(basename "$roll")"
    python3 - "$roll" "/app/out/$code" <<'PY'
import csv, os, shutil, subprocess, sys
src, work = sys.argv[1], sys.argv[2]
shutil.rmtree(work, ignore_errors=True)
os.makedirs(work)
for name in ("notes.csv", "expression.csv"):
    shutil.copy(os.path.join(src, name), work)
times = {r["note"]: float(r["time"]) for r in csv.DictReader(open(os.path.join(src, "notes.csv")))}
full = {r["note"]: int(r["velocity"]) for r in csv.DictReader(open(os.path.join(src, "proof.csv")))}
with open(os.path.join(work, "proof.csv"), "w") as fh:
    fh.write("note,velocity\n")
    for n, v in full.items():
        if times[n] < 40.0:
            fh.write("%s,%d\n" % (n, v))
subprocess.run(["python3", "/app/rolls/shade.py", work, os.path.join(work, "out.csv")], check=True)
got = {r["note"]: int(r["velocity"]) for r in csv.DictReader(open(os.path.join(work, "out.csv")))}
later = [n for n in full if times[n] >= 40.0]
close = sum(1 for n in later if n in got and abs(got[n] - full[n]) <= 3)
print("%s: %d of %d later notes within 3 of the measurement" % (os.path.basename(src.rstrip("/")), close, len(later)))
PY
done
