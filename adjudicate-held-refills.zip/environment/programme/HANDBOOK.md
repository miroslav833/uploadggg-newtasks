# Claims review programme: the refill-too-soon edit and the review model

## Adjudication

A pharmacy sends a claim when a member presents a prescription; the plan adjudicates it at once and
the pharmacy dispenses only what the plan pays. One of the plan's automated edits is the
**refill-too-soon edit**: a refill is rejected when too much of the member's previous supply of that
drug should still be on hand. Every plan in the programme runs such an edit, and every plan sets it
in its own way: how much of the earlier supply must have been used, how supply left over from
earlier fills or refilled early is counted, which earlier fills count as fills of the same drug, and whether
controlled substances are held to a tighter line. The settings sit in each plan's adjudication system
and are not written into a claim year. One thing is the same everywhere: an earlier fill counts as
history for 180 days from its fill date; after that the next fill is treated as a first fill.

A rejected claim is not dispensed, so it adds nothing to the member's supply. A claim carrying an
**override code** bypasses the edit and is paid: `03` vacation supply, `14` lost or stolen medication,
`19` dose change. A first fill of a drug, with nothing earlier to count against, is paid.

## The review model

The programme's review model scores claims before adjudication and **holds** the ones it flags for a
pharmacist. A held claim never reaches the automated edits: the pharmacist decides by hand, and the
claim is recorded as held with the pharmacist's resolution, `dispensed` or `denied`. A dispensed held
claim adds to the member's supply like a paid one; a denied one adds nothing.

The programme judges the review model by what the edit would have done with the claims it held: a
hold on a claim the edit would have rejected anyway cost pharmacist time and caught nothing.

## Drugs

`drugs.csv` lists every product in the plan's year: its NDC (one product of one manufacturer and
package), its GPI (the generic product identifier shared by equivalent products of the same drug,
strength and form), its name, and its controlled-substance schedule (`II` to `V`, or blank).

## A claim year

```
drugs.csv     ndc, gpi, name, schedule
claims.csv    claim, member, pharmacy, ndc, fill_date, days_supply, status, reason, override
holds.csv     claim, score                       the claims the review model held, with its score
```

`status` is `paid`, `rejected` or `held`. For a rejected claim `reason` is the edit that rejected it
(`RTS`, refill too soon; it is the only edit in these years); for a held claim `reason` is the
pharmacist's resolution, `dispensed` or `denied`; otherwise it is blank. Claims are listed in fill-date
order. The sample plans in `/app/plans` also carry `expected.csv`, the programme's verdict on each held
claim.

### Formats

```
ndc,gpi,name,schedule
52817-0330-30,1200031419,atorvastatin 20 mg,
```

```
claim,member,pharmacy,ndc,fill_date,days_supply,status,reason,override
C00412,M0087,P02,52817-0330-30,2023-03-14,30,rejected,RTS,
C00413,M0087,P02,52817-0330-30,2023-03-21,30,held,dispensed,
C00414,M0102,P01,60505-0132-01,2023-03-21,90,paid,,03
```

```
claim,score
C00413,0.871
```

`expected.csv`, and the program's output, have the layout `claim,verdict`, one row per held claim,
`reject` or `pay`:

```
claim,verdict
C00413,reject
```
