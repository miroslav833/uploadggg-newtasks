#!/usr/bin/env bash
# Installs the reference program and checks it against both sample plans' expected answers.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/review
cp "$HERE/review/adjudicate.py" /app/review/adjudicate.py
for p in /app/plans/*/; do
  code="$(basename "$p")"
  python3 /app/review/adjudicate.py "$p" "/tmp/$code.csv"
  if cmp -s "/tmp/$code.csv" "$p/expected.csv"; then echo "$code: matches expected.csv"; else echo "$code: differs from expected.csv"; fi
done
