#!/usr/bin/env python3
"""adjudicate.py PLAN_DIR OUT_CSV: for every claim the review model held, whether the plan's
refill-too-soon edit would have rejected it.

The edit's settings are read from the claims the plan did adjudicate. A setting is a utilisation share
(how much of the previous supply must have elapsed), how supply still on hand is reckoned (the last
fill alone; carried over across fills; or the supply dispensed in the window less the days since its
first fill), whether earlier fills are matched by product
(NDC) or by GPI, and whether scheduled drugs are held to a share ten points higher; a fill counts as
history for 180 days (handbook). Every combination is replayed over each member's claims in date order (held
claims follow their recorded resolution for the member's supply), and the combinations that reproduce
every paid and rejected decision are kept; the held claims are then judged under the first of them."""
import csv
import datetime
import itertools
import os
import sys

SHARES = [0.75, 0.80, 0.85, 0.90]
BASES = ["last", "cumulative", "window"]
MATCHES = ["ndc", "gpi"]
STRICTS = [False, True]
LOOKBACKS = [180]
DEFAULTS = {"share": None, "basis": None, "bases": None, "match": None, "strict": None, "lookback": None,
            "pick": "first", "fit_on": "all"}


def read_plan(path):
    def rows(name):
        with open(os.path.join(path, name), newline="") as fh:
            return list(csv.DictReader(fh))
    drugs = {r["ndc"]: r for r in rows("drugs.csv")}
    per_member = {}
    for r in rows("claims.csv"):
        r["date"] = datetime.date.fromisoformat(r["fill_date"])
        r["supply"] = int(r["days_supply"])
        per_member.setdefault(r["member"], []).append(r)
    for cs in per_member.values():
        cs.sort(key=lambda r: (r["date"], r["claim"]))
    held = [r["claim"] for r in rows("holds.csv")]
    return drugs, per_member, held


def left_over(basis, h, c, lookback):
    """Supply on hand when the claim arrives, under each way of reckoning it."""
    gap = (c["date"] - h["date"]).days
    if basis == "last":
        return max(0.0, h["supply"] - gap)
    if basis == "cumulative":
        return max(0.0, h["on_hand"] - gap)
    fills = [(d, q) for d, q in h["fills"] if (c["date"] - d).days <= lookback]
    return max(0.0, sum(q for _, q in fills) - (c["date"] - fills[0][0]).days)


def decide(setting, state, c, drug):
    share, basis, match, strict, lookback = setting
    key = c["ndc"] if match == "ndc" else drug["gpi"]
    if c["override"].strip():
        return True, key
    h = state.get(key)
    if h is None:
        return True, key
    if (c["date"] - h["date"]).days > lookback:
        return True, key
    s = share + (0.10 if strict and drug["schedule"].strip() else 0.0)
    return left_over(basis, h, c, lookback) <= (1.0 - s) * h["supply"] + 1e-9, key


def take(state, key, c, lookback):
    h = state.get(key)
    carried, fills = 0.0, []
    if h is not None and (c["date"] - h["date"]).days <= lookback:
        carried = max(0.0, h["on_hand"] - (c["date"] - h["date"]).days)
        fills = [(d, q) for d, q in h["fills"] if (c["date"] - d).days <= lookback]
    state[key] = {"date": c["date"], "supply": c["supply"], "on_hand": carried + c["supply"],
                  "fills": fills + [(c["date"], c["supply"])]}


def replay(setting, claims, drugs):
    """{claim: (allowed, status)} for one member's claims in order."""
    state, out = {}, {}
    for c in claims:
        drug = drugs[c["ndc"]]
        allowed, key = decide(setting, state, c, drug)
        out[c["claim"]] = allowed
        if c["status"] == "held":
            if c["reason"] == "dispensed":
                take(state, key, c, setting[4])
        elif allowed:
            take(state, key, c, setting[4])
    return out


def consistent(setting, per_member, drugs, members=None):
    bad = 0
    for m, cs in per_member.items():
        if members is not None and m not in members:
            continue
        got = replay(setting, cs, drugs)
        for c in cs:
            if c["status"] == "paid" and not got[c["claim"]]:
                bad += 1
            elif c["status"] == "rejected" and got[c["claim"]]:
                bad += 1
    return bad


def adjudicate(path, opt=None):
    opt = dict(DEFAULTS, **(opt or {}))
    drugs, per_member, held = read_plan(path)
    held_set = set(held)
    members = None
    if opt["fit_on"] == "held":
        members = {m for m, cs in per_member.items() if any(c["claim"] in held_set for c in cs)}
    space = itertools.product(
        [opt["share"]] if opt["share"] is not None else SHARES,
        [opt["basis"]] if opt["basis"] is not None else (opt["bases"] or BASES),
        [opt["match"]] if opt["match"] is not None else MATCHES,
        [opt["strict"]] if opt["strict"] is not None else STRICTS,
        [opt["lookback"]] if opt["lookback"] is not None else LOOKBACKS)
    scored = sorted((consistent(s, per_member, drugs, members), i, s) for i, s in enumerate(space))
    best = scored[0][0]
    fits = [s for bad, _, s in scored if bad == best]
    setting = fits[-1] if opt["pick"] == "last" else fits[0]
    verdict = {}
    for cs in per_member.values():
        got = replay(setting, cs, drugs)
        for c in cs:
            if c["claim"] in held_set:
                verdict[c["claim"]] = "pay" if got[c["claim"]] else "reject"
    return [(h, verdict.get(h, "pay")) for h in held]


def main():
    rows = adjudicate(sys.argv[1])
    out = sys.argv[2]
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w") as fh:
        fh.write("claim,verdict\n")
        for h, v in rows:
            fh.write("%s,%s\n" % (h, v))


if __name__ == "__main__":
    main()
