We run a review model over pharmacy claims before they're adjudicated, and the claims it flags go to a pharmacist instead of through the plan's automated edits. That makes the model impossible to score the usual way: a held claim never meets the refill-too-soon edit, so we can't tell whether the hold caught something the edit would have let through or just duplicated a rejection the plan would have made anyway. I need that answer for every held claim of a plan year, and I need it from a program, because we have twenty plans and they all set the edit differently.

```
python3 /app/review/adjudicate.py PLAN_DIR OUT_CSV
```

Given one plan's claim year, the program writes, for each claim the model held, `reject` if the plan's refill-too-soon edit would have rejected it had it been adjudicated, and `pay` if not.

/app/programme/HANDBOOK.md covers how adjudication and the edit work in general, what the review model does, what a claim year contains and how each file is laid out. Two sample plans sit in /app/plans with an expected.csv each, so you can test against them. The claims files are bulk data, several thousand rows; read them with code.

OUT_CSV: header claim,verdict, then one row per held claim, e.g. `C00413,reject`. A held claim with no row is wrong.

Scoring runs the program on 20 plans that aren't in the image you get. They're generated when the scoring image is built, and the edit is not set the same way on them as on the two samples. Each has about 120 held claims. A plan is right if at most 3 of its held claims get the wrong verdict, and 18 of the 20 plans have to be right.

For scoring, the program gets a fresh copy of each plan's folder, runs under an unprivileged account with the python3 that's in the image (standard library only, no packages), and has 120 seconds per plan. Only /app/review is carried into scoring, so keep everything the program needs in there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
