"""Two checks: the sealed verdicts are what the verifier's own account of the edit gives, and the
uploaded program gets enough held plans right."""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import edits    # noqa: E402
import enclose  # noqa: E402

PLANS = 20
WRONG_ALLOWED = 3   # a plan counts when at most 3 of its held claims carry the wrong verdict (instruction.md)
NEEDED = 18         # plans of 20 that must count (instruction.md)


def sealed(code):
    with open(os.path.join(enclose.HELD, "sealed", code + ".json")) as fh:
        rec = json.load(fh)
    key = {}
    for line in rec["answer"].splitlines()[1:]:
        c, v = line.split(",")
        key[c] = v
    return rec, key


@pytest.fixture(scope="module")
def tally():
    uid = enclose.unused_uid()
    wrong = {}
    for code in enclose.plans():
        _, key = sealed(code)
        got = enclose.run_plan(code, uid)
        wrong[code] = len(key) if got is None else sum(1 for c in key if got.get(c) != key[c])
        if wrong[code] > WRONG_ALLOWED:
            tail = open(os.path.join(enclose.PRIVATE, code + ".err"), "rb").read()[-600:]
            print("%s: %d wrong; stderr tail: %r" % (code, wrong[code], tail))
    with open(os.path.join(enclose.PRIVATE, "plans.json"), "w") as fh:
        json.dump(wrong, fh, indent=1)
    print(json.dumps(wrong))
    return wrong


def test_sealed_verdicts_follow_the_edit():
    assert len(enclose.plans()) == PLANS
    for code in enclose.plans():
        rec, key = sealed(code)
        mine = edits.reckon(rec, os.path.join(enclose.HELD, "plans", code))
        assert len(key) >= 100 and mine == key, code


def test_enough_plans_right(tally):
    good = [c for c, w in tally.items() if w <= WRONG_ALLOWED]
    assert len(good) >= NEEDED, "%d of %d plans counted (%s); %d needed" % (len(good), PLANS, tally, NEEDED)
