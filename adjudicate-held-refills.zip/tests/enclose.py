"""Runs the uploaded adjudicate.py on one held plan at a time and reads back what it wrote.

The plan is copied to a folder owned by a numeric account no process of the image uses. The program
runs under that account in its own session with no groups, 2 GiB of address space and 120 seconds;
every process left under the account is killed before the output is looked at. The output must be a
regular file of at most 1 MiB and is parsed as CSV text only."""
import csv
import os
import resource
import shutil
import signal
import subprocess
import time

HELD = "/tests/held"
PRIVATE = "/run/verifier"
WORK = "/var/tmp/plans"
PROGRAM = "/app/review/adjudicate.py"
SECONDS = 120
MAX_BYTES = 1 << 20


def unused_uid(start=53200):
    taken = set()
    for pid in os.listdir("/proc"):
        if pid.isdigit():
            try:
                taken.add(os.stat("/proc/" + pid).st_uid)
            except FileNotFoundError:
                pass
    while start in taken:
        start += 1
    return start


def end_all(uid):
    for _ in range(200):
        pids = []
        for pid in os.listdir("/proc"):
            if pid.isdigit():
                try:
                    if os.stat("/proc/" + pid).st_uid == uid:
                        pids.append(int(pid))
                except FileNotFoundError:
                    pass
        if not pids:
            return
        for p in pids:
            try:
                os.kill(p, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def read_verdicts(path):
    got = {}
    with open(path, newline="", encoding="utf-8", errors="replace") as fh:
        for row in csv.DictReader(fh):
            c = (row.get("claim") or "").strip()
            if c and c not in got:
                got[c] = (row.get("verdict") or "").strip().lower()
    return got


def run_plan(code, uid):
    home = os.path.join(WORK, code)
    shutil.rmtree(home, ignore_errors=True)
    os.makedirs(home, mode=0o755)
    plan, tmp, outdir = (os.path.join(home, x) for x in ("plan", "tmp", "out"))
    shutil.copytree(os.path.join(HELD, "plans", code), plan, symlinks=False)
    os.makedirs(tmp)
    os.makedirs(outdir)
    for root, dirs, files in os.walk(home):
        for n in dirs + files:
            os.chown(os.path.join(root, n), uid, uid)
    os.chown(home, uid, uid)
    target = os.path.join(outdir, "verdicts.csv")

    def lower():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": tmp, "TMPDIR": tmp, "LANG": "C.UTF-8",
           "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
    with open(os.path.join(PRIVATE, code + ".err"), "wb") as err:
        proc = subprocess.Popen(["python3", PROGRAM, plan, target], stdin=subprocess.DEVNULL, stdout=err,
                                stderr=err, cwd=tmp, env=env, preexec_fn=lower)
        try:
            proc.wait(timeout=SECONDS)
        except subprocess.TimeoutExpired:
            pass
    end_all(uid)
    got = None
    if os.path.isfile(target) and not os.path.islink(target) and os.path.getsize(target) <= MAX_BYTES:
        got = read_verdicts(target)
    shutil.rmtree(home, ignore_errors=True)
    return got


def plans():
    return sorted(os.listdir(os.path.join(HELD, "plans")))
