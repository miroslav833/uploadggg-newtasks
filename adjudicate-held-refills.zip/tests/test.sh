#!/usr/bin/env bash
# The reward folder is closed before anything uploaded runs: root-only, every reward-like file in it
# removed, reward.txt at 0. The program then runs under an invented account (tests/enclose.py). When
# grading ends, files root did not write are removed and reward.txt alone is written.
set -u
LOGS=/logs/verifier
HOLD=/run/verifier

mkdir -p "$LOGS"
mode_before="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

sweep() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
reward() {
    sweep
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
done_() {
    chmod "$mode_before" "$LOGS" 2>/dev/null
    exit 0
}

reward 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "not grading: $LOGS could not be made root-only" >&2
    done_
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$HOLD" && chown 0:0 "$HOLD" && chmod 700 "$HOLD"
chmod -R a+rX /app/review 2>/dev/null

verdict=fail
if ( cd /tests && python3 -m pytest test_plans.py -q -p no:cacheprovider --ctrf "$HOLD/ctrf.json" ); then
    verdict=pass
fi
if [ "$verdict" = pass ]; then reward 1; else reward 0; fi
for f in ctrf.json plans.json; do
    [ -f "$HOLD/$f" ] && (umask 022; cp "$HOLD/$f" "$LOGS/$f")
done
done_
