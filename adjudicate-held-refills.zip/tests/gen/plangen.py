#!/usr/bin/env python3
"""Claim years of invented pharmacy-benefit plans: a drug table, members' refill claims, the plan's
refill-too-soon edit decisions on the claims it adjudicated, and the claims a review model held
instead. The sealed truth is the plan's edit settings; the answer is, for each held claim, whether the
edit would have rejected it.

    python3 plangen.py samples OUTDIR
    python3 plangen.py graded OUTDIR SEALED_DIR

A plan is kept only when its adjudicated claims settle every held claim (see settled())."""
import datetime
import itertools
import json
import os
import random
import sys

SHARES = [0.75, 0.80, 0.85, 0.90]
BASES = ["last", "cumulative", "window", "bank8", "bank15"]
MATCHES = ["ndc", "gpi", "ndc@pharmacy", "gpi@pharmacy"]
STRICTS = [False, True]
LOOKBACKS = [180]
SETTINGS = list(itertools.product(SHARES, BASES, MATCHES, STRICTS, LOOKBACKS))
HELD = 120
MIN_MOVED = 8
OVERRIDES = {"03": "vacation supply", "14": "lost or stolen medication", "19": "dose change"}
REJECT = {}


def _rej(why):
    REJECT[why] = REJECT.get(why, 0) + 1


# ---------------------------------------------------------------- drugs
NAMES = ["atorvastatin", "lisinopril", "metformin", "levothyroxine", "amlodipine", "metoprolol", "omeprazole",
         "losartan", "sertraline", "gabapentin", "escitalopram", "montelukast", "tramadol", "zolpidem",
         "alprazolam", "lorazepam", "clonazepam", "oxycodone", "pantoprazole", "rosuvastatin"]
SCHEDULED = {"tramadol": "IV", "zolpidem": "IV", "alprazolam": "IV", "lorazepam": "IV", "clonazepam": "IV",
             "oxycodone": "II"}


def make_drugs(rng):
    drugs = []
    names = NAMES[:]
    rng.shuffle(names)
    for i, name in enumerate(names[:14]):
        gpi = "%02d%08d" % (10 + i, rng.randrange(10 ** 8))
        for k in range(rng.randint(2, 4)):
            ndc = "%05d-%04d-%02d" % (rng.randrange(10000, 99999), rng.randrange(1000, 9999), rng.choice([1, 30, 90]))
            drugs.append({"ndc": ndc, "gpi": gpi, "name": "%s %s" % (name, rng.choice(["5 mg", "10 mg", "20 mg", "25 mg", "50 mg", "100 mg", "500 mg"])),
                          "schedule": SCHEDULED.get(name, "")})
    return drugs


# ---------------------------------------------------------------- the edit
def on_hand_before(basis, hist, claim, lookback):
    """Supply still on hand when the claim arrives, under each reckoning of leftover supply."""
    elapsed = (claim["date"] - hist["date"]).days
    if basis == "last" or basis.startswith("bank"):
        return max(0.0, hist["supply"] - elapsed)
    if basis == "cumulative":
        return max(0.0, hist["on_hand"] - elapsed)
    fills = [f for f in hist["fills"] if (claim["date"] - f[0]).days <= lookback]
    return max(0.0, sum(f[1] for f in fills) - (claim["date"] - fills[0][0]).days)


def history_key(match, claim, drug):
    base = claim["ndc"] if match.startswith("ndc") else drug["gpi"]
    return base + "@" + claim["pharmacy"] if match.endswith("@pharmacy") else base


def judge(setting, state, claim, drug):
    """The edit's decision on a claim given the member's dispensing state. Returns (allowed, key)."""
    share, basis, match, strict, lookback = setting
    key = history_key(match, claim, drug)
    if claim["override"]:
        return True, key
    hist = state.get(key)
    if hist is None:
        return True, key
    elapsed = (claim["date"] - hist["date"]).days
    if elapsed > lookback:
        return True, key
    s = share + (0.10 if strict and drug["schedule"] else 0.0)
    left = on_hand_before(basis, hist, claim, lookback)
    ok = left <= (1.0 - s) * hist["supply"] + 1e-9
    if ok and basis.startswith("bank"):
        banked = sum(f[2] for f in hist["fills"] if (claim["date"] - f[0]).days <= lookback)
        ok = banked + left <= int(basis[4:]) + 1e-9
    return ok, key


def dispense(state, key, claim, lookback):
    hist = state.get(key)
    carried, fills, early = 0.0, [], 0.0
    if hist is not None:
        elapsed = (claim["date"] - hist["date"]).days
        if elapsed <= lookback:
            carried = max(0.0, hist["on_hand"] - elapsed)
            fills = [f for f in hist["fills"] if (claim["date"] - f[0]).days <= lookback]
            early = max(0.0, hist["supply"] - elapsed)
    state[key] = {"date": claim["date"], "supply": claim["supply"], "on_hand": carried + claim["supply"],
                  "fills": fills + [(claim["date"], claim["supply"], early)]}


def replay(setting, claims, drugs_by_ndc, held_resolution):
    """Runs the edit over a member's claims in date order. Returns {claim id: allowed} for every claim;
    held claims follow their recorded resolution for the state, adjudicated ones the edit's decision."""
    state, out = {}, {}
    for c in claims:
        drug = drugs_by_ndc[c["ndc"]]
        allowed, key = judge(setting, state, c, drug)
        out[c["id"]] = allowed
        if c["id"] in held_resolution:
            if held_resolution[c["id"]] == "dispensed":
                dispense(state, key, c, setting[4])
        elif allowed:
            dispense(state, key, c, setting[4])
    return out


# ---------------------------------------------------------------- members and claims
def make_members(rng, drugs, n_members, year):
    """Members with therapies; each therapy a list of (date, ndc, supply, override)."""
    by_gpi = {}
    for d in drugs:
        by_gpi.setdefault(d["gpi"], []).append(d)
    gpis = list(by_gpi)
    sched_gpis = [g for g in gpis if by_gpi[g][0]["schedule"]]
    plain_gpis = [g for g in gpis if not by_gpi[g][0]["schedule"]]
    start = datetime.date(year, 1, 1)
    members = []
    for m in range(n_members):
        arche = rng.choices(["steady", "early", "switcher", "gap", "scheduled"], [34, 22, 16, 14, 14])[0]
        n_ther = rng.randint(1, 3)
        therapies = []
        for _ in range(n_ther):
            gpi = rng.choice(sched_gpis) if arche == "scheduled" or rng.random() < 0.15 else rng.choice(plain_gpis)
            prods = by_gpi[gpi]
            ndc = rng.choice(prods)
            supply = rng.choice([30, 30, 30, 90])
            date = start + datetime.timedelta(days=rng.randint(0, 60))
            fills = []
            n_fills = rng.randint(6, 11) if supply == 30 else rng.randint(3, 4)
            switch_at = rng.randint(2, n_fills - 1) if arche == "switcher" and len(prods) > 1 else None
            gap_at = rng.randint(2, n_fills - 1) if arche == "gap" else None
            for k in range(n_fills):
                if k == switch_at:
                    ndc = rng.choice([p for p in prods if p is not ndc])
                override = rng.choice(list(OVERRIDES)) if rng.random() < 0.025 else ""
                fills.append((date, ndc["ndc"], supply, override))
                if k == gap_at:
                    ratio = rng.choice([rng.uniform(3.2, 5.8), rng.uniform(6.2, 11.5), rng.uniform(12.3, 14.0)]) if supply == 30 \
                        else rng.choice([rng.uniform(1.05, 1.9), rng.uniform(2.1, 3.9), rng.uniform(4.2, 4.6)])
                elif arche == "early":
                    ratio = rng.uniform(0.78, 0.92)
                elif arche == "switcher" and k == switch_at - 1:
                    ratio = rng.uniform(0.55, 0.80)
                elif arche == "scheduled":
                    ratio = rng.choice([rng.uniform(0.74, 0.96), rng.uniform(0.95, 1.1)])
                else:
                    ratio = rng.choices([rng.uniform(0.95, 1.12), rng.uniform(0.70, 0.95), rng.uniform(0.50, 0.70)], [60, 32, 8])[0]
                date = date + datetime.timedelta(days=max(1, round(supply * ratio)))
                if date.year > year:
                    break
            therapies.append(fills)
        members.append(therapies)
    return members


def build_plan(seed, profile):
    rng = random.Random(seed)
    setting = (profile["share"], profile["basis"], profile["match"], profile["strict"], profile["lookback"])
    for attempt in range(60):
        drugs = make_drugs(rng)
        drugs_by_ndc = {d["ndc"]: d for d in drugs}
        year = rng.choice([2022, 2023, 2024])
        members = make_members(rng, drugs, rng.randint(230, 300), year)
        pharmacies = ["P%02d" % i for i in range(1, 21)]
        claims = []
        for mi, therapies in enumerate(members):
            member = "M%04d" % (mi + 1)
            home = rng.choice(pharmacies)
            for fills in therapies:
                for date, ndc, supply, override in fills:
                    claims.append({"member": member, "date": date, "ndc": ndc, "supply": supply, "override": override,
                                   "pharmacy": home if rng.random() < 0.90 else rng.choice(pharmacies)})
        claims.sort(key=lambda c: (c["date"], c["member"], c["ndc"]))
        for i, c in enumerate(claims):
            c["id"] = "C%05d" % (i + 1)
        # the review model holds refills by a noisy earliness score; first fills are not held
        per_member = {}
        for c in claims:
            per_member.setdefault(c["member"], []).append(c)
        candidates = []
        for member, cs in per_member.items():
            last = {}
            for c in cs:
                g = drugs_by_ndc[c["ndc"]]["gpi"]
                if g in last and not c["override"]:
                    ratio = (c["date"] - last[g][0]).days / last[g][1]
                    score = 1 / (1 + 2.718 ** ((ratio - 0.86 + rng.gauss(0, 0.06)) / 0.05))
                    c["score"] = round(score, 3)
                    if score >= 0.5:
                        candidates.append(c)
                last[g] = (c["date"], c["supply"])
        rng.shuffle(candidates)
        held = candidates[:HELD]
        if len(held) < HELD - 5:
            _rej("fewheld")
            continue
        held_resolution = {c["id"]: ("dispensed" if rng.random() < 0.6 else "denied") for c in held}
        result = settled(setting, per_member, drugs_by_ndc, held_resolution, held)
        if result is None:
            continue
        truth, status = result
        return {"setting": setting, "drugs": drugs, "claims": claims, "held": held, "held_resolution": held_resolution,
                "status": status, "truth": truth, "year": year, "attempts": attempt + 1}
    raise RuntimeError("no settled plan for seed %d" % seed)


def run_plan(setting, per_member, drugs_by_ndc, held_resolution):
    out = {}
    for cs in per_member.values():
        out.update(replay(setting, cs, drugs_by_ndc, held_resolution))
    return out


def settled(setting, per_member, drugs_by_ndc, held_resolution, held):
    true_all = run_plan(setting, per_member, drugs_by_ndc, held_resolution)
    held_ids = [c["id"] for c in held]
    truth = {i: ("reject" if not true_all[i] else "pay") for i in held_ids}
    n_rej = sum(1 for v in truth.values() if v == "reject")
    if not (0.25 * len(held_ids) <= n_rej <= 0.75 * len(held_ids)):
        _rej("balance")
        return None
    adjudicated = {i: a for i, a in true_all.items() if i not in held_resolution}
    consistent = []
    for s in SETTINGS:
        got = run_plan(s, per_member, drugs_by_ndc, held_resolution)
        if all(got[i] == a for i, a in adjudicated.items()):
            consistent.append((s, got))
    assert any(s == setting for s, _ in consistent)
    for s, got in consistent:
        if any((not got[i]) != (truth[i] == "reject") for i in held_ids):
            _rej("unsettled")
            return None
    # a reading that assumes the samples' value of any one setting (the cheapest proxy) must get enough
    # held verdicts wrong; any other single flip must change at least one
    sample = (0.80, "last", "ndc", False, 180)
    for dim, values in enumerate([SHARES, BASES, MATCHES, STRICTS, LOOKBACKS]):
        for v in values:
            if v == setting[dim]:
                continue
            s = list(setting)
            s[dim] = v
            got = run_plan(tuple(s), per_member, drugs_by_ndc, held_resolution)
            moved = sum(1 for i in held_ids if (not got[i]) != (truth[i] == "reject"))
            if moved < (MIN_MOVED if v == sample[dim] else 1):
                _rej("moved-%d" % dim)
                return None
    status = {}
    for i, a in adjudicated.items():
        status[i] = "paid" if a else "rejected"
    return truth, status


# ---------------------------------------------------------------- writing
def write_plan(code, p, outdir, sealed_dir=None, expected=False):
    base = os.path.join(outdir, code)
    os.makedirs(base, exist_ok=True)
    with open(os.path.join(base, "drugs.csv"), "w") as fh:
        fh.write("ndc,gpi,name,schedule\n")
        for d in sorted(p["drugs"], key=lambda d: (d["gpi"], d["ndc"])):
            fh.write("%s,%s,%s,%s\n" % (d["ndc"], d["gpi"], d["name"], d["schedule"]))
    with open(os.path.join(base, "claims.csv"), "w") as fh:
        fh.write("claim,member,pharmacy,ndc,fill_date,days_supply,status,reason,override\n")
        for c in p["claims"]:
            if c["id"] in p["held_resolution"]:
                status, reason = "held", p["held_resolution"][c["id"]]
            else:
                status = p["status"][c["id"]]
                reason = "RTS" if status == "rejected" else ""
            fh.write("%s,%s,%s,%s,%s,%d,%s,%s,%s\n" % (c["id"], c["member"], c["pharmacy"], c["ndc"], c["date"].isoformat(),
                                                      c["supply"], status, reason, c["override"]))
    with open(os.path.join(base, "holds.csv"), "w") as fh:
        fh.write("claim,score\n")
        for c in sorted(p["held"], key=lambda c: c["id"]):
            fh.write("%s,%.3f\n" % (c["id"], c["score"]))
    answer = "claim,verdict\n" + "".join("%s,%s\n" % (c["id"], p["truth"][c["id"]]) for c in sorted(p["held"], key=lambda c: c["id"]))
    if expected:
        with open(os.path.join(base, "expected.csv"), "w") as fh:
            fh.write(answer)
    if sealed_dir:
        os.makedirs(sealed_dir, exist_ok=True)
        share, basis, match, strict, lookback = p["setting"]
        with open(os.path.join(sealed_dir, code + ".json"), "w") as fh:
            json.dump({"share": share, "basis": basis, "match": match, "strict": strict, "lookback": lookback,
                       "answer": answer}, fh)


SAMPLES = [("plan-0362", {"share": 0.80, "basis": "last", "match": "ndc", "strict": False, "lookback": 180}),
           ("plan-0718", {"share": 0.80, "basis": "last", "match": "ndc", "strict": False, "lookback": 180})]


def graded_profiles():
    rng = random.Random(2511)
    shares = [0.75] * 5 + [0.80] * 5 + [0.85] * 5 + [0.90] * 5
    bases = ["last"] * 4 + ["cumulative"] * 4 + ["window"] * 4 + ["bank8"] * 4 + ["bank15"] * 4
    matches = ["ndc"] * 5 + ["gpi"] * 5 + ["ndc@pharmacy"] * 5 + ["gpi@pharmacy"] * 5
    stricts = [False] * 10 + [True] * 10
    looks = [180] * 20
    for lst in (shares, bases, matches, stricts, looks):
        rng.shuffle(lst)
    profiles = [{"share": a, "basis": b, "match": c, "strict": d, "lookback": e} for a, b, c, d, e in zip(shares, bases, matches, stricts, looks)]
    # no graded plan repeats the samples' settings
    # a banked-days limit binds only where the share lets early refills through: give bank plans the low shares
    low = [pr for pr in profiles if pr["share"] in (0.75, 0.80)]
    for pr in profiles:
        if pr["basis"].startswith("bank") and pr["share"] not in (0.75, 0.80):
            swap = next(q for q in low if not q["basis"].startswith("bank"))
            pr["share"], swap["share"] = swap["share"], pr["share"]
            low.remove(swap)
    for pr in profiles:
        if pr == SAMPLES[0][1]:
            pr["basis"] = "cumulative"
    return profiles


def build_graded(outdir, sealed_dir, seed0=90001):
    rng = random.Random(seed0)
    codes = set()
    for n, prof in enumerate(graded_profiles()):
        code = "plan-%04d" % rng.randint(100, 9999)
        while code in codes or code in dict(SAMPLES):
            code = "plan-%04d" % rng.randint(100, 9999)
        codes.add(code)
        for extra in range(5):
            try:
                plan = build_plan(seed0 + 89 * n + 1000003 * extra, prof)
                break
            except RuntimeError:
                if extra == 4:
                    raise
        write_plan(code, plan, outdir, sealed_dir)


def build_samples(outdir):
    for n, (code, prof) in enumerate(SAMPLES):
        write_plan(code, build_plan(7301 + 17 * n, prof), outdir, expected=True)


if __name__ == "__main__":
    if sys.argv[1] == "samples":
        build_samples(sys.argv[2])
    else:
        build_graded(sys.argv[2], sys.argv[3])
