"""The verifier's own account of a plan's refill-too-soon edit: from the sealed settings, the verdict
the edit would have given every held claim. Written apart from the generator."""
import csv
import datetime
import os


def reckon(sealed, plan_dir):
    with open(os.path.join(plan_dir, "drugs.csv"), newline="") as fh:
        drug = {r["ndc"]: r for r in csv.DictReader(fh)}
    with open(os.path.join(plan_dir, "claims.csv"), newline="") as fh:
        claims = list(csv.DictReader(fh))
    with open(os.path.join(plan_dir, "holds.csv"), newline="") as fh:
        held = [r["claim"] for r in csv.DictReader(fh)]
    share, basis, match, strict, lookback = (sealed["share"], sealed["basis"], sealed["match"],
                                             sealed["strict"], sealed["lookback"])
    by_member = {}
    for c in claims:
        c["_d"] = datetime.date.fromisoformat(c["fill_date"])
        by_member.setdefault(c["member"], []).append(c)
    verdict = {}
    for cs in by_member.values():
        cs.sort(key=lambda c: (c["_d"], c["claim"]))
        last = {}   # group -> (date, supply, days on hand right after that fill, fills kept as (date, supply, early days))
        for c in cs:
            d = drug[c["ndc"]]
            group = c["ndc"] if match.startswith("ndc") else d["gpi"]
            if match.endswith("@pharmacy"):
                group = (group, c["pharmacy"])
            supply = int(c["days_supply"])
            prev = last.get(group)
            gap = (c["_d"] - prev[0]).days if prev else None
            in_window = prev is not None and gap <= lookback
            line = share + (0.10 if strict and d["schedule"] else 0.0)
            kept = [f for f in prev[3] if (c["_d"] - f[0]).days <= lookback] if prev else []
            early_now = max(0.0, prev[1] - gap) if in_window else 0.0
            if c["override"] or not in_window:
                ok = True
            else:
                if basis in ("last", "bank8", "bank15"):
                    on_hand = prev[1] - gap
                elif basis == "cumulative":
                    on_hand = prev[2] - gap
                else:
                    on_hand = sum(f[1] for f in kept) - (c["_d"] - kept[0][0]).days
                ok = max(0.0, on_hand) <= (1.0 - line) * prev[1] + 1e-9
                if ok and basis.startswith("bank"):
                    ok = sum(f[2] for f in kept) + max(0.0, on_hand) <= int(basis[4:]) + 1e-9
            if c["claim"] in held:
                verdict[c["claim"]] = "pay" if ok else "reject"
                dispensed = c["reason"] == "dispensed"
            else:
                dispensed = ok
            if dispensed:
                carry = max(0.0, prev[2] - gap) if in_window else 0.0
                last[group] = (c["_d"], supply, carry + supply, kept + [(c["_d"], supply, early_now)])
    return {h: verdict[h] for h in held}
