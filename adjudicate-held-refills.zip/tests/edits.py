"""The verifier's own account of a plan's refill-too-soon edit: from the sealed settings, the verdict
the edit would have given every held claim. Written apart from the generator."""
import csv
import datetime
import os


def reckon(sealed, plan_dir):
    with open(os.path.join(plan_dir, "drugs.csv"), newline="") as fh:
        drug = {r["ndc"]: r for r in csv.DictReader(fh)}
    with open(os.path.join(plan_dir, "claims.csv"), newline="") as fh:
        claims = list(csv.DictReader(fh))
    with open(os.path.join(plan_dir, "holds.csv"), newline="") as fh:
        held = [r["claim"] for r in csv.DictReader(fh)]
    share, basis, match, strict, lookback = (sealed["share"], sealed["basis"], sealed["match"],
                                             sealed["strict"], sealed["lookback"])
    by_member = {}
    for c in claims:
        c["_d"] = datetime.date.fromisoformat(c["fill_date"])
        by_member.setdefault(c["member"], []).append(c)
    verdict = {}
    for cs in by_member.values():
        cs.sort(key=lambda c: (c["_d"], c["claim"]))
        last = {}   # group -> (date, supply, days on hand right after that fill, dispensed fills kept)
        for c in cs:
            d = drug[c["ndc"]]
            group = c["ndc"] if match == "ndc" else d["gpi"]
            supply = int(c["days_supply"])
            prev = last.get(group)
            gap = (c["_d"] - prev[0]).days if prev else None
            in_window = prev is not None and gap <= lookback
            line = share + (0.10 if strict and d["schedule"] else 0.0)
            kept = [(fd, fq) for fd, fq in prev[3] if (c["_d"] - fd).days <= lookback] if prev else []
            if c["override"] or not in_window:
                ok = True
            else:
                if basis == "last":
                    on_hand = prev[1] - gap
                elif basis == "cumulative":
                    on_hand = prev[2] - gap
                else:
                    on_hand = sum(fq for _, fq in kept) - (c["_d"] - kept[0][0]).days
                ok = max(0.0, on_hand) <= (1.0 - line) * prev[1] + 1e-9
            if c["claim"] in held:
                verdict[c["claim"]] = "pay" if ok else "reject"
                dispensed = c["reason"] == "dispensed"
            else:
                dispensed = ok
            if dispensed:
                carry = max(0.0, prev[2] - gap) if in_window else 0.0
                last[group] = (c["_d"], supply, carry + supply, kept + [(c["_d"], supply)])
    return {h: verdict[h] for h in held}
