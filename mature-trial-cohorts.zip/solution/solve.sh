#!/usr/bin/env bash
# Puts the reference maturation program in place and runs it over the two sample offers.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/maturity
cp "$HERE/maturity/mature.py" /app/maturity/mature.py
for c in /app/cases/*/; do
  python3 /app/maturity/mature.py "$c" "/tmp/$(basename "$c")-maturity.json"
done
