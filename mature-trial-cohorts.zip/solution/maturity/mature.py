#!/usr/bin/env python3
"""Matures one offer extract: the eventual sixty-day upgrades of the four youngest gradable sign-up
weeks and the review's verdict.

    python3 mature.py OFFER_DIR OUT_JSON

The path: tell the billing partner's rows from the store channel's statement rows by their reported
dates, and read each channel's cadence off them to find the last upgrade date the extract can hold
for that channel (its cutoff); where the offer sheet records a campaign, split each campaign day's
trials into the organic baseline (the pre-campaign weekday pattern per band) and the campaign's
sign-ups; estimate, within each probability band, the share of a cohort's organic sixty-day upgrades
that have happened by each lag, from the cohorts old enough to be complete at the partner's cutoff;
mature each graded week's organic sign-ups from their own reported upgrades through the share their
sign-up days have reached; read the week's calibration (matured organic upgrades over the organic
summed scores) and carry it onto the campaign sign-ups' summed scores, since the store's statement
has not yet reported their upgrades; and take the ratio of the matured total to the summed
predictions."""
import csv
import datetime as dt
import json
import os
import re
import sys

HORIZON = 60
GRADED = 4
GRADABLE_LAG = 10
LOW, HIGH = 0.875, 1.125

DEFAULT = dict(cutoff="cadence",      # cadence | snapshot
               strata="band",         # band | pooled
               sources="split",       # split | blind
               channels="split",      # split | blind
               baseline="mean",       # mean | median
               complete=HORIZON,      # lag from which a cohort counts as complete (60 | 56 | 61)
               curve="complete",      # complete | ladder
               estimator="weighted",  # weighted | perday | equalweight
               campaign="carry",      # carry | own | predicted | observed
               mode="mature")         # mature | naive | carry | blanket


def read_offer(folder):
    snapshot, campaign = None, None
    with open(os.path.join(folder, "OFFER.md"), encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("- Snapshot date:"):
                snapshot = dt.date.fromisoformat(line.split(":", 1)[1].strip())
            m = re.search(r"campaign (?:has run since|ran from) (\d{4}-\d{2}-\d{2})(?: to (\d{4}-\d{2}-\d{2}))?", line)
            if m:
                campaign = (dt.date.fromisoformat(m.group(1)),
                            dt.date.fromisoformat(m.group(2)) if m.group(2) else None)
    trials = {}
    with open(os.path.join(folder, "trials.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            trials[(dt.date.fromisoformat(row["signup_date"]), int(row["band"]))] = (
                int(row["trials"]), float(row["predicted_sum"]))
    ups = []
    with open(os.path.join(folder, "upgrades.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            ups.append((dt.date.fromisoformat(row["signup_date"]), int(row["band"]),
                        dt.date.fromisoformat(row["upgrade_date"]),
                        dt.date.fromisoformat(row["reported_date"]), int(row["count"])))
    return snapshot, campaign, trials, ups


def monday(d):
    return d - dt.timedelta(days=d.weekday())


def label(d):
    return d.strftime("%G-W%V")


def graded_weeks(snapshot, days):
    mondays = sorted({monday(d) for d in days})
    ok = [m for m in mondays if (snapshot - (m + dt.timedelta(days=6))).days >= GRADABLE_LAG]
    return ok[-GRADED:]


def first_thursday(rep):
    return rep.weekday() == 3 and rep.day <= 7


def split_channels(ups, campaign, opts):
    """Partner rows and store rows. The store reports on the first Thursday of a month everything
    upgraded in the month before; the partner's rows follow one cadence (same day, next day, or a
    Monday file), read off the rows that cannot be the store's. A first-Thursday row is the
    partner's only when it fits that cadence exactly."""
    if campaign is None or opts["channels"] != "split":
        return ups, []
    lags = {}
    for s, b, u, rep, c in ups:
        if not first_thursday(rep):
            lags[(rep - u).days] = lags.get((rep - u).days, 0) + c
    if set(lags) == {0}:
        fits = lambda u, rep: rep == u
    elif set(lags) == {1}:
        fits = lambda u, rep: (rep - u).days == 1
    else:
        weekday = {rep.weekday() for s, b, u, rep, c in ups if not first_thursday(rep)}
        fits = lambda u, rep: rep.weekday() in weekday
    partner, store = [], []
    for row in ups:
        s, b, u, rep, c = row
        if first_thursday(rep) and not fits(u, rep):
            store.append(row)
        else:
            partner.append(row)
    return partner, store


def find_cutoff(snapshot, ups, opts):
    """The last upgrade date the partner's reports could have carried into the extract."""
    if opts["cutoff"] == "snapshot":
        return snapshot
    lags = {(rep - u).days for _, _, u, rep, _ in ups}
    if lags == {0}:
        cut = snapshot
    elif lags == {1}:
        cut = snapshot - dt.timedelta(days=1)
    else:
        last_file = max(rep for _, _, _, rep, _ in ups)
        cut = last_file - dt.timedelta(days=1)
    seen = max(u for _, _, u, _, _ in ups)
    if seen != cut:
        print("note: last reported upgrade on %s, cutoff read as %s" % (seen, cut), file=sys.stderr)
    return cut


def split_sources(trials, campaign, opts):
    """Per (day, band): organic and campaign trials. Without a campaign everything is organic;
    with one, the organic baseline is the pre-campaign pattern by weekday and band."""
    org = {k: n for k, (n, _) in trials.items()}
    camp = {k: 0 for k in trials}
    if campaign is None or opts["sources"] != "split":
        return org, camp
    start, end = campaign
    bands = sorted({b for _, b in trials})
    base = {}
    for b in bands:
        for wd in range(7):
            vals = sorted(n for (d, bb), (n, _) in trials.items() if bb == b and d.weekday() == wd and d < start)
            if not vals:
                continue
            base[(wd, b)] = vals[len(vals) // 2] if opts["baseline"] == "median" else sum(vals) / len(vals)
    for (d, b), (n, _) in trials.items():
        if d >= start and (end is None or d <= end):
            expected = base.get((d.weekday(), b), n)
            c = max(0, int(round(n - expected)))
            camp[(d, b)] = min(c, n)
            org[(d, b)] = n - camp[(d, b)]
    return org, camp


def empirical_curve(hist_days, need_lag, cutoff):
    total = [0] * (HORIZON + 1)
    for s, arr in hist_days:
        if (cutoff - s).days < need_lag:
            continue
        for d in range(HORIZON + 1):
            total[d] += arr[d]
    n = sum(total)
    acc, f = 0, []
    for d in range(HORIZON + 1):
        acc += total[d]
        f.append(acc / n if n else 1.0)
    return f


def ladder_curve(hist_days, cutoff):
    cum = {}
    for s, arr in hist_days:
        acc, out = 0, []
        for v in arr:
            acc += v
            out.append(acc)
        cum[s] = out
    factors = []
    for d in range(HORIZON):
        num = sum(cum[s][d + 1] for s in cum if (cutoff - s).days >= d + 1)
        den = sum(cum[s][d] for s in cum if (cutoff - s).days >= d + 1)
        factors.append(num / den if den > 0 else 1.0)
    f = [1.0] * (HORIZON + 1)
    for d in range(HORIZON - 1, -1, -1):
        f[d] = f[d + 1] / factors[d]
    return f


def curves(trials, partner, cutoff, opts):
    """share[g]: the share of a cohort's organic sixty-day upgrades that have happened within d days
    of sign-up, d = 0..HORIZON, per band group, from the partner's rows of complete cohorts."""
    bands = sorted({b for _, b in trials})
    groups = {b: [b] for b in bands} if opts["strata"] == "band" else {0: bands}
    hist = {}
    for s, b, u, rep, c in partner:
        g = b if opts["strata"] == "band" else 0
        d = (u - s).days
        if d > HORIZON or u > cutoff:
            continue
        hist.setdefault((g, s), [0] * (HORIZON + 1))[d] += c
    share = {}
    for g in groups:
        entries = [(s, arr) for (gg, s), arr in hist.items() if gg == g]
        if opts["curve"] == "ladder":
            share[g] = ladder_curve(entries, cutoff)
        else:
            share[g] = empirical_curve(entries, opts["complete"], cutoff)
    return share, groups


def mature(folder, opts=None):
    opts = dict(DEFAULT, **(opts or {}))
    snapshot, campaign, trials, ups = read_offer(folder)
    weeks = graded_weeks(snapshot, [d for d, _ in trials])
    labels = [label(w) for w in weeks]
    predicted = {lab: 0.0 for lab in labels}
    for (d, b), (n, p) in trials.items():
        if label(d) in predicted:
            predicted[label(d)] += p
    if opts["mode"] == "blanket":
        return {"weeks": {lab: round(predicted[lab]) for lab in labels}, "verdict": "hold"}
    partner, store = split_channels(ups, campaign, opts)
    cutoff = find_cutoff(snapshot, partner, opts)
    observed = {}     # (label, band, day) -> the partner's reported upgrades within the horizon
    for s, b, u, rep, c in partner:
        lab = label(s)
        if lab in predicted and (u - s).days <= HORIZON:
            observed[(lab, b, s)] = observed.get((lab, b, s), 0) + c
    store_seen = {}   # (label, band, day) -> the store's reported upgrades within the horizon
    for s, b, u, rep, c in store:
        lab = label(s)
        if lab in predicted and (u - s).days <= HORIZON:
            store_seen[(lab, b, s)] = store_seen.get((lab, b, s), 0) + c
    if opts["mode"] == "naive":
        out = {lab: 0 for lab in labels}
        for (lab, b, s), c in list(observed.items()) + list(store_seen.items()):
            out[lab] += c
        ratio = sum(out.values()) / sum(predicted.values())
        return {"weeks": out, "verdict": verdict(ratio)}
    if opts["mode"] == "carry":
        done_up, done_pred = 0, 0.0
        for (d, b), (n, p) in trials.items():
            if (cutoff - d).days >= HORIZON:
                done_pred += p
        for s, b, u, rep, c in ups:
            if (cutoff - s).days >= HORIZON and (u - s).days <= HORIZON:
                done_up += c
        r = done_up / done_pred if done_pred else 1.0
        out = {lab: round(predicted[lab] * r) for lab in labels}
        return {"weeks": out, "verdict": verdict(r)}
    org, camp = split_sources(trials, campaign, opts)
    share, groups = curves(trials, partner, cutoff, opts)
    est = {lab: 0.0 for lab in labels}
    org_pred = {lab: 0.0 for lab in labels}
    camp_pred = {lab: 0.0 for lab in labels}
    for (d, b), (n, p) in trials.items():
        lab = label(d)
        if lab in predicted and n:
            org_pred[lab] += p * org[(d, b)] / n
            camp_pred[lab] += p * camp[(d, b)] / n
    for g, members in groups.items():
        for lab, w in zip(labels, weeks):
            days = [w + dt.timedelta(days=i) for i in range(7)]
            if opts["estimator"] == "perday":
                for s in days:
                    lag = (cutoff - s).days
                    if lag < 0:
                        continue
                    f = share[g][min(lag, HORIZON)]
                    o = sum(observed.get((lab, b, s), 0) for b in members)
                    est[lab] += o / f if f > 0 else 0.0
            else:
                n_tot, g_tot, o_tot = 0.0, 0.0, 0
                for s in days:
                    lag = (cutoff - s).days
                    for b in members:
                        n_org = org.get((s, b), 0)
                        if opts["estimator"] == "equalweight" and n_org:
                            n_org = 1.0
                        if lag >= 0:
                            g_tot += n_org * share[g][min(lag, HORIZON)]
                        n_tot += n_org
                        o_tot += observed.get((lab, b, s), 0)
                if n_tot and g_tot > 0:
                    est[lab] += o_tot / (g_tot / n_tot)
    # the campaign sign-ups: the store's statement has not reported the graded weeks' upgrades, so
    # they are carried on their summed scores at the calibration the week's organic part shows
    for lab in labels:
        organic = est[lab]
        if camp_pred[lab] <= 0:
            continue
        if opts["campaign"] == "predicted":
            est[lab] = organic + camp_pred[lab]
        elif opts["campaign"] == "own":
            # the campaign's calibration as its complete cohorts showed it (store rows, every upgrade in)
            done_up, done_pred = 0, 0.0
            scut = store_cutoff_of(store)
            for (d, b), (n, p) in trials.items():
                if camp.get((d, b), 0) and scut and (scut - d).days >= HORIZON:
                    done_pred += p * camp[(d, b)] / n
            for s, b, u, rep, c in store:
                if scut and (scut - s).days >= HORIZON and (u - s).days <= HORIZON:
                    done_up += c
            r = done_up / done_pred if done_pred else 1.0
            est[lab] = organic + r * camp_pred[lab]
        elif opts["campaign"] == "observed":
            est[lab] = organic + sum(c for (ll, b, s), c in store_seen.items() if ll == lab)
        else:
            kappa = organic / org_pred[lab] if org_pred[lab] else 1.0
            est[lab] = organic + kappa * camp_pred[lab]
    ratio = sum(est.values()) / sum(predicted.values())
    return {"weeks": {lab: int(round(v)) for lab, v in est.items()}, "verdict": verdict(ratio)}


def store_cutoff_of(store):
    """The end of the month the store's last statement covered."""
    if not store:
        return None
    last = max(rep for _, _, _, rep, _ in store)
    return last.replace(day=1) - dt.timedelta(days=1)


def verdict(ratio):
    return "hold" if LOW <= ratio <= HIGH else "retrain"


def main():
    folder, out = sys.argv[1], sys.argv[2]
    filed = mature(folder)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(filed, fh, indent=1)


if __name__ == "__main__":
    main()
