# Trial funnel handbook: offer extracts and the calibration review

The product is sold by subscription and acquired through a free trial. Each offer is one edition of
the product in one market, billed through that market's billing partner. The upgrade model scores
every trial the moment it signs up, and the evaluation desk reviews the model's calibration offer
by offer from a snapshot extract of the warehouse. This handbook describes the funnel, the model,
how upgrades reach the warehouse, the extract, what the review asks for and every file an extract
holds.

## The funnel

A trial signs up on a date. If the trial starts a paid subscription, that is its upgrade, and the
upgrade has a date. An upgrade counts for the trial's sign-up cohort when it falls within sixty days
of the sign-up date (the upgrade date minus the sign-up date is at most 60 days); a later paid
start is not counted. An offer's trials last 14 days unless the offer sheet records another trial
length for some of its sign-ups; a trial may upgrade during the trial or any time after it ends,
and most offers see upgrades spread over several weeks. Trials never upgrade twice.

## The upgrade model

The upgrade model takes what is known about a trial at sign-up and returns the probability that
the trial upgrades within sixty days. The warehouse does not keep the score per trial; it keeps,
for each sign-up date, the number of trials whose score fell in each of the model's eight probability
bands (band 1 the lowest scores, band 8 the highest) and the sum of those trials' scores. The bands
are fixed across offers and dates. A trial's band is set at sign-up and never changes.

## How upgrades reach the warehouse

The product does not bill its own customers. Each offer's billing partner reports every upgrade to
the warehouse with the trial's sign-up date and band and the upgrade date, and the warehouse stamps
each report with the date it arrived. Partners report on their own cadence: some pass each upgrade
on the day it occurs, some send a file each morning with the previous day's upgrades, and some send
a file on Mondays, every week or every second week, with every upgrade up to and including the
Sunday before it that their previous file did not carry. Sign-ups that come through the store
channel are billed by the store, which reports their upgrades on a statement issued on the first
Thursday of each month, covering every upgrade of the previous calendar month. An upgrade is in the
warehouse from its reported date onwards. Partners and the store do not report trials that have
not upgraded, and they do not revise what they have reported.

## The snapshot extract

An extract is taken for one offer on one snapshot date. It holds every trial that signed up in the
offer's sign-up weeks (sixteen ISO weeks, Monday to Sunday), grouped by sign-up date and band, and
every reported upgrade of those trials whose reported date is on or before the snapshot date,
grouped by sign-up date, band, upgrade date and reported date. The offer sheet names the snapshot
date, the sign-up weeks, the trial length and any event the market team recorded for the offer (a
paid acquisition campaign with its dates, the channel it ran through and the trial length its
sign-ups receive, a price change) with its date. Campaign sign-ups are scored by the upgrade model
like any other trial; the warehouse does not mark a trial's channel, on either table. Snapshots are
taken on Wednesdays.

## The calibration review

The desk reviews each offer at its snapshot and compares the model's summed scores with what its
youngest sign-up weeks go on to do: for each such week, the number of the week's trials that upgrade
within sixty days of signing up, the count the warehouse will show once every upgrade of that week
has happened and been reported. The review cannot wait for those weeks to complete; it is taken at
the snapshot, and the model is either kept as deployed or retrained on the offer's recent traffic.

## Files in an offer extract

`OFFER.md`, the offer sheet, for example:

```
# Offer OF-K4QD

- Market: NL
- Snapshot date: 2026-08-12
- Sign-up weeks in the extract: 2026-W17 (week of 2026-04-20) to 2026-W32 (week of 2026-08-03)
- Trial length: 14 days

## Recorded events

- A paid acquisition campaign has run since 2026-07-05 through the store channel; its sign-ups receive a 30-day trial and are billed by the store.
```

`trials.csv`, one row per sign-up date and band that had any trials, for example:

```
signup_date,band,trials,predicted_sum
2026-04-20,3,1402,53.18
```

`trials` is the number of trials that signed up on that date with a score in that band;
`predicted_sum` is the sum of those trials' scores, to two decimals.

`upgrades.csv`, one row per sign-up date, band, upgrade date and reported date that had any
reported upgrades, for example:

```
signup_date,band,upgrade_date,reported_date,count
2026-04-20,3,2026-05-03,2026-05-04,2
```

`count` is the number of upgrades of trials that signed up on `signup_date` in `band`, upgraded on
`upgrade_date` and were reported on `reported_date`.

The two sample extracts also carry `matured.csv`, one row per sign-up week with the week's
sixty-day upgrades as a snapshot taken 100 days later showed them, for example:

```
signup_week,eventual_upgrades
2026-W17,4712
```

Graded extracts carry no such file.

## The maturation program

The desk runs `python3 /app/maturity/mature.py OFFER_DIR OUT_JSON` once per offer. `OFFER_DIR`
holds the extract; the program writes `OUT_JSON` as one object with two fields: `weeks`, an object
from each graded week's ISO label (`2026-W29`) to its eventual sixty-day upgrade count as an
integer, and `verdict`, `hold` or `retrain`. For example:

```
{"weeks": {"2026-W29": 4810, "2026-W30": 4655, "2026-W31": 4902, "2026-W32": 4733}, "verdict": "hold"}
```

The program runs under the image's python3 with numpy 2.2.6 and the standard library, with no
network.
