#!/usr/bin/env python3
"""Builds offer extracts of the trial funnel: the warehouse tables an offer's snapshot holds, and the
sealed ledger of every upgrade (reported or not) with the parameters that produced it.

    extract_offers.py graded  CASES_DIR TRUTH_DIR [SEED]    twenty graded offers
    extract_offers.py samples CASES_DIR TRUTH_DIR [SEED]    the two sample offers, with matured.csv

Each offer is drawn until its graded weeks are settled by their own evidence (maturation.settled).
"""
import datetime as dt
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import maturation as M  # noqa: E402

WEEKS = 16
HORIZON = 60
BANDS = 8
BAND_P = np.array([0.012, 0.022, 0.038, 0.060, 0.090, 0.135, 0.200, 0.300])
WEEKDAY = np.array([1.06, 1.10, 1.08, 1.02, 0.94, 0.70, 0.64])
MARKETS = ["DE", "FR", "ES", "IT", "NL", "PL", "SE", "PT", "AT", "BE", "DK", "CZ", "IE", "FI", "NO", "CH"]
CADENCES = ("occurs", "daily", "weekly", "fortnightly")


def wednesdays(rng):
    first = dt.date(2026, 5, 6)
    return first + dt.timedelta(days=7 * int(rng.integers(0, 30)))


def code_of(rng):
    letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    digits = "23456789"
    return "OF-%s%s%s%s" % (letters[rng.integers(24)], digits[rng.integers(8)],
                            letters[rng.integers(24)], letters[rng.integers(24)])


def delay_params(rng):
    """Per band: share and median of the early component, the expiry component's centre and width,
    the late component's share and median. High bands upgrade early, low bands at the trial's end or
    later. Offer-level scaling keeps the curves from matching across offers."""
    early_share = np.clip(np.linspace(0.08, 0.90, BANDS) + rng.normal(0, 0.04, BANDS), 0.04, 0.95)
    early_med = np.linspace(9.0, 1.2, BANDS) * rng.uniform(0.8, 1.25)
    late_share = np.clip(np.linspace(0.50, 0.01, BANDS) + rng.normal(0, 0.03, BANDS), 0.0, 0.6)
    late_share = np.minimum(late_share, 1 - early_share - 0.05)
    return dict(early_share=early_share.tolist(), early_med=early_med.tolist(),
                early_sigma=float(rng.uniform(0.5, 0.75)),
                expiry_centre=float(rng.uniform(14.0, 16.5)), expiry_width=float(rng.uniform(2.0, 3.2)),
                late_share=late_share.tolist(), late_med=float(rng.uniform(28, 36)),
                late_sigma=float(rng.uniform(0.3, 0.45)))


def delay_pmf(dp, band):
    """P(delay = d | eventual upgrade), d = 0..HORIZON, from the band's mixture, by numerical mass."""
    d = np.arange(HORIZON + 1)
    edges_lo, edges_hi = d - 0.5, d + 0.5
    from math import erf, sqrt, log

    def ncdf(x):
        return 0.5 * (1 + erf(x / sqrt(2)))

    def lognorm_mass(med, sig):
        lo = np.array([ncdf((log(max(h, 1e-9)) - log(med)) / sig) if h > 0 else 0.0 for h in edges_lo])
        hi = np.array([ncdf((log(h) - log(med)) / sig) for h in edges_hi])
        return hi - lo

    def norm_mass(mu, sd):
        lo = np.array([ncdf((h - mu) / sd) for h in edges_lo])
        hi = np.array([ncdf((h - mu) / sd) for h in edges_hi])
        return hi - lo

    a, c = dp["early_share"][band], dp["late_share"][band]
    pmf = (a * lognorm_mass(dp["early_med"][band], dp["early_sigma"])
           + (1 - a - c) * norm_mass(dp["expiry_centre"], dp["expiry_width"])
           + c * lognorm_mass(dp["late_med"], dp["late_sigma"]))
    pmf = np.maximum(pmf, 0)
    return pmf / pmf.sum()


def report_date(upgrade, cadence, snapshot, phase):
    """The date the partner's report carrying an upgrade reaches the warehouse."""
    if cadence == "occurs":
        return upgrade
    if cadence == "daily":
        return upgrade + dt.timedelta(days=1)
    # a Monday file carries every upgrade before that Monday; fortnightly files land on alternate
    # Mondays, the last of them on the Monday before the snapshot
    days_to_monday = (7 - upgrade.weekday()) % 7 or 7
    monday = upgrade + dt.timedelta(days=days_to_monday)
    if cadence == "weekly":
        return monday
    anchor = snapshot - dt.timedelta(days=(snapshot.weekday() - 0) % 7)   # the Monday before the snapshot
    diff = (monday - anchor).days
    if diff % 14 != 0:
        monday = monday + dt.timedelta(days=7)
    return monday


def campaign_delay_params(dp, rng):
    """Campaign sign-ups get a longer trial, so their expiry-driven upgrades come later; the early
    component (upgrades during the trial) keeps the band's shape."""
    cp = dict(dp)
    cp["early_share"] = [float(a * rng.uniform(0.55, 0.75)) for a in dp["early_share"]]
    cp["expiry_centre"] = float(rng.uniform(30.0, 32.5))
    cp["expiry_width"] = float(rng.uniform(2.5, 3.5))
    cp["late_med"] = float(rng.uniform(42, 50))
    cp["late_sigma"] = float(rng.uniform(0.2, 0.3))
    return cp


def statement_date(upgrade):
    """The store channel's statement: the first Thursday of the month after the upgrade's month."""
    y, m = (upgrade.year + (upgrade.month // 12), upgrade.month % 12 + 1)
    first = dt.date(y, m, 1)
    return first + dt.timedelta(days=(3 - first.weekday()) % 7)


def draw_offer(rng, spec):
    snapshot = wednesdays(rng)
    week1 = snapshot - dt.timedelta(days=snapshot.weekday()) - dt.timedelta(days=7 * WEEKS)
    days = [week1 + dt.timedelta(days=i) for i in range(7 * WEEKS)]
    base = float(rng.uniform(20000, 28000))
    mix = rng.dirichlet(np.array([14, 17, 17, 15, 13, 11, 8, 5]) * 3.0)
    dp = delay_params(rng)
    pmfs = [delay_pmf(dp, b) for b in range(BANDS)]
    cdfs = [np.cumsum(p) for p in pmfs]
    # the model's calibration on this offer: close to 1 where a drift will be measured against it,
    # otherwise a few per cent off, and moving from week to week as traffic does
    if spec["drift"]:
        kappa0 = float(rng.uniform(0.97, 1.03))
    else:
        kappa0 = float(rng.uniform(0.92, 0.97) if rng.random() < 0.5 else rng.uniform(1.03, 1.08))
    week_mult = rng.uniform(0.92, 1.08, WEEKS)
    drift_week, r = None, None
    if spec["drift"]:
        drift_week = int(spec.get("drift_week") or rng.choice([11, 12] if spec["campaign"] else [11, 12, 13]))
        r = float(rng.uniform(0.70, 0.78) if rng.random() < 0.5 else rng.uniform(1.22, 1.30))
    campaign, cpmfs, ccdfs = None, None, None
    if spec["campaign"]:
        start = week1 + dt.timedelta(days=7 * int(rng.choice([3, 4])) + int(rng.integers(0, 7)))
        end = None
        if spec["campaign"] == "ended":
            end = week1 + dt.timedelta(days=7 * int(rng.choice([12, 13])) + int(rng.integers(0, 7)))
        tilt = np.array([1.6, 1.4, 1.2, 1.0, 0.8, 0.7, 0.6, 0.5])
        cmix = mix * tilt
        cmix = rng.dirichlet(cmix / cmix.sum() * 40.0)
        cp = campaign_delay_params(dp, rng)
        cpmfs = [delay_pmf(cp, b) for b in range(BANDS)]
        ccdfs = [np.cumsum(p) for p in cpmfs]
        campaign = dict(start=start.isoformat(), end=end.isoformat() if end else None,
                        lift_max=float(rng.uniform(2.5, 3.5)), ramp_days=int(rng.integers(35, 50)),
                        ramp_from=float(rng.uniform(0.1, 0.2)), trial_days=30,
                        mix=cmix.tolist(), delay=cp)
    price_change = None
    if rng.random() < 0.3:
        price_change = (week1 + dt.timedelta(days=int(rng.integers(20, 100)))).isoformat()

    trials_rows, ledger, extract, camp_counts = [], {}, {}, {}
    for s in days:
        n_day = base * WEEKDAY[s.weekday()] * rng.lognormal(0, 0.04)
        counts = rng.multinomial(int(round(n_day)), mix)
        extra = np.zeros(BANDS, dtype=int)
        if campaign:
            c_start = dt.date.fromisoformat(campaign["start"])
            c_end = dt.date.fromisoformat(campaign["end"]) if campaign["end"] else None
            if s >= c_start and (c_end is None or s <= c_end):
                ramp = min(1.0, campaign["ramp_from"] + (1 - campaign["ramp_from"])
                           * (s - c_start).days / campaign["ramp_days"])
                extra = rng.multinomial(int(round(n_day * campaign["lift_max"] * ramp)), campaign["mix"])
        kappa = kappa0
        if drift_week and s >= week1 + dt.timedelta(days=7 * (drift_week - 1)):
            kappa = r
        kappa *= float(week_mult[(s - week1).days // 7])
        for b in range(BANDS):
            n_org, n_camp = int(counts[b]), int(extra[b])
            n = n_org + n_camp
            if n == 0:
                continue
            if n_camp:
                camp_counts["%s,%d" % (s.isoformat(), b + 1)] = n_camp
            pred = n * BAND_P[b] * rng.normal(1.0, 0.02)
            trials_rows.append((s.isoformat(), b + 1, n, round(float(pred), 2)))
            for n_src, pmf, via_store in ((n_org, pmfs[b], False), (n_camp, cpmfs[b] if cpmfs else None, True)):
                if n_src == 0:
                    continue
                up = rng.binomial(n_src, min(0.95, BAND_P[b] * kappa))
                if up == 0:
                    continue
                delays = rng.multinomial(up, pmf)
                for d in np.nonzero(delays)[0]:
                    u = s + dt.timedelta(days=int(d))
                    c = int(delays[d])
                    ledger[(s, b + 1, u)] = ledger.get((s, b + 1, u), 0) + c
                    rep = statement_date(u) if via_store else report_date(u, spec["cadence"], snapshot, 0)
                    if rep <= snapshot:
                        key = (s, b + 1, u, rep)
                        extract[key] = extract.get(key, 0) + c
    params = dict(snapshot=snapshot.isoformat(), week1=week1.isoformat(), cadence=spec["cadence"],
                  base=base, mix=mix.tolist(), delay=dp, kappa0=kappa0, week_mult=week_mult.tolist(),
                  drift_week=drift_week, r=r,
                  campaign=campaign, campaign_counts=camp_counts, price_change=price_change,
                  cdf=[c.tolist() for c in cdfs],
                  cdf_campaign=[c.tolist() for c in ccdfs] if ccdfs else None)
    return dict(code=code_of(rng), market=MARKETS[rng.integers(len(MARKETS))], snapshot=snapshot,
                week1=week1, trials=trials_rows, ledger=ledger, extract=extract, params=params)


def write_offer(offer, cases, truth, matured):
    folder = os.path.join(cases, offer["code"])
    os.makedirs(folder, exist_ok=True)
    weeks = [offer["week1"] + dt.timedelta(days=7 * i) for i in range(WEEKS)]
    events = []
    p = offer["params"]
    if p["campaign"] and p["campaign"]["end"]:
        events.append("- A paid acquisition campaign ran from %s to %s through the store channel; its sign-ups "
                      "received a %d-day trial and are billed by the store."
                      % (p["campaign"]["start"], p["campaign"]["end"], p["campaign"]["trial_days"]))
    elif p["campaign"]:
        events.append("- A paid acquisition campaign has run since %s through the store channel; its sign-ups "
                      "receive a %d-day trial and are billed by the store."
                      % (p["campaign"]["start"], p["campaign"]["trial_days"]))
    if p["price_change"]:
        events.append("- The monthly price changed on %s." % p["price_change"])
    sheet = ["# Offer %s" % offer["code"], "",
             "- Market: %s" % offer["market"],
             "- Snapshot date: %s" % offer["snapshot"].isoformat(),
             "- Sign-up weeks in the extract: %s (week of %s) to %s (week of %s)"
             % (weeks[0].strftime("%G-W%V"), weeks[0].isoformat(),
                weeks[-1].strftime("%G-W%V"), weeks[-1].isoformat()),
             "- Trial length: 14 days", "",
             "## Recorded events", ""]
    sheet += events if events else ["- None recorded for this offer."]
    with open(os.path.join(folder, "OFFER.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(sheet) + "\n")
    with open(os.path.join(folder, "trials.csv"), "w", encoding="utf-8") as fh:
        fh.write("signup_date,band,trials,predicted_sum\n")
        for row in offer["trials"]:
            fh.write("%s,%d,%d,%.2f\n" % row)
    with open(os.path.join(folder, "upgrades.csv"), "w", encoding="utf-8") as fh:
        fh.write("signup_date,band,upgrade_date,reported_date,count\n")
        for (s, b, u, rep), c in sorted(offer["extract"].items()):
            fh.write("%s,%d,%s,%s,%d\n" % (s.isoformat(), b, u.isoformat(), rep.isoformat(), c))
    tdir = os.path.join(truth, offer["code"])
    os.makedirs(tdir, exist_ok=True)
    with open(os.path.join(tdir, "ledger.csv"), "w", encoding="utf-8") as fh:
        fh.write("signup_date,band,upgrade_date,count\n")
        for (s, b, u), c in sorted(offer["ledger"].items()):
            fh.write("%s,%d,%s,%d\n" % (s.isoformat(), b, u.isoformat(), c))
    with open(os.path.join(tdir, "params.json"), "w", encoding="utf-8") as fh:
        json.dump(offer["params"], fh, indent=1)
    key = M.key_from_ledger(tdir, folder)
    with open(os.path.join(tdir, "key.json"), "w", encoding="utf-8") as fh:
        json.dump(key, fh, indent=1)
    if matured:
        with open(os.path.join(folder, "matured.csv"), "w", encoding="utf-8") as fh:
            fh.write("signup_week,eventual_upgrades\n")
            for wk, n in M.eventual_by_week(tdir, folder).items():
                fh.write("%s,%d\n" % (wk, n))
    return key


def specs(mode, rng):
    if mode == "samples":
        return [dict(cadence="occurs", campaign=False, drift=False),
                dict(cadence="daily", campaign=False, drift=True, drift_week=8)]
    cad = ["occurs"] * 4 + ["daily"] * 4 + ["weekly"] * 6 + ["fortnightly"] * 6
    camp = ["running"] * 5 + ["ended"] * 5 + [False] * 10
    drift = [True] * 8 + [False] * 2 + [True] * 1 + [False] * 9   # eight drifts on campaign offers
    rng.shuffle(cad)
    order = list(range(20))
    rng.shuffle(order)
    return [dict(cadence=cad[i], campaign=camp[j], drift=drift[j]) for i, j in enumerate(order)]


def main():
    mode, cases, truth = sys.argv[1], sys.argv[2], sys.argv[3]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else (20261020 if mode == "graded" else 7)
    rng = np.random.default_rng(seed)
    os.makedirs(cases, exist_ok=True)
    os.makedirs(truth, exist_ok=True)
    used = set()
    for i, spec in enumerate(specs(mode, rng)):
        for attempt in range(40):
            offer = draw_offer(rng, spec)
            if offer["code"] in used:
                continue
            key = write_offer(offer, cases, truth, matured=(mode == "samples"))
            ok, why = M.settled(os.path.join(truth, offer["code"]), os.path.join(cases, offer["code"]))
            if ok:
                used.add(offer["code"])
                print("%2d %s %-12s campaign=%s drift=%s verdict=%s ratio=%.3f"
                      % (i, offer["code"], spec["cadence"], spec["campaign"], spec["drift"],
                         key["verdict"], key["ratio"]), flush=True)
                break
            import shutil
            shutil.rmtree(os.path.join(cases, offer["code"]))
            shutil.rmtree(os.path.join(truth, offer["code"]))
            print("   redraw: %s" % why, flush=True)
        else:
            raise SystemExit("offer %d could not be settled" % i)


if __name__ == "__main__":
    main()
