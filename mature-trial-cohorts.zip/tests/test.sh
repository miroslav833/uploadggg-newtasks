#!/usr/bin/env bash
# Grading entry point. Before any uploaded code runs, the verdict folder is locked: /logs/verifier
# is made root-only and checked, every reward-, result- or score-shaped file in it is removed and
# reward.txt is set to 0. The program then runs as an unprivileged account (tests/run_offers.py).
# When the checks are over, everything in /logs/verifier that root did not write is removed again
# and reward.txt alone is written: 1 only when both checks passed.
set -u
LOGS=/logs/verifier
ROOM=/run/verifier

mkdir -p "$LOGS"
kept_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

purge() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
verdict() {
    purge
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
done_() {
    chmod "$kept_mode" "$LOGS" 2>/dev/null
    exit 0
}

verdict 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "grading: $LOGS could not be locked; nothing is run" >&2
    done_
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$ROOM" && chown 0:0 "$ROOM" && chmod 700 "$ROOM"
chmod -R a+rX /app/maturity 2>/dev/null

outcome=0
if ( cd /tests && python3 -m pytest test_offers.py -q -p no:cacheprovider --ctrf "$ROOM/ctrf.json" ); then
    outcome=1
fi

verdict "$outcome"
for f in ctrf.json offers.json; do
    [ -f "$ROOM/$f" ] && (umask 022; cp "$ROOM/$f" "$LOGS/$f")
done
done_
