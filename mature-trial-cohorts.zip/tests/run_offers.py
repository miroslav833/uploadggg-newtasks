"""Runs the uploaded maturation program over every graded offer and reads what it filed.

Each offer is handed to the program as a private copy of its extract folder, with an empty output
folder, under a numeric account invented for the run that owns nothing else in the image, with a
wall-clock limit and resource limits. Every process of that account is stopped before the output is
read. The output is parsed as JSON text and nothing in it is executed.
"""
import json
import os
import resource
import shutil
import signal
import subprocess
import time

OFFERS = "/tests/offers/cases"
TRUTH = "/tests/offers/truth"
PRIVATE = "/run/verifier"
SCRATCH = "/var/tmp/offers"
PROGRAM = "/app/maturity/mature.py"
SECONDS = 120              # wall-clock limit per offer; printed in instruction.md
MAX_BYTES = 64 * 1024      # an output larger than this is not read
UID_FROM = 61000


def codes():
    return sorted(os.listdir(OFFERS))


def key_of(code):
    with open(os.path.join(TRUTH, code, "key.json"), encoding="utf-8") as fh:
        return json.load(fh)


class Runner:
    def __init__(self):
        taken = set()
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    taken.add(os.stat("/proc/" + d).st_uid)
                except FileNotFoundError:
                    pass
        self.uid = UID_FROM
        while self.uid in taken:
            self.uid += 1

    def _pids(self):
        out = []
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == self.uid:
                    out.append(int(d))
            except FileNotFoundError:
                continue
        return out

    def stop_all(self):
        for _ in range(200):
            pids = self._pids()
            if not pids:
                return
            for pid in pids:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            time.sleep(0.03)

    def _become(self):
        os.setsid()
        os.setgroups([])
        os.setgid(self.uid)
        os.setuid(self.uid)
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))

    def run(self, code):
        """Runs the program on one offer; returns the parsed filing (a dict) or None."""
        area = os.path.join(SCRATCH, code)
        shutil.rmtree(area, ignore_errors=True)
        folder, outdir, home = (os.path.join(area, n) for n in ("offer", "out", "home"))
        shutil.copytree(os.path.join(OFFERS, code), folder, symlinks=False)
        os.makedirs(outdir)
        os.makedirs(home)
        for base, dirs, files in os.walk(area):
            for n in dirs + files:
                os.chown(os.path.join(base, n), self.uid, self.uid)
        os.chown(area, self.uid, self.uid)
        target = os.path.join(outdir, "maturity.json")
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8",
               "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
        with open(os.path.join(PRIVATE, code + ".log"), "wb") as log:
            child = subprocess.Popen(["python3", PROGRAM, folder, target], stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=log, cwd=home, env=env, preexec_fn=self._become)
            try:
                child.wait(timeout=SECONDS)
            except subprocess.TimeoutExpired:
                pass
        self.stop_all()
        filed = read_filing(target)
        shutil.rmtree(area, ignore_errors=True)
        return filed


def read_filing(path):
    """The filed JSON, read as text: a regular file under MAX_BYTES holding one object."""
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > MAX_BYTES:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        raw = os.read(fd, MAX_BYTES + 1)
    finally:
        os.close(fd)
    try:
        obj = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        return None
    return obj if isinstance(obj, dict) else None
