"""The verifier's own account of the funnel: what an offer's sealed ledger says each graded week's
eventual sixty-day upgrades are, the review's ratio and verdict from them, and whether the offer's
visible extract settles those numbers (the true maturation curves and the partner's true cutoff,
applied to the reported counts, land close to the ledger).

Nothing here uses the reference program. The verifier draws nothing at random."""
import csv
import datetime as dt
import json
import math
import os

HORIZON = 60            # an upgrade counts within this many days of the sign-up date
GRADED_WEEKS = 4        # the youngest gradable sign-up weeks the review judges
GRADABLE_LAG = 10       # a week is gradable when its Sunday is at least this many days before the snapshot
LOW, HIGH = 0.875, 1.125   # the review's hold band on the calibration ratio
TOLERANCE = 0.10        # a filed count is right within this share of the sealed count
SETTLED_SHARE = 0.04    # the ideal maturation must land within this share of the ledger's count
RATIO_MARGIN = 0.035    # the sealed ratio keeps this distance from both thresholds
MIN_REPORTED = 300      # the youngest graded week shows at least this many reported upgrades


def read_sheet(folder):
    """The snapshot date from OFFER.md."""
    with open(os.path.join(folder, "OFFER.md"), encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("- Snapshot date:"):
                return dt.date.fromisoformat(line.split(":", 1)[1].strip())
    raise ValueError("no snapshot date in OFFER.md")


def read_trials(folder):
    out = {}
    with open(os.path.join(folder, "trials.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            key = (dt.date.fromisoformat(row["signup_date"]), int(row["band"]))
            out[key] = (int(row["trials"]), float(row["predicted_sum"]))
    return out


def read_upgrades(folder):
    out = []
    with open(os.path.join(folder, "upgrades.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            out.append((dt.date.fromisoformat(row["signup_date"]), int(row["band"]),
                        dt.date.fromisoformat(row["upgrade_date"]),
                        dt.date.fromisoformat(row["reported_date"]), int(row["count"])))
    return out


def read_ledger(truth_dir):
    out = []
    with open(os.path.join(truth_dir, "ledger.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            out.append((dt.date.fromisoformat(row["signup_date"]), int(row["band"]),
                        dt.date.fromisoformat(row["upgrade_date"]), int(row["count"])))
    return out


def week_label(day):
    return day.strftime("%G-W%V")


def monday_of(day):
    return day - dt.timedelta(days=day.weekday())


def graded_weeks(snapshot, signup_days):
    """The four most recent ISO weeks among the sign-up days whose Sunday lies at least GRADABLE_LAG
    days before the snapshot, as Monday dates, oldest first."""
    mondays = sorted({monday_of(d) for d in signup_days})
    ok = [m for m in mondays if (snapshot - (m + dt.timedelta(days=6))).days >= GRADABLE_LAG]
    return ok[-GRADED_WEEKS:]


def eventual_by_week(truth_dir, folder):
    """Every sign-up week's eventual sixty-day upgrades from the sealed ledger."""
    trials = read_trials(folder)
    weeks = sorted({monday_of(d) for d, _ in trials})
    totals = {week_label(w): 0 for w in weeks}
    for s, b, u, c in read_ledger(truth_dir):
        if (u - s).days <= HORIZON:
            totals[week_label(s)] += c
    return totals


def key_from_ledger(truth_dir, folder):
    """The sealed key: each graded week's eventual upgrades, the ratio and the verdict."""
    snapshot = read_sheet(folder)
    trials = read_trials(folder)
    weeks = graded_weeks(snapshot, [d for d, _ in trials])
    labels = [week_label(w) for w in weeks]
    eventual = {lab: 0 for lab in labels}
    for s, b, u, c in read_ledger(truth_dir):
        lab = week_label(s)
        if lab in eventual and (u - s).days <= HORIZON:
            eventual[lab] += c
    predicted = {lab: 0.0 for lab in labels}
    for (d, b), (n, p) in trials.items():
        lab = week_label(d)
        if lab in predicted:
            predicted[lab] += p
    ratio = sum(eventual.values()) / sum(predicted.values())
    return dict(weeks=labels, eventual=eventual, predicted={k: round(v, 2) for k, v in predicted.items()},
                ratio=ratio, verdict=verdict_of(ratio))


def verdict_of(ratio):
    return "hold" if LOW <= ratio <= HIGH else "retrain"


def true_cutoff(params):
    """The last upgrade date the billing partner's reports could have carried into the snapshot."""
    snapshot = dt.date.fromisoformat(params["snapshot"])
    cadence = params["cadence"]
    if cadence == "occurs":
        return snapshot
    if cadence == "daily":
        return snapshot - dt.timedelta(days=1)
    last_monday = snapshot - dt.timedelta(days=snapshot.weekday())
    return last_monday - dt.timedelta(days=1)


def store_cutoff(snapshot):
    """The last upgrade date the store channel's statements could have carried into the snapshot:
    the end of the month before the last first-Thursday statement on or before the snapshot."""
    first = snapshot.replace(day=1)
    thursday = first + dt.timedelta(days=(3 - first.weekday()) % 7)
    if thursday > snapshot:
        first = (first - dt.timedelta(days=1)).replace(day=1)
    return first - dt.timedelta(days=1)


def ideal_maturation(truth_dir, folder):
    """Each graded week's count as the evidence settles it with the true structure: the organic
    sign-ups matured through the true band curves at the partner's true cutoff, the week's calibration
    read off that organic part, and the campaign sign-ups (reported only through the store's monthly
    statement) carried at that calibration on their summed scores."""
    params = json.load(open(os.path.join(truth_dir, "params.json"), encoding="utf-8"))
    snapshot = read_sheet(folder)
    cutoff = true_cutoff(params)
    scut = store_cutoff(snapshot)
    trials = read_trials(folder)
    weeks = graded_weeks(snapshot, [d for d, _ in trials])
    labels = {week_label(w) for w in weeks}
    camp_counts = params.get("campaign_counts") or {}
    org_n, org_g, org_pred, camp_pred = {}, {}, {}, {}
    for (d, b), (n, p) in trials.items():
        lab = week_label(d)
        if lab not in labels:
            continue
        lag = (cutoff - d).days
        n_camp = int(camp_counts.get("%s,%d" % (d.isoformat(), b), 0))
        n_org = n - n_camp
        g = params["cdf"][b - 1][min(lag, HORIZON)] if lag >= 0 else 0.0
        org_n[(lab, b)] = org_n.get((lab, b), 0) + n_org
        org_g[(lab, b)] = org_g.get((lab, b), 0.0) + n_org * g
        org_pred[lab] = org_pred.get(lab, 0.0) + p * n_org / n
        camp_pred[lab] = camp_pred.get(lab, 0.0) + p * n_camp / n
    observed = {}
    reported = {lab: 0 for lab in labels}
    for s, b, u, rep, c in read_upgrades(folder):
        lab = week_label(s)
        if lab not in labels or (u - s).days > HORIZON:
            continue
        reported[lab] += c
        if is_statement(rep) and not partner_fits(params["cadence"], u, rep):
            continue       # a store-reported campaign upgrade: not part of the organic evidence
        observed[(lab, b)] = observed.get((lab, b), 0) + c
    est = {}
    for lab in labels:
        organic = 0.0
        for (ll, b), n in org_n.items():
            if ll != lab or n == 0:
                continue
            g = org_g[(ll, b)] / n
            organic += observed.get((ll, b), 0) / g if g > 0 else 0.0
        kappa = organic / org_pred[lab] if org_pred.get(lab) else 1.0
        est[lab] = organic + kappa * camp_pred.get(lab, 0.0)
    return est, reported


def partner_fits(cadence, u, rep):
    """Whether a reported date is one the billing partner's own cadence would give the upgrade."""
    if cadence == "occurs":
        return rep == u
    if cadence == "daily":
        return (rep - u).days == 1
    return rep.weekday() == 0


def is_statement(rep):
    """Whether a reported date is a first Thursday of its month (the store's statement day)."""
    return rep.weekday() == 3 and rep.day <= 7


def settled(truth_dir, folder):
    """Whether the offer's graded weeks are settled by its own evidence. Returns (ok, reason)."""
    key = key_from_ledger(truth_dir, folder)
    est, reported = ideal_maturation(truth_dir, folder)
    for lab in key["weeks"]:
        truth = key["eventual"][lab]
        if truth <= 0:
            return False, "%s has no eventual upgrades" % lab
        if not math.isfinite(est[lab]) or abs(est[lab] - truth) > SETTLED_SHARE * truth:
            return False, "%s: ideal maturation %.0f against %d" % (lab, est[lab], truth)
    youngest = key["weeks"][-1]
    if reported[youngest] < MIN_REPORTED:
        return False, "%s shows only %d reported upgrades" % (youngest, reported[youngest])
    r = key["ratio"]
    if not math.isfinite(r) or min(abs(r - LOW), abs(r - HIGH)) < RATIO_MARGIN:
        return False, "ratio %.3f too near a threshold" % r
    return True, ""


def right(filed, key):
    """Whether a filed object (parsed JSON) matches the sealed key: every graded week within
    TOLERANCE and the verdict equal. Non-finite or missing numbers are wrong."""
    if not isinstance(filed, dict):
        return False
    weeks = filed.get("weeks")
    if not isinstance(weeks, dict):
        return False
    for lab in key["weeks"]:
        v = weeks.get(lab)
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            return False
        if not math.isfinite(v):
            return False
        truth = key["eventual"][lab]
        if abs(v - truth) > TOLERANCE * truth:
            return False
    return filed.get("verdict") == key["verdict"]
