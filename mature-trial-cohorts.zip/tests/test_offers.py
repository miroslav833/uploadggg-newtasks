"""Two checks. First, every sealed key is what the offer's sealed ledger says, and the offer's visible
extract settles it (the true curves and the true cutoff applied to the reported counts land within
4 per cent of the ledger, the ratio keeps its distance from both thresholds, and the youngest graded
week shows enough reported upgrades). Second, the uploaded program matures enough offers."""
import json
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import maturation as M     # noqa: E402
import run_offers as RO    # noqa: E402

OFFERS = 20
MARK = 18        # offers the program must get right; printed in instruction.md


def test_sealed_keys_follow_the_ledger_and_are_settled():
    codes = RO.codes()
    assert len(codes) == OFFERS
    for code in codes:
        truth_dir = os.path.join(RO.TRUTH, code)
        folder = os.path.join(RO.OFFERS, code)
        key = RO.key_of(code)
        again = M.key_from_ledger(truth_dir, folder)
        assert again["weeks"] == key["weeks"], code
        assert again["eventual"] == key["eventual"], code
        assert again["verdict"] == key["verdict"], code
        assert math.isfinite(key["ratio"]) and abs(again["ratio"] - key["ratio"]) < 1e-9, code
        ok, why = M.settled(truth_dir, folder)
        assert ok, "%s: %s" % (code, why)


@pytest.fixture(scope="module")
def filings():
    runner = RO.Runner()
    out = {}
    for code in RO.codes():
        filed = runner.run(code)
        out[code] = bool(filed) and M.right(filed, RO.key_of(code))
    with open(os.path.join(RO.PRIVATE, "offers.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)
    print(json.dumps(out))
    return out


def test_program_matures_enough_offers(filings):
    right = sum(1 for ok in filings.values() if ok)
    assert right >= MARK, "%d of %d offers right (%s); %d needed" % (right, OFFERS, filings, MARK)
