Write a program that, from one offer extract of a subscription product's trial funnel, files the eventual sixty-day upgrade count of each of the offer's four youngest gradable sign-up weeks and the calibration review's verdict on the deployed upgrade model. It runs as

```
python3 /app/maturity/mature.py OFFER_DIR OUT_JSON
```

`/app/guide/HANDBOOK.md` describes the funnel, the upgrade model and its bands, how billing partners report upgrades, the snapshot extract, the review's rule and every file in an extract. Two sample extracts are in `/app/cases`, each with `OFFER.md`, `trials.csv` (trials and summed scores per sign-up date and band), `upgrades.csv` (reported upgrades per sign-up date, band, upgrade date and reported date) and `matured.csv` (each sign-up week's sixty-day upgrades as a later snapshot showed them).

OUT_JSON is one object with two fields:

```
{"weeks": {"2026-W29": 4810, "2026-W30": 4655, "2026-W31": 4902, "2026-W32": 4733}, "verdict": "hold"}
```

`weeks` maps each graded week's ISO label to the number of its trials that upgrade within sixty days of signing up, as an integer. The graded weeks are the four most recent ISO weeks whose Sunday lies at least 10 days before the snapshot date. `verdict` is `hold` when the ratio of the four counts' sum to the four weeks' summed scores is between 0.875 and 1.125 inclusive, and `retrain` otherwise. An offer is right when every graded week's count is within 10 per cent of the sealed count, read from that offer's complete upgrade record, and the verdict equals the sealed verdict; a missing week, an unparseable file or a non-finite number makes it wrong.

Grading runs the program on 20 other offer extracts that are not on this machine, from offers whose billing partners and traffic do not all behave as the two samples do. At least 18 of the 20 offers must be right. The program runs once per offer on a fresh copy of its folder, as an unprivileged user, under the image's python3 with numpy 2.2.6 and the standard library, with 120 seconds per offer. Anything else it needs must be inside `/app/maturity`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
