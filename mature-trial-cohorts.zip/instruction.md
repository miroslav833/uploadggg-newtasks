Write a maturation program for the trial-funnel review: given one offer extract, it has to say how many of the trials that signed up in each of the offer's four youngest gradable weeks will have upgraded within sixty days, and whether the upgrade model deployed on that offer should be held or retrained.

Call signature:

```
python3 /app/maturity/mature.py OFFER_DIR OUT_JSON
```

Read `/app/guide/HANDBOOK.md` first. It covers the funnel itself, the upgrade model and its probability bands, the ways upgrades get reported into the warehouse, what a snapshot extract contains, and the layout of every file. There are two worked extracts under `/app/cases`. An extract folder holds the offer sheet `OFFER.md`, `trials.csv` (sign-ups and summed scores by date and band) and `upgrades.csv` (the upgrades the warehouse had received by the snapshot, by sign-up date, band, upgrade date and reported date). The two samples also carry `matured.csv`: the sixty-day upgrade count of every sign-up week, as a snapshot taken a hundred days later showed it.

The output is a single JSON object, like this one:

```
{"weeks": {"2026-W29": 4810, "2026-W30": 4655, "2026-W31": 4902, "2026-W32": 4733}, "verdict": "hold"}
```

Which weeks: take the ISO weeks whose Sunday falls 10 or more days before the snapshot date, and keep the four most recent of them. Under `weeks`, give each one the count of its trials that upgrade within sixty days of their sign-up date, as a whole number. The verdict comes from one ratio: the four counts added together, divided by the four weeks' summed scores added together. Between 0.875 and 1.125 (inclusive) it is `hold`; anything else is `retrain`.

Scoring: for every offer the sealed answer is computed from its complete upgrade record. The offer counts as right when all four counts land within 10 per cent of the sealed ones and the verdict matches. A week left out, a number that is not finite, or a file that does not parse means the offer is wrong.

The grader holds 20 further extracts, kept back in its own image; their billing partners and their traffic are not all like the two samples. You need 18 of the 20 right. Each run gets a clean copy of one extract folder, an unprivileged account, the image's python3 with numpy 2.2.6 plus the standard library, and 120 seconds. Keep everything the program depends on under `/app/maturity`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
