# Importing a card game from its print sheets

## What a publisher sends

One folder per game. `game.txt` gives the game's title, the publisher and how the sheets are printed; the sheets
are SVG pages exported from the publisher's layout tool, numbered in print order (`sheet-2`, `page03`, `p4`, ...).
Each page holds up to nine cards in a grid, with crop marks or cut outlines around them and sometimes a printer's
line in the margin. The finished art is not included: art windows are empty or hold a proof picture.

Publishers work in Adobe Illustrator, Inkscape, LibreOffice Draw, their own scripts (svgwrite), Figma, Sketch,
CorelDRAW or Affinity Designer. Every file is ordinary SVG 1.1, but each tool writes it its own way (units, styles
as attributes or classes, transforms, reused symbols, one text element per line or per word or per style, one
position per letter). Only what prints counts: hidden or fully transparent elements are not part of a card.

## The database

`<folder name>.json` holds `{"game": <title from game.txt>, "cards": [...]}`, the cards ordered by collector
number, one record per distinct card:

- `number`: the collector number as an integer. Printed as `12/48`, `#12`, `012` or `No. 12`.
- `name`: the card's name as printed (letter case kept).
- `type`: the type line as printed, for example `Spell` or `Unit · Knight`.
- `cost`: an integer, `"X"`, or `null` when the card has no cost.
- `stats`: an object such as `{"attack": 3, "health": 5}`, empty when the card has none.
- `text`: the rules text (below).
- `keywords`: the keywords in the rules text, in the order printed.
- `rarity`: `common`, `uncommon`, `rare` or `mythic`.
- `copies`: how many times the card is printed across the game's sheets.
- `back`: `null`, or for a double-faced card the other face as `{"name", "type", "stats", "text", "keywords"}`.

## Reading a card

Every publisher lays a card out the same way, though each draws the parts differently.

- **Name**: the largest lettering across the top.
- **Cost**: in a top corner. A numeral or `X` on a badge (a circle, a hexagon or a diamond), or a row of small
  pips (the cost is how many). No cost mark: `null`.
- **Art window**, then the **type line** just below it. At the right end of the type line, the **rarity**: a
  crown-shaped mark coloured black or dark grey (common), silver or light grey (uncommon), gold or yellow (rare),
  orange or red (mythic); or one to four dots (one = common ... four = mythic); or the letter C, U, R or M in a
  small circle.
- **Text box** below the type line.
- **Stats** on badges in the bottom corners, each a numeral on a shape that names it: a sword or a spiky burst is
  `attack`, a heart or a drop is `health`, a shield is `defense`.
- **Collector number** at the bottom. The artist credit (`Illus. ...`) is not data.

Locations are landscape cards. They are printed turned a quarter on the sheet; their art is on the left, with the
type line and text box to its right. They have no cost and no stats.

## Rules text

The text box's lines, top to bottom, joined with single spaces. A word broken at the end of a line with a hyphen is
one word. Spacing does not matter otherwise.

Icons in the text become tokens in their place:

| token | drawn as |
|---|---|
| `{coin}` | a coin: a disc with a ring inside, or an eight-sided coin |
| `{exhaust}` | a curved arrow, or a card turned on its side |
| `{damage}` | a spiky burst, or a drop |
| `{heal}` | a plus-shaped cross, or a heart |
| `{card}` | an upright card, or two overlapping cards |

Some tools leave a run of spaces in the line and draw the icon over it; the token takes the place of the spaces.

Not part of the rules text:
- reminder text: anything in parentheses;
- flavour text: set apart below a short rule line, or in quotation marks with an attribution, or set in light
  grey.

**Keywords** are the words set in bold or in small capitals in the rules text (not in reminder or flavour text).
Each keyword is one entry, without punctuation: `Swift`, `First Strike`. Many tools draw small capitals as capital
letters at a smaller size after a full-size capital; the smaller capitals stand for lower-case letters
(`F` + smaller `IRST` is `First`).

## Card backs and double-faced cards

`game.txt` says how the game is printed. `single-sided` games have the fronts on their pages and, if any, the card
back on a page of its own. `double-sided` games alternate pages: every second page is the back of the page before
it. A card's back is at the mirrored place on that page: flipped on the long edge, mirrored left to right; flipped
on the short edge, mirrored top to bottom and printed upside down.

The game's card back (the same design on every card, with no collector number) is not a card. A card whose back is
another face instead is double-faced: that face goes in `back`. It has a name, type line, text and perhaps stats,
but no cost, number or rarity of its own.
