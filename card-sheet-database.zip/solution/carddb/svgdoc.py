"""Flatten one SVG sheet into absolute shapes, images and text runs (standard library only)."""
import math
import re
import xml.etree.ElementTree as ET

NUM = re.compile(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?")
INHERITED = ("fill", "stroke", "stroke-width", "font-family", "font-size", "font-weight", "font-style", "font-variant",
             "text-anchor", "visibility", "white-space", "letter-spacing")
NAMED = {"black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000", "blue": "#0000ff",
         "grey": "#808080", "gray": "#808080", "silver": "#c0c0c0", "gold": "#ffd700", "orange": "#ffa500",
         "yellow": "#ffff00", "none": "none", "transparent": "none"}
IDENTITY = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def tag(e):
    return e.tag.rsplit("}", 1)[-1] if isinstance(e.tag, str) else ""


def mul(m, n):
    a, b, c, d, e, f = m
    a2, b2, c2, d2, e2, f2 = n
    return (a * a2 + c * b2, b * a2 + d * b2, a * c2 + c * d2, b * c2 + d * d2, a * e2 + c * f2 + e, b * e2 + d * f2 + f)


def ap(m, x, y):
    return (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])


def scale(m):
    return math.sqrt(abs(m[0] * m[3] - m[1] * m[2])) or 1.0


def transform(s):
    m = IDENTITY
    for name, args in re.findall(r"([a-zA-Z]+)\s*\(([^)]*)\)", s or ""):
        v = [float(x) for x in NUM.findall(args)]
        if name == "matrix" and len(v) == 6:
            t = tuple(v)
        elif name == "translate" and v:
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0.0)
        elif name == "scale" and v:
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "rotate" and v:
            r = math.radians(v[0])
            t = (math.cos(r), math.sin(r), -math.sin(r), math.cos(r), 0, 0)
            if len(v) == 3:
                t = mul(mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == "skewX" and v:
            t = (1, 0, math.tan(math.radians(v[0])), 1, 0, 0)
        elif name == "skewY" and v:
            t = (1, math.tan(math.radians(v[0])), 0, 1, 0, 0)
        else:
            continue
        m = mul(m, t)
    return m


def colour(v):
    if v is None:
        return None
    v = v.strip().lower()
    if v.startswith("url("):
        return "pattern"
    if v in NAMED:
        return NAMED[v]
    if v.startswith("#"):
        h = v[1:]
        if len(h) == 3:
            h = "".join(ch * 2 for ch in h)
        return "#" + h[:6]
    if v.startswith("rgb"):
        parts = re.findall(r"[-+]?\d*\.?\d+%?", v)
        out = []
        for p in parts[:3]:
            out.append(round(float(p[:-1]) * 2.55) if p.endswith("%") else round(float(p)))
        return "#%02x%02x%02x" % tuple(max(0, min(255, x)) for x in out)
    return v


def length(v, em=16.0):
    if v is None:
        return None
    m = NUM.match(v.strip())
    if not m:
        return None
    x = float(m.group(0))
    unit = v.strip()[m.end():].strip()
    if unit == "em":
        return x * em
    if unit == "%":
        return None
    return x


def declarations(text):
    out = {}
    for part in (text or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip().lower()] = v.strip()
    return out


def stylesheet(text):
    rules = []
    text = re.sub(r"/\*.*?\*/", "", text.replace("<![CDATA[", "").replace("]]>", ""), flags=re.S)
    for sel, body in re.findall(r"([^{}]+)\{([^}]*)\}", text):
        decl = declarations(body)
        for one in sel.split(","):
            one = one.strip()
            if not one:
                continue
            m = re.match(r"^([a-zA-Z]*)((?:\.[\w-]+)*)$", one)
            if not m:
                continue
            rules.append((m.group(1) or None, [c for c in m.group(2).split(".") if c], decl))
    return rules


def flatten_path(d, steps=8):
    """Subpaths of a path's data as (points, closed)."""
    toks = re.findall(r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", d or "")
    out = []
    pts = []
    i = 0
    cmd = None
    x = y = 0.0
    sx = sy = 0.0
    last_c = None
    last_q = None

    def nums(n):
        nonlocal i
        vals = [float(t) for t in toks[i:i + n]]
        i += n
        return vals

    def flush(closed):
        nonlocal pts
        if len(pts) >= 2:
            out.append((pts, closed))
        pts = []

    while i < len(toks):
        t = toks[i]
        if re.match(r"[A-Za-z]", t):
            cmd = t
            i += 1
            if cmd in "Zz":
                flush(True)
                x, y = sx, sy
                last_c = last_q = None
                continue
        if cmd is None:
            break
        rel = cmd.islower()
        c = cmd.upper()
        if c == "M":
            dx, dy = nums(2)
            flush(False)
            x, y = (x + dx, y + dy) if rel else (dx, dy)
            sx, sy = x, y
            pts = [(x, y)]
            cmd = "l" if rel else "L"
            last_c = last_q = None
        elif c == "L":
            dx, dy = nums(2)
            x, y = (x + dx, y + dy) if rel else (dx, dy)
            pts.append((x, y))
            last_c = last_q = None
        elif c == "H":
            (v,) = nums(1)
            x = x + v if rel else v
            pts.append((x, y))
            last_c = last_q = None
        elif c == "V":
            (v,) = nums(1)
            y = y + v if rel else v
            pts.append((x, y))
            last_c = last_q = None
        elif c in "CS":
            if c == "C":
                x1, y1, x2, y2, x3, y3 = nums(6)
                if rel:
                    x1, y1, x2, y2, x3, y3 = x + x1, y + y1, x + x2, y + y2, x + x3, y + y3
            else:
                x2, y2, x3, y3 = nums(4)
                if rel:
                    x2, y2, x3, y3 = x + x2, y + y2, x + x3, y + y3
                x1, y1 = (2 * x - last_c[0], 2 * y - last_c[1]) if last_c else (x, y)
            for k in range(1, steps + 1):
                tt = k / steps
                mt = 1 - tt
                pts.append((mt ** 3 * x + 3 * mt * mt * tt * x1 + 3 * mt * tt * tt * x2 + tt ** 3 * x3,
                            mt ** 3 * y + 3 * mt * mt * tt * y1 + 3 * mt * tt * tt * y2 + tt ** 3 * y3))
            last_c = (x2, y2)
            last_q = None
            x, y = x3, y3
        elif c in "QT":
            if c == "Q":
                x1, y1, x2, y2 = nums(4)
                if rel:
                    x1, y1, x2, y2 = x + x1, y + y1, x + x2, y + y2
            else:
                x2, y2 = nums(2)
                if rel:
                    x2, y2 = x + x2, y + y2
                x1, y1 = (2 * x - last_q[0], 2 * y - last_q[1]) if last_q else (x, y)
            for k in range(1, steps + 1):
                tt = k / steps
                mt = 1 - tt
                pts.append((mt * mt * x + 2 * mt * tt * x1 + tt * tt * x2, mt * mt * y + 2 * mt * tt * y1 + tt * tt * y2))
            last_q = (x1, y1)
            last_c = None
            x, y = x2, y2
        elif c == "A":
            rx, ry, phi, fa, fs, x2, y2 = nums(7)
            if rel:
                x2, y2 = x + x2, y + y2
            pts += arc(x, y, rx, ry, phi, int(fa), int(fs), x2, y2)
            x, y = x2, y2
            last_c = last_q = None
        else:
            i += 1
    flush(False)
    return out


def arc(x1, y1, rx, ry, phi, fa, fs, x2, y2, per=16):
    if rx == 0 or ry == 0:
        return [(x2, y2)]
    rx, ry = abs(rx), abs(ry)
    p = math.radians(phi)
    cp, sp = math.cos(p), math.sin(p)
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    xp, yp = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = (xp / rx) ** 2 + (yp / ry) ** 2
    if lam > 1:
        rx, ry = rx * math.sqrt(lam), ry * math.sqrt(lam)
    num = rx * rx * ry * ry - rx * rx * yp * yp - ry * ry * xp * xp
    den = rx * rx * yp * yp + ry * ry * xp * xp
    k = math.sqrt(max(0.0, num / den)) if den else 0.0
    if fa == fs:
        k = -k
    cxp, cyp = k * rx * yp / ry, -k * ry * xp / rx
    cx = cp * cxp - sp * cyp + (x1 + x2) / 2
    cy = sp * cxp + cp * cyp + (y1 + y2) / 2
    a1 = math.atan2((yp - cyp) / ry, (xp - cxp) / rx)
    a2 = math.atan2((-yp - cyp) / ry, (-xp - cxp) / rx)
    da = a2 - a1
    if fs and da < 0:
        da += 2 * math.pi
    elif not fs and da > 0:
        da -= 2 * math.pi
    n = max(2, int(abs(da) / (math.pi / per)))
    out = []
    for j in range(1, n + 1):
        a = a1 + da * j / n
        out.append((cx + rx * math.cos(a) * cp - ry * math.sin(a) * sp, cy + rx * math.cos(a) * sp + ry * math.sin(a) * cp))
    return out


def ellipse_points(cx, cy, rx, ry, n=32):
    return [(cx + rx * math.cos(2 * math.pi * k / n), cy + ry * math.sin(2 * math.pi * k / n)) for k in range(n)]


def rect_points(x, y, w, h, rx, ry):
    if not rx and not ry:
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    rx = min(rx or ry, w / 2)
    ry = min(ry or rx, h / 2)
    pts = []
    for cx, cy, a0 in ((x + w - rx, y + ry, -90), (x + w - rx, y + h - ry, 0), (x + rx, y + h - ry, 90), (x + rx, y + ry, 180)):
        for k in range(7):
            a = math.radians(a0 + 15 * k)
            pts.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
    return pts


class Shape:
    def __init__(self, pts, closed, fill, stroke, width, tag_, circle=None):
        self.pts = pts
        self.closed = closed
        self.fill = fill
        self.stroke = stroke
        self.width = width
        self.tag = tag_
        self.circle = circle       # (cx, cy, r) when drawn as a circle or a round ellipse

    def bbox(self):
        xs = [p[0] for p in self.pts]
        ys = [p[1] for p in self.pts]
        return min(xs), min(ys), max(xs), max(ys)


class Run:
    """A stretch of text set in one style from one position: start point, direction, size, style flags."""

    def __init__(self, text, x, y, m, size, st, elem, xs=None):
        self.text = text
        self.x, self.y = ap(m, x, y)
        self.dir = (m[0], m[1])
        n = math.hypot(*self.dir) or 1.0
        self.dir = (self.dir[0] / n, self.dir[1] / n)
        self.size = size * scale(m)
        self.elem = elem
        self.fill = colour(st.get("fill")) or "#000000"
        fam = (st.get("font-family") or "").lower()
        w = (st.get("font-weight") or "normal").lower()
        self.bold = w in ("bold", "bolder") or (w.isdigit() and int(w) >= 600) or bool(re.search(r"bold|black|heavy", fam))
        self.italic = (st.get("font-style") or "").lower() in ("italic", "oblique") or bool(re.search(r"italic|oblique", fam))
        self.smallcaps = "small-caps" in (st.get("font-variant") or "").lower()
        self.anchor = st.get("text-anchor") or "start"
        self.xs = [ap(m, v, y) for v in xs] if xs else None


class Doc:
    def __init__(self, path):
        self.root = ET.parse(path).getroot()
        self.ids = {e.get("id"): e for e in self.root.iter() if e.get("id")}
        self.css = []
        for e in self.root.iter():
            if tag(e) == "style" and (e.text or "").strip():
                self.css += stylesheet(e.text)
        vb = [float(v) for v in NUM.findall(self.root.get("viewBox") or "")]
        self.box = vb if len(vb) == 4 else [0, 0, length(self.root.get("width")) or 1000, length(self.root.get("height")) or 1000]
        self.shapes, self.runs, self.images = [], [], []
        self.elem = 0
        self.walk(self.root, IDENTITY, {"fill": "#000000", "font-size": "16"})

    def style(self, e, parent):
        st = {k: v for k, v in parent.items() if k in INHERITED}
        for k in INHERITED + ("opacity", "display"):
            if e.get(k) is not None:
                st[k] = e.get(k)
        classes = (e.get("class") or "").split()
        for etag, cls, decl in self.css:
            if cls and all(c in classes for c in cls) and (etag is None or etag == tag(e)):
                st.update(decl)
        st.update(declarations(e.get("style")))
        return st

    def walk(self, e, m, st):
        t = tag(e)
        if t in ("defs", "symbol", "clipPath", "mask", "pattern", "style", "metadata", "title", "desc", "namedview",
                 "linearGradient", "radialGradient", "marker", "script", "font", "font-face"):
            return
        st = self.style(e, st)
        if st.get("display") == "none" or st.get("visibility") == "hidden":
            return
        try:
            if float(NUM.match((e.get("opacity") or declarations(e.get("style")).get("opacity") or "1").strip()).group(0)) == 0:
                return            # drawn fully transparent: nothing prints
        except (AttributeError, ValueError):
            pass
        m = mul(m, transform(e.get("transform")))
        if t in ("svg", "g", "a", "switch"):
            if t == "svg" and e is not self.root:
                m = mul(m, (1, 0, 0, 1, length(e.get("x")) or 0, length(e.get("y")) or 0))
            for c in e:
                self.walk(c, m, st)
            return
        if t == "use":
            href = next((v for k, v in e.attrib.items() if k.endswith("href")), "").lstrip("#")
            ref = self.ids.get(href)
            if ref is None:
                return
            m2 = mul(m, (1, 0, 0, 1, length(e.get("x")) or 0, length(e.get("y")) or 0))
            if tag(ref) == "symbol":
                vb = [float(v) for v in NUM.findall(ref.get("viewBox") or "")]
                w, h = length(e.get("width")), length(e.get("height"))
                if len(vb) == 4 and w and h:
                    s = min(w / vb[2], h / vb[3])
                    m2 = mul(m2, (s, 0, 0, s, (w - vb[2] * s) / 2 - vb[0] * s, (h - vb[3] * s) / 2 - vb[1] * s))
                for c in ref:
                    self.walk(c, m2, self.style(ref, st))
            elif tag(ref) == "image":
                self.walk(ref, m2, st)
            else:
                self.walk(ref, m2, st)
            return
        if t == "image":
            x, y = length(e.get("x")) or 0, length(e.get("y")) or 0
            w, h = length(e.get("width")) or 0, length(e.get("height")) or 0
            self.images.append([ap(m, *p) for p in ((x, y), (x + w, y), (x + w, y + h), (x, y + h))])
            return
        if t == "text":
            self.elem += 1
            self.text(e, m, st, {"x": 0.0, "y": 0.0}, self.elem)
            return
        fill = colour(st.get("fill", "#000000"))
        if fill == "pattern":
            # an art window painted with an image pattern
            for pts, closed in self.geometry(e):
                self.images.append([ap(m, *p) for p in pts])
            return
        stroke = colour(st.get("stroke")) or "none"
        sw = (length(st.get("stroke-width")) or 1.0) * scale(m)
        if (st.get("opacity") or "1").strip() in ("0", "0.0"):
            return
        for pts, closed in self.geometry(e):
            circ = None
            if t == "circle" or (t == "ellipse" and abs(float(e.get("rx", 0) or 0) - float(e.get("ry", 0) or 0)) < 1e-6):
                r = length(e.get("r")) if t == "circle" else length(e.get("rx"))
                c = ap(m, length(e.get("cx")) or 0, length(e.get("cy")) or 0)
                circ = (c[0], c[1], (r or 0) * scale(m))
            self.shapes.append(Shape([ap(m, *p) for p in pts], closed, fill if closed else "none", stroke, sw, t, circ))

    def geometry(self, e):
        t = tag(e)
        g = lambda k: length(e.get(k)) or 0.0
        if t == "rect":
            return [(rect_points(g("x"), g("y"), g("width"), g("height"), length(e.get("rx")), length(e.get("ry"))), True)]
        if t == "circle":
            return [(ellipse_points(g("cx"), g("cy"), g("r"), g("r")), True)]
        if t == "ellipse":
            return [(ellipse_points(g("cx"), g("cy"), g("rx"), g("ry")), True)]
        if t == "line":
            return [([(g("x1"), g("y1")), (g("x2"), g("y2"))], False)]
        if t in ("polygon", "polyline"):
            v = [float(x) for x in NUM.findall(e.get("points") or "")]
            return [(list(zip(v[0::2], v[1::2])), t == "polygon")]
        if t == "path":
            return flatten_path(e.get("d"))
        return []

    # ---- text --------------------------------------------------------------------------------------------
    def text(self, e, m, st, state, elem):
        st = self.style(e, st) if e is not None else st
        size = length(st.get("font-size"), 16.0) or 16.0
        if tag(e) == "tspan" and e.get("transform"):
            m = mul(m, transform(e.get("transform")))
        xs = [float(v) for v in NUM.findall(e.get("x") or "")]
        ys = [float(v) for v in NUM.findall(e.get("y") or "")]
        if xs:
            state["x"] = xs[0]
        if ys:
            state["y"] = ys[0]
        if e.get("dx"):
            state["x"] += length(e.get("dx"), size) or 0
        if e.get("dy"):
            state["y"] += length(e.get("dy"), size) or 0
        preserve = (e.get("{http://www.w3.org/XML/1998/namespace}space") == "preserve" or state.get("pre")
                    or "pre" in (st.get("white-space") or ""))
        state["pre"] = preserve
        self.emit(e.text, m, st, size, state, elem, xs if len(xs) > 1 else None)
        for c in e:
            if tag(c) in ("tspan", "a", "textPath"):
                self.text(c, m, st, state, elem)
            self.emit(c.tail, m, st, size, state, elem, None)

    def emit(self, s, m, st, size, state, elem, xs):
        if not s:
            return
        s = s.replace("\n", "" if not state.get("pre") else " ").replace("\t", " ")
        if not state.get("pre"):
            s = re.sub(r" +", " ", s)
        if not s:
            return
        run = Run(s, state["x"], state["y"], m, size, st, elem, xs[:len(s)] if xs else None)
        self.runs.append(run)
        state["x"] += advance(s, size)


# Helvetica advance widths (per 1000 em) for estimating where unpositioned text continues
_W = {" ": 278, "!": 278, '"': 355, "#": 556, "$": 556, "%": 889, "&": 667, "'": 191, "(": 333, ")": 333, "*": 389,
      "+": 584, ",": 278, "-": 333, ".": 278, "/": 278, ":": 278, ";": 278, "?": 556, "I": 278, "J": 500, "M": 833,
      "W": 944, "i": 222, "j": 222, "l": 222, "f": 278, "t": 278, "r": 333, "m": 833, "w": 722}


def advance(s, size):
    total = 0
    for ch in s:
        if ch in _W:
            total += _W[ch]
        elif ch.isdigit():
            total += 556
        elif ch.isupper():
            total += 667
        else:
            total += 540
    return total / 1000 * size * 1.1
