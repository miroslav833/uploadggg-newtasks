"""What a drawn shape is: badge kinds, inline icons, pips and rarity marks, judged from geometry only."""
import math


def area(p):
    return abs(sum(p[i][0] * p[i - 1][1] - p[i - 1][0] * p[i][1] for i in range(len(p)))) / 2


def hull(pts):
    ps = sorted(set((round(x, 6), round(y, 6)) for x, y in pts))
    if len(ps) < 3:
        return ps

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo, up = [], []
    for p in ps:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0:
            lo.pop()
        lo.append(p)
    for p in reversed(ps):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0:
            up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]


def dedupe(pts, eps):
    out = []
    for p in pts:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > eps:
            out.append(p)
    if len(out) > 2 and math.hypot(out[0][0] - out[-1][0], out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def inside(pt, poly):
    x, y = pt
    c = False
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[i - 1]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1:
            c = not c
    return c


class F:
    """Features of one closed outline."""

    def __init__(self, pts):
        b = (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))
        self.w, self.h = b[2] - b[0], b[3] - b[1]
        sz = max(self.w, self.h) or 1.0
        self.pts = dedupe(pts, sz * 0.01)
        self.n = len(self.pts)
        self.box = b
        a = area(self.pts)
        ha = area(hull(self.pts)) or 1e-9
        self.solidity = a / ha
        self.fill = a / ((self.w * self.h) or 1e-9)
        self.aspect = self.w / (self.h or 1e-9)
        cx = sum(p[0] for p in self.pts) / self.n
        cy = sum(p[1] for p in self.pts) / self.n
        rs = [math.hypot(p[0] - cx, p[1] - cy) for p in self.pts]
        mr = sum(rs) / len(rs)
        self.round_cv = (sum((r - mr) ** 2 for r in rs) / len(rs)) ** 0.5 / (mr or 1e-9)
        self.center = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
        # straight edges that run level or upright
        level = 0
        for i in range(self.n):
            (x1, y1), (x2, y2) = self.pts[i - 1], self.pts[i]
            L = math.hypot(x2 - x1, y2 - y1)
            if L > 0.25 * sz and (abs(y2 - y1) < 0.02 * L or abs(x2 - x1) < 0.02 * L):
                level += 1
        self.level_edges = level

    def notch_top(self):
        """Something cut into the middle of the top edge (a heart's dip)."""
        x0, y0, x1, y1 = self.box
        return not inside(((x0 + x1) / 2, y0 + 0.1 * self.h), self.pts)

    def flat_top(self):
        x0, y0, x1, y1 = self.box
        top = [p for p in self.pts if p[1] < y0 + 0.04 * self.h]
        return bool(top) and max(p[0] for p in top) - min(p[0] for p in top) > 0.6 * self.w

    def pointed_top(self):
        x0, y0, x1, y1 = self.box
        top = [p for p in self.pts if p[1] < y0 + 0.08 * self.h]
        return bool(top) and max(p[0] for p in top) - min(p[0] for p in top) < 0.25 * self.w

    def roundish(self):
        return self.round_cv < 0.06 and 0.85 < self.aspect < 1.18


def round_small(s, H):
    """A pip: a small filled round mark."""
    if not s.closed or s.fill in (None, "none") or s.size > 0.045 * H:
        return False
    return s.circle is not None or F(s.pts).roundish()


def greyish(col):
    if not col or not col.startswith("#") or len(col) < 7:
        return False
    r, g, b = int(col[1:3], 16), int(col[3:5], 16), int(col[5:7], 16)
    return max(r, g, b) - min(r, g, b) < 18 and 0x60 <= r <= 0xb8


def rarity(shapes, letters, H):
    for r in letters:
        t = r.text.strip().upper()
        if t in ("C", "U", "R", "M"):
            return {"C": "common", "U": "uncommon", "R": "rare", "M": "mythic"}[t]
    dots = [s for s in shapes if round_small(s, H) and s.size < 0.025 * H]
    marks = [s for s in shapes if s.closed and s.fill not in (None, "none") and s not in dots]
    if dots and not marks:
        return ["common", "uncommon", "rare", "mythic"][min(len(dots), 4) - 1]
    if marks:
        s = max(marks, key=lambda s: s.size)
        return colour_rarity(s.fill)
    return None


def colour_rarity(col):
    r, g, b = int(col[1:3], 16), int(col[3:5], 16), int(col[5:7], 16)
    if max(r, g, b) - min(r, g, b) < 40:
        return "common" if max(r, g, b) < 110 else "uncommon"
    if g > 0.6 * r:
        return "rare"
    return "mythic"


def stat_kind(s):
    """attack (a sword or a burst), health (a heart or a drop), defense (a shield)."""
    f = F(s.pts)
    if f.n >= 20 and f.solidity < 0.93 and not f.notch_top():
        return "attack"                  # burst
    if f.solidity < 0.85 and f.n <= 18:
        return "attack"                  # sword: crossguard notches
    if f.notch_top():
        return "health"                  # heart
    if f.flat_top():
        return "defense"                 # shield
    if f.pointed_top():
        return "health"                  # drop
    return None


def icon_groups(shapes, size):
    """Inline icons: nearby parts grouped, each group classified."""
    parts = sorted(shapes, key=lambda s: s.c)
    groups = []
    for s in parts:
        for g in groups:
            if any(math.hypot(s.c[0] - t.c[0], s.c[1] - t.c[1]) < 0.75 * max(s.size, t.size, size) for t in g):
                g.append(s)
                break
        else:
            groups.append([s])
    out = []
    for g in groups:
        k = icon_kind(g)
        if k:
            xs = [p[0] for s in g for p in s.pts]
            ys = [p[1] for s in g for p in s.pts]
            out.append({"kind": k, "c": ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2)})
    return out


def icon_kind(g):
    opened = [s for s in g if not s.closed and len(s.pts) >= 4]
    closed = [s for s in g if s.closed and len(s.pts) >= 3]
    if opened:
        return "exhaust"                 # a curved arrow
    if len(closed) >= 2:
        fs = [F(s.pts) for s in closed]
        if all(s.circle is not None or f.roundish() for s, f in zip(closed, fs)):
            return "coin"                # a ring: two circles, one in the other
        if all(f.fill > 0.85 for f in fs):
            return "card"                # two cards
        return None
    if not closed:
        return None
    s = closed[0]
    f = F(s.pts)
    if s.circle is not None or f.roundish() and f.n >= 7:
        return "coin"                    # a round coin or an eight-sided one
    if f.solidity < 0.8:
        return "damage" if f.n >= 15 else "heal"     # burst / cross
    if f.n == 4 and f.level_edges < 2:
        return "exhaust"                 # a card turned on its side
    if f.fill > 0.85 and f.aspect < 0.85:
        return "card"
    if f.notch_top():
        return "heal"                    # heart
    if f.pointed_top():
        return "damage"                  # drop
    return None
