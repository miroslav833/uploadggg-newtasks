"""python3 -m carddb IN_DIR OUT_DIR: one card database (JSON) per game folder of print sheets."""
import json
import os
import re
import sys
import traceback

from .cards import read_sheet


def title_of(folder):
    p = os.path.join(folder, "game.txt")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            if line.lower().startswith("game:"):
                return line.split(":", 1)[1].strip()
    return os.path.basename(folder)


def print_mode(folder):
    p = os.path.join(folder, "game.txt")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            if line.lower().startswith("print:"):
                v = line.split(":", 1)[1].lower()
                if "double" in v:
                    return "short" if "short" in v else "long"
    return None


def tidy(t):
    return re.sub(r" ([.,:;)])", r"\1", " ".join(t.split()))


def natural(name):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", name)]


def database(folder):
    pages = []
    for name in sorted((n for n in os.listdir(folder) if n.lower().endswith(".svg")), key=natural):
        try:
            pages.append(read_sheet(os.path.join(folder, name)))
        except Exception:
            traceback.print_exc()
            pages.append(([], [0, 0, 1, 1]))
    duplex = print_mode(folder)
    found = {}
    for k, (recs, box) in enumerate(pages):
        for r in recs:
            if r.get("face"):
                continue
            n = r["number"]
            if n not in found:
                found[n] = dict(r, copies=0, back=None)
            found[n]["copies"] += 1
        if duplex and k % 2 == 1:
            # the page before this one is its front; a face sits behind the front card at the mirrored place
            fronts = [r for r in pages[k - 1][0] if not r.get("face")]
            for f in [r for r in recs if r.get("face")]:
                x, y = f["_at"]
                x0, y0, w, h = box
                mx, my = (2 * x0 + w - x, y) if duplex == "long" else (x, 2 * y0 + h - y)
                if fronts:
                    front = min(fronts, key=lambda r: (r["_at"][0] - mx) ** 2 + (r["_at"][1] - my) ** 2)
                    face = {k2: f[k2] for k2 in ("name", "type", "stats", "text", "keywords")}
                    found[front["number"]]["back"] = face
    cards = []
    for n in sorted(found):
        c = {k2: v for k2, v in found[n].items() if not k2.startswith("_")}
        c["text"] = tidy(c["text"])
        if c.get("back"):
            c["back"]["text"] = tidy(c["back"]["text"])
        cards.append(c)
    return {"game": title_of(folder), "cards": cards}


def main(argv):
    src, dst = argv[1], argv[2]
    os.makedirs(dst, exist_ok=True)
    for game in sorted(os.listdir(src)):
        folder = os.path.join(src, game)
        if not os.path.isdir(folder):
            continue
        db = database(folder)
        with open(os.path.join(dst, game + ".json"), "w", encoding="utf-8") as f:
            json.dump(db, f, indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main(sys.argv)
