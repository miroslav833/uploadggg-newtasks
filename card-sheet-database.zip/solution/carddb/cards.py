"""From a flattened sheet to card records: find each card, turn it upright, read its fields."""
import math
import re

from .svgdoc import Doc
from . import kinds

NUMBER = [re.compile(r"^(\d+)\s*/\s*\d+$"), re.compile(r"^#\s*(\d+)$"), re.compile(r"^No\.\s*(\d+)$"), re.compile(r"^(\d+)$")]


def area(p):
    return abs(sum(p[i][0] * p[i - 1][1] - p[i - 1][0] * p[i][1] for i in range(len(p)))) / 2


def bbox(p):
    xs = [q[0] for q in p]
    ys = [q[1] for q in p]
    return min(xs), min(ys), max(xs), max(ys)


def inside(pt, poly):
    x, y = pt
    c = False
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[i - 1]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1:
            c = not c
    return c


def in_box(pt, b, pad=0.0):
    return b[0] - pad <= pt[0] <= b[2] + pad and b[1] - pad <= pt[1] <= b[3] + pad


class Item:
    """A card's shapes and runs in upright card coordinates (u right, v down, origin at the frame's top left)."""

    def __init__(self, frame_box, direction):
        self.fb = frame_box
        self.dir = direction
        x0, y0, x1, y1 = frame_box
        if direction == "right":
            self.w, self.h = x1 - x0, y1 - y0
        elif direction == "down":
            self.w, self.h = y1 - y0, x1 - x0
        elif direction == "up":
            self.w, self.h = y1 - y0, x1 - x0
        else:
            self.w, self.h = x1 - x0, y1 - y0

    def L(self, p):
        x, y = p
        x0, y0, x1, y1 = self.fb
        if self.dir == "right":
            return x - x0, y - y0
        if self.dir == "down":
            return y - y0, x1 - x
        if self.dir == "up":
            return y1 - y, x - x0
        return x1 - x, y1 - y


class LRun:
    def __init__(self, r, item):
        self.r = r
        self.text = r.text
        self.u, self.v = item.L((r.x, r.y))
        self.size = r.size
        self.bold = r.bold
        self.italic = r.italic
        self.sc = r.smallcaps
        self.fill = r.fill
        self.anchor = r.anchor
        self.elem = r.elem
        self.us = [item.L(p)[0] for p in r.xs] if r.xs else None


class LShape:
    def __init__(self, s, item):
        self.s = s
        self.pts = [item.L(p) for p in s.pts]
        self.closed = s.closed
        self.fill = s.fill
        self.stroke = s.stroke
        self.width = s.width
        self.circle = s.circle
        b = bbox(self.pts)
        self.box = b
        self.c = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
        self.size = max(b[2] - b[0], b[3] - b[1])


def direction_of(runs):
    votes = {"right": 0, "down": 0, "up": 0, "left": 0}
    for r in runs:
        if not r.text.strip():
            continue
        dx, dy = r.dir
        if abs(dx) >= abs(dy):
            votes["right" if dx > 0 else "left"] += len(r.text)
        else:
            votes["down" if dy > 0 else "up"] += len(r.text)
    return max(votes, key=votes.get)


def frames(doc):
    """Card frames: filled, rectangular, card-sized shapes; of nested ones (bleed around frame) the inner."""
    page = doc.box[2] * doc.box[3]
    cands = []
    for s in doc.shapes:
        if not s.closed or s.fill in (None, "none") or len(s.pts) < 4:
            continue
        b = s.bbox()
        ba = (b[2] - b[0]) * (b[3] - b[1])
        if not 0.02 * page < ba < 0.2 * page:
            continue
        if area(s.pts) < 0.95 * ba:
            continue
        cands.append(b)
    keep = []
    for b in cands:
        if any(c is not b and c[0] >= b[0] - 1e-6 and c[1] >= b[1] - 1e-6 and c[2] <= b[2] + 1e-6 and c[3] <= b[3] + 1e-6
               and (c[2] - c[0]) * (c[3] - c[1]) < 0.97 * (b[2] - b[0]) * (b[3] - b[1]) for c in cands):
            continue
        if any(abs(b[0] - k[0]) < 1e-3 and abs(b[1] - k[1]) < 1e-3 and abs(b[2] - k[2]) < 1e-3 for k in keep):
            continue
        keep.append(b)
    return keep


def read_sheet(path):
    doc = Doc(path)
    out = []
    for fb in frames(doc):
        runs = [r for r in doc.runs if in_box((r.x, r.y), fb)]
        if not runs:
            continue
        item = Item(fb, direction_of(runs))
        shapes = []
        for s in doc.shapes:
            b = s.bbox()
            c = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            if in_box(c, fb) and (b[2] - b[0]) * (b[3] - b[1]) < 0.5 * (fb[2] - fb[0]) * (fb[3] - fb[1]):
                shapes.append(LShape(s, item))
        imgs = []
        for im in doc.images:
            b = bbox(im)
            c = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
            if in_box(c, fb):
                lb = bbox([item.L(p) for p in im])
                imgs.append(lb)
        rec = read_card(item, [LRun(r, item) for r in runs], shapes, imgs)
        if rec is not None:
            rec["_at"] = ((fb[0] + fb[2]) / 2, (fb[1] + fb[3]) / 2)
            out.append(rec)
    return out, doc.box


# ---- one card --------------------------------------------------------------------------------------------------
def holder(run, shapes):
    """The closed shape a numeral or letter sits in, if any."""
    w = sum(1 for _ in run.text.strip()) * run.size * 0.55
    if run.anchor == "middle":
        c = (run.u, run.v - run.size * 0.35)
    else:
        c = (run.u + w / 2, run.v - run.size * 0.35)
    best = None
    for s in shapes:
        if s.closed and s.fill not in ("none", None) and s.size < 3.5 * run.size and inside(c, s.pts):
            if best is None or s.size < best.size:
                best = s
    return best


def lines_of(runs):
    """Runs grouped into lines by baseline, each line ordered along the text."""
    out = []
    for r in sorted(runs, key=lambda r: (round(r.v, 3), r.u)):
        size = max(r.size, 1e-9)
        for ln in out:
            ref = ln[0]
            if abs(ref.v - r.v) < 0.3 * min(ref.size, size) or (not r.text.strip() and abs(ref.v - r.v) < 0.3 * ref.size):
                ln.append(r)
                break
        else:
            out.append([r])
    for ln in out:
        ln.sort(key=lambda r: (r.u, r.elem))
    out.sort(key=lambda ln: min(r.v for r in ln if r.text.strip()) if any(r.text.strip() for r in ln) else ln[0].v)
    return out


def join(ln):
    """A line's text. Runs are words apart unless the later one is the smaller capitals of a word begun in the
    earlier one; smaller capitals stand for lower-case letters."""
    words = []
    prev = None
    for r in ln:
        t = r.text
        if not t.strip():
            if words:
                words.append(" ")
            prev = None
            continue
        if prev is not None and sc_continues(prev, r):
            words.append(t.lower() if t.isupper() else t)
        else:
            if words and words[-1] != " " and not t.startswith(" "):
                words.append(" ")
            words.append(t)
        prev = r
    return re.sub(r" +", " ", "".join(words)).strip()


def sc_continues(a, b):
    """b is the reduced capitals continuing a word that a began (fake small capitals)."""
    if a.text.endswith(" ") or b.text.startswith(" "):
        return False
    letters = [c for c in b.text if c.isalpha()]
    if not letters or not all(c.isupper() for c in letters):
        return False
    return 0.6 * a.size < b.size < 0.9 * a.size and a.text.rstrip()[-1:].isalpha()


def is_small_caps_word(run_list):
    return any(r.sc for r in run_list)


def read_card(item, runs, shapes, imgs):
    W, H = item.w, item.h
    landscape = W > H
    solid = [r for r in runs if r.text.strip()]
    if not solid:
        return None
    # numerals and letters inside badges
    held = {}
    for r in solid:
        s = holder(r, shapes)
        if s is not None and len(r.text.strip()) <= 2:
            held[id(r)] = s
    free = [r for r in solid if id(r) not in held]
    # collector number
    number = None
    for r in free:
        t = r.text.strip()
        if r.v > 0.85 * H:
            for rx in NUMBER:
                m = rx.match(t)
                if m:
                    number = int(m.group(1))
    art = max(imgs, key=lambda b: (b[2] - b[0]) * (b[3] - b[1])) if imgs else None
    top_limit = 0.11 * H if not landscape else 0.15 * H
    # name: the biggest free text in the top band
    top = [r for r in free if r.v < top_limit]
    name = ""
    if top:
        big = max(r.size for r in top)
        name = join(sorted([r for r in top if r.size > 0.8 * big], key=lambda r: r.u))
    # cost: a badge numeral in the top band, or pips
    cost = None
    for r in solid:
        if id(r) in held and r.v < top_limit:
            t = r.text.strip()
            cost = int(t) if t.isdigit() else t
    if cost is None:
        pips = [s for s in shapes if s.c[1] < top_limit and kinds.round_small(s, H)]
        if pips:
            cost = len(pips)
    # type line: the first line after the art
    if art is None:
        return None
    if not landscape:
        cand = [r for r in free if art[3] < r.v < art[3] + 0.12 * H]
    else:
        cand = [r for r in free if r.u > art[2] and top_limit < r.v < 0.45 * H]
    tls = lines_of(cand)
    if not tls:
        return None
    tl = tls[0]
    type_line = join(tl)
    tv = min(r.v for r in tl)
    tsize = max(r.size for r in tl)
    # rarity: at the right end of the type line
    rar_shapes = [s for s in shapes if abs(s.c[1] - (tv - tsize * 0.35)) < tsize * 1.2 and s.c[0] > 0.7 * W]
    rar_text = [r for r in solid if id(r) in held and abs(r.v - tv) < tsize * 1.2 and r.u > 0.7 * W]
    rarity = kinds.rarity(rar_shapes, rar_text, H)
    # text box
    bottom = 0.855 * H if not landscape else 0.86 * H
    if not landscape:
        box_runs = [r for r in runs if r.v > tv + 0.5 * tsize and r.v < bottom]
        box_left = 0
    else:
        box_runs = [r for r in runs if r.u > art[2] and r.v > tv + 0.5 * tsize and r.v < bottom]
        box_left = art[2]
    box_runs = [r for r in box_runs if id(r) not in held]
    text, keys = rules_text(item, box_runs, shapes, tv + 0.5 * tsize, bottom, box_left)
    # stats
    stats = {}
    for r in solid:
        if id(r) in held and r.v > 0.8 * H and r.text.strip().isdigit():
            k = kinds.stat_kind(held[id(r)])
            if k:
                stats[k] = int(r.text.strip())
    if number is None:
        # the other face of a double-faced card: no cost, number or rarity of its own
        if not name:
            return None
        return {"face": True, "name": name, "type": type_line, "stats": dict(sorted(stats.items())), "text": text,
                "keywords": keys}
    return {"number": number, "name": name, "type": type_line, "cost": cost, "stats": dict(sorted(stats.items())),
            "text": text, "keywords": keys, "rarity": rarity}


def rules_text(item, runs, shapes, vtop, vbottom, left):
    W, H = item.w, item.h
    lines = lines_of(runs)
    if not lines:
        return "", []
    size = max(r.size for ln in lines for r in ln if r.text.strip()) if any(r.text.strip() for ln in lines for r in ln) else 1
    # dividers and icons in the box
    divider = None
    for s in shapes:
        if not s.closed and len(s.pts) == 2 and s.c[1] > vtop - size and s.c[1] < vbottom and s.c[0] > left:
            (a, b) = s.pts
            if abs(a[1] - b[1]) < 0.05 * size and abs(a[0] - b[0]) > 0.25 * W:
                divider = s.c[1] if divider is None else min(divider, s.c[1])
    cand = [s for s in shapes if vtop - size * 1.2 < s.c[1] < vbottom and s.c[0] > left and s.size < 2.2 * size
            and not (not s.closed and len(s.pts) == 2)]
    icons = kinds.icon_groups(cand, size)
    # words with their style, line by line; icons in their places
    tokens = []
    flavour = False
    for ln in lines:
        solid = [r for r in ln if r.text.strip()]
        if not solid:
            continue
        lv = min(r.v for r in solid)
        lsize = max(r.size for r in solid)
        if divider is not None and lv > divider:
            break
        first = join(ln).lstrip()
        if first[:1] in ("“", '"'):
            break
        mine = sorted([g for g in icons if lv - lsize * 1.15 < g["c"][1] < lv + 0.3 * lsize], key=lambda g: g["c"][0])
        new = line_tokens(ln, mine)
        # a word broken at the end of the line with a hyphen carries on at the start of the next
        if tokens and new and tokens[-1]["kind"] == "word" and tokens[-1]["text"].endswith("-") and new[0]["kind"] == "word" \
                and tokens[-1]["text"][-2:-1].isalpha():
            tokens[-1] = dict(tokens[-1], text=tokens[-1]["text"][:-1] + new[0]["text"])
            new = new[1:]
        tokens += new
    # drop grey (flavour) and parenthesised reminder text
    out = []
    depth = 0
    for t in tokens:
        if t.get("grey"):
            continue
        w = t["text"]
        if t["kind"] == "word" and w.startswith("("):
            depth = 1
        if depth:
            if t["kind"] == "word" and w.endswith(")") or t["kind"] == "word" and w.endswith(").") :
                depth = 0
            continue
        out.append(t)
    text = " ".join(t["text"] for t in out)
    keys = []
    prev = False
    for t in out:
        if t["kind"] == "word" and t["key"]:
            if prev and not keys[-1].endswith((".", ",", ";", ":")):
                keys[-1] += " " + t["text"]
            else:
                keys.append(t["text"])
            prev = True
        else:
            prev = False
    return text, [k.strip(" .,;:") for k in keys]


def line_tokens(ln, icons):
    """Tokens of one line: words (with keyword and grey flags) and icon tokens in order."""
    # tools that leave the icon drawn over a run of spaces in the text
    gaps = []
    for r in ln:
        for m in re.finditer(r" {3,}", r.text):
            gaps.append((r, m.start(), m.end()))
    seq = []
    if icons and len(gaps) == len(icons):
        k = 0
        for r in ln:
            parts = re.split(r"( {3,})", r.text)
            for p in parts:
                if re.fullmatch(r" {3,}", p):
                    seq.append(("icon", icons[k]["kind"]))
                    k += 1
                elif p:
                    seq.append(("run", r, p))
    else:
        items = [("run", r, r.text) for r in ln] + [("icon", g["kind"], g["c"][0]) for g in icons]
        def pos(it):
            return it[1].u if it[0] == "run" else it[2]
        items.sort(key=pos)
        seq = [(it[0], it[1]) if it[0] == "icon" else it for it in items]
    tokens = []
    prev_run = None
    for it in seq:
        if it[0] == "icon":
            tokens.append({"kind": "icon", "text": "{%s}" % it[1], "key": False})
            prev_run = None
            continue
        _, r, txt = it
        key = r.bold or r.sc
        grey = kinds.greyish(r.fill)
        if prev_run is not None and sc_continues(prev_run, r) and tokens and tokens[-1]["kind"] == "word":
            tokens[-1]["text"] += txt.lower()
            tokens[-1]["key"] = True
            prev_run = r
            continue
        for i, w in enumerate(txt.split(" ")):
            if not w:
                continue
            tokens.append({"kind": "word", "text": w, "key": key, "grey": grey})
        prev_run = r if not txt.endswith(" ") else None
    # a word in reduced capitals right after a capital is small capitals: a keyword
    return tokens
