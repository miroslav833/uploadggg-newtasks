#!/bin/bash
# Reference: a sheet reader that flattens each tool's SVG, finds the cards, turns them upright and reads every field.
set -e
rm -rf /app/carddb
cp -r /solution/carddb /app/carddb
cd /app
rm -rf /tmp/carddb_approved
python3 -m carddb /app/studio/approved /tmp/carddb_approved
for d in /app/studio/approved/*/; do
    g=$(basename "$d")
    if python3 -c "import json,sys; a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2])); sys.exit(a != b)" "$d/cards.json" "/tmp/carddb_approved/$g.json"; then
        echo "approved $g: same"
    else
        echo "approved $g: different"
    fi
done
