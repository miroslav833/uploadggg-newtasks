We bring tabletop card games to our digital table. Publishers send their print-ready card sheets as SVG, exported from whatever layout tool their designer uses, and at the moment someone here types every card into our database by hand.

Please write a program that builds the database from the sheets. It should be a Python package in `/app/carddb`, run from `/app` as `python3 -m carddb IN_DIR OUT_DIR`. `IN_DIR` has one folder per game, and for each folder the program writes `OUT_DIR/<folder name>.json`. The guide in `/app/studio/import-guide.md` explains what a delivery contains, how a card is read and what goes in the database.

Games we have already entered, each with the database we approved, are in `/app/studio/approved/`. Their publishers use four of the eight tools we get files from.

We will run the program on 48 new games, six from each tool. It gets only the game folders, Python 3.13 with its standard library, and no network. A game counts when its database is exactly ours (spacing inside text aside), and at least 43 of the 48 must count.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
