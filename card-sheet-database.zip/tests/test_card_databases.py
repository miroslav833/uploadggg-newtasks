"""The carddb package, run once over the 48 sealed games."""
import pytest

import harness


@pytest.fixture(scope="module")
def result():
    return harness.grade()


def test_program_exits_cleanly(result):
    assert result["clean"], "python3 -m carddb did not exit 0 within %d s" % harness.SECONDS


def test_databases_match(result):
    assert result["total"] == 48
    wrong = sorted(g for g, ok in result["games"].items() if not ok)
    assert result["matched"] >= harness.REQUIRED, "%d of %d game databases match (need %d); wrong: %s" % (
        result["matched"], result["total"], harness.REQUIRED, ", ".join(wrong))
