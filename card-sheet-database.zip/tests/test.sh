#!/bin/bash
# Runs /app/carddb over the sealed games as the cardrun account; the reward is 1 only if both tests pass.
OUT=/logs/verifier
mkdir -p "$OUT"
KEEP_MODE=$(stat -c %a "$OUT")
chown 0:0 "$OUT" && chmod 700 "$OUT"
if [ "$(stat -c %u:%a "$OUT")" != "0:700" ]; then
    echo 0 > "$OUT/reward.txt"
    exit 0
fi
chmod 755 /tmp /var/tmp
chmod 1777 /dev/shm
REPORT_DIR=/run/cardcheck
rm -rf "$REPORT_DIR" && mkdir -p "$REPORT_DIR" && chmod 700 "$REPORT_DIR"
cd /tests
python3 -m pytest -q -p no:cacheprovider --ctrf "$REPORT_DIR/ctrf.json" test_card_databases.py
PYTEST_STATUS=$?
python3 /tests/harness.py sweep
find "$OUT" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
REWARD=0
if [ "$PYTEST_STATUS" -eq 0 ] && python3 /tests/harness.py report "$REPORT_DIR/ctrf.json"; then
    REWARD=1
fi
cp "$REPORT_DIR/ctrf.json" "$OUT/ctrf.json" 2>/dev/null
echo "$REWARD" > "$OUT/reward.txt"
chmod "$KEEP_MODE" "$OUT"
exit 0
