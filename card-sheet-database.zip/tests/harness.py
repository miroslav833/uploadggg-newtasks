"""Grade a carddb package: run it on the sealed games as the cardrun account, then compare its databases.

The package runs from /app (owned by root, read-only to it) on a copy of the games under /opt/cardcheck, writing
into an empty folder there that only cardrun may write. The approved databases stay in /tests, which cardrun
cannot read. Anything the package leaves running is frozen and killed before its output is opened.
"""
import json
import os
import pwd
import re
import resource
import shutil
import signal
import subprocess
import sys
import time

TESTS = os.path.dirname(os.path.abspath(__file__))
GAMES = os.path.join(TESTS, "games")
EXPECTED = os.path.join(TESTS, "expected")
BASE = "/opt/cardcheck"
USER = "cardrun"
SECONDS = 300
REQUIRED = 43
RARITIES = ("common", "uncommon", "rare", "mythic")


class Sandbox:
    def __init__(self):
        acct = pwd.getpwnam(USER)
        self.uid, self.gid = acct.pw_uid, acct.pw_gid
        self.games = os.path.join(BASE, "games")
        self.out = os.path.join(BASE, "out")
        self.home = os.path.join(BASE, "home")

    def prepare(self):
        shutil.rmtree(BASE, ignore_errors=True)
        os.makedirs(BASE)
        os.chmod(BASE, 0o755)
        shutil.copytree(GAMES, self.games)
        os.makedirs(self.home)
        for top, mode in ((self.games, 0o755), (self.home, 0o555)):
            for here, dirs, files in os.walk(top):
                os.chown(here, 0, 0)
                os.chmod(here, mode)
                for f in files:
                    os.chown(os.path.join(here, f), 0, 0)
                    os.chmod(os.path.join(here, f), 0o644)
        os.makedirs(self.out)
        os.chown(self.out, self.uid, self.gid)
        os.chmod(self.out, 0o700)

    def _child(self):
        os.setsid()
        os.setgroups([])
        os.setgid(self.gid)
        os.setuid(self.uid)
        resource.setrlimit(resource.RLIMIT_NPROC, (512, 512))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    def run(self):
        """True when the package exited 0 inside the time limit."""
        self.prepare()
        if not os.path.isfile("/app/carddb/__main__.py"):
            return False
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": self.home, "TMPDIR": "/tmp", "LANG": "C.UTF-8",
               "PYTHONDONTWRITEBYTECODE": "1"}
        try:
            done = subprocess.run([sys.executable, "-m", "carddb", self.games, self.out], cwd="/app", env=env,
                                  preexec_fn=self._child, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL, timeout=SECONDS)
            return done.returncode == 0
        except subprocess.TimeoutExpired:
            return False
        finally:
            sweep(self.uid)


def sweep(uid=None):
    """Freeze then kill every process of the account, until three passes in a row find none."""
    if uid is None:
        uid = pwd.getpwnam(USER).pw_uid
    quiet = 0
    while quiet < 3:
        mine = []
        for pid in filter(str.isdigit, os.listdir("/proc")):
            try:
                with open("/proc/%s/status" % pid) as fh:
                    uids = next(l for l in fh if l.startswith("Uid:")).split()[1:3]
            except (OSError, StopIteration):
                continue
            if str(uid) in uids:
                mine.append(int(pid))
        for sig in (signal.SIGSTOP, signal.SIGKILL):
            for pid in mine:
                try:
                    os.kill(pid, sig)
                except OSError:
                    pass
        quiet = 0 if mine else quiet + 1
        time.sleep(0.05)


def tidy(t):
    t = re.sub(r" ([.,:;)])", r"\1", " ".join(t.split()))
    return t.replace("( ", "(")


def face(v, front):
    """A record (or back face) in comparable form, or None when it is malformed."""
    keys = {"number", "name", "type", "cost", "stats", "text", "keywords", "rarity", "copies", "back"} if front else \
        {"name", "type", "stats", "text", "keywords"}
    if not isinstance(v, dict) or set(v) != keys:
        return None
    if not all(isinstance(v[k], str) for k in ("name", "type", "text")):
        return None
    st = v["stats"]
    if not isinstance(st, dict) or not all(k in ("attack", "health", "defense") and type(x) is int for k, x in st.items()):
        return None
    kw = v["keywords"]
    if not isinstance(kw, list) or not all(isinstance(k, str) for k in kw):
        return None
    out = [tidy(v["name"]), tidy(v["type"]), tuple(sorted(st.items())), tidy(v["text"]), tuple(k.strip() for k in kw)]
    if front:
        if type(v["number"]) is not int or type(v["copies"]) is not int or v["rarity"] not in RARITIES:
            return None
        c = v["cost"]
        if not (c is None or c == "X" or type(c) is int):
            return None
        back = None
        if v["back"] is not None:
            back = face(v["back"], False)
            if back is None:
                return None
        out = [v["number"]] + out + [c, v["rarity"], v["copies"], back]
    return tuple(out)


def database(path):
    if not os.path.isfile(path) or os.path.islink(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            db = json.load(fh)
    except (OSError, ValueError, RecursionError):
        return None
    if not isinstance(db, dict) or set(db) != {"game", "cards"} or not isinstance(db["game"], str) \
            or not isinstance(db["cards"], list):
        return None
    cards = [face(c, True) for c in db["cards"]]
    if any(c is None for c in cards):
        return None
    return tidy(db["game"]), cards


def grade():
    box = Sandbox()
    clean = box.run()
    games = {}
    for name in sorted(os.listdir(EXPECTED)):
        want = database(os.path.join(EXPECTED, name))
        got = database(os.path.join(box.out, name))
        games[name[:-5]] = got is not None and got == want
    return {"clean": clean, "games": games, "matched": sum(games.values()), "total": len(games)}


def report_is_ours(path):
    """The CTRF report is a regular file owned by root naming exactly the two tests, both passed."""
    st = os.lstat(path)
    if st.st_uid != 0 or not os.path.isfile(path) or os.path.islink(path):
        return False
    with open(path) as fh:
        tests = json.load(fh)["results"]["tests"]
    names = sorted(t["name"].rsplit("::", 1)[-1] for t in tests)
    return names == ["test_databases_match", "test_program_exits_cleanly"] and all(t["status"] == "passed" for t in tests)


if __name__ == "__main__":
    if sys.argv[1:2] == ["sweep"]:
        sweep()
    elif sys.argv[1:2] == ["report"]:
        sys.exit(0 if report_is_ours(sys.argv[2]) else 1)
