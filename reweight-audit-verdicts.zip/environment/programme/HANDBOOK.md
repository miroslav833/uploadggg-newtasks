# Listing-policy review programme: handbook

## What the programme is

Every new listing on the marketplace is scored by the listing-policy classifier release in
service. The release register gives each release's threshold and its band cut points. A listing
whose score is at or over the threshold is *flagged* and queued for review; a listing under the
threshold is *unflagged* and goes live. The programme measures each release through campaigns:
a measurement window of 28 days over which every scored listing is kept in the scoring ledger and
every review decision in the review ledger.

## Score bands

Each release's register row lists four cut points, ascending. They divide the score range into
five bands: band 1 runs from 0 up to the first cut, band 2 from the first cut up to the second,
and so on to band 5, from the fourth cut to 1. A score equal to a cut point belongs to the band
above it. The third cut point is the release's threshold, so bands 4 and 5 are the flag bands and
bands 1 to 3 the unflagged bands.

## Review queues

Reviewers work two lanes.

- **flag**: every flagged listing is reviewed.
- **audit**: unflagged listings reach reviewers only through the audit draw. The review lead sets
  the draw rate per band for each campaign, and where the policy team names listing categories of
  concern, per category as well. The rates live in the queue configuration, which is not part of
  the campaign export. The scoring ledger lists every listing scored in the window; the review
  ledger lists every listing that was drawn or flagged.

Within a lane the queue is worked in order of arrival by whichever reviewers are on shift that
day. The review console shows the reviewer the listing, the policy text and the release's score
band for the listing. A decision is `violation` or `clean`.

## Quality control

A drawn share of every reviewer's decisions is sent, blind, to a second reviewer; the review lead
then adjudicates the listing with both decisions in hand. The share is part of the campaign's
queue configuration; some campaigns set one share for every decision, others set the share for
`violation` decisions and the share for `clean` decisions separately. The lead's adjudication is
the programme's final word on that listing, and a listing the lead finds clean is reinstated. In
the ledger the two reviewers' decisions carry the stages `first` and `second`, and the lead's
carries the stage `lead` under the reviewer name `lead`. A listing not drawn for quality control
has a `first` decision only.

## Appeals

In campaigns run after the appeals programme opened, a seller whose listing was removed on a
`violation` decision, and not reinstated, may appeal. Whether to appeal is the seller's choice. A
lead decides every appeal, and that decision is final; in the ledger it carries the stage `appeal`
under the reviewer name `lead`, in the same review as the decision appealed. The two sample
campaigns ran before the programme opened and hold no appeals.

Measurement campaigns are sometimes closed out by adjudicating every listing in the window; the
figures those close-outs produced are published with the campaign.

## The campaign folder

`campaign.txt`: the campaign sheet, one `key: value` per line.

```
campaign: harrow
window_days: 28
releases: r1
reviewers: 8
listings: 70012
```

`releases.csv`: the release register for the window. `band_cuts` holds the four cut points
joined by `;`.

```
release,threshold,band_cuts
r1,0.63,0.16;0.38;0.63;0.84
```

`scoring.csv.gz` (gzip-compressed CSV): one row per listing scored in the window. `day` is the
campaign day, 1 to 28; `release` is the release that scored it; `score` is its score to three
decimals.

```
listing,day,category,release,score
k3x9q2,17,apparel,r1,0.173
```

`reviews.csv.gz` (gzip-compressed CSV): one row per decision. Rows that share a `review` are the
decisions on one listing; `lane` is `flag` or `audit`; `stage` is `first`, `second`, `lead` or
`appeal`.

```
review,listing,lane,stage,reviewer,decision
a00vb81,wrx7s4,audit,first,rv04,clean
a00vb81,wrx7s4,audit,second,rv02,clean
a00vb81,wrx7s4,audit,lead,lead,clean
b3kq0zt,m2f8xp,flag,first,rv07,violation
b3kq0zt,m2f8xp,flag,appeal,lead,clean
```

`figures.csv` (sample campaigns only): the figures the campaign's close-out adjudication gave.

```
release,precision,recall
r1,0.6512,0.7610
```

Listing codes, review codes and reviewer names are the export's own identifiers and carry no
meaning. Every campaign has five bands per release, the six listing categories `apparel`,
`electronics`, `home`, `media`, `supplements` and `toys`, and the stages above; a campaign
has one or two releases and between seven and eleven reviewers.

## The measurement program

The programme runs one program over a campaign folder:

```
python3 /app/measure/release_figures.py CAMPAIGN_DIR OUT_CSV
```

It writes a CSV with a header row and one row per release in the register, `release,precision,recall`,
with the figures as decimals.
