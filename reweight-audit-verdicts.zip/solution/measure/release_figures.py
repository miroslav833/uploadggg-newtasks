#!/usr/bin/env python3
"""Precision and recall of each classifier release over a review-programme campaign.

    python3 release_figures.py CAMPAIGN_DIR OUT_CSV

Reads the campaign folder only. Every reviewer's sensitivity and specificity per band shown and every
stratum's prevalence are fitted together by a latent-class EM over the adjudicated listings and the
single-reviewed decisions; audited strata are weighted by their draw rate recovered from the ledgers.
"""
import csv
import gzip
import math
import os
import sys
from collections import defaultdict


def read_csv(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def logit(p):
    p = min(max(p, 1e-6), 1 - 1e-6)
    return math.log(p / (1 - p))


def expit(x):
    return 1 / (1 + math.exp(-x))


def load(campaign):
    releases = {}
    for r in read_csv(os.path.join(campaign, "releases.csv")):
        releases[r["release"]] = dict(thr=float(r["threshold"]),
                                      cuts=[float(c) for c in r["band_cuts"].split(";")])
    listings = {}
    for r in read_csv(os.path.join(campaign, "scoring.csv.gz")):
        rel = releases[r["release"]]
        s = float(r["score"])
        band = 1 + sum(1 for c in rel["cuts"] if s >= c)
        listings[r["listing"]] = dict(release=r["release"], day=int(r["day"]), score=s, band=band,
                                      flagged=s >= rel["thr"], week=(int(r["day"]) - 1) // 7,
                                      category=r["category"])
    reviews = defaultdict(dict)
    for r in read_csv(os.path.join(campaign, "reviews.csv.gz")):
        reviews[r["review"]][r["stage"]] = (r["listing"], r["lane"], r["reviewer"], r["decision"])
    return releases, listings, reviews


def confusion(listings, reviews, model="cells", shrink=4.0):
    """Sensitivity and specificity per (reviewer, band) from the adjudicated reviews.

    model 'cells': each cell's own rates, shrunk towards the reviewer's pooled rates by `shrink`
                   pseudo-observations (a sparse cell falls back on the reviewer).
          'logit': one additive logistic model per rate: a reviewer effect and a common slope in the
                   band shown (fitted by Newton's method on the adjudicated decisions).
          'reviewer': the reviewer's pooled rates for every band.
    Returns a function (reviewer, band) -> (se, sp)."""
    cells = defaultdict(lambda: [0, 0, 0, 0])      # tp, fn, fp, tn
    for stages in reviews.values():
        if "lead" not in stages:
            continue
        lid = stages["lead"][0]
        truth = stages["lead"][3] == "violation"
        band = listings[lid]["band"]
        for st in ("first", "second"):
            if st not in stages:
                continue
            rv, dec = stages[st][2], stages[st][3] == "violation"
            c = cells[(rv, band)]
            if truth:
                c[0 if dec else 1] += 1
            else:
                c[2 if dec else 3] += 1
    by_rv = defaultdict(lambda: [0, 0, 0, 0])
    tot = [0, 0, 0, 0]
    for (rv, band), c in cells.items():
        for i in range(4):
            by_rv[rv][i] += c[i]
            tot[i] += c[i]

    def rates(c):
        se = (c[0] + 0.5) / (c[0] + c[1] + 1.0)
        sp = (c[3] + 0.5) / (c[2] + c[3] + 1.0)
        return se, sp

    if model == "reviewer":
        pooled = {rv: rates(c) for rv, c in by_rv.items()}
        g = rates(tot)
        return lambda rv, band: pooled.get(rv, g)
    if model == "cells":
        out = {}
        for (rv, band), c in cells.items():
            se_rv, sp_rv = rates(by_rv[rv])
            se = (c[0] + shrink * se_rv) / (c[0] + c[1] + shrink)
            sp = (c[3] + shrink * sp_rv) / (c[2] + c[3] + shrink)
            out[(rv, band)] = (se, sp)
        pooled = {rv: rates(c) for rv, c in by_rv.items()}
        g = rates(tot)
        return lambda rv, band: out.get((rv, band), pooled.get(rv, g))
    if model == "logit":
        se_fit = fit_logit(cells, positive=True)
        sp_fit = fit_logit(cells, positive=False)
        pooled = {rv: rates(c) for rv, c in by_rv.items()}
        g = rates(tot)

        def f(rv, band):
            if rv not in se_fit[0]:
                return pooled.get(rv, g)
            return (expit(se_fit[0][rv] + se_fit[1] * (band - 3)), expit(sp_fit[0][rv] + sp_fit[1] * (band - 3)))
        return f
    raise ValueError(model)


def fit_logit(cells, positive, iters=40):
    """logit P(decision right) = a_reviewer + slope * (band - 3), on the adjudicated decisions of one
    truth class (positive: violations, the rate is sensitivity; else clean, the rate is specificity)."""
    obs = []     # (reviewer, band, right, wrong)
    for (rv, band), c in cells.items():
        right, wrong = (c[0], c[1]) if positive else (c[3], c[2])
        if right + wrong:
            obs.append((rv, band, right, wrong))
    rvs = sorted({o[0] for o in obs})
    a = {rv: 2.0 for rv in rvs}
    slope = 0.0
    for _ in range(iters):
        # coordinate Newton steps: each reviewer effect, then the slope
        for rv in rvs:
            g = h = 0.0
            for r, band, right, wrong in obs:
                if r != rv:
                    continue
                p = expit(a[rv] + slope * (band - 3))
                g += right - (right + wrong) * p
                h += (right + wrong) * p * (1 - p)
            if h > 1e-9:
                a[rv] += max(-2.0, min(2.0, g / h))
            a[rv] = max(-6.0, min(8.0, a[rv]))
        g = h = 0.0
        for rv, band, right, wrong in obs:
            x = band - 3
            p = expit(a[rv] + slope * x)
            g += x * (right - (right + wrong) * p)
            h += x * x * (right + wrong) * p * (1 - p)
        if h > 1e-9:
            slope += max(-1.0, min(1.0, g / h))
    return a, slope


def posterior(dec, se, sp, pi):
    """P(violation | the reviewer's decision) for a listing in a stratum of prevalence pi."""
    if dec:
        a, b = pi * se, (1 - pi) * (1 - sp)
    else:
        a, b = pi * (1 - se), (1 - pi) * sp
    return a / (a + b) if a + b > 0 else pi


def joint_fit(items, model="cells", rounds=300):
    """Latent-class EM over every reviewed listing.

    items: list of (stratum, truth or None, [(reviewer, band, decided_violation), ...]).
    Fits the prevalence of every stratum and each reviewer's sensitivity and specificity per band
    shown ('cells'), per reviewer across bands ('reviewer'), or as an additive logistic model with a
    reviewer effect and one slope in the band ('logit').  Adjudicated listings hold their status;
    the others carry a posterior that the fit updates each round.  Listings with the same stratum,
    reviewer, band and decision share a posterior, so the loops run over groups, not listings."""
    def cell(rv, band):
        return (rv, band) if model in ("cells", "logit") else rv

    # adjudicated listings: fixed contributions
    g_pos, g_n = defaultdict(float), defaultdict(int)
    fixed = defaultdict(float)          # (cell, truth, decided) -> count
    groups = defaultdict(int)           # (stratum, reviewer, band, decided) -> count of single-reviewed
    for s, t, decs in items:
        if t is not None:
            g_pos[s] += t
            g_n[s] += 1
            for rv, band, v in decs:
                fixed[(cell(rv, band), t > 0.5, v)] += 1
        else:
            rv, band, v = decs[0]
            groups[(s, rv, band, v)] += 1
    strata = sorted(set(g_n) | {g[0] for g in groups})
    # start from what the adjudicated listings say on their own
    pi = {s: (g_pos[s] + 0.5) / (g_n[s] + 1.0) for s in strata}
    a0, b0, c0, d0 = defaultdict(float), defaultdict(float), defaultdict(float), defaultdict(float)
    for (k, t, v), n in fixed.items():
        if t:
            (a0 if v else b0)[k] += n
        else:
            (c0 if v else d0)[k] += n
    se = defaultdict(lambda: 0.9, {k: (a0[k] + 0.9 * 2) / (a0[k] + b0[k] + 2) for k in set(a0) | set(b0)})
    sp = defaultdict(lambda: 0.95, {k: (d0[k] + 0.95 * 2) / (c0[k] + d0[k] + 2) for k in set(c0) | set(d0)})
    r = {}
    for g in groups:
        s_, rv, band, v = g
        k = cell(rv, band)
        la = pi[s_] * (se[k] if v else 1 - se[k])
        lb = (1 - pi[s_]) * (1 - sp[k] if v else sp[k])
        r[g] = la / (la + lb) if la + lb > 0 else pi[s_]
    for _ in range(rounds):
        # M-step
        num, den = defaultdict(float), defaultdict(float)
        a, b, c, d = defaultdict(float), defaultdict(float), defaultdict(float), defaultdict(float)
        for (k, t, v), n in fixed.items():
            if t:
                (a if v else b)[k] += n
            else:
                (c if v else d)[k] += n
        for s in strata:
            num[s] += g_pos[s]
            den[s] += g_n[s]
        for (s, rv, band, v), n in groups.items():
            ri = r[(s, rv, band, v)]
            num[s] += n * ri
            den[s] += n
            k = cell(rv, band)
            if v:
                a[k] += n * ri
                c[k] += n * (1 - ri)
            else:
                b[k] += n * ri
                d[k] += n * (1 - ri)
        for s in strata:
            pi[s] = min(1 - 1e-6, max(1e-6, num[s] / den[s])) if den[s] else 1e-6
        keys = set(a) | set(b) | set(c) | set(d)
        if model == "logit":
            se_fit = fit_logit_weighted(a, b)
            sp_fit = fit_logit_weighted(d, c)
            for k in keys:
                rv, band = k
                se[k] = expit(se_fit[0].get(rv, 2.0) + se_fit[1] * (band - 3))
                sp[k] = expit(sp_fit[0].get(rv, 3.0) + sp_fit[1] * (band - 3))
        else:
            for k in keys:
                se[k] = min(0.999, max(0.5, (a[k] + 0.5) / (a[k] + b[k] + 1.0)))
                sp[k] = min(0.9999, max(0.5, (d[k] + 0.5) / (c[k] + d[k] + 1.0)))
        # E-step
        for g in groups:
            s, rv, band, v = g
            k = cell(rv, band)
            la = pi[s] * (se[k] if v else 1 - se[k])
            lb = (1 - pi[s]) * (1 - sp[k] if v else sp[k])
            r[g] = la / (la + lb) if la + lb > 0 else pi[s]
    return pi


def fit_logit_weighted(right, wrong, iters=25):
    """logit P(right) = a_reviewer + slope * (band - 3) on weighted counts keyed by (reviewer, band)."""
    keys = set(right) | set(wrong)
    rvs = sorted({k[0] for k in keys})
    a = {rv: 2.0 for rv in rvs}
    slope = 0.0
    for _ in range(iters):
        for rv in rvs:
            g = h = 0.0
            for k in keys:
                if k[0] != rv:
                    continue
                n = right.get(k, 0.0) + wrong.get(k, 0.0)
                p = expit(a[rv] + slope * (k[1] - 3))
                g += right.get(k, 0.0) - n * p
                h += n * p * (1 - p)
            if h > 1e-9:
                a[rv] = max(-6.0, min(9.0, a[rv] + max(-2.0, min(2.0, g / h))))
        g = h = 0.0
        for k in keys:
            x = k[1] - 3
            n = right.get(k, 0.0) + wrong.get(k, 0.0)
            p = expit(a[k[0]] + slope * x)
            g += x * (right.get(k, 0.0) - n * p)
            h += x * x * n * p * (1 - p)
        if h > 1e-9:
            slope += max(-1.0, min(1.0, g / h))
    return a, slope


def measure(campaign, model="cells", strata="category", weighted=True, correct=True, gold_only=False,
            estimator="joint", rounds=300, shrink=4.0, data=None):
    """Precision and recall per release. estimator: 'two-stage' (reviewer rates from the adjudicated
    listings, then EM on the prevalences), 'joint' (joint_fit), 'one-step' (adjudicated share as prior,
    one posterior per decision) or 'linear' (the per-decision correction (v - (1 - sp)) / (se + sp - 1));
    model: 'cells', 'reviewer' or 'logit'; strata: 'category', 'band' or 'category-week'; weighted=False
    carries the audit lane's mean to the whole unflagged population; correct=False reads decisions at
    face value; gold_only uses the adjudicated listings alone, scaled per lane and band."""
    releases, listings, reviews = data if data is not None else load(campaign)
    key = {"category": lambda L: (L["release"], L["band"], L["category"]),
           "category-week": lambda L: (L["release"], L["band"], L["category"], L["week"]),
           "band": lambda L: (L["release"], L["band"])}[strata]

    def stratum_of(L):
        k = key(L) if (weighted or L["flagged"]) else (L["release"],)
        return (L["flagged"],) + k

    items = []            # (stratum, truth or None, decisions)
    gold = {}
    for stages in reviews.values():
        if "first" not in stages:
            continue
        lid = stages["first"][0]
        L = listings[lid]
        truth = None
        if "lead" in stages:
            truth = 1.0 if stages["lead"][3] == "violation" else 0.0
            gold[lid] = truth
        decs = [(stages[st][2], L["band"], stages[st][3] == "violation") for st in ("first", "second") if st in stages]
        items.append((stratum_of(L), truth, decs))

    pop = defaultdict(int)
    for L in listings.values():
        if not L["flagged"]:
            pop[key(L)] += 1
    n_items = defaultdict(int)
    for s, _, _ in items:
        n_items[s] += 1

    prev = {}
    if gold_only:
        pass
    elif not correct:
        for s in n_items:
            prev[s] = sum(1.0 if t is not None and t else (0.0 if t is not None else float(decs[0][2]))
                          for ss, t, decs in items if ss == s) / n_items[s]
    elif estimator == "joint":
        prev = joint_fit(items, model=model, rounds=rounds)
    else:
        conf = confusion(listings, reviews, model=model, shrink=shrink)
        g_pos, g_n, singles = defaultdict(float), defaultdict(int), defaultdict(list)
        for s, t, decs in items:
            if t is not None:
                g_pos[s] += t
                g_n[s] += 1
            else:
                rv, band, v = decs[0]
                singles[s].append((v,) + tuple(conf(rv, band)))
        for s in n_items:
            if estimator == "linear":
                tot = g_pos[s] + sum((v - (1 - sp)) / max(se + sp - 1, 0.05) for v, se, sp in singles[s])
                prev[s] = min(1.0, max(0.0, tot / n_items[s]))
                continue
            pi = (g_pos[s] + 0.5) / (g_n[s] + 1.0)
            for _ in range(rounds if estimator == "two-stage" else 1):      # one-step keeps the prior
                tot = g_pos[s] + sum(posterior(v, se, sp, pi) for v, se, sp in singles[s])
                pi = min(1 - 1e-6, max(1e-6, tot / n_items[s]))
            prev[s] = pi

    out = {}
    for rel in releases:
        n_flag = sum(1 for L in listings.values() if L["release"] == rel and L["flagged"])
        if gold_only:
            per = defaultdict(lambda: [0.0, 0])
            n_band = defaultdict(int)
            for lid, L in listings.items():
                if L["release"] != rel:
                    continue
                n_band[(L["flagged"], L["band"])] += 1
                if lid in gold:
                    c = per[(L["flagged"], L["band"])]
                    c[0] += gold[lid]
                    c[1] += 1
            tp = sum(n_band[k] * g / n for k, (g, n) in per.items() if k[0] and n)
            fn = sum(n_band[k] * g / n for k, (g, n) in per.items() if not k[0] and n)
        else:
            tp = fn = 0.0
            for s, pi in prev.items():
                flagged, k = s[0], s[1:]
                if k[0] != rel:
                    continue
                if flagged:
                    tp += n_items[s] * pi
                elif weighted:
                    fn += pop[k] * pi
                else:
                    fn += sum(v for kk, v in pop.items() if kk[0] == rel) * pi
        out[rel] = (tp / n_flag if n_flag else 0.0, tp / (tp + fn) if tp + fn > 0 else 0.0)
    return out


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    figs = measure(argv[1])
    with open(argv[2], "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["release", "precision", "recall"])
        for rel in sorted(figs):
            w.writerow([rel, "%.4f" % figs[rel][0], "%.4f" % figs[rel][1]])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
