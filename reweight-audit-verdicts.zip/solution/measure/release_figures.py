#!/usr/bin/env python3
"""Precision and recall of each classifier release over a review-programme campaign.

    python3 release_figures.py CAMPAIGN_DIR OUT_CSV

Reads the campaign folder only. Every reviewer's sensitivity and specificity per band shown and every
stratum's prevalence (release, band, category; flag and audit lanes apart) are fitted together by a
latent-class EM over every first and second decision. Lead-adjudicated listings are held at their
status. Appeal outcomes are left out: sellers choose whether to appeal, and a wrongly removed seller
appeals far more often than a rightly removed one, so appealed listings are not a fair sample. A
quality-control share drawn by decision needs no weighting here, because the fit conditions on every
decision, drawn or not. Audited strata are scaled by their unflagged population over their audited
count, which is the Horvitz-Thompson weight of the stratum's recovered draw rate.
"""
import csv
import gzip
import os
import sys
from collections import defaultdict

ROUNDS = 300


def read_csv(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def load(campaign):
    releases = {}
    for r in read_csv(os.path.join(campaign, "releases.csv")):
        releases[r["release"]] = dict(thr=float(r["threshold"]),
                                      cuts=[float(c) for c in r["band_cuts"].split(";")])
    listings = {}
    for r in read_csv(os.path.join(campaign, "scoring.csv.gz")):
        rel = releases[r["release"]]
        s = float(r["score"])
        listings[r["listing"]] = dict(release=r["release"], category=r["category"],
                                      band=1 + sum(1 for c in rel["cuts"] if s >= c),
                                      flagged=s >= rel["thr"])
    reviews = defaultdict(dict)
    for r in read_csv(os.path.join(campaign, "reviews.csv.gz")):
        reviews[r["review"]][r["stage"]] = (r["listing"], r["lane"], r["reviewer"], r["decision"])
    return releases, listings, reviews


def joint_fit(items, rounds=ROUNDS):
    """items: (stratum, truth or None, [(reviewer, band, decided_violation), ...]).
    Returns each stratum's fitted prevalence. Single-reviewed listings with the same stratum,
    reviewer, band and decision share a posterior, so the loops run over groups."""
    g_pos, g_n = defaultdict(float), defaultdict(int)
    fixed = defaultdict(float)          # ((reviewer, band), truth, decided) -> count
    groups = defaultdict(int)           # (stratum, reviewer, band, decided) -> count
    for s, t, decs in items:
        if t is not None:
            g_pos[s] += t
            g_n[s] += 1
            for rv, band, v in decs:
                fixed[((rv, band), t > 0.5, v)] += 1
        else:
            rv, band, v = decs[0]
            groups[(s, rv, band, v)] += 1
    strata = sorted(set(g_n) | {g[0] for g in groups})
    pi = {s: (g_pos[s] + 0.5) / (g_n[s] + 1.0) for s in strata}
    a0, b0, c0, d0 = (defaultdict(float) for _ in range(4))
    for (k, t, v), n in fixed.items():
        if t:
            (a0 if v else b0)[k] += n
        else:
            (c0 if v else d0)[k] += n
    se = defaultdict(lambda: 0.9, {k: (a0[k] + 1.8) / (a0[k] + b0[k] + 2) for k in set(a0) | set(b0)})
    sp = defaultdict(lambda: 0.95, {k: (d0[k] + 1.9) / (c0[k] + d0[k] + 2) for k in set(c0) | set(d0)})

    def posterior(s, k, v):
        la = pi[s] * (se[k] if v else 1 - se[k])
        lb = (1 - pi[s]) * (1 - sp[k] if v else sp[k])
        return la / (la + lb) if la + lb > 0 else pi[s]

    r = {g: posterior(g[0], (g[1], g[2]), g[3]) for g in groups}
    for _ in range(rounds):
        num, den = defaultdict(float), defaultdict(float)
        a, b, c, d = (defaultdict(float) for _ in range(4))
        for (k, t, v), n in fixed.items():
            if t:
                (a if v else b)[k] += n
            else:
                (c if v else d)[k] += n
        for s in strata:
            num[s] += g_pos[s]
            den[s] += g_n[s]
        for (s, rv, band, v), n in groups.items():
            ri = r[(s, rv, band, v)]
            num[s] += n * ri
            den[s] += n
            k = (rv, band)
            if v:
                a[k] += n * ri
                c[k] += n * (1 - ri)
            else:
                b[k] += n * ri
                d[k] += n * (1 - ri)
        for s in strata:
            pi[s] = min(1 - 1e-6, max(1e-6, num[s] / den[s])) if den[s] else 1e-6
        for k in set(a) | set(b) | set(c) | set(d):
            se[k] = min(0.999, max(0.5, (a[k] + 0.5) / (a[k] + b[k] + 1.0)))
            sp[k] = min(0.9999, max(0.5, (d[k] + 0.5) / (c[k] + d[k] + 1.0)))
        for g in groups:
            r[g] = posterior(g[0], (g[1], g[2]), g[3])
    return pi


def measure(campaign):
    releases, listings, reviews = load(campaign)

    def stratum_of(L):
        return (L["flagged"], L["release"], L["band"], L["category"])

    items = []
    for stages in reviews.values():
        if "first" not in stages:
            continue
        L = listings[stages["first"][0]]
        truth = None
        if "lead" in stages:                       # quality-control adjudication; never "appeal"
            truth = 1.0 if stages["lead"][3] == "violation" else 0.0
        decs = [(stages[st][2], L["band"], stages[st][3] == "violation")
                for st in ("first", "second") if st in stages]
        items.append((stratum_of(L), truth, decs))

    pop, reviewed = defaultdict(int), defaultdict(int)
    for L in listings.values():
        if not L["flagged"]:
            pop[stratum_of(L)] += 1
    for s, _, _ in items:
        reviewed[s] += 1
    prev = joint_fit(items)

    out = {}
    for rel in releases:
        n_flag = sum(1 for L in listings.values() if L["release"] == rel and L["flagged"])
        tp = fn = 0.0
        for s, p in prev.items():
            if s[1] != rel:
                continue
            if s[0]:
                tp += reviewed[s] * p                  # every flagged listing is reviewed
            else:
                fn += pop[s] * p                       # the stratum's unflagged population
        out[rel] = (tp / n_flag if n_flag else 0.0, tp / (tp + fn) if tp + fn > 0 else 0.0)
    return out


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    figs = measure(argv[1])
    with open(argv[2], "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["release", "precision", "recall"])
        for rel in sorted(figs):
            w.writerow([rel, "%.4f" % figs[rel][0], "%.4f" % figs[rel][1]])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
