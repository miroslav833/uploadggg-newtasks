#!/usr/bin/env bash
# Installs the reference measurement program and runs it on the two sample campaigns.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/measure
cp "$HERE/measure/release_figures.py" /app/measure/release_figures.py
for c in /app/programme/campaigns/*/; do
  python3 /app/measure/release_figures.py "$c" "/tmp/$(basename "$c")-figures.csv"
done
