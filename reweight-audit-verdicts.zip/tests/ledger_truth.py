"""The verifier's own forward model: each release's precision and recall over a campaign, reckoned
from the sealed status of every listing and the campaign's own scoring ledger and release register.
Test 1 checks the sealed figures against it."""
import csv
import gzip
import os


def rows(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def figures(campaign_dir, sealed_dir):
    thr = {r["release"]: float(r["threshold"]) for r in rows(os.path.join(campaign_dir, "releases.csv"))}
    status = {r["listing"]: r["violation"] == "1" for r in rows(os.path.join(sealed_dir, "status.csv.gz"))}
    tally = {rel: [0, 0, 0] for rel in thr}        # flagged, flagged violations, violations
    for r in rows(os.path.join(campaign_dir, "scoring.csv.gz")):
        t = tally[r["release"]]
        flagged = float(r["score"]) >= thr[r["release"]]
        bad = status[r["listing"]]
        t[0] += flagged
        t[1] += flagged and bad
        t[2] += bad
    return {rel: (round(t[1] / t[0], 4) if t[0] else 0.0, round(t[1] / t[2], 4) if t[2] else 0.0)
            for rel, t in tally.items()}
