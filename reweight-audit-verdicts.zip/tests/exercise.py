"""Runs the uploaded program once per graded campaign and reads what it filed.

Each run gets a fresh copy of the campaign folder, a numeric account that owns nothing else, a new
session, address-space and file-size limits and a wall-clock budget. Every process of that account is
stopped before the output is opened. The output is read as text through a non-following descriptor
and parsed; nothing in it is executed.
"""
import csv
import io
import math
import os
import resource
import shutil
import signal
import subprocess
import time

HELD = "/tests/held"
KEEP = "/run/verifier"
WORK = "/var/tmp/campaigns"
PROGRAM = "/app/measure/release_figures.py"
BUDGET_S = 120
CAP_BYTES = 256 * 1024


def fresh_uid():
    taken = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                taken.add(os.stat("/proc/" + d).st_uid)
            except FileNotFoundError:
                pass
    uid = 61473
    while uid in taken:
        uid += 1
    return uid


def halt(uid):
    for _ in range(200):
        mine = []
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    mine.append(int(d))
            except FileNotFoundError:
                pass
        if not mine:
            return
        for p in mine:
            try:
                os.kill(p, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def campaigns():
    return sorted(os.listdir(os.path.join(HELD, "campaigns")))


def run_campaign(name, uid):
    root = os.path.join(WORK, name)
    shutil.rmtree(root, ignore_errors=True)
    os.makedirs(root, mode=0o755)
    folder, outdir, home = (os.path.join(root, x) for x in ("campaign", "out", "home"))
    shutil.copytree(os.path.join(HELD, "campaigns", name), folder, symlinks=False)
    os.makedirs(outdir)
    os.makedirs(home)
    for base, dirs, files in os.walk(root):
        for x in dirs + files:
            os.lchown(os.path.join(base, x), uid, uid)
    os.chown(root, uid, uid)

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    target = os.path.join(outdir, "figures.csv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8"}
    with open(os.path.join(KEEP, name + ".log"), "wb") as log:
        proc = subprocess.Popen(["python3", PROGRAM, folder, target], stdin=subprocess.DEVNULL,
                                stdout=log, stderr=log, cwd=home, env=env, preexec_fn=drop)
        try:
            proc.wait(timeout=BUDGET_S)
        except subprocess.TimeoutExpired:
            pass
    halt(uid)
    filed = read_figures(target)
    shutil.rmtree(root, ignore_errors=True)
    return filed


def read_figures(path):
    """{release: (precision, recall)} from the filed CSV; a release whose row does not parse to two
    finite numbers is left out (and so counts as wrong)."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError:
        return {}
    try:
        st = os.fstat(fd)
        if not os.path.stat.S_ISREG(st.st_mode) or st.st_size > CAP_BYTES:
            return {}
        raw = os.read(fd, CAP_BYTES)
    finally:
        os.close(fd)
    out = {}
    try:
        rows = csv.DictReader(io.StringIO(raw.decode("utf-8", "replace")))
        for row in rows:
            rel = (row.get("release") or "").strip()
            if not rel or rel in out:
                continue
            try:
                p, r = float(row.get("precision", "")), float(row.get("recall", ""))
            except (TypeError, ValueError):
                continue
            if math.isfinite(p) and math.isfinite(r):
                out[rel] = (p, r)
    except csv.Error:
        return {}
    return out
