#!/usr/bin/env python3
"""Builds review-programme campaigns: the scoring ledger, the review ledger, the release register and
the campaign sheet, plus the sealed truth (every listing's policy status and the figures it implies).

    python3 campaigngen.py graded CAMPAIGN_DIR SEALED_DIR [SEED0]   the 20 graded campaigns
    python3 campaigngen.py samples CAMPAIGN_DIR [SEED0]            the two sample campaigns (with figures.csv)

Standard library only. Everything is drawn from one seeded generator per campaign.
"""
import csv
import gzip
import json
import math
import os
import random
import string
import sys

DAYS = 28
CATEGORIES = ["apparel", "electronics", "home", "media", "supplements", "toys"]
ALNUM = string.ascii_lowercase + string.digits


def logit(p):
    return math.log(p / (1.0 - p))


def expit(x):
    return 1.0 / (1.0 + math.exp(-x))


# --------------------------------------------------------------------------- profiles
# classes: catrates = the lead set the audit draw rates per listing category as well as per band;
#          noisy = reviewers err at rates of their own; bias = a reviewer's error moves with the band
#          the console shows.  Every class sits on at least 8 campaigns.
GRADED = [
    ("alder", 1, set()), ("birch", 2, set()), ("cedar", 2, set()),
    ("damson", 1, {"catrates"}), ("elder", 2, {"catrates"}),
    ("fir", 1, {"noisy"}), ("gorse", 2, {"noisy"}), ("hazel", 1, {"noisy"}),
    ("ilex", 2, {"noisy", "bias"}), ("juniper", 1, {"noisy", "bias"}), ("kauri", 2, {"noisy", "bias"}),
    ("larch", 1, {"noisy", "bias"}),
    ("maple", 2, {"catrates", "noisy"}), ("nutmeg", 1, {"catrates", "noisy"}), ("osier", 2, {"catrates", "noisy"}),
    ("poplar", 1, {"catrates", "noisy", "bias"}), ("quince", 2, {"catrates", "noisy", "bias"}),
    ("rowan", 1, {"catrates", "noisy", "bias"}), ("sorbus", 2, {"catrates", "noisy", "bias"}),
    ("tamarisk", 2, {"noisy", "bias"}),
]
SAMPLES = [("harrow", 1, set()), ("lenton", 2, set())]


def code(rng, n, used):
    while True:
        c = "".join(rng.choice(ALNUM) for _ in range(n))
        if c not in used and c[0].isalpha():
            used.add(c)
            return c


# --------------------------------------------------------------------------- one campaign
def draw_release(rng, idx, classes, risk):
    """A release: score model, threshold, band cut points, audit draw rates per band (and category).
    `risk` ranks the categories by the prevalence the policy team expects; with catrates the lead
    draws the risky categories harder and the quiet ones lighter."""
    thr = round(rng.uniform(0.56, 0.70), 2)
    cuts = [round(rng.uniform(0.12, 0.20), 2), round(rng.uniform(0.32, 0.44), 2), thr, round(rng.uniform(0.80, 0.88), 2)]
    viol = dict(main=(rng.uniform(6.0, 7.5), rng.uniform(1.4, 1.9)), hard=(4.0, 3.2), hard_share=rng.uniform(0.10, 0.20))
    clean = dict(main=(rng.uniform(1.1, 1.4), rng.uniform(7.5, 10.0)), tail=(3.4, 3.2), tail_share=rng.uniform(0.14, 0.24))
    base = [rng.uniform(0.03, 0.06), rng.uniform(0.10, 0.18), rng.uniform(0.22, 0.30)]
    rates = {}
    for cat, r in zip(CATEGORIES, risk):
        if "catrates" in classes:
            m = {"high": rng.uniform(2.8, 3.2), "mid": 1.0, "low": rng.uniform(0.18, 0.28)}[r]
        else:
            m = 1.0
        rates[cat] = [min(0.95, b * m) for b in base]
    return dict(name="r%d" % idx, thr=thr, cuts=cuts, viol=viol, clean=clean, rates=rates)


def band_of(score, cuts):
    b = 1
    for c in cuts:
        if score >= c:
            b += 1
    return b


def reviewer_pool(rng, classes):
    n = rng.randint(7, 11)
    gamma = rng.uniform(1.1, 1.7) if "bias" in classes else 0.0
    pool = []
    for i in range(n):
        if "bias" in classes:
            se, sp = rng.uniform(0.80, 0.94), rng.uniform(0.90, 0.96)
        elif "noisy" in classes:
            se, sp = rng.uniform(0.78, 0.95), rng.uniform(0.905, 0.985)
        else:
            se, sp = rng.uniform(0.975, 0.995), rng.uniform(0.985, 0.998)
        share = rng.uniform(0.7, 1.0)
        active = {d for d in range(1, DAYS + 1) if rng.random() < share}
        if len(active) < 10:
            active = set(range(1, DAYS + 1))
        sp_low = [rng.uniform(0.9994, 0.9999), rng.uniform(0.998, 0.9995)]
        pool.append(dict(name="rv%02d" % (i + 1), se=se, sp=sp, sp_low=sp_low, qc=rng.uniform(0.03, 0.045),
                         active=active))
    return pool, gamma


def rates_shown(rv, gamma, band):
    """A reviewer's sensitivity and specificity for the band the console shows. Plainly clean
    listings (bands 1 and 2) are almost never contested; in the flag bands a reviewer who leans on
    the score confirms more (higher sensitivity, lower specificity), by gamma per band."""
    if band <= 2:
        return expit(logit(rv["se"]) - 1.0), rv["sp_low"][band - 1]
    lift = gamma * (band - 3)
    return expit(logit(rv["se"]) + lift), expit(logit(rv["sp"]) - lift)


def decide(rng, rv, gamma, band, truth):
    se, sp = rates_shown(rv, gamma, band)
    if truth:
        return "violation" if rng.random() < se else "clean"
    return "clean" if rng.random() < sp else "violation"


def category_mix(rng, classes):
    """Category shares of the traffic and each category's violation prevalence multiplier."""
    w = [rng.uniform(0.7, 1.4) for _ in CATEGORIES]
    tot = sum(w)
    shares = [x / tot for x in w]
    if "catrates" in classes:
        mult = [0.2, 0.3, 1.0, 1.0, 3.5, 5.0]
        rng.shuffle(mult)
    else:
        mult = [rng.choice([0.2, 0.3, 1.0, 1.0, 2.5, 3.5, 5.0]) for _ in CATEGORIES]
    risk = ["high" if m >= 2.5 else "low" if m <= 0.3 else "mid" for m in mult]
    if "high" not in risk:
        risk[mult.index(max(mult))] = "high"
    if "low" not in risk:
        risk[mult.index(min(mult))] = "low"
    return shares, mult, risk


def build(name, n_rel, classes, seed, out_dir, sealed_dir=None, figures=False, n=None, draw_lift=1.0):
    rng = random.Random(seed)
    if n is None:
        n = rng.randint(130000, 160000) * n_rel
    prev = rng.uniform(0.040, 0.075)
    shares, mult, risk = category_mix(rng, classes)
    releases = [draw_release(rng, i + 1, classes, risk) for i in range(n_rel)]
    for rel in releases:                 # a sample campaign draws its audits harder
        rel["rates"] = {c: [min(0.95, x * draw_lift) for x in v] for c, v in rel["rates"].items()}
    switch = rng.randint(11, 17) if n_rel == 2 else DAYS + 1
    pool, gamma = reviewer_pool(rng, classes)
    # the category prevalences are scaled so the campaign's prevalence is `prev`
    mean_mult = sum(s * m for s, m in zip(shares, mult))
    cat_prev = [min(0.5, prev * m / mean_mult) for m in mult]

    used = set()
    listings = []
    day_w = [1.0 + 0.25 * math.sin(2 * math.pi * d / 7.0) for d in range(1, DAYS + 1)]
    tot = sum(day_w)
    for d in range(1, DAYS + 1):
        k = int(round(n * day_w[d - 1] / tot))
        rel = releases[0] if d < switch else releases[-1]
        for _ in range(k):
            ci = rng.choices(range(len(CATEGORIES)), shares)[0]
            truth = 1 if rng.random() < cat_prev[ci] else 0
            if truth:
                m = rel["viol"]
                a, b = m["hard"] if rng.random() < m["hard_share"] else m["main"]
            else:
                m = rel["clean"]
                a, b = m["tail"] if rng.random() < m["tail_share"] else m["main"]
            s = min(0.999, max(0.001, rng.betavariate(a, b)))
            listings.append([code(rng, 6, used), d, rel, CATEGORIES[ci], round(s, 3), truth])
    rng.shuffle(listings)

    reviews = []
    rid_used = set()
    for lid, d, rel, cat, s, truth in listings:
        band = band_of(s, rel["cuts"])
        if s >= rel["thr"]:
            lane = "flag"
        else:
            if rng.random() >= rel["rates"][cat][band - 1]:
                continue
            lane = "audit"
        act = [rv for rv in pool if d in rv["active"]] or pool
        first = rng.choice(act)
        rid = code(rng, 7, rid_used)
        rows = [[rid, lid, lane, "first", first["name"], decide(rng, first, gamma, band, truth)]]
        if rng.random() < first["qc"]:
            others = [rv for rv in act if rv is not first] or [rv for rv in pool if rv is not first]
            second = rng.choice(others)
            rows.append([rid, lid, lane, "second", second["name"], decide(rng, second, gamma, band, truth)])
            rows.append([rid, lid, lane, "lead", "lead", "violation" if truth else "clean"])
        reviews.extend(rows)
    order = {"first": 0, "second": 1, "lead": 2}
    reviews.sort(key=lambda r: (r[0], order[r[3]]))

    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "campaign.txt"), "w", encoding="utf-8") as fh:
        fh.write("campaign: %s\nwindow_days: %d\nreleases: %s\nreviewers: %d\nlistings: %d\n"
                 % (name, DAYS, " ".join(r["name"] for r in releases), len(pool), len(listings)))
    with open(os.path.join(out_dir, "releases.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["release", "threshold", "band_cuts"])
        for r in releases:
            w.writerow([r["name"], "%.2f" % r["thr"], ";".join("%.2f" % c for c in r["cuts"])])
    with gzip.open(os.path.join(out_dir, "scoring.csv.gz"), "wt", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["listing", "day", "category", "release", "score"])
        for lid, d, rel, cat, s, truth in listings:
            w.writerow([lid, d, cat, rel["name"], "%.3f" % s])
    with gzip.open(os.path.join(out_dir, "reviews.csv.gz"), "wt", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["review", "listing", "lane", "stage", "reviewer", "decision"])
        w.writerows(reviews)

    figs = reckon(listings)
    if figures:
        with open(os.path.join(out_dir, "figures.csv"), "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["release", "precision", "recall"])
            for r in releases:
                w.writerow([r["name"], "%.4f" % figs[r["name"]][0], "%.4f" % figs[r["name"]][1]])
    if sealed_dir:
        os.makedirs(sealed_dir, exist_ok=True)
        with gzip.open(os.path.join(sealed_dir, "status.csv.gz"), "wt", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["listing", "violation"])
            for lid, d, rel, cat, s, truth in sorted(listings):
                w.writerow([lid, truth])
        with open(os.path.join(sealed_dir, "figures.json"), "w", encoding="utf-8") as fh:
            json.dump({r["name"]: {"precision": round(figs[r["name"]][0], 4), "recall": round(figs[r["name"]][1], 4)}
                       for r in releases}, fh, indent=1)
        with open(os.path.join(sealed_dir, "profile.json"), "w", encoding="utf-8") as fh:
            json.dump(dict(name=name, classes=sorted(classes), n=len(listings), prevalence=prev, gamma=gamma,
                           switch=switch, categories=dict(zip(CATEGORIES, zip(shares, cat_prev, risk))),
                           releases=[dict(name=r["name"], thr=r["thr"], cuts=r["cuts"], rates=r["rates"])
                                     for r in releases],
                           reviewers=[dict(name=rv["name"], se=rv["se"], sp=rv["sp"], sp_low=rv["sp_low"], qc=rv["qc"])
                                      for rv in pool]),
                      fh, indent=1)
    return figs


def reckon(listings):
    """Precision and recall per release from every listing's status: the figures the programme would
    publish after adjudicating every listing."""
    acc = {}
    for lid, d, rel, cat, s, truth in listings:
        a = acc.setdefault(rel["name"], [0, 0, 0])   # flagged, flagged & violation, violation
        flagged = s >= rel["thr"]
        a[0] += flagged
        a[1] += flagged and truth
        a[2] += truth
    return {k: (v[1] / v[0] if v[0] else 0.0, v[1] / v[2] if v[2] else 0.0) for k, v in acc.items()}


def build_graded(camp_dir, sealed_dir, seed0=20261020):
    out = {}
    for i, (name, n_rel, classes) in enumerate(GRADED):
        out[name] = build(name, n_rel, classes, seed0 * 100 + i, os.path.join(camp_dir, name),
                          os.path.join(sealed_dir, name))
    return out


def build_samples(camp_dir, seed0=7001, seeds=None):
    for i, (name, n_rel, classes) in enumerate(SAMPLES):
        seed = seeds[i] if seeds else seed0 * 100 + i
        build(name, n_rel, classes, seed, os.path.join(camp_dir, name), figures=True,
              n=35000 + 10000 * n_rel, draw_lift=1.8)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "graded":
        build_graded(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 20261020)
    elif len(sys.argv) >= 3 and sys.argv[1] == "samples":
        build_samples(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 7001)
    else:
        print(__doc__)
        sys.exit(2)
