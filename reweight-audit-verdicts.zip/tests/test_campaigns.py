"""Two tests: the sealed figures follow the verifier's own forward model, and the uploaded program
files enough figures within tolerance over the twenty graded campaigns."""
import json
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import exercise       # noqa: E402
import ledger_truth   # noqa: E402

CAMPAIGNS = 20
FIGURES = 62            # 31 releases, a precision and a recall each
TOLERANCE = 0.05        # a figure counts when within this of the sealed value; printed in instruction.md
MARK = 58               # figures that must count, of 62; printed in instruction.md


def sealed(name):
    base = os.path.join(exercise.HELD, "sealed", name)
    with open(os.path.join(base, "figures.json"), encoding="utf-8") as fh:
        return {rel: (v["precision"], v["recall"]) for rel, v in json.load(fh).items()}


@pytest.fixture(scope="module")
def filed():
    uid = exercise.fresh_uid()
    out = {}
    for name in exercise.campaigns():
        out[name] = exercise.run_campaign(name, uid)
    with open(os.path.join(exercise.KEEP, "figures.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)
    return out


def counted(truth, got):
    n = 0
    for rel, (p, r) in truth.items():
        if rel not in got:
            continue
        fp, fr = got[rel]
        if not math.isfinite(fp) or not math.isfinite(fr):
            continue                       # a non-finite figure is wrong
        if abs(fp - p) <= TOLERANCE:
            n += 1
        if abs(fr - r) <= TOLERANCE:
            n += 1
    return n


def test_sealed_figures_follow_the_forward_model():
    names = exercise.campaigns()
    assert len(names) == CAMPAIGNS
    total = 0
    for name in names:
        truth = sealed(name)
        model = ledger_truth.figures(os.path.join(exercise.HELD, "campaigns", name),
                                     os.path.join(exercise.HELD, "sealed", name))
        assert set(model) == set(truth), name
        for rel in truth:
            assert all(math.isfinite(x) for x in model[rel] + truth[rel]), (name, rel)
            assert abs(model[rel][0] - truth[rel][0]) < 1e-9 and abs(model[rel][1] - truth[rel][1]) < 1e-9, (name, rel)
        total += 2 * len(truth)
    assert total == FIGURES


def test_enough_figures_within_tolerance(filed):
    per = {name: counted(sealed(name), filed.get(name, {})) for name in exercise.campaigns()}
    score = sum(per.values())
    print(json.dumps(per))
    assert score >= MARK, "%d of %d figures within %.2f (%s); %d needed" % (score, FIGURES, TOLERANCE, per, MARK)
