#!/usr/bin/env bash
# Grades the uploaded measurement program. The reward channel is sealed first: /logs/verifier is
# made root-only, anything reward-shaped in it is removed and reward.txt is set to 0. Only then does
# the program run, as an unprivileged account (tests/exercise.py). At the end every file root did
# not write is removed and reward.txt is written once: 1 when both tests passed.
set -u
LOGS=/logs/verifier
KEEP=/run/verifier

mkdir -p "$LOGS"
saved_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

sweep() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
write_reward() {
    sweep
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
leave() {
    chmod "$saved_mode" "$LOGS" 2>/dev/null
    exit 0
}

write_reward 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "grader: $LOGS is not root-only; nothing is run" >&2
    leave
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$KEEP" && chown 0:0 "$KEEP" && chmod 700 "$KEEP"
chmod -R a+rX /app/measure 2>/dev/null

verdict=1
if ( cd /tests && python3 -m pytest test_campaigns.py -q -p no:cacheprovider --ctrf "$KEEP/ctrf.json" ); then
    verdict=0
fi

if [ "$verdict" -eq 0 ]; then write_reward 1; else write_reward 0; fi
for f in ctrf.json figures.json; do
    [ -f "$KEEP/$f" ] && (umask 022; cp "$KEEP/$f" "$LOGS/$f")
done
leave
