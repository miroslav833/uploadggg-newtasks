Find the precision and recall of each classifier release in one review campaign of our listing-policy programme, at the threshold the release was registered with. The program is run as `python3 /app/measure/release_figures.py CAMPAIGN_DIR OUT_CSV`.

Handbook is at `/app/programme/HANDBOOK.md`, and it explains how listings are scored, flagged and drawn for audit, how quality control and appeals work, and each file in a campaign folder. Two finished campaigns are in `/app/programme/campaigns` with the figures their close-out adjudication gave. Ledgers there are big gzip CSV files.

A listing is a violation when it breaks the listing policy, which is what a lead's adjudication records, and each listing has one status however many decisions it got. Precision is the share of listings the release flagged in the window that are violations. Recall is the share of all violations, among listings the release scored in the window, that it flagged.

OUT_CSV needs this header and one row for each release in the campaign's register, with figures as decimals

```
release,precision,recall
r2,0.9000,0.2000
```

We run your program on 20 campaigns that are not in the image, 31 releases so 62 figures altogether, and reviewers and audit draws in them do not all act like in the two samples. A figure is accepted when it is within 0.05 of the value from the sealed status of every listing, and at least 58 of the 62 must be accepted. Campaigns run one at a time on a clean copy of their folder, 120 seconds each, without root, using the image's python3 and its standard library only. Anything the program needs besides the campaign folder must sit inside `/app/measure`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
