Write a program that measures, for one campaign of a marketplace's listing-policy review programme, the precision and recall of each classifier release at its registered threshold over the campaign window. It runs as

```
python3 /app/measure/release_figures.py CAMPAIGN_DIR OUT_CSV
```

where CAMPAIGN_DIR is one campaign folder. `/app/programme/HANDBOOK.md` describes the programme, the review queues, quality control and every file in a campaign folder. Two sample campaigns are in `/app/programme/campaigns`, each with the figures its close-out adjudication produced; their ledgers are large gzip-compressed CSV files.

OUT_CSV gets a header row and one row per release in the campaign's register:

```
release,precision,recall
r1,0.6512,0.7610
```

A listing is a violation when it violates the listing policy; a lead adjudication records that status, and a listing has one status however many decisions were recorded on it. A release's precision is the share of the listings it flagged in the window that are violations, and its recall is the share of the violations among the listings it scored in the window that it flagged.

Grading runs the program on 20 other campaigns, 31 releases in all, that are not on this machine. Their reviewer pools and audit draws do not all behave as the two samples do. Each release's precision and each release's recall is one figure; a figure counts when it is within 0.05 of the value the sealed status of every listing gives, and at least 58 of the 62 figures must count. The program runs once per campaign on a fresh copy of the folder, as an unprivileged user, under the image's python3 with the standard library only, with 120 seconds per campaign. Anything else it needs must be inside `/app/measure`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
