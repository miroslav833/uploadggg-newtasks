For each of the 48 topics of the retrieval test collection under `/app`, file the lowest and the highest rank-biased precision the candidate retriever's ranked list can reach, given what the collection's judgments settle.

Inputs:

- `/app/runs/candidate.tsv`: `topic`, `rank` (1 to 50), `document` and `score` for the candidate run.
- `/app/judgments/2025.tsv`: `topic`, `document`, `rel` (1 relevant, 0 not relevant), the 2025 campaign's judgments.
- `/app/judgments/2026.tsv`: `topic`, `document`, `grade` (0, 1 or 2), the 2026 campaign's judgments.
- `/app/corpus/manifest.tsv`: `document`, `crawl`, `url`, `title` and `words` for every document the other files name.
- `/app/topics/topics.tsv`: `topic`, `first_campaign` and the query text.
- `/app/notes/COLLECTION.md`: how the corpus, the judgments and the candidate run were made.

Write `/app/out/scores.csv` with a header row and one row per topic, in any order:

```
topic,low,high
Q7F2,0.312,0.655
```

Rank-biased precision here is the sum over the 50 ranked documents of 0.2 times 0.8 to the power (rank minus 1) times the document's gain, where a document of grade 0, 1 or 2 on the three-level scale has gain 0, 0.5 or 1. A judged document carries any grade on the three-level scale that is consistent with its recorded judgment. Two documents with the same content carry the same grade. Any other document may carry any of the three grades. `low` and `high` are the least and the greatest rank-biased precision over every assignment of grades consistent with these rules, each written to 3 decimals.

A topic is right when both its `low` and its `high` are within 0.005 of the reference values; a row that does not parse is wrong. At least 43 of the 48 topics must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
