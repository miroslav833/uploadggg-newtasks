Write an evaluator that scores a retriever on any pooled test collection in our registry. It is run as

```
python3 /app/evaluator/bound_run.py COLLECTION_DIR OUT_CSV
```

where COLLECTION_DIR is one collection as it sits in the registry. It writes OUT_CSV with a header row and one row per topic of the collection:

```
topic,low,high
Q7F2,0.312,0.655
```

`low` and `high` are the least and the greatest nDCG@50 the collection's candidate run can reach over every assignment of grades to the topic's documents consistent with the collection, each written to 3 decimals. The handbook at `/app/registry/HANDBOOK.md` gives the file formats, the grade scale and gains, how judgments and the published gain totals are made, and the exact definition of the bounds. `/app/registry/tools/published_totals.py` recomputes a collection's published totals from a reading of it.

Four collections are in `/app/registry/collections` for trying it out. Grading uses 24 other collections that are not in here, built by campaigns whose crawls, judging tools and exports did not all record things the way these four did. A collection counts when at least 44 of its 48 topics have both `low` and `high` within 0.005 of the reference bounds. At least 22 of the 24 collections have to count.

For grading your program runs once per collection on a fresh copy of it, as an unprivileged user, under the image's python3 with the standard library only. It gets 120 seconds per collection. `/app/registry` will be there as it is now, minus the sample collections. Anything else the program needs should go in `/app/evaluator`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
