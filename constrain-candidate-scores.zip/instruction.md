For each of the 48 topics of the retrieval test collection under `/app`, file the lowest and the highest nDCG@50 the candidate retriever's ranked list can reach, given what the collection's judgments settle.

Inputs:

- `/app/runs/candidate.tsv`: `topic`, `rank` (1 to 50), `document` and `score` for the candidate run.
- `/app/judgments/2025.tsv`: `topic`, `document`, `rel` (1 relevant, 0 not relevant), the 2025 campaign's judgments.
- `/app/judgments/2026.tsv`: `topic`, `document`, `grade` (0, 1 or 2), the 2026 campaign's judgments.
- `/app/corpus/manifest.tsv`: `document`, `crawl`, `url`, `title` and `words` for every document the other files name.
- `/app/topics/topics.tsv`: `topic`, `first_campaign` and the query text.
- `/app/notes/COLLECTION.md`: how the corpus, the judgments and the candidate run were made.

Write `/app/out/scores.csv` with a header row and one row per topic, in any order:

```
topic,low,high
Q7F2,0.312,0.655
```

A document of grade 0, 1 or 2 on the three-level scale has gain 0, 1 or 3. The DCG of a ranked list is the sum over its first 50 positions of the gain at each position divided by log2(position + 1). A topic's documents are every document the run or either judgment file names for it. nDCG@50 of the candidate's list is its DCG divided by the DCG of the best possible ordering of the topic's documents under the same grades. A judged document carries any grade on the three-level scale that is consistent with its recorded judgment. Two documents with the same content carry the same grade. Any other document may carry any of the three grades. `low` and `high` are the least and the greatest nDCG@50 over every assignment of grades to the topic's documents consistent with these rules, each written to 3 decimals.

A topic is right when both its `low` and its `high` are within 0.005 of the reference values; a row that does not parse is wrong. At least 43 of the 48 topics must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
