I'm trying to score our new dense retriever on the old pooled test collections, and since it never took part in any campaign, plenty of its documents were never judged. So instead of one nDCG@50 per topic I want the range it could really have. Please write me an evaluator for that, at /app/evaluator/bound_run.py, called like this:

```
python3 /app/evaluator/bound_run.py COLLECTION_DIR OUT_CSV
```

COLLECTION_DIR is a single collection straight out of the registry. OUT_CSV should start with the header topic,low,high and then have a line per topic, like `Q7F2,0.312,0.655`. low is the smallest and high the largest nDCG@50 the candidate run gets over all grade assignments the collection allows, rounded to 3 decimals. What "allows" means, along with the file layouts, the grades and gains and how the published gain totals came about, is all in /app/registry/HANDBOOK.md. There's also /app/registry/tools/published_totals.py, which recomputes a collection's published totals from your reading of it, if that helps you check yourself.

I left four collections in /app/registry/collections to work with. For grading I use 24 others you won't see. The campaigns behind them crawled, judged and exported in ways these four don't always show. Per topic, both of your numbers must be within 0.005 of mine. If 44 or more of a collection's 48 topics are right, that collection counts, and 22 of the 24 collections need to count.

During grading your evaluator gets a fresh copy of each collection and runs on it as a plain unprivileged user, using the image's python3 and only the standard library, with 120 seconds for each one. /app/registry stays as it is apart from the sample collections, which are removed. Keep everything else your program depends on inside /app/evaluator.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
