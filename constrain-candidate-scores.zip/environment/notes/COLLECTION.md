# The Ashby collection: corpus, judgments and the candidate run

## Corpus

The corpus is a merge of two crawls of the same forty sites. Crawl A was taken in
February 2025 and crawl B in March 2026. The merge kept every fetched page and
removed only byte-identical duplicates (same content hash). Crawl A's fetcher
recorded plain http urls; crawl B's fetcher recorded https urls, and for sites
that put the site name in the title element it kept the page title as the site
served it, with the site name appended.

`corpus/manifest.tsv` lists every document named in a run or a judgment file:
`document` (the corpus identifier), `crawl` (A or B), `url` as the fetcher
recorded it, `title` as the fetcher recorded it, and `words` (the word count of
the extracted text).

## The 2025 campaign

The topics written in 2025 are those `topics/topics.tsv` lists with `first_campaign`
2025. Five lexical systems ran them against
crawl A, their top 50 documents per topic were pooled, and assessors judged each
pooled document as relevant or not relevant to the topic. `judgments/2025.tsv`
holds these judgments: `topic`, `document`, `rel` (1 relevant, 0 not relevant).

## The 2026 campaign

The 2026 campaign kept every topic of 2025 and added new ones, 48 in all. Five systems
ran all 48 topics against the merged corpus, their top 50 documents per topic
were pooled, and assessors judged on a three-level scale: 0 (not relevant), 1
(relevant) and 2 (highly relevant). Assessors read each document and judge it on
what it says. A document already judged in 2025 for a reused topic was not
judged again; the 2026 pool was judged only where it went beyond the 2025
judgments. `judgments/2026.tsv` holds these judgments: `topic`, `document`,
`grade`. `topics/topics.tsv` gives each topic's code, the campaign that
introduced it (`first_campaign`) and its query text.

## The candidate run

A dense retriever under evaluation ran the 48 topics against the merged corpus
after both campaigns had closed. It did not contribute to either pool.
`runs/candidate.tsv` holds its top 50 documents per topic: `topic`, `rank`,
`document`, `score` (the retriever's similarity score, descending).
