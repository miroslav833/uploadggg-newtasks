# Test-collection registry handbook

The registry keeps the pooled retrieval test collections our campaigns have built, so that a
retriever which took part in no campaign can still be scored on them. A collection is a directory
exactly as the campaign office assembled it from the crawls, the judging tool's exports and the
systems' submissions; nothing in it was re-keyed, renamed or reconciled afterwards.

## What a collection holds

| file | columns | what it is |
|---|---|---|
| `campaigns.tsv` | `campaign`, `year`, `scale`, `crawl`, `systems` | the judging campaigns in order; `scale` is 2 (relevant or not) or 3 (0, 1, 2); `crawl` is the crawl the campaign's systems ran against; `systems` the pooled systems, `;`-joined |
| `crawls.tsv` | `crawl`, `order` | the crawls merged into the corpus, oldest first |
| `topics.tsv` | `topic`, `first_campaign`, `query` | each topic and the campaign that introduced it |
| `manifest.tsv` | `document`, `crawl`, `url`, `title`, `words` | every document any other file names: its corpus identifier, the crawl that fetched it, the url and title as that crawl's fetcher recorded them, and the word count of its text as that crawl's extractor counted it |
| `judgments/<campaign>.tsv` | `topic`, `document`, `value` | the campaign's export: a value on the campaign's scale per line |
| `runs/<system>.tsv` | `topic`, `rank`, `document`, `score` | a pooled system's submission, up to 50 documents per topic |
| `published.tsv` | `campaign`, `system`, `topic`, `gain_total` | the campaign's published gain total for each pooled run and topic (below) |
| `candidate.tsv` | `topic`, `rank`, `document`, `score` | the run to be scored, up to 50 documents per topic |

Files are tab-separated with a header; read columns by name. One line of each, as the sample
collection `ashby` holds it:

```
campaigns.tsv   C2026	2026	3	B	S26X;S26S;S26Z
crawls.tsv      B	2
topics.tsv      Q2RJ	C2026	barley ewer archive
manifest.tsv    D00G390	B	https://flint.net/bastion/vellum/7494	Almanac Grange Kestrel - Flint	1038
judgments/C2025.tsv   Q2V7	D0Q6CI0	1
runs/S25H.tsv   Q2V7	1	DMSA6RK	0.9392
published.tsv   C2025	S25H	Q2V7	3.9361
candidate.tsv   Q0GQ	1	DDZCK07	0.9012
```

(The file name at the left is not part of the line; the fields are tab-separated.)

## The corpus

A collection's corpus is the merge of its crawls. The merge kept every fetched page and removed only
byte-identical duplicates, so a page fetched by more than one crawl is in the corpus once per fetch,
each time under its own identifier. The crawls were run by different fetchers at different times,
and each fetcher recorded urls and titles its own way; sites also change between crawls. A judgment
attaches to the page, not to the identifier.

## Judging

Each campaign pooled its systems' top documents per topic and had assessors judge every pooled
document on the campaign's scale by reading it. A page judged by an earlier campaign is not judged
again: when it comes up in a later campaign's pool, the judging tool enters the earlier judgment on
the later campaign's sheet, expressed on that campaign's scale, under whichever identifier the tool
holds for the page. The export of a campaign is its sheet as exported, so it holds the campaign's own
judgments and the entries carried from earlier campaigns alike, and an identifier can appear on more
than one line.

On the registry's scale a document has grade 0, 1 or 2 with gain 0, 1 or 3. A three-level judgment
is the grade. A two-level judgment settles only whether the grade is 0 or above 0.

## Scores

The DCG of a ranked list is the sum over its first 50 positions of the gain at each position divided
by log2(position + 1). nDCG@50 divides it by the DCG of the best possible ordering of the topic's
documents, where a topic's documents are every document the collection's files name for that topic.

A campaign's published gain total for a pooled run is that run's DCG at the campaign's close, with
every document at the lowest grade consistent with the judgments made by then. The published totals
are the registry's record of what each campaign scored; a reading of a collection that does not
reproduce them is wrong.

## Scoring a candidate run

The candidate took part in no campaign, so some of its documents were never judged. Its score is
confined between two bounds: the least and the greatest nDCG@50 over every assignment of grades to
the topic's documents consistent with the collection, where a judged document carries any grade
consistent with its judgment, two identifiers of one page carry the same grade, and any other
document may carry any grade.

An evaluator is run as

```
python3 /app/evaluator/bound_run.py COLLECTION_DIR OUT_CSV
```

and writes `OUT_CSV` with a header row `topic,low,high` and one row per topic of the collection, the
bounds written to 3 decimals. `tools/published_totals.py COLLECTION_DIR GRADES_TSV` recomputes the
published totals from a file of `document`, `grade` lines and prints where they differ, for checking
a reading of a collection.
