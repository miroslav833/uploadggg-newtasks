#!/usr/bin/env python3
"""Recompute a collection's published gain totals from a reading of it, and print where they differ.

    python3 published_totals.py COLLECTION_DIR GRADES_TSV

GRADES_TSV has a header and the columns `topic`, `document`, `grade`: the lowest grade (0, 1 or 2)
your reading gives each document that appears in a pooled run, per topic. Every pooled run of every
campaign is recomputed as DCG over its first 50 positions with gains 0, 1, 3, and compared with
published.tsv. A missing document counts as grade 0.
"""
import csv
import math
import os
import sys

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]


def read_tsv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def main():
    root, grades_path = sys.argv[1], sys.argv[2]
    grades = {}
    for r in read_tsv(grades_path):
        grades[(r["topic"], r["document"])] = int(r["grade"])
    published = {(r["campaign"], r["system"], r["topic"]): float(r["gain_total"])
                 for r in read_tsv(os.path.join(root, "published.tsv"))}
    runs = {}
    for c in read_tsv(os.path.join(root, "campaigns.tsv")):
        for s in c["systems"].split(";"):
            if not s:
                continue
            for r in read_tsv(os.path.join(root, "runs", s + ".tsv")):
                runs.setdefault((c["campaign"], s, r["topic"]), []).append((int(r["rank"]), r["document"]))
    checked = differ = 0
    for key, ranked in sorted(runs.items()):
        if key not in published:
            continue
        total = sum(DISC[r] * GAIN[grades.get((key[2], d), 0)] for r, d in ranked if r <= DEPTH)
        checked += 1
        if not (math.isfinite(total) and math.isfinite(published[key])) or abs(total - published[key]) > 5e-4:
            differ += 1
            print("%s %s %s: published %.4f, yours %.4f" % (key[0], key[1], key[2], published[key], total))
    print("%d pooled run totals checked, %d differ" % (checked, differ))
    sys.exit(1 if differ else 0)


if __name__ == "__main__":
    main()
