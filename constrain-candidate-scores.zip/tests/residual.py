"""The verifier's own forward model: the bounds every topic's run is confined to, rebuilt from the
sealed collection (which documents are the same page, what each campaign judged, and which 2026
lines are the seeded 2025 judgments), not from the reference's code. It optimises by dynamic
programming over the counts of documents raised to each grade, with the ideal DCG a function of
those counts alone."""
import json
import math

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]


def load_collection(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def ideal_dcg(n3, n1):
    total = 0.0
    for pos in range(1, DEPTH + 1):
        if pos <= n3:
            total += 3.0 * DISC[pos]
        elif pos <= n3 + n1:
            total += 1.0 * DISC[pos]
    return total


def page_groups(universe, pairs):
    parent = {d: d for d in universe}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for a, b in pairs:
        if a in parent and b in parent:
            parent[find(a)] = find(b)
    out = {}
    for d in universe:
        out.setdefault(find(d), []).append(d)
    return list(out.values())


def group_grades(topic, docs):
    """The grades the record leaves open for one page: a 2025 judgment (whose seeded 2026 line adds
    nothing) is binary; a genuine 2026 grade is settled; an unjudged page is open."""
    j25, j26, seeded = topic["judged_2025"], topic["judged_2026"], topic["seeded_2026"]
    for d in docs:
        if d in j25 or d in seeded:
            rel = j25[d] if d in j25 else seeded[d]
            return (0,) if rel == 0 else (1, 2)
    for d in docs:
        if d in j26:
            return (j26[d],)
    return (0, 1, 2)


def items_of(topic):
    weight = {}
    for row in topic["run"]:
        weight[row["document"]] = weight.get(row["document"], 0.0) + DISC[row["rank"]]
    universe = (set(weight) | set(topic["judged_2026"]) | set(topic["judged_2025"])
                | set(topic["seeded_2026"]))
    items = []
    for docs in page_groups(universe, topic["same_pages"]):
        items.append((group_grades(topic, docs), sum(weight.get(d, 0.0) for d in docs), len(docs)))
    return items


def extremes(items):
    """Over every assignment: for each (n3, n1) over the whole universe, the greatest and least DCG the
    run can reach, by a table over the open items; then the ratio against the ideal at those counts."""
    fixed_dcg, f3, f1 = 0.0, 0, 0
    open_items = []
    for grades, w, m in items:
        if len(grades) == 1:
            fixed_dcg += w * GAIN[grades[0]]
            f3 += m * (grades[0] == 2)
            f1 += m * (grades[0] == 1)
        else:
            open_items.append((grades, w, m))
    table = {(0, 0): (0.0, 0.0)}
    for grades, w, m in open_items:
        nxt = {}
        for (c3, c1), (hi, lo) in table.items():
            for g in grades:
                key = (c3 + m * (g == 2), c1 + m * (g == 1))
                h2, l2 = hi + w * GAIN[g], lo + w * GAIN[g]
                if key in nxt:
                    nxt[key] = (max(nxt[key][0], h2), min(nxt[key][1], l2))
                else:
                    nxt[key] = (h2, l2)
        table = nxt
    best, worst = -1.0, 2.0
    for (c3, c1), (hi, lo) in table.items():
        denom = ideal_dcg(f3 + c3, f1 + c1)
        best = max(best, (fixed_dcg + hi) / denom)
        worst = min(worst, (fixed_dcg + lo) / denom)
    return worst, best


def reckon(collection):
    return {topic["topic"]: extremes(items_of(topic)) for topic in collection}
