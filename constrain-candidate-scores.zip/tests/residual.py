"""The verifier's own forward model: the bounds every topic's run is confined to, rebuilt from the
sealed collection (which document is the same page as which, and what each campaign judged), not
from the reference's code. It optimises by dynamic programming over the counts of documents raised
to each grade, with the ideal DCG a function of those counts alone."""
import json
import math

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]


def load_collection(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def open_grades(topic, doc):
    """The grades the record leaves open for a judged document: the 2026 grade as judged; a 2025
    'not relevant' at 0; a 2025 'relevant' anywhere between the two relevant grades. None if unjudged."""
    j26, j25 = topic["judged_2026"], topic["judged_2025"]
    if doc in j26:
        return (j26[doc],)
    if doc in j25:
        return (0,) if j25[doc] == 0 else (1, 2)
    return None


def ideal_dcg(n3, n1):
    total = 0.0
    for pos in range(1, DEPTH + 1):
        if pos <= n3:
            total += 3.0 * DISC[pos]
        elif pos <= n3 + n1:
            total += 1.0 * DISC[pos]
    return total


def items_of(topic):
    """(grades, run weight, number of documents) per grade-sharing group of the topic's documents."""
    weight = {}
    for row in topic["run"]:
        weight[row["document"]] = weight.get(row["document"], 0.0) + DISC[row["rank"]]
    universe = set(weight) | set(topic["judged_2026"]) | set(topic["judged_2025"])
    head = {}
    for row in topic["run"]:
        if row["same_page_as"]:
            head[row["document"]] = row["same_page_as"]
    groups = {}
    for d in universe:
        groups.setdefault(head.get(d, d), []).append(d)
    items = []
    for h, docs in groups.items():
        grades = open_grades(topic, h) or (0, 1, 2)
        items.append((grades, sum(weight.get(d, 0.0) for d in docs), len(docs)))
    return items


def extremes(items):
    """Over every assignment: for each (n3, n1) over the whole universe, the greatest and least DCG the
    run can reach, by a table over the open items; then the ratio against the ideal at those counts."""
    fixed_dcg, f3, f1 = 0.0, 0, 0
    open_items = []
    for grades, w, m in items:
        if len(grades) == 1:
            fixed_dcg += w * GAIN[grades[0]]
            f3 += m * (grades[0] == 2)
            f1 += m * (grades[0] == 1)
        else:
            open_items.append((grades, w, m))
    # table[(c3, c1)] = (max dcg, min dcg) over the open items processed so far
    table = {(0, 0): (0.0, 0.0)}
    for grades, w, m in open_items:
        nxt = {}
        for (c3, c1), (hi, lo) in table.items():
            for g in grades:
                key = (c3 + m * (g == 2), c1 + m * (g == 1))
                h2, l2 = hi + w * GAIN[g], lo + w * GAIN[g]
                if key in nxt:
                    nxt[key] = (max(nxt[key][0], h2), min(nxt[key][1], l2))
                else:
                    nxt[key] = (h2, l2)
        table = nxt
    best, worst = -1.0, 2.0
    for (c3, c1), (hi, lo) in table.items():
        denom = ideal_dcg(f3 + c3, f1 + c1)
        best = max(best, (fixed_dcg + hi) / denom)
        worst = min(worst, (fixed_dcg + lo) / denom)
    return worst, best


def reckon(collection):
    return {topic["topic"]: extremes(items_of(topic)) for topic in collection}
