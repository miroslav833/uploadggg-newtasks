"""The verifier's own forward model: the bounds every topic's run is confined to, rebuilt from the
sealed collection (which document is which page, and what each campaign judged), not from the
reference's code."""
import json

P = 0.8
DEPTH = 50
GAIN = {0: 0.0, 1: 0.5, 2: 1.0}


def load_collection(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def open_grades(topic, doc):
    """The grades the record leaves open for a judged document: the 2026 grade as judged; a 2025
    'not relevant' at 0; a 2025 'relevant' anywhere between the two relevant grades. None if unjudged."""
    j26, j25 = topic["judged_2026"], topic["judged_2025"]
    if doc in j26:
        return (j26[doc], j26[doc])
    if doc in j25:
        return (0, 0) if j25[doc] == 0 else (1, 2)
    return None


def reckon(collection):
    out = {}
    for topic in collection:
        lo = hi = 0.0
        for row in topic["run"]:
            grades = open_grades(topic, row["document"])
            if grades is None and row["same_page_as"]:
                grades = open_grades(topic, row["same_page_as"])
            if grades is None:
                grades = (0, 2)
            w = (1 - P) * P ** (row["rank"] - 1)
            lo += w * GAIN[grades[0]]
            hi += w * GAIN[grades[1]]
        out[topic["topic"]] = (lo, hi)
    return out
