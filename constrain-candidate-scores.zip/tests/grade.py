"""Runs /app/evaluator on each held-out collection and scores its bounds against the sealed truth.

The evaluator runs as a numeric account invented for this run, once per collection, on its own copy
of the collection, with a wall-clock budget and an address-space limit. Before anything it wrote is
read, every process that account started is stopped. The truth stays under /tests, root-only.
"""
import csv
import json
import math
import os
import resource
import shutil
import signal
import subprocess
import sys
import time

HELD = "/tests/held"
SCRATCH = "/var/tmp/evaluations"
PROGRAM = "/app/evaluator/bound_run.py"
SECONDS = 120
MEMORY_BYTES = 3 * 1024 ** 3
OUT_CAP = 1 << 20
TOL = 0.005               # on each bound; printed in instruction.md
TOPIC_SHARE = 44          # topics right of 48 for a collection to count; printed in instruction.md
TOPICS = 48


def pick_uid(index):
    """An unprivileged numeric account for one run: the first unused id above 42000 past `index`."""
    used = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                used.add(os.stat("/proc/" + d).st_uid)
            except FileNotFoundError:
                pass
    uid = 42000 + index
    while uid in used or uid < 1000:
        uid += 1
    return uid


def account_pids(uid):
    out = []
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    out.append(int(d))
            except FileNotFoundError:
                pass
    return out


def stop_account(uid):
    quiet = 0
    for _ in range(300):
        pids = account_pids(uid)
        if not pids:
            quiet += 1
            if quiet >= 3:
                return
            time.sleep(0.05)
            continue
        quiet = 0
        for sig in (signal.SIGSTOP, signal.SIGKILL):
            for p in pids:
                try:
                    os.kill(p, sig)
                except ProcessLookupError:
                    pass
        time.sleep(0.05)


def run_evaluator(name, uid):
    work = os.path.join(SCRATCH, name)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, mode=0o755)
    src = os.path.join(work, "collection")
    shutil.copytree(os.path.join(HELD, "collections", name), src, symlinks=False)
    out_dir = os.path.join(work, "out")
    os.makedirs(out_dir)
    for root, dirs, files in os.walk(work):
        os.chown(root, uid, uid)
        for f in files:
            os.chown(os.path.join(root, f), uid, uid)
    out_path = os.path.join(out_dir, "bounds.csv")
    log = open(os.path.join(work, "log.txt"), "wb")

    def demote():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (MEMORY_BYTES, MEMORY_BYTES))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work, "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        proc = subprocess.Popen([sys.executable, PROGRAM, src, out_path], cwd=work, stdout=log, stderr=log,
                                env=env, preexec_fn=demote)
        try:
            proc.wait(timeout=SECONDS)
        except subprocess.TimeoutExpired:
            pass
    except OSError:
        pass
    finally:
        log.close()
    stop_account(uid)
    return out_path


def read_bounds(path):
    """The filed bounds as text: a regular file under the size cap, rows that parse; nothing is run."""
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > OUT_CAP:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
        rows = {}
        try:
            for row in csv.DictReader(fh):
                topic = (row.get("topic") or "").strip()
                if not topic or topic in rows:
                    continue
                try:
                    lo, hi = float((row.get("low") or "").strip()), float((row.get("high") or "").strip())
                except ValueError:
                    continue
                if math.isfinite(lo) and math.isfinite(hi):
                    rows[topic] = (lo, hi)
        except csv.Error:
            return None
    return rows


def topics_right(rows, truth):
    if not rows:
        return 0
    n = 0
    for topic, (lo, hi) in truth.items():
        if topic in rows:
            a, b = rows[topic]
            if math.isfinite(a) and math.isfinite(b) and abs(a - lo) <= TOL and abs(b - hi) <= TOL:
                n += 1
    return n


def grade_all():
    with open(os.path.join(HELD, "truth.json"), encoding="utf-8") as fh:
        truth = json.load(fh)
    os.makedirs(SCRATCH, mode=0o755, exist_ok=True)
    table = []
    for index, name in enumerate(sorted(truth)):
        uid = pick_uid(index)
        out_path = run_evaluator(name, uid)
        rows = read_bounds(out_path)
        right = topics_right(rows, truth[name])
        table.append(dict(collection=name, parsed=rows is not None and len(rows) > 0, topics_right=right,
                          counts=right >= TOPIC_SHARE))
        shutil.rmtree(os.path.join(SCRATCH, name), ignore_errors=True)
    return table


if __name__ == "__main__":
    for row in grade_all():
        print(row)
