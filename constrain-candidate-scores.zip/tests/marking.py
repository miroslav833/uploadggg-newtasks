"""The verifier's reader for the filing. The filing is data: it is parsed, never executed."""
import csv
import math


def _number(cell):
    try:
        return float((cell or "").strip())
    except ValueError:
        return float("nan")


class Filing:
    """One scores.csv: the first row per topic counts; a row that does not parse is wrong."""

    def __init__(self, path=None, rows=None):
        self.rows = {}
        if rows is not None:
            self.rows = {t: (float(a), float(b)) for t, (a, b) in rows.items()}
        if path is not None:
            with open(path, newline="", encoding="utf-8") as fh:
                for row in csv.DictReader(fh):
                    topic = (row.get("topic") or "").strip()
                    if not topic or topic in self.rows:
                        continue
                    self.rows[topic] = (_number(row.get("low")), _number(row.get("high")))

    def right(self, topic, wanted, tol):
        if topic not in self.rows:
            return False
        lo, hi = self.rows[topic]
        if not (math.isfinite(lo) and math.isfinite(hi)):
            return False
        return abs(lo - wanted[0]) <= tol and abs(hi - wanted[1]) <= tol

    def count_right(self, key, tol):
        return sum(1 for topic, wanted in key.items() if self.right(topic, wanted, tol))


def load_key(path):
    """The sealed bounds, topic -> (low, high)."""
    with open(path, newline="", encoding="utf-8") as fh:
        return {r["topic"]: (float(r["low"]), float(r["high"])) for r in csv.DictReader(fh)}
