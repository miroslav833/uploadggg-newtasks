"""Two things are proved on the held-out collections: the evaluator writes bounds that parse for enough
of them, and enough collections are scored right (at least 44 of 48 topics with both bounds within
0.005 of the sealed truth)."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import grade   # noqa: E402

COLLECTIONS = 24
MARK = 22          # collections that count, of 24; printed in instruction.md

_table = None


def table():
    global _table
    if _table is None:
        _table = grade.grade_all()
        with open("/logs/verifier/collections.json", "w", encoding="utf-8") as fh:
            json.dump(_table, fh, indent=1)
    return _table


def test_enough_outputs_parse():
    rows = table()
    assert len(rows) == COLLECTIONS
    assert sum(1 for r in rows if r["parsed"]) >= MARK


def test_enough_collections_scored_right():
    rows = table()
    counted = sum(1 for r in rows if r["counts"])
    assert counted >= MARK, "%d of %d collections counted, %d needed" % (counted, COLLECTIONS, MARK)
