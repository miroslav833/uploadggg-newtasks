#!/bin/bash
# Reward channel: 0 is written before anything runs, 1 only once pytest has passed.
set -u
LOG=/logs/verifier
mkdir -p "$LOG"
chmod 700 "$LOG"
printf '0\n' > "$LOG/reward.txt"
if ( cd /tests && python3 -m pytest test_bounds.py -q -p no:cacheprovider --ctrf "$LOG/ctrf.json" ); then
    printf '1\n' > "$LOG/reward.txt"
fi
exit 0
