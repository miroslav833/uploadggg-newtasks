"""Two things are proved: the sealed bounds are what the verifier's own forward model gives from the
sealed collection, and the filing under /app/out gets enough topics right."""
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import marking    # noqa: E402
import residual   # noqa: E402

ARTIFACT = "/app/out/scores.csv"
TOPICS = 48
MARK = 43            # topics right, of 48; printed in instruction.md
TOL = 0.005          # on each bound; printed in instruction.md


@pytest.fixture(scope="module")
def key():
    return marking.load_key(os.path.join(HERE, "sealed", "bounds.csv"))


def test_bounds_follow_the_forward_model(key):
    model = residual.reckon(residual.load_collection(os.path.join(HERE, "sealed", "collection.json")))
    assert len(key) == TOPICS and set(model) == set(key)
    assert all(math.isfinite(v) for t in key for v in key[t] + model[t])
    off = sorted(t for t in key if abs(key[t][0] - model[t][0]) > 1e-6 or abs(key[t][1] - model[t][1]) > 1e-6)
    assert not off, off


def test_artifact_is_present():
    assert os.path.isfile(ARTIFACT), "nothing at " + ARTIFACT


def test_enough_topics_right(key):
    filed = marking.Filing(ARTIFACT)
    right = filed.count_right(key, TOL)
    assert right >= MARK, "%d of %d topics right, %d needed" % (right, TOPICS, MARK)
