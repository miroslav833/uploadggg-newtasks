#!/usr/bin/env python3
"""Pooled retrieval test collections for the evaluator task.

A collection is a registry directory (see HANDBOOK.md): a merged corpus of one or more crawls, one or
more judging campaigns with their pooled systems' runs and published gain totals, and a candidate run.
`build_collection(spec)` returns the files and the truth (the bounds of the candidate run's nDCG@50
per topic under the registry's semantics). The same code writes the sample collections the agent sees
and the held-out collections the verifier image builds and grades on; the held-out specs use crawl,
export and campaign conventions the samples do not show.
"""
import csv
import json
import math
import os
import random
import string

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(i + 1) for i in range(1, DEPTH + 1)]
CUM = [0.0]
for _i in range(1, DEPTH + 1):
    CUM.append(CUM[-1] + DISC[_i])

WORDS = ("harbour market ledger quarry meadow signal timber copper lantern saddle ridge canal orchard "
         "compass granary furnace parcel beacon anchor tunnel willow saffron marble tallow pulley "
         "cistern archive bridle mortar plinth gable trellis barley shingle rudder spindle "
         "ballast charter ember flint girder hamlet ingot jetty kiln lattice mantle nozzle oriel "
         "paddock quay rampart sluice turret vellum wicket yardarm zephyr almanac brace cobble "
         "drover fathom glazier hearth isthmus joiner keel loam mallet notch outcrop pennant "
         "reeve scythe tiller umber verge warden abacus bastion cairn dovetail estuary ferry "
         "grange heron inlet jute kestrel lintel moor nave ostler pier quern rill stile tarn "
         "usher vane weir yoke acre bellows cask drift ewer forge gorse hive inkwell kelp "
         "lathe mews osier pike ridgeway sett thatch upland vat wold").split()
TLDS = ["org", "net", "com", "info", "co"]

DEFAULT_CRAWL = dict(scheme="http", www=False, slash=False, query=False, case="lower", suffix=None,
                     jitter=0.01, moved=0.0, retitle=0.0, scale=1.0)


def default_spec(**kw):
    spec = dict(
        name="sample", seed=1, n_topics=48, n_systems=3,
        campaigns=[dict(year=2025, scale=2, crawl="A"), dict(year=2026, scale=3, crawl="B")],
        crawls={"A": dict(DEFAULT_CRAWL), "B": dict(DEFAULT_CRAWL, scheme="https", suffix=" - ")},
        refetch=0.35, repeat_identity="newest", short_runs=False, dup_rows=False,
    )
    spec.update(kw)
    return spec


# ---- bounds (the registry's semantics) ---------------------------------------------------------
def idcg(n3, n1):
    a = min(n3, DEPTH)
    b = min(n3 + n1, DEPTH)
    return 3.0 * CUM[a] + (CUM[b] - CUM[a])


def bounds(items):
    """items: (grade set, run weight, multiplicity). Exact min and max nDCG@50 over the open grades.

    The ideal DCG depends only on how many documents carry each grade, so for a given number of
    free single-document items raised to each grade and, per multiplicity class, a given number of
    ranked binary items raised to 2, the run's DCG is largest with the high grades on the heaviest
    items of each class (rearrangement) and smallest with them on the lightest. Unranked binary
    items go to 1 for the high bound and 2 for the low bound."""
    import itertools
    fixed = 0.0
    n3 = n1 = 0
    free, classes, bin0 = [], {}, 0
    for grades, w, m in items:
        if len(grades) == 1:
            fixed += w * GAIN[grades[0]]
            n3 += m * (grades[0] == 2)
            n1 += m * (grades[0] == 1)
        elif grades == (1, 2):
            if w > 0:
                classes.setdefault(m, []).append(w)
            else:
                bin0 += m
        else:
            free.append(w)
    weights = sorted(free, reverse=True)
    pre_desc = [0.0]
    for w in weights:
        pre_desc.append(pre_desc[-1] + w)
    pre_asc = [0.0]
    for w in reversed(weights):
        pre_asc.append(pre_asc[-1] + w)
    k = len(weights)
    cls = []
    for m, ws in classes.items():
        ws = sorted(ws, reverse=True)
        pd = [0.0]
        for w in ws:
            pd.append(pd[-1] + w)
        pa = [0.0]
        for w in reversed(ws):
            pa.append(pa[-1] + w)
        cls.append((m, len(ws), pd, pa))
    cum = CUM
    depth = DEPTH

    def ideal_of(a, b):
        a = a if a < depth else depth
        b = b if b < depth else depth
        return 3.0 * cum[a] + (cum[b] - cum[a])

    best, worst = -1.0, 2.0
    for raised in itertools.product(*[range(n + 1) for _, n, _, _ in cls]):
        hi_b = lo_b = 0.0
        b3 = b1 = 0
        for (m, n, pd, pa), j in zip(cls, raised):
            hi_b += 3.0 * pd[j] + (pd[n] - pd[j])
            lo_b += 3.0 * pa[j] + (pa[n] - pa[j])
            b3 += m * j
            b1 += m * (n - j)
        base3, base1 = n3 + b3, n1 + b1
        for a2 in range(k + 1):
            f3 = base3 + a2
            for a1 in range(k - a2 + 1):
                d = fixed + hi_b + 3.0 * pre_desc[a2] + (pre_desc[a2 + a1] - pre_desc[a2])
                v = d / ideal_of(f3, f3 + base1 + a1 + bin0)
                if v > best:
                    best = v
                d = fixed + lo_b + 3.0 * pre_asc[a2] + (pre_asc[a2 + a1] - pre_asc[a2])
                v = d / ideal_of(f3 + bin0, f3 + bin0 + base1 + a1)
                if v < worst:
                    worst = v
    return worst, best


# ---- the world --------------------------------------------------------------------------------
class Builder:
    def __init__(self, spec):
        self.spec = spec
        self.rng = random.Random(spec["seed"])
        self.crawl_order = []
        seen = set()
        for c in spec["campaigns"]:
            if c["crawl"] not in seen:
                seen.add(c["crawl"])
                self.crawl_order.append(c["crawl"])
        for cid in spec["crawls"]:
            if cid not in seen:
                seen.add(cid)
                self.crawl_order.append(cid)
        self.ids = set()
        self.paths = set()
        self.docs = {}             # identity -> record
        self.hosts = self._hosts()
        self.moved = {}            # (crawl, host) -> new host name for moved sites
        for cid in self.crawl_order[1:]:
            frac = spec["crawls"][cid].get("moved", 0.0)
            for h in self.hosts:
                if self.rng.random() < frac:
                    self.moved[(cid, h)] = self._word() + "-" + self._word() + "." + self.rng.choice(TLDS)
        self.site_name = {h: h.split(".")[0].replace("-", " ").title() for h in self.hosts}
        for (cid, h), nh in self.moved.items():
            self.site_name[nh] = self.site_name[h]
        self.suffix_hosts = set(self.rng.sample(self.hosts, len(self.hosts) // 2))
        # sites whose title template changed by a later crawl: a section name leads every title
        self.retitled = {}
        for cid in self.crawl_order[1:]:
            frac = spec["crawls"][cid].get("retitle", 0.0)
            for h in self.hosts:
                if self.rng.random() < frac:
                    self.retitled[(cid, h)] = self._word().capitalize()
            # a site that migrated to a new domain usually moved to a new system too: new title template
            if spec["crawls"][cid].get("retitle_with_moved"):
                for (c2, h) in self.moved:
                    if c2 == cid:
                        self.retitled[(cid, h)] = self._word().capitalize()

    def _word(self):
        return self.rng.choice(WORDS)

    def _hosts(self):
        hosts = set()
        while len(hosts) < 30:
            hosts.add(self._word() + (("-" + self._word()) if self.rng.random() < 0.4 else "") + "." +
                      self.rng.choice(TLDS))
        return sorted(hosts)

    def new_id(self):
        while True:
            d = "D" + "".join(self.rng.choice(string.ascii_uppercase + string.digits) for _ in range(6))
            if d not in self.ids:
                self.ids.add(d)
                return d

    def new_path(self, host):
        rng = self.rng
        while True:
            style = rng.random()
            if style < 0.4:
                p = "/%s/%s-%s" % (self._word(), self._word(), self._word())
            elif style < 0.7:
                p = "/%d/%s-%s" % (rng.randint(2014, 2026), self._word(), self._word())
            else:
                p = "/%s/%s/%d" % (self._word(), self._word(), rng.randint(100, 9999))
            if (host, p) not in self.paths:
                self.paths.add((host, p))
                return p

    def new_title(self):
        rng = self.rng
        n = rng.randint(3, 6)
        return " ".join(w.capitalize() if i == 0 or rng.random() < 0.5 else w
                        for i, w in enumerate(self._word() for _ in range(n)))

    # a page: (host, path, title, words); identities: one per crawl it was fetched in
    def new_page(self, born):
        host = self.rng.choice(self.hosts)
        page = dict(host=host, path=self.new_path(host), title=self.new_title(),
                    words=max(120, min(4000, int(self.rng.lognormvariate(6.4, 0.6)))), ids={})
        order = self.crawl_order
        start = order.index(born)
        for cid in order[start:]:
            if cid == born or self.rng.random() < self.spec["refetch"]:
                page["ids"][cid] = self._identity(page, cid)
        return page

    def _identity(self, page, cid):
        c = self.spec["crawls"][cid]
        d = self.new_id()
        jitter = 1.0 + self.rng.uniform(-c["jitter"], c["jitter"]) if page["ids"] else 1.0
        words = max(120, int(round(page["words"] * jitter * c.get("scale", 1.0))))
        if page["ids"] and words == page["words"]:
            words += self.rng.choice((-1, 1))
        host = self.moved.get((cid, page["host"]), page["host"])
        shown_host = host
        if c["www"]:
            shown_host = "www." + shown_host
        if c["case"] == "mixed":
            shown_host = "".join(ch.upper() if self.rng.random() < 0.3 else ch for ch in shown_host)
        url = c["scheme"] + "://" + shown_host + page["path"]
        if c["slash"]:
            url += "/"
        if c["query"]:
            url += "?ref=" + self._word()
        title = page["title"]
        if (cid, page["host"]) in self.retitled:
            # the site's new system shows its own heading: a section name, new words, the old title's last word
            title = "%s: %s %s %s" % (self.retitled[(cid, page["host"])], self._word().capitalize(), self._word(),
                                      title.split()[-1])
        if c["suffix"] and page["host"] in self.suffix_hosts:
            title = title + c["suffix"] + self.site_name[host]
        self.docs[d] = dict(doc=d, crawl=cid, url=url, title=title, words=words)
        return d

    def decoy_title(self, page, cid):
        """Another page sharing the title, on another host, far longer or shorter."""
        host = self.rng.choice([h for h in self.hosts if h != page["host"]])
        p = dict(host=host, path=self.new_path(host), title=page["title"], words=self._far(page["words"]), ids={})
        p["ids"][cid] = self._identity(p, cid)
        return p

    def decoy_rewrite(self, page, cid):
        """The same path in a later crawl, but the page was replaced: new title and length."""
        p = dict(host=page["host"], path=page["path"], title=self.new_title(), words=self._far(page["words"]), ids={})
        p["ids"][cid] = self._identity(p, cid)
        return p

    def _far(self, words):
        if words < 400:
            f = self.rng.uniform(1.45, 2.2)
        else:
            f = self.rng.choice((self.rng.uniform(0.35, 0.62), self.rng.uniform(1.45, 2.2)))
        return max(120, int(words * f))

    def _candidate_identity(self, page):
        """The identifier the candidate retriever returns for a page: the newest fetch more often than
        not (its index was built from the whole merged corpus), otherwise any of them."""
        ids = page["ids"]
        newest = ids[max(ids, key=self.crawl_order.index)]
        return newest if self.rng.random() < 0.6 else ids[self.rng.choice(list(ids))]

    # ---- topics ---------------------------------------------------------------------------
    def build(self):
        spec, rng = self.spec, self.rng
        codes = set()
        while len(codes) < spec["n_topics"]:
            codes.add("Q" + "".join(rng.choice(string.ascii_uppercase + string.digits) for _ in range(3)))
        systems = {}
        for c in spec["campaigns"]:
            systems[c["year"]] = ["S%d%s" % (c["year"] % 100, rng.choice(string.ascii_uppercase)) for _ in range(spec["n_systems"])]
            while len(set(systems[c["year"]])) < spec["n_systems"]:
                systems[c["year"]] = ["S%d%s" % (c["year"] % 100, rng.choice(string.ascii_uppercase)) for _ in range(spec["n_systems"])]
        self.systems = systems
        self.topics = [self._topic(code) for code in sorted(codes)]
        return self

    def _topic(self, code):
        spec, rng = self.spec, self.rng
        order = self.crawl_order
        first_year = spec["campaigns"][0]["year"] if rng.random() < 0.55 or len(spec["campaigns"]) == 1 \
            else rng.choice(spec["campaigns"][1:])["year"]
        # pages of the topic, born in some crawl
        pages = []
        for _ in range(rng.randint(90, 150)):
            born = order[0] if rng.random() < 0.7 else rng.choice(order)
            grade = 0 if rng.random() < 0.65 else 1 if rng.random() < 0.55 else 2
            p = self.new_page(born)
            p["grade"] = grade
            pages.append(p)
        judged = {}            # page index -> (year, scale, value)
        exports = {}           # year -> list of (identity, value)
        runs = {}              # (year, system) -> list of identities
        published = {}         # (year, system) -> total
        for camp in spec["campaigns"]:
            if camp["year"] < first_year:
                continue
            cid = camp["crawl"]
            avail = [i for i, p in enumerate(pages) if any(order.index(k) <= order.index(cid) for k in p["ids"])]
            pooled = set()
            for sysname in self.systems[camp["year"]]:
                rel = [i for i in avail if pages[i]["grade"] > 0]
                non = [i for i in avail if pages[i]["grade"] == 0]
                take_rel = rng.sample(rel, min(len(rel), rng.randint(12, 28)))
                take_non = rng.sample(non, min(len(non), DEPTH - len(take_rel)))
                chosen = take_rel + take_non
                rng.shuffle(chosen)
                ids = []
                for i in chosen:
                    ex = [k for k in pages[i]["ids"] if order.index(k) <= order.index(cid)]
                    k = ex[-1] if rng.random() < 0.7 else rng.choice(ex)
                    ids.append((i, pages[i]["ids"][k]))
                runs[(camp["year"], sysname)] = ids
                pooled.update(i for i, _ in ids)
            lines = []
            for i in sorted(pooled):
                p = pages[i]
                ex = [k for k in p["ids"] if order.index(k) <= order.index(cid)]
                if i in judged:
                    year0, scale0, value0 = judged[i]
                    # repeated on this campaign's export, on its own scale
                    if camp["scale"] == 3 and scale0 == 3:
                        v = value0
                    elif camp["scale"] == 3:
                        v = 1 if value0 > 0 else 0
                    else:
                        v = 1 if value0 > 0 else 0
                    targets = {"newest": [ex[-1]], "oldest": [ex[0]], "both": ex}[spec["repeat_identity"]]
                    for k in targets:
                        lines.append((p["ids"][k], v))
                else:
                    v = p["grade"] if camp["scale"] == 3 else (1 if p["grade"] > 0 else 0)
                    judged[i] = (camp["year"], camp["scale"], v)
                    # the pool is a set of pages: each is entered on the sheet once, under the
                    # identifier the judging tool holds for it, whichever identity the systems surfaced
                    # (a tool that carries earlier judgments under every identifier still holds one)
                    held = ex[0] if spec["repeat_identity"] == "oldest" else ex[-1]
                    lines.append((p["ids"][held], v))
            exports[camp["year"]] = lines
            for (yr, sysname), ids in runs.items():
                if yr != camp["year"]:
                    continue
                total = 0.0
                for r, (i, d) in enumerate(ids, start=1):
                    year0, scale0, value0 = judged[i]
                    lowest = value0 if scale0 == 3 else (1 if value0 > 0 else 0)
                    total += DISC[r] * GAIN[lowest]
                published[(yr, sysname)] = total
        # the candidate run
        n_run = DEPTH if not spec["short_runs"] or rng.random() < 0.6 else rng.randint(28, 45)
        judged_idx = [i for i in judged]
        unjudged_idx = [i for i in range(len(pages)) if i not in judged]
        run_ids = []
        used = set()
        n_j = int(round(n_run * rng.uniform(0.45, 0.65)))
        for i in rng.sample(judged_idx, min(len(judged_idx), n_j)):
            p = pages[i]
            run_ids.append(self._candidate_identity(p))          # any identity, judged under it or not
            used.add(i)
        for i in rng.sample(unjudged_idx, min(len(unjudged_idx), n_run - len(run_ids))):
            p = pages[i]
            run_ids.append(self._candidate_identity(p))
        decoy_pages = []
        if rng.random() < 0.5 and len(order) > 1:
            src = pages[rng.choice([i for i in judged if pages[i]["grade"] > 0])]
            later = rng.choice(order[1:])
            for maker in (self.decoy_title, self.decoy_rewrite):
                dp = maker(src, later)
                decoy_pages.append(dp)
                run_ids.append(list(dp["ids"].values())[0])
        while len(run_ids) < n_run:
            p = self.new_page(rng.choice(order))
            p["grade"] = 0
            pages.append(p)
            run_ids.append(self._candidate_identity(p))
        rng.shuffle(run_ids)
        run_ids = run_ids[:n_run]
        s = rng.uniform(0.86, 0.97)
        scores = []
        for _ in range(len(run_ids)):
            scores.append(round(s, 4))
            s -= rng.uniform(0.0015, 0.018)
        # truth: the bounds under the registry's semantics
        ident_page = {}
        for i, p in enumerate(pages):
            for d in p["ids"].values():
                ident_page[d] = i
        for dp in decoy_pages:
            pages.append(dp)
            for d in dp["ids"].values():
                ident_page[d] = len(pages) - 1
        named = set(run_ids)
        for lines in exports.values():
            named.update(d for d, _ in lines)
        for ids in runs.values():
            named.update(d for _, d in ids)
        weight = {}
        for r, d in enumerate(run_ids, start=1):
            weight[d] = weight.get(d, 0.0) + DISC[r]
        groups = {}
        for d in named:
            groups.setdefault(ident_page[d], []).append(d)
        items = []
        for i, docs in groups.items():
            if i in judged:
                year0, scale0, value0 = judged[i]
                grades = (value0,) if scale0 == 3 else ((1, 2) if value0 > 0 else (0,))
            else:
                grades = (0, 1, 2)
            items.append((grades, sum(weight.get(d, 0.0) for d in docs), len(docs)))
        lo, hi = bounds(items)
        return dict(topic=code, first_year=first_year, query=" ".join(self._word() for _ in range(rng.randint(2, 5))),
                    exports=exports, runs=runs, published=published, run=list(zip(run_ids, scores)),
                    low=lo, high=hi, named=named,
                    groups={min(docs): (groups_grades(judged, i), sorted(docs)) for i, docs in groups.items()})


def groups_grades(judged, i):
    if i in judged:
        year0, scale0, value0 = judged[i]
        return (value0,) if scale0 == 3 else ((1, 2) if value0 > 0 else (0,))
    return (0, 1, 2)


# ---- writing ------------------------------------------------------------------------------------
def write_collection(builder, out):
    spec, rng = builder.spec, builder.rng
    os.makedirs(os.path.join(out, "judgments"), exist_ok=True)
    os.makedirs(os.path.join(out, "runs"), exist_ok=True)

    def tsv(path, header, rows):
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh, delimiter="\t", lineterminator="\n")
            w.writerow(header)
            for r in rows:
                w.writerow(r)

    tsv(os.path.join(out, "campaigns.tsv"), ["campaign", "year", "scale", "crawl", "systems"],
        [["C%d" % c["year"], c["year"], c["scale"], c["crawl"], ";".join(builder.systems[c["year"]])]
         for c in spec["campaigns"]])
    tsv(os.path.join(out, "crawls.tsv"), ["crawl", "order"], [[cid, i + 1] for i, cid in enumerate(builder.crawl_order)])
    tsv(os.path.join(out, "topics.tsv"), ["topic", "first_campaign", "query"],
        [[t["topic"], "C%d" % t["first_year"], t["query"]] for t in builder.topics])
    named = set()
    for t in builder.topics:
        named.update(t["named"])
    tsv(os.path.join(out, "manifest.tsv"), ["document", "crawl", "url", "title", "words"],
        [[d, builder.docs[d]["crawl"], builder.docs[d]["url"], builder.docs[d]["title"], builder.docs[d]["words"]]
         for d in sorted(named)])
    for c in spec["campaigns"]:
        rows = []
        for t in builder.topics:
            for d, v in t["exports"].get(c["year"], []):
                rows.append([t["topic"], d, v])
                if spec["dup_rows"] and rng.random() < 0.03:
                    rows.append([t["topic"], d, v])
        rows.sort(key=lambda r: (r[0], r[1]))
        tsv(os.path.join(out, "judgments", "C%d.tsv" % c["year"]), ["topic", "document", "value"], rows)
        for sysname in builder.systems[c["year"]]:
            rows = []
            for t in builder.topics:
                ids = t["runs"].get((c["year"], sysname), [])
                for r, (_, d) in enumerate(ids, start=1):
                    rows.append([t["topic"], r, d, "%.4f" % (0.95 - 0.012 * r + rng.uniform(0, 0.004))])
            tsv(os.path.join(out, "runs", "%s.tsv" % sysname), ["topic", "rank", "document", "score"], rows)
    rows = []
    for c in spec["campaigns"]:
        for sysname in builder.systems[c["year"]]:
            for t in builder.topics:
                if (c["year"], sysname) in t["published"]:
                    rows.append(["C%d" % c["year"], sysname, t["topic"], "%.4f" % t["published"][(c["year"], sysname)]])
    tsv(os.path.join(out, "published.tsv"), ["campaign", "system", "topic", "gain_total"], rows)
    tsv(os.path.join(out, "candidate.tsv"), ["topic", "rank", "document", "score"],
        [[t["topic"], r, d, "%.4f" % s] for t in builder.topics for r, (d, s) in enumerate(t["run"], start=1)])


def truth_of(builder):
    return {t["topic"]: (t["low"], t["high"]) for t in builder.topics}


def build_collection(spec, out):
    b = Builder(spec).build()
    write_collection(b, out)
    return truth_of(b)


# ---- the populations ------------------------------------------------------------------------
def sample_specs():
    """Four collections the agent sees: two crawls (scheme and a ' - Site' suffix), repeats under the
    newest identity; one crawl and one campaign; two three-level campaigns; repeats under the oldest."""
    return [
        default_spec(name="ashby", seed=101, n_topics=12),
        default_spec(name="bowmere", seed=102, n_topics=12, campaigns=[dict(year=2026, scale=3, crawl="A")],
                     crawls={"A": dict(DEFAULT_CRAWL)}),
        default_spec(name="calder", seed=103, n_topics=12,
                     campaigns=[dict(year=2024, scale=3, crawl="A"), dict(year=2026, scale=3, crawl="B")],
                     crawls={"A": dict(DEFAULT_CRAWL), "B": dict(DEFAULT_CRAWL, scheme="https", suffix=" - ")}),
        default_spec(name="dunmore", seed=104, n_topics=12, repeat_identity="oldest",
                     crawls={"A": dict(DEFAULT_CRAWL), "B": dict(DEFAULT_CRAWL, scheme="https")}),
    ]


def graded_specs(base_seed=5000):
    """Twenty-four held-out collections. Every hidden class appears in at least three of them."""
    A = dict(DEFAULT_CRAWL)
    B = lambda **k: dict(DEFAULT_CRAWL, scheme="https", **k)   # noqa: E731
    specs = [
        # trailing slash and www in the later crawl
        dict(crawls={"A": A, "B": B(slash=True, www=True, suffix=" - ")}),
        dict(crawls={"A": A, "B": B(www=True, suffix=" | ")}, repeat_identity="both"),
        # query strings on one crawl, mixed-case hosts
        dict(crawls={"A": dict(A, query=True), "B": B(case="mixed", suffix=" - ")}),
        # moved hosts: url alone cannot pair the copies; retitled sites: title alone cannot either
        dict(crawls={"A": A, "B": B(moved=0.4, suffix=" - ", retitle=0.35)}),
        dict(crawls={"A": A, "B": B(moved=0.5, suffix=" | ", slash=True, retitle=0.3)}, repeat_identity="both"),
        dict(crawls={"A": A, "B": B(moved=0.35, retitle=0.4)}, short_runs=True, dup_rows=True),
        dict(crawls={"A": A, "B": B(moved=0.45, www=True, retitle=0.35)}, repeat_identity="oldest"),
        dict(crawls={"A": dict(A, query=True), "B": B(moved=0.4, suffix=" - ", retitle=0.3)}, short_runs=True),
        # three crawls, three campaigns
        dict(campaigns=[dict(year=2024, scale=2, crawl="A"), dict(year=2025, scale=3, crawl="B"),
                        dict(year=2026, scale=3, crawl="C")],
             crawls={"A": A, "B": B(suffix=" - "), "C": B(suffix=" - ", slash=True)}),
        dict(campaigns=[dict(year=2024, scale=2, crawl="A"), dict(year=2025, scale=2, crawl="B"),
                        dict(year=2026, scale=3, crawl="C")],
             crawls={"A": A, "B": B(www=True), "C": B(www=True, suffix=" | ")}, repeat_identity="oldest"),
        dict(campaigns=[dict(year=2024, scale=3, crawl="A"), dict(year=2025, scale=3, crawl="B"),
                        dict(year=2026, scale=3, crawl="C")],
             crawls={"A": A, "B": B(), "C": B(moved=0.3, retitle=0.3)}, repeat_identity="both"),
        # larger extraction differences between crawls
        dict(crawls={"A": A, "B": B(jitter=0.04, suffix=" - ")}),
        dict(crawls={"A": dict(A, jitter=0.03), "B": B(jitter=0.03, suffix=" | ", query=True)}, short_runs=True),
        # repeats under both identities; short runs; duplicated export rows
        dict(crawls={"A": A, "B": B(suffix=" - ")}, repeat_identity="both", dup_rows=True),
        # two-level campaign after a three-level one is never built (a campaign never coarsens); instead
        # a three-level first campaign with a two-level second one on another crawl convention
        dict(campaigns=[dict(year=2025, scale=3, crawl="A"), dict(year=2026, scale=2, crawl="B")],
             crawls={"A": A, "B": B(moved=0.3, retitle=0.35)}, repeat_identity="both"),
        # single crawl, two campaigns (no copies at all; only the scales)
        # the sample conventions with high refetch
        dict(refetch=0.6, crawls={"A": dict(A, www=True), "B": B(www=True, suffix=" | ", moved=0.25)}, repeat_identity="oldest"),
        # a newer crawl D that the candidate indexed and no campaign pooled: its conventions are
        # learnable only from the manifest, never from the pool or the published totals
        dict(crawls={"A": A, "B": B(suffix=" - "), "D": B(www=True, suffix=" | ", moved=0.45, retitle_with_moved=True)}),
        dict(crawls={"A": A, "B": B(suffix=" - "), "D": B(slash=True, scale=1.12, moved=0.45, retitle_with_moved=True)},
             repeat_identity="oldest"),
        dict(crawls={"A": A, "B": B(), "D": B(query=True, suffix=" | ", moved=0.4, retitle_with_moved=True, retitle=0.2, scale=0.9)},
             short_runs=True),
        dict(campaigns=[dict(year=2025, scale=3, crawl="A"), dict(year=2026, scale=3, crawl="B")],
             crawls={"A": A, "B": B(suffix=" - "), "D": B(www=True, moved=0.5, retitle_with_moved=True, scale=1.08)}),
        dict(campaigns=[dict(year=2026, scale=3, crawl="A")],
             crawls={"A": A, "D": B(suffix=" | ", moved=0.45, retitle_with_moved=True)}),
        dict(campaigns=[dict(year=2026, scale=2, crawl="A")],
             crawls={"A": A, "D": B(case="mixed", slash=True, moved=0.45, retitle_with_moved=True, scale=1.15)}, dup_rows=True),
        dict(crawls={"A": A, "B": B(suffix=" - "), "D": B(suffix=" - ", moved=0.5, retitle_with_moved=True, retitle=0.2)},
             repeat_identity="both"),
        dict(refetch=0.6, crawls={"A": A, "B": B(suffix=" - "), "D": B(www=True, slash=True, moved=0.45, retitle_with_moved=True, scale=1.1)}),
    ]
    out = []
    for i, s in enumerate(specs):
        out.append(default_spec(name="H%02d" % (i + 1), seed=base_seed + 7 * i, **s))
    return out


def build_many(specs, out_dir, truth_path):
    truth = {}
    for spec in specs:
        truth[spec["name"]] = build_collection(spec, os.path.join(out_dir, spec["name"]))
    os.makedirs(os.path.dirname(truth_path) or ".", exist_ok=True)
    with open(truth_path, "w", encoding="utf-8") as fh:
        json.dump(truth, fh)
    return truth


if __name__ == "__main__":
    import sys
    what, out_dir, truth_path = sys.argv[1], sys.argv[2], sys.argv[3]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 5000
    specs = sample_specs() if what == "samples" else graded_specs(seed)
    build_many(specs, out_dir, truth_path)
    print("built", len(specs), "collections under", out_dir)
