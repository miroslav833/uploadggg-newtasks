#!/bin/bash
python3 "$(dirname "$0")/constrain_scores.py" /app
