#!/usr/bin/env bash
# Installs the reference evaluator at /app/evaluator and runs it on the sample collections.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/evaluator /app/out
cp "$HERE/evaluator/bound_run.py" /app/evaluator/bound_run.py
for c in /app/registry/collections/*/; do
    name="$(basename "$c")"
    python3 /app/evaluator/bound_run.py "$c" "/app/out/$name.csv"
done
