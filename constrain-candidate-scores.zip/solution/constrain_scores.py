#!/usr/bin/env python3
"""Reference for constrain-candidate-scores: the lowest and highest nDCG@50 the candidate run can reach
on each topic over every grading consistent with the record, from the shipped files only.

The honest path, in the order a collection curator takes it:
  1. read the manifest and find the pages the merge kept twice: the same host and path under the
     http (crawl A) and https (crawl B) identities, with the same text length to within a few per
     cent (crawl B's titles may carry the site name; the length and the path decide);
  2. group every document of the topic (judged or ranked) with its other identity, since one page
     carries one grade;
  3. the grades the record leaves open to each group: a group holding a 2025 judgment is binary (a
     2025 'relevant' is 1 or 2, a 'not relevant' is 0); the 2026 sheet's line for that page, under
     either identity, is the seeded copy of that same judgment and says nothing more, which is why
     the 2026 file lists the crawl-A identifier only where the page has no crawl-B copy; a group
     with a genuine 2026 grade is settled; anything else is 0, 1 or 2;
  4. the ideal ranking moves with the open grades, so the bounds are a joint optimisation: for
     each count of free groups raised to grade 2 and to grade 1, the run's DCG is largest with
     the high grades on its highest-ranked free documents (smallest with them on its lowest), the
     ideal depends only on the counts, unranked binary pages go to whichever grade moves the ideal
     the right way, and the few ranked binary groups are enumerated outright.
"""
import csv
import itertools
import math
import os
import sys

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]
CUM = [0.0]
for _r in range(1, DEPTH + 1):
    CUM.append(CUM[-1] + DISC[_r])


def read_tsv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def page_key(url):
    u = url.strip()
    for scheme in ("https://", "http://"):
        if u.startswith(scheme):
            u = u[len(scheme):]
    return u.rstrip("/")


def base_title(title):
    return title.rsplit(" - ", 1)[0].strip() if " - " in title else title.strip()


def same_pages(manifest, match="path", words_tol=0.05):
    """document -> the documents that are the same page under the other crawl's identity."""
    groups = {}
    for r in manifest:
        if match in ("path", "path-only"):
            k = page_key(r["url"])
        elif match in ("title", "title-words"):
            k = base_title(r["title"])
        elif match == "title-raw":
            k = r["title"].strip()
        else:
            continue
        groups.setdefault(k, []).append(r)
    same = {}
    for rows in groups.values():
        for a in rows:
            for b in rows:
                if a is b or a["crawl"] == b["crawl"]:
                    continue
                if match in ("path", "title-words"):
                    wa, wb = int(a["words"]), int(b["words"])
                    if abs(wa - wb) > words_tol * max(wa, wb):
                        continue
                same.setdefault(a["document"], []).append(b["document"])
    return same


def page_groups(universe, same):
    parent = {d: d for d in universe}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for d in universe:
        for other in same.get(d, []):
            if other in parent:
                parent[find(d)] = find(other)
    out = {}
    for d in universe:
        out.setdefault(find(d), []).append(d)
    return list(out.values())


def group_grades(topic, docs, j26, j25, binary="open", seeding="group"):
    """The grades a page group may carry under the record."""
    rels = [j25[(topic, d)] for d in docs if (topic, d) in j25]
    g26 = [j26[(topic, d)] for d in docs if (topic, d) in j26]
    sets = []
    if seeding == "group" and rels:
        # the 2026 line for this page (either identity) is the seeded 2025 judgment
        sets.append(_binary(rels[0], binary))
    else:
        for d in docs:
            if (topic, d) in j25:
                sets.append(_binary(j25[(topic, d)], binary))
                if seeding == "overlap" and (topic, d) in j26:
                    continue            # the same identifier in both files: seeded, says nothing more
            if (topic, d) in j26:
                if seeding == "all-reused-ones" and j26[(topic, d)] == 1:
                    sets.append((1, 2))
                else:
                    sets.append((j26[(topic, d)],))
    if binary == "ignore":
        sets = [s for s in sets if s is not None]
    if not sets:
        return (0, 1, 2)
    grades = set(sets[0])
    for s in sets[1:]:
        grades &= set(s)
    return tuple(sorted(grades)) or tuple(sorted(sets[0]))


def _binary(rel, binary):
    if binary == "ignore":
        return None
    if rel == 0:
        return (0,)
    return {"open": (1, 2), "one": (1,), "two": (2,)}[binary]


def ideal(n3, n1):
    a = min(n3, DEPTH)
    b = min(n3 + n1, DEPTH)
    return 3.0 * CUM[a] + (CUM[b] - CUM[a])


def optimise(items, mode="exact"):
    """items: (grades, run weight, multiplicity). Returns (min, max) nDCG@50 over the open grades."""
    fixed = 0.0
    n3 = n1 = 0
    free, binw, bin0 = [], [], 0
    for grades, w, m in items:
        if len(grades) == 1:
            fixed += w * GAIN[grades[0]]
            n3 += m * (grades[0] == 2)
            n1 += m * (grades[0] == 1)
        elif grades == (1, 2):
            if w > 0:
                binw.append((w, m))
            else:
                bin0 += m
        else:
            free.append((w, m))
    if mode in ("monotone", "fixed-ideal"):
        lo_dcg = fixed + sum(w * 1.0 for w, _ in binw)
        hi_dcg = fixed + sum(w * 3.0 for w, _ in binw) + sum(w * 3.0 for w, _ in free)
        if mode == "fixed-ideal":
            i_lo = i_hi = ideal(n3, n1 + sum(m for _, m in binw) + bin0)
        else:
            i_lo = ideal(n3, n1 + sum(m for _, m in binw) + bin0)
            i_hi = ideal(n3 + sum(m for _, m in binw) + bin0 + sum(m for _, m in free), n1)
        return lo_dcg / i_lo, hi_dcg / i_hi
    # free groups of several documents are not produced by this record; treat each as one document
    weights = sorted((w for w, _ in free), reverse=True)
    pre_desc = [0.0]
    for w in weights:
        pre_desc.append(pre_desc[-1] + w)
    pre_asc = [0.0]
    for w in reversed(weights):
        pre_asc.append(pre_asc[-1] + w)
    k = len(weights)
    best, worst = -1.0, 2.0
    for choice in itertools.product((1, 2), repeat=len(binw)):
        bdcg = sum(w * GAIN[g] for (w, _), g in zip(binw, choice))
        b3 = sum(m for (_, m), g in zip(binw, choice) if g == 2)
        b1 = sum(m for (_, m), g in zip(binw, choice) if g == 1)
        for a2 in range(k + 1):
            for a1 in range(k - a2 + 1):
                dcg = fixed + bdcg + 3.0 * pre_desc[a2] + (pre_desc[a2 + a1] - pre_desc[a2])
                best = max(best, dcg / ideal(n3 + b3 + a2, n1 + b1 + a1 + bin0))
                dcg = fixed + bdcg + 3.0 * pre_asc[a2] + (pre_asc[a2 + a1] - pre_asc[a2])
                worst = min(worst, dcg / ideal(n3 + b3 + a2 + bin0, n1 + b1 + a1))
    return worst, best


def solve(app, match="path", words_tol=0.05, binary="open", decimals=3, use_same=True, mode="exact",
          seeding="group", unranked_binary="open"):
    manifest = read_tsv(os.path.join(app, "corpus", "manifest.tsv"))
    same = same_pages(manifest, match, words_tol) if use_same else {}
    j26 = {(r["topic"], r["document"]): int(r["grade"])
           for r in read_tsv(os.path.join(app, "judgments", "2026.tsv"))}
    j25 = {(r["topic"], r["document"]): int(r["rel"])
           for r in read_tsv(os.path.join(app, "judgments", "2025.tsv"))}
    run = {}
    for r in read_tsv(os.path.join(app, "runs", "candidate.tsv")):
        run.setdefault(r["topic"], {})[r["document"]] = DISC[int(r["rank"])]
    judged = {}
    for (t, d) in list(j26) + list(j25):
        judged.setdefault(t, set()).add(d)
    out = {}
    for topic, weights in run.items():
        universe = set(weights) | judged.get(topic, set())
        items = []
        for docs in page_groups(universe, same):
            grades = group_grades(topic, docs, j26, j25, binary, seeding)
            w = sum(weights.get(d, 0.0) for d in docs)
            if grades == (1, 2) and w == 0 and unranked_binary == "one":
                grades = (1,)
            items.append((grades, w, len(docs)))
        lo, hi = optimise(items, mode)
        out[topic] = (round(lo, decimals), round(hi, decimals))
    return out


def main():
    app = sys.argv[1] if len(sys.argv) > 1 else "/app"
    out = solve(app)
    os.makedirs(os.path.join(app, "out"), exist_ok=True)
    with open(os.path.join(app, "out", "scores.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["topic", "low", "high"])
        for topic in sorted(out):
            w.writerow([topic, "%.3f" % out[topic][0], "%.3f" % out[topic][1]])


if __name__ == "__main__":
    main()
