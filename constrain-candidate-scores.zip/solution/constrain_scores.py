#!/usr/bin/env python3
"""Reference for constrain-candidate-scores: the lowest and highest nDCG@50 the candidate run can reach
on each topic over every grading consistent with the record, from the shipped files only.

The honest path, in the order a collection curator takes it:
  1. read the manifest and find the pages the merge kept twice: the same host and path under the
     http (crawl A) and https (crawl B) identities, with the same text length to within a few per
     cent (crawl B's titles may carry the site name; the length and the path decide);
  2. for every document of the topic (judged or ranked), the grades the record leaves open: the 2026
     grade as judged; a 2025 'not relevant' at 0; a 2025 'relevant' at 1 or 2, since that scale did
     not distinguish them; a page's second copy at whatever its judged copy carries; anything else
     at 0, 1 or 2;
  3. the ideal ranking moves with the open grades, so the bounds are a joint optimisation and not a
     per-document min and max: for each count of open documents raised to grade 2 and to grade 1,
     the run's DCG is largest with the high grades on its highest-ranked open documents (and
     smallest with them on its lowest-ranked ones), the ideal DCG depends only on the counts, and
     judged-but-unranked 'relevant' documents are set to whichever grade moves the ideal the right
     way; the few open pairs that share a grade are enumerated outright.
"""
import csv
import itertools
import math
import os
import sys

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]
CUM = [0.0]
for _r in range(1, DEPTH + 1):
    CUM.append(CUM[-1] + DISC[_r])


def read_tsv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def page_key(url):
    u = url.strip()
    for scheme in ("https://", "http://"):
        if u.startswith(scheme):
            u = u[len(scheme):]
    return u.rstrip("/")


def base_title(title):
    return title.rsplit(" - ", 1)[0].strip() if " - " in title else title.strip()


def same_pages(manifest, match="path", words_tol=0.05):
    """document -> the documents that are the same page under the other crawl's identity."""
    groups = {}
    for r in manifest:
        if match in ("path", "path-only"):
            k = page_key(r["url"])
        elif match in ("title", "title-words"):
            k = base_title(r["title"])
        elif match == "title-raw":
            k = r["title"].strip()
        else:
            continue
        groups.setdefault(k, []).append(r)
    same = {}
    for rows in groups.values():
        for a in rows:
            for b in rows:
                if a is b or a["crawl"] == b["crawl"]:
                    continue
                if match in ("path", "title-words"):
                    wa, wb = int(a["words"]), int(b["words"])
                    if abs(wa - wb) > words_tol * max(wa, wb):
                        continue
                same.setdefault(a["document"], []).append(b["document"])
    return same


def open_grades(topic, doc, j26, j25, binary="open"):
    """The grades a judged document may carry, or None when it is unjudged for the topic."""
    if (topic, doc) in j26:
        return (j26[(topic, doc)],)
    if (topic, doc) in j25:
        if binary == "ignore":
            return None
        if j25[(topic, doc)] == 0:
            return (0,)
        return {"open": (1, 2), "one": (1,), "two": (2,)}[binary]
    return None


def ideal(n3, n1, cut=DEPTH):
    a = min(n3, cut)
    b = min(n3 + n1, cut)
    return 3.0 * CUM[a] + (CUM[b] - CUM[a])


def optimise(items, mode="exact"):
    """items: (grades, run weight, multiplicity). Returns (min, max) nDCG@50 over the open grades.
    mode 'monotone': every open item at its least for the low and its greatest for the high, with the
    ideal taken under that same assignment. mode 'fixed-ideal': the ideal from judged grades only."""
    fixed = 0.0
    n3 = n1 = 0
    free, binw, bin0 = [], [], 0
    for grades, w, m in items:
        if len(grades) == 1:
            fixed += w * GAIN[grades[0]]
            n3 += m * (grades[0] == 2)
            n1 += m * (grades[0] == 1)
        elif grades == (1, 2):
            if w > 0:
                binw.append((w, m))
            else:
                bin0 += m
        else:
            free.append((w, m))
    if mode in ("monotone", "fixed-ideal"):
        lo_dcg = fixed + sum(w * 1.0 for w, _ in binw)
        hi_dcg = fixed + sum(w * 3.0 for w, _ in binw) + sum(w * 3.0 for w, _ in free)
        if mode == "fixed-ideal":
            i_lo = i_hi = ideal(n3, n1 + sum(m for _, m in binw) + bin0)
        else:
            i_lo = ideal(n3, n1 + sum(m for _, m in binw) + bin0)
            i_hi = ideal(n3 + sum(m for _, m in binw) + bin0 + sum(m for _, m in free), n1)
        return lo_dcg / i_lo, hi_dcg / i_hi
    weights = sorted((w for w, _ in free), reverse=True)
    pre_desc = [0.0]
    for w in weights:
        pre_desc.append(pre_desc[-1] + w)
    pre_asc = [0.0]
    for w in reversed(weights):
        pre_asc.append(pre_asc[-1] + w)
    k = len(weights)
    best, worst = -1.0, 2.0
    for choice in itertools.product((1, 2), repeat=len(binw)):
        bdcg = sum(w * GAIN[g] for (w, _), g in zip(binw, choice))
        b3 = sum(m for (_, m), g in zip(binw, choice) if g == 2)
        b1 = sum(m for (_, m), g in zip(binw, choice) if g == 1)
        for a2 in range(k + 1):
            for a1 in range(k - a2 + 1):
                dcg = fixed + bdcg + 3.0 * pre_desc[a2] + (pre_desc[a2 + a1] - pre_desc[a2])
                best = max(best, dcg / ideal(n3 + b3 + a2, n1 + b1 + a1 + bin0))
                dcg = fixed + bdcg + 3.0 * pre_asc[a2] + (pre_asc[a2 + a1] - pre_asc[a2])
                worst = min(worst, dcg / ideal(n3 + b3 + a2 + bin0, n1 + b1 + a1))
    return worst, best


def solve(app, match="path", words_tol=0.05, binary="open", decimals=3, use_same=True, mode="exact",
          unranked_binary="open"):
    manifest = read_tsv(os.path.join(app, "corpus", "manifest.tsv"))
    same = same_pages(manifest, match, words_tol) if use_same else {}
    j26 = {(r["topic"], r["document"]): int(r["grade"])
           for r in read_tsv(os.path.join(app, "judgments", "2026.tsv"))}
    j25 = {(r["topic"], r["document"]): int(r["rel"])
           for r in read_tsv(os.path.join(app, "judgments", "2025.tsv"))}
    run = {}
    for r in read_tsv(os.path.join(app, "runs", "candidate.tsv")):
        run.setdefault(r["topic"], {})[r["document"]] = DISC[int(r["rank"])]
    judged = {}
    for (t, d) in list(j26) + list(j25):
        judged.setdefault(t, set()).add(d)
    out = {}
    for topic, weights in run.items():
        universe = set(weights) | judged.get(topic, set())
        # the same page under two identities shares one grade: group by the judged copy
        head = {}
        for d in universe:
            h = d
            if open_grades(topic, d, j26, j25, binary) is None:
                for other in same.get(d, []):
                    if other in universe and open_grades(topic, other, j26, j25, binary) is not None:
                        h = other
                        break
            head[d] = h
        groups = {}
        for d, h in head.items():
            groups.setdefault(h, []).append(d)
        items = []
        for h, docs in groups.items():
            grades = open_grades(topic, h, j26, j25, binary) or (0, 1, 2)
            w = sum(weights.get(d, 0.0) for d in docs)
            if grades == (1, 2) and w == 0 and unranked_binary == "one":
                grades = (1,)
            items.append((grades, w, len(docs)))
        lo, hi = optimise(items, mode)
        out[topic] = (round(lo, decimals), round(hi, decimals))
    return out


def main():
    app = sys.argv[1] if len(sys.argv) > 1 else "/app"
    out = solve(app)
    os.makedirs(os.path.join(app, "out"), exist_ok=True)
    with open(os.path.join(app, "out", "scores.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["topic", "low", "high"])
        for topic in sorted(out):
            w.writerow([topic, "%.3f" % out[topic][0], "%.3f" % out[topic][1]])


if __name__ == "__main__":
    main()
