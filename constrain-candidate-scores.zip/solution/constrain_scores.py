#!/usr/bin/env python3
"""Reference for constrain-candidate-scores: the lowest and highest rank-biased precision the candidate
run can reach on each topic, from the shipped files only.

The honest path, in the order a collection curator takes it:
  1. read the manifest and find the pages the merge kept twice: the same host and path under the
     http (crawl A) and https (crawl B) identities, with the same text length to within a few per
     cent (crawl B's titles may carry the site name; the length and the path decide);
  2. for each ranked document, settle its grade from the 2026 judgments (the three-level scale as
     recorded), from the 2025 judgments (not relevant is 0; relevant is 1 or 2, since the 2025
     scale did not distinguish them), or from the judgment of the same page under its other
     identity; anything else is open between 0 and 2;
  3. sum the rank-biased weights with every open grade at its least and at its greatest.
"""
import csv
import os
import sys

P = 0.8
GAIN = {0: 0.0, 1: 0.5, 2: 1.0}


def read_tsv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def page_key(url):
    u = url.strip()
    for scheme in ("https://", "http://"):
        if u.startswith(scheme):
            u = u[len(scheme):]
    return u.rstrip("/")


def base_title(title):
    return title.rsplit(" - ", 1)[0].strip() if " - " in title else title.strip()


def same_pages(manifest, match="path", words_tol=0.05):
    """document -> the documents that are the same page under the other crawl's identity."""
    groups = {}
    for r in manifest:
        if match in ("path", "path-only"):
            k = page_key(r["url"])
        elif match in ("title", "title-words"):
            k = base_title(r["title"])
        elif match == "title-raw":
            k = r["title"].strip()
        else:
            continue
        groups.setdefault(k, []).append(r)
    same = {}
    for rows in groups.values():
        for a in rows:
            for b in rows:
                if a is b or a["crawl"] == b["crawl"]:
                    continue
                if match in ("path", "title-words"):
                    wa, wb = int(a["words"]), int(b["words"])
                    if abs(wa - wb) > words_tol * max(wa, wb):
                        continue
                same.setdefault(a["document"], []).append(b["document"])
    return same


def grade_range(topic, doc, j26, j25, same, binary="open"):
    """(lo, hi) on the 0-2 scale, or None when the record says nothing about this document."""
    if (topic, doc) in j26:
        g = j26[(topic, doc)]
        return (g, g)
    if (topic, doc) in j25:
        if binary == "ignore":
            return None
        if j25[(topic, doc)] == 0:
            return (0, 0)
        return {"open": (1, 2), "one": (1, 1), "two": (2, 2)}[binary]
    return None


def solve(app, match="path", words_tol=0.05, binary="open", decimals=3, use_same=True):
    manifest = read_tsv(os.path.join(app, "corpus", "manifest.tsv"))
    same = same_pages(manifest, match, words_tol) if use_same else {}
    j26 = {(r["topic"], r["document"]): int(r["grade"])
           for r in read_tsv(os.path.join(app, "judgments", "2026.tsv"))}
    j25 = {(r["topic"], r["document"]): int(r["rel"])
           for r in read_tsv(os.path.join(app, "judgments", "2025.tsv"))}
    run = {}
    for r in read_tsv(os.path.join(app, "runs", "candidate.tsv")):
        run.setdefault(r["topic"], []).append((int(r["rank"]), r["document"]))
    out = {}
    for topic, rows in run.items():
        lo = hi = 0.0
        for rank, doc in sorted(rows):
            rng = grade_range(topic, doc, j26, j25, same, binary)
            if rng is None:
                for other in same.get(doc, []):
                    rng = grade_range(topic, other, j26, j25, same, binary)
                    if rng is not None:
                        break
            if rng is None:
                rng = (0, 2)
            w = (1 - P) * P ** (rank - 1)
            lo += w * GAIN[rng[0]]
            hi += w * GAIN[rng[1]]
        out[topic] = (round(lo, decimals), round(hi, decimals))
    return out


def main():
    app = sys.argv[1] if len(sys.argv) > 1 else "/app"
    out = solve(app)
    os.makedirs(os.path.join(app, "out"), exist_ok=True)
    with open(os.path.join(app, "out", "scores.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["topic", "low", "high"])
        for topic in sorted(out):
            w.writerow([topic, "%.3f" % out[topic][0], "%.3f" % out[topic][1]])


if __name__ == "__main__":
    main()
