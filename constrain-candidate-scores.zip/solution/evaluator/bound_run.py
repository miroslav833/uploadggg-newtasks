#!/usr/bin/env python3
"""Evaluator: the bounds of a candidate run's nDCG@50 on a pooled test collection.

    python3 bound_run.py COLLECTION_DIR OUT_CSV

The evaluator never assumes how a crawl wrote its urls or titles, or under which identifier a
judging tool carried an earlier judgment. It reads the collection, forms candidate readings of
"which identifiers are one page" from strict to loose (url with the scheme dropped; then with www,
a trailing slash, letter case and query strings dropped; then title and length; then path, title
and length for pages whose site moved), with the word-count tolerance widened step by step, and
keeps the first reading that reproduces every published gain total of the collection's pooled runs.
Under that reading, each page's grades are those the earliest campaign to judge it left open (a
two-level judgment leaves the two relevant grades open; later sheets only carry it), and the bounds
are an exact optimisation over the open grades, the ideal ranking moving with them.

Switches (ARGS after OUT_CSV, for the ablations in the task's metadata; the default is the full
evaluator): identity=scheme|www|slash|case|query|title|moved  words=0.015|...  nosearch  carried=exact
mode=monotone|fixed-ideal
"""
import csv
import itertools
import math
import os
import re
import sys

DEPTH = 50
GAIN = {0: 0.0, 1: 1.0, 2: 3.0}
DISC = [0.0] + [1.0 / math.log2(r + 1) for r in range(1, DEPTH + 1)]
CUM = [0.0]
for _r in range(1, DEPTH + 1):
    CUM.append(CUM[-1] + DISC[_r])


def read_tsv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


# ---- the collection ---------------------------------------------------------------------------
class Collection:
    def __init__(self, root):
        self.root = root
        self.campaigns = read_tsv(os.path.join(root, "campaigns.tsv"))
        self.campaigns.sort(key=lambda c: int(c["year"]))
        self.manifest = {r["document"]: r for r in read_tsv(os.path.join(root, "manifest.tsv"))}
        self.judgments = {}       # campaign -> {(topic, doc): value}
        for c in self.campaigns:
            d = {}
            for r in read_tsv(os.path.join(root, "judgments", c["campaign"] + ".tsv")):
                d[(r["topic"], r["document"])] = int(r["value"])
            self.judgments[c["campaign"]] = d
        self.runs = {}            # system -> {topic: [(rank, doc)]}
        for c in self.campaigns:
            for s in c["systems"].split(";"):
                if s and s not in self.runs:
                    self.runs[s] = self._run(os.path.join(root, "runs", s + ".tsv"))
        self.published = {}
        for r in read_tsv(os.path.join(root, "published.tsv")):
            self.published[(r["campaign"], r["system"], r["topic"])] = float(r["gain_total"])
        self.candidate = self._run(os.path.join(root, "candidate.tsv"))
        self.topics = [r["topic"] for r in read_tsv(os.path.join(root, "topics.tsv"))]

    @staticmethod
    def _run(path):
        out = {}
        for r in read_tsv(path):
            out.setdefault(r["topic"], []).append((int(r["rank"]), r["document"]))
        for t in out:
            out[t].sort()
        return out


# ---- identity readings ------------------------------------------------------------------------
LEVELS = ["scheme", "www", "slash", "case", "query", "title", "moved"]
SUFFIXES = [" - ", " | ", " :: ", " – "]


def url_key(url, level):
    u = url.strip()
    u = re.sub(r"^[a-z]+://", "", u, flags=re.I)
    rank = LEVELS.index(level)
    if rank >= LEVELS.index("query"):
        u = u.split("?", 1)[0]
    if rank >= LEVELS.index("case"):
        host, _, path = u.partition("/")
        u = host.lower() + "/" + path
    if rank >= LEVELS.index("slash"):
        u = u.rstrip("/")
    if rank >= LEVELS.index("www"):
        u = re.sub(r"^www\.", "", u, flags=re.I)
    return u


def base_title(title):
    t = title.strip()
    for s in SUFFIXES:
        if s in t:
            t = t.rsplit(s, 1)[0].strip()
    return t


def path_of(url):
    u = re.sub(r"^[a-z]+://", "", url.strip(), flags=re.I).split("?", 1)[0]
    return u.partition("/")[2].rstrip("/")


def same_pages(manifest, level, words_tol):
    """identifier -> identifiers that are the same page under this reading."""
    rank = LEVELS.index(level)
    keys = {}
    for d, r in manifest.items():
        ks = [("u", url_key(r["url"], level if rank < LEVELS.index("title") else "query"))]
        if rank >= LEVELS.index("title"):
            ks.append(("t", base_title(r["title"]).lower()))
        if rank >= LEVELS.index("moved"):
            ks.append(("p", path_of(r["url"]).lower() + "#" + base_title(r["title"]).lower()))
        for k in ks:
            keys.setdefault(k, []).append(d)
    same = {}
    for k, docs in keys.items():
        if len(docs) < 2:
            continue
        for a in docs:
            for b in docs:
                if a == b or manifest[a]["crawl"] == manifest[b]["crawl"]:
                    continue
                if k[0] == "u" and rank < LEVELS.index("title") and words_tol >= 1.0:
                    pass
                wa, wb = int(manifest[a]["words"]), int(manifest[b]["words"])
                if abs(wa - wb) > words_tol * max(wa, wb):
                    continue
                same.setdefault(a, set()).add(b)
    return same


def groups_of(universe, same):
    parent = {d: d for d in universe}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    for d in universe:
        for o in same.get(d, ()):
            if o in parent:
                parent[find(d)] = find(o)
    out = {}
    for d in universe:
        out.setdefault(find(d), []).append(d)
    return list(out.values())


# ---- grades under a reading ------------------------------------------------------------------
def grades_of(coll, topic, docs, carried="earliest"):
    """The grades a page may carry: from the earliest campaign that judged any of its identifiers."""
    for c in coll.campaigns:
        vals = [coll.judgments[c["campaign"]][(topic, d)] for d in docs if (topic, d) in coll.judgments[c["campaign"]]]
        if vals:
            v = vals[0]
            if carried == "exact":
                # every sheet's entry taken as an exact grade on that sheet's scale, intersected
                sets = []
                for c2 in coll.campaigns:
                    for d in docs:
                        if (topic, d) in coll.judgments[c2["campaign"]]:
                            v2 = coll.judgments[c2["campaign"]][(topic, d)]
                            sets.append({v2} if c2["scale"] == "3" else ({0} if v2 == 0 else {1, 2}))
                g = set.intersection(*sets)
                return tuple(sorted(g)) or (v,)
            if c["scale"] == "3":
                return (v,)
            return (0,) if v == 0 else (1, 2)
    return (0, 1, 2)


def lowest(grades):
    return grades[0]


def published_match(coll, same, carried="earliest"):
    """Does this reading reproduce every published gain total? Returns the worst gap."""
    worst = 0.0
    for c in coll.campaigns:
        for s in c["systems"].split(";"):
            for topic, ranked in coll.runs[s].items():
                key = (c["campaign"], s, topic)
                if key not in coll.published:
                    continue
                universe = set(d for _, d in ranked)
                # the judgments made by this campaign's close
                closes = [cc for cc in coll.campaigns if int(cc["year"]) <= int(c["year"])]
                sub = _SubCollection(coll, closes)
                docs_groups = groups_of(universe | _judged_docs(sub, topic), same)
                grade_of = {}
                for docs in docs_groups:
                    g = grades_of(sub, topic, docs, carried)
                    for d in docs:
                        grade_of[d] = lowest(g)
                total = sum(DISC[r] * GAIN[grade_of[d]] for r, d in ranked if r <= DEPTH)
                worst = max(worst, abs(total - coll.published[key]))
    return worst


class _SubCollection:
    def __init__(self, coll, campaigns):
        self.campaigns = campaigns
        self.judgments = coll.judgments


def _judged_docs(sub, topic):
    out = set()
    for c in sub.campaigns:
        out.update(d for (t, d) in sub.judgments[c["campaign"]] if t == topic)
    return out


# ---- bounds --------------------------------------------------------------------------------------
def ideal(n3, n1):
    a = min(n3, DEPTH)
    b = min(n3 + n1, DEPTH)
    return 3.0 * CUM[a] + (CUM[b] - CUM[a])


def optimise(items, mode="exact"):
    fixed = 0.0
    n3 = n1 = 0
    free, binw, bin0 = [], [], 0
    for grades, w, m in items:
        if len(grades) == 1:
            fixed += w * GAIN[grades[0]]
            n3 += m * (grades[0] == 2)
            n1 += m * (grades[0] == 1)
        elif grades == (1, 2):
            if w > 0:
                binw.append((w, m))
            else:
                bin0 += m
        else:
            free.append((w, m))
    if mode in ("monotone", "fixed-ideal"):
        lo_dcg = fixed + sum(w for w, _ in binw)
        hi_dcg = fixed + sum(3.0 * w for w, _ in binw) + sum(3.0 * w for w, _ in free)
        nb = sum(m for _, m in binw) + bin0
        nf = sum(m for _, m in free)
        if mode == "fixed-ideal":
            i_lo = i_hi = ideal(n3, n1 + nb)
        else:
            i_lo, i_hi = ideal(n3, n1 + nb), ideal(n3 + nb + nf, n1)
        return lo_dcg / i_lo, hi_dcg / i_hi
    # The ideal depends only on the counts at each grade. For given counts of free items raised to
    # each grade and, per multiplicity class, of ranked binary items raised to 2, the run's DCG is
    # largest with the high grades on the heaviest items of each class and smallest with them on
    # the lightest (rearrangement); unranked binary items go to 1 for the high bound, 2 for the low.
    weights = sorted((w for w, _ in free), reverse=True)
    pre_desc = [0.0]
    for w in weights:
        pre_desc.append(pre_desc[-1] + w)
    pre_asc = [0.0]
    for w in reversed(weights):
        pre_asc.append(pre_asc[-1] + w)
    k = len(weights)
    classes = {}
    for w, m in binw:
        classes.setdefault(m, []).append(w)
    cls = []
    for m, ws in classes.items():
        ws = sorted(ws, reverse=True)
        pd = [0.0]
        for w in ws:
            pd.append(pd[-1] + w)
        pa = [0.0]
        for w in reversed(ws):
            pa.append(pa[-1] + w)
        cls.append((m, len(ws), pd, pa))
    cum, depth = CUM, DEPTH

    def ideal_of(a, b):
        a = a if a < depth else depth
        b = b if b < depth else depth
        return 3.0 * cum[a] + (cum[b] - cum[a])

    best, worst = -1.0, 2.0
    for raised in itertools.product(*[range(n + 1) for _, n, _, _ in cls]):
        hi_b = lo_b = 0.0
        b3 = b1 = 0
        for (m, n, pd, pa), j in zip(cls, raised):
            hi_b += 3.0 * pd[j] + (pd[n] - pd[j])
            lo_b += 3.0 * pa[j] + (pa[n] - pa[j])
            b3 += m * j
            b1 += m * (n - j)
        base3, base1 = n3 + b3, n1 + b1
        for a2 in range(k + 1):
            f3 = base3 + a2
            for a1 in range(k - a2 + 1):
                d = fixed + hi_b + 3.0 * pre_desc[a2] + (pre_desc[a2 + a1] - pre_desc[a2])
                v = d / ideal_of(f3, f3 + base1 + a1 + bin0)
                if v > best:
                    best = v
                d = fixed + lo_b + 3.0 * pre_asc[a2] + (pre_asc[a2 + a1] - pre_asc[a2])
                v = d / ideal_of(f3 + bin0, f3 + bin0 + base1 + a1)
                if v < worst:
                    worst = v
    return worst, best


def evaluate(root, identity=None, words=None, nosearch=False, carried="earliest", mode="exact"):
    coll = Collection(root)
    readings = []
    levels = [identity] if identity else LEVELS
    tols = [words] if words is not None else [0.015, 0.03, 0.06, 0.09]
    for tol in tols:
        for level in levels:
            readings.append((level, tol))
    chosen = None
    best_gap = None
    for level, tol in readings:
        same = same_pages(coll.manifest, level, tol)
        gap = published_match(coll, same, carried)
        if best_gap is None or gap < best_gap - 1e-9:
            best_gap, chosen = gap, same
        if gap < 5e-4 or nosearch:
            chosen = same
            break
    out = {}
    for topic in coll.topics:
        ranked = coll.candidate.get(topic, [])
        # the topic's documents: every identifier any file of the collection names for it
        universe = set(d for _, d in ranked)
        for c in coll.campaigns:
            universe.update(d for (t, d) in coll.judgments[c["campaign"]] if t == topic)
        for s in coll.runs:
            universe.update(d for _, d in coll.runs[s].get(topic, []))
        weight = {}
        for r, d in ranked:
            if r <= DEPTH:
                weight[d] = weight.get(d, 0.0) + DISC[r]
        items = []
        for docs in groups_of(universe, chosen):
            items.append((grades_of(coll, topic, docs, carried), sum(weight.get(d, 0.0) for d in docs), len(docs)))
        out[topic] = optimise(items, mode)
    return out


def main():
    root, out_path = sys.argv[1], sys.argv[2]
    kw = {}
    for arg in sys.argv[3:]:
        if arg == "nosearch":
            kw["nosearch"] = True
        elif arg.startswith("identity="):
            kw["identity"] = arg.split("=", 1)[1]
        elif arg.startswith("words="):
            kw["words"] = float(arg.split("=", 1)[1])
        elif arg.startswith("carried="):
            kw["carried"] = arg.split("=", 1)[1]
        elif arg.startswith("mode="):
            kw["mode"] = arg.split("=", 1)[1]
    res = evaluate(root, **kw)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["topic", "low", "high"])
        for topic in sorted(res):
            w.writerow([topic, "%.3f" % res[topic][0], "%.3f" % res[topic][1]])


if __name__ == "__main__":
    main()
