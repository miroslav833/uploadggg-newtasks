# Reading handbook

A tutor records a reader on the opening verses of a portion and prepares the melody of the remaining
verses from that recording. Every word of a verse carries one of the te'amim, the marks of cantillation,
and in a reader's tradition each mark is sung to a fixed motif. The motif is fitted to the word it falls
on, so the same mark sounds different on a short word, a long word, a word stressed on its last syllable
and a word stressed on the syllable before. Readers differ in their motifs and in how they do the
fitting. A reading directory holds three files.

## `reading.json`

```
{"reading": "alef", "reader": "r01", "recorded_verses": 7, "verses": 21}
```

`recorded_verses` is how many verses from the start `sung.csv` covers; `verses` is the total.

## `words.csv`

One row per word, in the order of the text. No text is given, only each word's shape:

```
verse,word,syllables,stress,mark,maqaf
1,1,2,1,munach,0
1,2,3,2,etnachta,0
1,3,1,1,,1
1,4,2,1,merkha,0
```

- `syllables` is the word's syllable count, 1 to 5.
- `stress` is counted from the end: 1 when the last syllable is stressed, 2 when the second-last is.
- `mark` is the word's ta'am. The marks used are the pausal marks `sof_pasuq`, `etnachta`, `zaqef`,
  `segol`, `revia`, `tipcha`, `pashta`, `tevir` and `geresh`, and the joining marks `munach`, `merkha`,
  `mahpakh`, `qadma` and `darga`. `sof_pasuq` ends every verse and `etnachta` ends its first half. The
  five marks `sof_pasuq`, `etnachta`, `zaqef`, `segol` and `revia` are the strong pauses.
- `maqaf` is 1 when the word is joined to the next by a maqaf (a hyphen). A joined word carries no mark
  of its own; the pair is governed by the mark on the second word.

## `sung.csv`

What the reader sang for the recorded verses, one row per note, in the order sung:

```
verse,word,syllable,order,pitch,length
1,1,1,1,4,1
1,1,2,1,5,2
1,1,2,2,3,1
```

`syllable` counts from 1 within the word; `order` counts from 1 within the syllable, so a syllable sung
to three notes has rows with order 1, 2 and 3. `pitch` is a degree of the reader's scale, 1 to 8, and
`length` is a whole number of eighth notes. The recording has no timing noise: the same word under the
same mark in the same place is sung the same way every time.

## Terms

- **Motif**: the fixed run of notes a mark calls for in a reader's tradition. One note of it is the
  **accented note**, and it goes with the word's stressed syllable. The notes before it are the
  **opening**; the notes after it are the **tail**.
- **Melisma**: more than one note sung on one syllable.
- **Holding tone**: a single repeated pitch on which spare syllables are carried.
- **Shortened form**: the form some readers give a joining mark when a strong pause follows, with
  fewer notes than its full motif.

How a reader fits a motif to a word is the reader's own: how a word with more syllables before the
stress than the motif has opening notes carries the extra ones, how a word with fewer takes the
opening, what a word stressed on its last syllable does with the tail, whether a word stressed on the
syllable before puts any of the tail on the stressed syllable, how a maqaf-joined pair is sung, how
long a holding tone lasts, and whether and how a joining mark is shortened before a strong pause. The
recorded verses show the reader's way.
