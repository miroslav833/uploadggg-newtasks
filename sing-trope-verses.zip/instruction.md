A reader was recorded on the opening verses of a portion and then had to stop. Finish the recording for them: build `/app/trope/sing.py`, which takes a reading directory and writes the notes that this reader would have sung for all the verses left unrecorded.

Start with `/app/HANDBOOK.md`. It describes `reading.json`, `words.csv` and `sung.csv`, which marks occur, and what a motif, an accented note, a melisma, a holding tone and a shortened form are.

Call:

```
python3 /app/trope/sing.py READING_DIR OUT_CSV
```

OUT_CSV has these columns and one row for each sung note of each unrecorded verse:

```
verse,word,syllable,order,pitch,length
8,1,1,1,4,1
```

Number the notes inside a syllable from 1 in `order`; give `pitch` as a scale degree 1-8 and `length` in eighth notes.

Work it out on the four readings under `/app/readings`; their `answer.csv` files hold the notes of the verses their reader did not record. Grading then runs your program on 20 further readings, each by a different reader. Those readers do not share the motifs or the habits of the four, and their verses put marks onto word shapes that the four readings never contain. Every reading obeys the handbook, and a reader keeps to one way of singing from the recorded verses through to the end.

Scoring: a verse is right only when your rows for it are exactly the reader's, the same notes on the same syllables in the same order with the same pitch and length, none missing and none added. One wrong verse is allowed per reading; a second wrong verse fails that reading. 18 or more of the 20 readings have to pass.

Per reading your program gets a copy of the directory, 60 seconds of wall time, no network, no numpy, the standard library of the image's python3, and an ordinary user account. Keep every file it depends on inside `/app/trope`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
