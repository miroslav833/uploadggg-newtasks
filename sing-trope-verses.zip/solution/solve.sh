#!/bin/bash
# Install the reference program and sing the four sample readings as a self-check.
set -e
mkdir -p /app/trope
cp "$(dirname "$0")"/trope/*.py /app/trope/
set +e
for d in /app/readings/*/; do
    name=$(basename "$d")
    out=$(mktemp)
    python3 /app/trope/sing.py "$d" "$out"
    python3 - "$out" "$d/answer.csv" "$name" <<'PY'
import csv, sys
def load(p):
    out = {}
    for r in csv.DictReader(open(p)):
        out.setdefault(int(r["verse"]), set()).add(tuple(int(r[k]) for k in ("word", "syllable", "order", "pitch", "length")))
    return out
mine, key = load(sys.argv[1]), load(sys.argv[2])
wrong = sum(1 for v in key if mine.get(v) != key[v])
print("%s: %d of %d verses wrong" % (sys.argv[3], wrong, len(key)))
PY
    rm -f "$out"
done
exit 0
