"""How a reader sings a reading under a given system: motifs per mark and the reader's word-fitting habits
(the reference's own renderer).
"""
import csv
import json
import os

STRONG = ("sof_pasuq", "etnachta", "zaqef", "segol", "revia")
DISJUNCTIVE = STRONG + ("tipcha", "pashta", "tevir", "geresh")
CONJUNCTIVE = ("munach", "merkha", "mahpakh", "qadma", "darga")
MARKS = DISJUNCTIVE + CONJUNCTIVE

HABITS = {
    "abbrev": ("none", "tail", "last2"),      # a conjunctive before a strong pause
    "long": ("first", "before", "spread"),    # more pre-stress syllables than opening notes
    "short": ("melisma", "drop"),             # fewer pre-stress syllables than opening notes
    "final": ("melisma", "hold"),             # a final-stressed word's notes after the accent
    "maqaf": ("join", "hold"),                # words joined by a maqaf
    "tail_split": ("final", "split"),         # a penult-stressed word's tail: all on the last syllable, or one note early
    "hold_len": (1, 2),                       # the length of a holding-tone note
}
PLAIN = {"abbrev": "none", "long": "first", "short": "melisma", "final": "melisma", "maqaf": "join",
         "tail_split": "final", "hold_len": 1}


def read_reading(d):
    meta = json.load(open(os.path.join(d, "reading.json")))
    words = []
    with open(os.path.join(d, "words.csv"), newline="") as fh:
        for r in csv.DictReader(fh):
            words.append(dict(verse=int(r["verse"]), word=int(r["word"]), n=int(r["syllables"]),
                              stress=int(r["stress"]), mark=r["mark"], maqaf=int(r["maqaf"])))
    return meta, words


def load_system(path):
    s = json.load(open(path))
    s["motifs"] = {m: (tuple((int(p), int(l)) for p, l in v["notes"]), int(v["accent"])) for m, v in s["motifs"].items()}
    return s


def effective_motif(system, mark, next_mark):
    notes, a = system["motifs"][mark]
    if mark in CONJUNCTIVE and next_mark in STRONG and system["abbrev"] != "none":
        if system["abbrev"] == "tail":
            return notes[a:], 0
        return notes[-2:], 0
    return notes, a


def fit_word(motif, n, stress, system):
    """{syllable (1-based): [(pitch, length), ...]} for a word of n syllables stressed on the last (1) or the
    second-last (2) syllable, under the reader's habits."""
    notes, a = motif
    O, A, T = list(notes[:a]), notes[a], list(notes[a + 1:])
    pre = n - stress
    post = stress - 1
    syl = {i: [] for i in range(1, n + 1)}
    hold = (O[0] if O else A)[0]
    hl = system["hold_len"]
    if pre == len(O):
        for j in range(pre):
            syl[j + 1].append(O[j])
    elif pre > len(O):
        k = pre - len(O)
        if system["long"] == "first":
            for j in range(k):
                syl[j + 1].append((hold, hl))
            for j in range(len(O)):
                syl[k + j + 1].append(O[j])
        elif system["long"] == "before":
            for j in range(len(O)):
                syl[j + 1].append(O[j])
            tone = O[-1][0] if O else hold
            for j in range(k):
                syl[len(O) + j + 1].append((tone, hl))
        else:
            if not O:
                for j in range(pre):
                    syl[j + 1].append((hold, hl))
            else:
                last = -1
                for j in range(pre):
                    idx = j * len(O) // pre
                    syl[j + 1].append(O[idx] if idx != last else (O[idx][0], 1))
                    last = idx
    else:
        m = len(O) - pre
        if system["short"] == "melisma":
            if pre == 0:
                syl[1].extend(O)
            else:
                syl[1].extend(O[:m + 1])
                for j in range(1, pre):
                    syl[j + 1].append(O[m + j])
        else:
            for j in range(pre):
                syl[j + 1].append(O[m + j])
    syl[pre + 1].append(A)
    if post == 1:
        if system["tail_split"] == "split" and len(T) >= 2:
            syl[pre + 1].append(T[0])
            syl[n].extend(T[1:])
        else:
            syl[n].extend(T)
    else:
        if system["final"] == "melisma":
            syl[n].extend(T)
        else:
            syl[n].append((T[-1][0], sum(l for _, l in T)))
    return syl


def sing_verse(system, verse_words):
    """[(word, syllable, order, pitch, length)] for one verse's words in order."""
    out = []
    i = 0
    while i < len(verse_words):
        w = verse_words[i]
        nxt = verse_words[i + 1]["mark"] if i + 1 < len(verse_words) else ""
        if w["maqaf"] and i + 1 < len(verse_words):
            w2 = verse_words[i + 1]
            nxt2 = verse_words[i + 2]["mark"] if i + 2 < len(verse_words) else ""
            motif = effective_motif(system, w2["mark"], nxt2)
            if system["maqaf"] == "join":
                syl = fit_word(motif, w["n"] + w2["n"], w2["stress"], system)
                for s in range(1, w["n"] + w2["n"] + 1):
                    word, k = (w["word"], s) if s <= w["n"] else (w2["word"], s - w["n"])
                    for o, (p, l) in enumerate(syl[s], 1):
                        out.append((word, k, o, p, l))
            else:
                hold = (motif[0][0] if motif[1] > 0 else motif[0][motif[1]])[0]
                for s in range(1, w["n"] + 1):
                    out.append((w["word"], s, 1, hold, system["hold_len"]))
                syl = fit_word(motif, w2["n"], w2["stress"], system)
                for s in range(1, w2["n"] + 1):
                    for o, (p, l) in enumerate(syl[s], 1):
                        out.append((w2["word"], s, o, p, l))
            i += 2
        else:
            motif = effective_motif(system, w["mark"], nxt)
            syl = fit_word(motif, w["n"], w["stress"], system)
            for s in range(1, w["n"] + 1):
                for o, (p, l) in enumerate(syl[s], 1):
                    out.append((w["word"], s, o, p, l))
            i += 1
    return out


def sing_reading(system, words):
    """[(verse, word, syllable, order, pitch, length)] for every verse."""
    by_verse = {}
    for w in words:
        by_verse.setdefault(w["verse"], []).append(w)
    out = []
    for v in sorted(by_verse):
        for row in sing_verse(system, by_verse[v]):
            out.append((v,) + row)
    return out
