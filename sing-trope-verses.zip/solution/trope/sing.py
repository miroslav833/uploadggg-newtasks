#!/usr/bin/env python3
"""Sing the unrecorded verses of a reading the way its reader sang the recorded ones.

    python3 sing.py READING_DIR OUT_CSV

Reads reading.json, words.csv and sung.csv. Every mark's motif is read off the recorded verses, and the
reader's habits (shortening before a pause, long and short words, final-stressed words, maqaf, holding
tones, tails) are chosen so that the recorded verses come out exactly as sung; the
remaining verses are then sung under the same motifs and habits.
"""
import csv
import itertools
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import chant as C  # noqa: E402


def read_sung(path):
    """{verse: {(word, syllable): [(pitch, length), ...]}} from the recorded verses."""
    sung = {}
    with open(path, newline="") as fh:
        rows = list(csv.DictReader(fh))
    rows.sort(key=lambda r: (int(r["verse"]), int(r["word"]), int(r["syllable"]), int(r["order"])))
    for r in rows:
        sung.setdefault(int(r["verse"]), {}).setdefault((int(r["word"]), int(r["syllable"])), []).append(
            (int(r["pitch"]), int(r["length"])))
    return sung


def as_map(notes):
    """sing_verse output -> {(word, syllable): [(pitch, length), ...]}."""
    m = {}
    for word, s, o, p, l in notes:
        m.setdefault((word, s), []).append((p, l))
    return m


def occurrences(words, sung):
    """Every recorded word with its mark, the next word's mark and the notes sung on it (maqaf pairs skipped)."""
    by_verse = {}
    for w in words:
        by_verse.setdefault(w["verse"], []).append(w)
    out = []
    for v, vw in by_verse.items():
        if v not in sung:
            continue
        for i, w in enumerate(vw):
            if w["maqaf"] or (i > 0 and vw[i - 1]["maqaf"]):
                continue
            nxt = vw[i + 1]["mark"] if i + 1 < len(vw) else ""
            notes = [sung[v][(w["word"], s)] for s in range(1, w["n"] + 1)] if sung[v] else None
            out.append((w, nxt, notes))
    return out


def candidate_motifs(occ):
    """Motifs that could underlie an occurrence: every contiguous run of its notes that contains the stressed
    syllable's first note, with that note as the accent."""
    w, nxt, notes = occ
    flat, stressed_at = [], None
    for s, ns in enumerate(notes, 1):
        if s == w["n"] - w["stress"] + 1:
            stressed_at = len(flat)
        flat.extend(ns)
    cands = set()
    for lo in range(0, stressed_at + 1):
        for hi in range(stressed_at + 1, len(flat) + 1):
            run = tuple(flat[lo:hi])
            a = stressed_at - lo
            if a > len(run) - 2:
                continue
            cands.add((run, a))
    return cands


def word_matches(system, mark, w, nxt, notes):
    m = C.effective_motif(system, mark, nxt)
    syl = C.fit_word(m, w["n"], w["stress"], system)
    return [syl[s] for s in range(1, w["n"] + 1)] == notes


def solutions(meta, words, sung, variant=None, all_motifs=False):
    """Every habit set that, with some motif per mark, sings the recorded verses exactly.
    Yields (system, {mark: [consistent motifs]}); with all_motifs False only the first consistent motif is kept."""
    v = variant or {}
    occ = occurrences(words, sung)
    by_mark = {}
    for o in occ:
        by_mark.setdefault(o[0]["mark"], []).append(o)
    cand = {}
    for mark, os_ in by_mark.items():
        pool = set()
        for o in os_:
            pool |= candidate_motifs(o)
        cand[mark] = sorted(pool, key=lambda c: (len(c[0]), c), reverse=bool(v.get("_rev")))
    habit_names = list(C.HABITS)
    grids = [([v[h]] if h in v else list(C.HABITS[h])) for h in habit_names]
    if v.get("_revgrid"):
        grids = [list(reversed(g)) for g in grids]
    by_verse = {}
    for w in words:
        by_verse.setdefault(w["verse"], []).append(w)
    recorded = sorted(sung)
    # the recorded rows each mark governs: its own words and the maqaf-joined word before them
    governed = {}
    for vn in recorded:
        vw = by_verse[vn]
        for i, w in enumerate(vw):
            m = w["mark"]
            if not m:
                continue
            keys = [(w["word"], s) for s in range(1, w["n"] + 1)]
            if i > 0 and vw[i - 1]["maqaf"]:
                keys += [(vw[i - 1]["word"], s) for s in range(1, vw[i - 1]["n"] + 1)]
            governed.setdefault(m, []).append((vn, keys))
    filler = (((3, 2), (2, 1)), 0)

    def sings_governed(system, mark, c):
        """Does motif c for `mark` reproduce every recorded row that mark governs, maqaf pairs included?"""
        system["motifs"] = {m: filler for m in C.MARKS}
        system["motifs"][mark] = c
        for vn, keys in governed.get(mark, []):
            got = as_map(C.sing_verse(system, by_verse[vn]))
            if any(got.get(k) != sung[vn].get(k) for k in keys):
                return False
        return True

    for combo in itertools.product(*grids):
        system = dict(zip(habit_names, combo))
        motifs = {}
        ok = True
        for mark in by_mark:
            cons = []
            for c in cand[mark]:
                system["motifs"] = {mark: c}
                if not all(word_matches(system, mark, w, nxt, notes) for w, nxt, notes in by_mark[mark]):
                    continue
                if not sings_governed(system, mark, c):
                    continue
                cons.append(c)
                if not all_motifs:
                    break
            if not cons:
                ok = False
                break
            motifs[mark] = cons
        if not ok:
            continue
        system["motifs"] = {m: cs[0] for m, cs in motifs.items()}
        for m in C.MARKS:
            system["motifs"].setdefault(m, filler)
        if all(as_map(C.sing_verse(system, by_verse[vn])) == sung[vn] for vn in recorded):
            yield system, motifs


def fit(meta, words, sung, variant=None):
    """The (system, motifs) that sing the recorded verses exactly; the first found wins unless asked otherwise."""
    v = variant or {}
    found = []
    for system, motifs in solutions(meta, words, sung, v):
        found.append(system)
        if not v.get("_all"):
            break
    if found:
        return found[-1] if v.get("_last") else found[0]
    occ = occurrences(words, sung)
    pool = {}
    for o in occ:
        pool.setdefault(o[0]["mark"], set()).update(candidate_motifs(o))
    system = dict(C.PLAIN)
    system["motifs"] = {m: sorted(cs, key=lambda c: (len(c[0]), c))[0] for m, cs in pool.items()}
    return system


def sing(reading_dir, variant=None):
    meta, words = C.read_reading(reading_dir)
    sung = read_sung(os.path.join(reading_dir, "sung.csv"))
    if (variant or {}).get("_naive"):
        system = dict(C.PLAIN)
        first = {}
        for w, nxt, notes in occurrences(words, sung):
            if w["mark"] not in first:
                flat = [n for ns in notes for n in ns]
                a = sum(len(ns) for ns in notes[:w["n"] - w["stress"]])
                first[w["mark"]] = (tuple(flat), min(a, len(flat) - 2) if len(flat) >= 2 else 0)
        system["motifs"] = first
    elif (variant or {}).get("_copy"):
        # readings only: copy every recorded (mark, shape, before-a-pause) as sung; sing the rest plain
        system = dict(C.PLAIN)
        table, first = {}, {}
        for w, nxt, notes in occurrences(words, sung):
            table.setdefault((w["mark"], w["n"], w["stress"], nxt in C.STRONG), notes)
            if w["mark"] not in first:
                flat = [n for ns in notes for n in ns]
                a = sum(len(ns) for ns in notes[:w["n"] - w["stress"]])
                first[w["mark"]] = (tuple(flat), min(a, len(flat) - 2) if len(flat) >= 2 else 0)
        system["motifs"] = first
        for m in C.MARKS:
            system["motifs"].setdefault(m, (((3, 2), (2, 1)), 0))
        by_verse = {}
        for w in words:
            by_verse.setdefault(w["verse"], []).append(w)
        rows = []
        for vn, vw in sorted(by_verse.items()):
            if vn in sung:
                continue
            plain = C.sing_verse(system, vw)
            for i, w in enumerate(vw):
                nxt = vw[i + 1]["mark"] if i + 1 < len(vw) else ""
                key = (w["mark"], w["n"], w["stress"], nxt in C.STRONG)
                if w["mark"] and not w["maqaf"] and not (i > 0 and vw[i - 1]["maqaf"]) and key in table:
                    plain = [r for r in plain if r[0] != w["word"]]
                    for sidx, ns in enumerate(table[key], 1):
                        for o, (pch, ln) in enumerate(ns, 1):
                            plain.append((w["word"], sidx, o, pch, ln))
            rows += [(vn,) + r for r in plain]
        return rows
    else:
        system = fit(meta, words, sung, variant)
    for m in C.MARKS:                      # a mark the recorded verses never carry: a plain two-note fallback
        system["motifs"].setdefault(m, (((3, 2), (2, 1)), 0))
    rec = set(sung)
    return [row for row in C.sing_reading(system, words) if row[0] not in rec]


def main(reading_dir, out_csv):
    rows = sing(reading_dir)
    with open(out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["verse", "word", "syllable", "order", "pitch", "length"])
        for row in rows:
            w.writerow(row)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
