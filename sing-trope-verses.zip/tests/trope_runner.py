"""Run the solver's program on every stored reading and count the verses it gets wrong.

A reading is copied to a scratch directory owned by root and readable by all, with an output folder owned
by a numeric account nobody holds. The program runs under that account in its own session with memory,
file-size and time limits; every process of the account is killed before the output is read, and only a
regular file of at most 1 MiB is read, as text. The readers' systems and answers stay under /tests.
"""
import csv
import os
import pwd
import resource
import shutil
import signal
import subprocess
import time

STORE = "/tests/store"
SCRATCH = "/var/tmp/trope-runs"
PROGRAM = "/app/trope/sing.py"
LIMIT_S = 60
WRONG_VERSES = 1          # a reading passes with at most this many wrong verses
NEEDED = 18               # readings of 20
CAP = 1 << 20


def owned_by(uid):
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    yield int(d)
            except FileNotFoundError:
                pass


def spare_uid(after):
    known = {p.pw_uid for p in pwd.getpwall()}
    uid = after + 1
    while uid in known or any(True for _ in owned_by(uid)):
        uid += 1
    return uid


def kill_all(uid):
    for _ in range(100):
        pids = list(owned_by(uid))
        if not pids:
            return
        for p in pids:
            try:
                os.kill(p, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def read_rows(path):
    """{verse: {(word, syllable, order, pitch, length)}} read as text; rows that do not parse are skipped."""
    out = {}
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return out
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > CAP:
        return out
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, newline="", encoding="utf-8", errors="replace") as fh:
        for rec in csv.DictReader(fh):
            try:
                vals = tuple(int(float(rec[k])) for k in ("verse", "word", "syllable", "order", "pitch", "length"))
            except (TypeError, ValueError, KeyError):
                continue
            out.setdefault(vals[0], set()).add(vals[1:])
    return out


def wrong_verses(filed, answer):
    return sum(1 for v, rows in answer.items() if filed.get(v) != rows)


def run_reading(code, uid):
    base = os.path.join(SCRATCH, code)
    shutil.rmtree(base, ignore_errors=True)
    src = os.path.join(base, "reading")
    os.makedirs(src)
    for name in ("reading.json", "words.csv", "sung.csv"):
        shutil.copyfile(os.path.join(STORE, code, name), os.path.join(src, name))
    out = os.path.join(base, "out")
    os.makedirs(out)
    for root, dirs, files in os.walk(base):
        os.chown(root, 0, 0)
        os.chmod(root, 0o755)
        for f in files:
            os.chown(os.path.join(root, f), 0, 0)
            os.chmod(os.path.join(root, f), 0o644)
    os.chown(out, uid, uid)
    os.chmod(out, 0o700)
    target = os.path.join(out, "verses.csv")

    def drop():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_AS, (1 << 31, 1 << 31))
        resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": out, "TMPDIR": out,
           "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
    try:
        subprocess.run(["python3", PROGRAM, src, target], preexec_fn=drop, env=env, cwd=out,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=LIMIT_S)
    except subprocess.TimeoutExpired:
        pass
    kill_all(uid)
    return read_rows(target)


def answer_of(code):
    return read_rows(os.path.join(STORE, code, "answer.csv"))


def run_all():
    os.makedirs(SCRATCH, exist_ok=True)
    os.chmod(SCRATCH, 0o755)
    result = {}
    uid = 51000
    for code in sorted(os.listdir(STORE)):
        uid = spare_uid(uid)
        result[code] = wrong_verses(run_reading(code, uid), answer_of(code))
    return result
