import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import trope_engine   # noqa: E402
import trope_runner   # noqa: E402

STORE = trope_runner.STORE


def test_sealed_answers_come_from_the_readers_systems():
    codes = sorted(os.listdir(STORE))
    assert len(codes) == 20
    for code in codes:
        d = os.path.join(STORE, code)
        meta, words = trope_engine.read_reading(d)
        system = trope_engine.load_system(os.path.join(d, "system.json"))
        sealed = trope_runner.answer_of(code)
        sung = {}
        for row in trope_engine.sing_reading(system, words):
            if row[0] > meta["recorded_verses"]:
                sung.setdefault(row[0], set()).add(row[1:])
        assert set(sung) == set(sealed), code
        for v in sung:
            assert all(math.isfinite(x) for r in sealed[v] for x in r), (code, v)
            assert sung[v] == sealed[v], (code, v)


def test_program_reaches_the_mark():
    assert os.path.isfile(trope_runner.PROGRAM), "no /app/trope/sing.py"
    result = trope_runner.run_all()
    passed = [c for c, n in result.items() if n <= trope_runner.WRONG_VERSES]
    print("readings passed %d of %d: %s" % (len(passed), len(result),
                                            ", ".join("%s %d" % (c, n) for c, n in sorted(result.items()))))
    assert len(passed) >= trope_runner.NEEDED, "%d of 20 readings passed; %d needed" % (len(passed), trope_runner.NEEDED)
