#!/bin/bash
# Reward 0 unless test_trope.py passes with the program run on the 20 stored readings. The reward folder is
# made root-only and emptied before the program runs, and ends up holding the reward and the report.
umask 077
mkdir -p /logs/verifier
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier
if [ "$(stat -c %u:%a /logs/verifier)" != "0:700" ]; then
    echo "reward folder could not be locked; not grading" >&2
    exit 0
fi
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
find /logs/verifier -mindepth 1 -exec rm -rf {} + 2>/dev/null
echo 0 > /logs/verifier/reward.txt
REPORTDIR=$(mktemp -d /run/trope-report.XXXXXX)
cd /tests || exit 0
if python3 -m pytest -q -rA -p no:cacheprovider -s --ctrf "$REPORTDIR/ctrf.json" test_trope.py; then
    verdict=1
else
    verdict=0
fi
find /logs/verifier -mindepth 1 ! -user 0 -exec rm -rf {} + 2>/dev/null
rm -f /logs/verifier/reward.json
cp "$REPORTDIR/ctrf.json" /logs/verifier/ctrf.json 2>/dev/null
echo "$verdict" > /logs/verifier/reward.txt
find /logs/verifier -mindepth 1 -type f -exec chmod 644 {} +
chmod 755 /logs/verifier
exit 0
