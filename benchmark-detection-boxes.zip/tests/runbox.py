"""Runs the uploaded evaluator for one graded line inside a throwaway account.

The parent copies the line into a fresh directory owned by an unused uid, forks, and the child drops
every privilege (new session, no groups, that uid) and caps its address space, file size, process count
and core dumps before exec'ing python3 on the evaluator. The parent waits up to the time limit, kills the
child's session and anything else the uid still runs, and only then reads the result: a plain file under
1 MiB opened with O_NOFOLLOW, parsed as CSV text."""
import csv
import math
import os
import resource
import shutil
import signal
import time

BATCH = "/tests/batch"
SANDBOX = "/var/tmp/tallying"
VERDICTS = "/run/tallying"
EVALUATOR = "/app/evaluator/tally.py"
SECONDS = 120
BYTES = 1 << 20
COLUMNS = ("ap", "ap_small", "ap_medium", "ap_large")


def lines():
    return sorted(os.listdir(os.path.join(BATCH, "lines")))


def spare_uid(start=63500):
    owners = set()
    for entry in os.listdir("/proc"):
        if entry.isdigit():
            try:
                owners.add(os.stat("/proc/" + entry).st_uid)
            except OSError:
                pass
    while start in owners:
        start += 1
    return start


def _owned(uid):
    found = []
    for entry in os.listdir("/proc"):
        if entry.isdigit():
            try:
                if os.stat("/proc/" + entry).st_uid == uid:
                    found.append(int(entry))
            except OSError:
                pass
    return found


def _kill_all(uid):
    for _ in range(200):
        pids = _owned(uid)
        if not pids:
            return
        for pid in pids:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.03)


def _child(uid, line_dir, out_path, home, log_path):
    try:
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        for what, cap in ((resource.RLIMIT_AS, 3 << 30), (resource.RLIMIT_FSIZE, 32 << 20),
                          (resource.RLIMIT_NPROC, 64), (resource.RLIMIT_CORE, 0)):
            resource.setrlimit(what, (cap, cap))
        fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        os.dup2(fd, 1)
        os.dup2(fd, 2)
        null = os.open(os.devnull, os.O_RDONLY)
        os.dup2(null, 0)
        os.chdir(home)
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": home, "TMPDIR": home, "LANG": "C.UTF-8",
               "OPENBLAS_NUM_THREADS": "2", "OMP_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
        os.execve("/usr/local/bin/python3", ["python3", EVALUATOR, line_dir, out_path], env)
    finally:
        os._exit(127)


def evaluate_line(code, uid):
    root = os.path.join(SANDBOX, code)
    shutil.rmtree(root, ignore_errors=True)
    shutil.copytree(os.path.join(BATCH, "lines", code), os.path.join(root, "line"), symlinks=False)
    for sub in ("out", "home"):
        os.makedirs(os.path.join(root, sub))
    for top, dirs, files in os.walk(root):
        os.chown(top, uid, uid)
        for name in files:
            os.chown(os.path.join(top, name), uid, uid)
    out_path = os.path.join(root, "out", "tally.csv")
    log_path = os.path.join(root, "home", "console.log")
    pid = os.fork()
    if pid == 0:
        _child(uid, os.path.join(root, "line"), out_path, os.path.join(root, "home"), log_path)
    deadline = time.monotonic() + SECONDS
    while time.monotonic() < deadline:
        done, _ = os.waitpid(pid, os.WNOHANG)
        if done:
            break
        time.sleep(0.05)
    else:
        try:
            os.killpg(pid, signal.SIGKILL)
        except OSError:
            pass
        os.waitpid(pid, 0)
    _kill_all(uid)
    if os.path.isfile(log_path) and not os.path.islink(log_path):
        shutil.copyfile(log_path, os.path.join(VERDICTS, code + ".log"))
    result = read_tally(out_path)
    shutil.rmtree(root, ignore_errors=True)
    return result


def read_tally(path):
    """{(dump, class, column): value}, or None for a missing, linked, oversized or malformed file, a row
    given twice, or a value that is not finite."""
    try:
        st = os.lstat(path)
    except OSError:
        return None
    if os.path.islink(path) or not os.path.isfile(path) or st.st_size > BYTES:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        text = os.read(fd, BYTES + 1).decode("utf-8", "replace")
    finally:
        os.close(fd)
    table = {}
    try:
        for row in csv.DictReader(text.splitlines()):
            for col in COLUMNS:
                key = (row["dump"], row["class"], col)
                value = float(row[col])
                if key in table or not math.isfinite(value):
                    return None
                table[key] = value
    except (KeyError, ValueError, TypeError):
        return None
    return table
