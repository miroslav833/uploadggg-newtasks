"""Release-gate acceptance for the evaluator: the sealed reports are what the verifier's own evaluator
computes from each line's build sheet, every line is pinned by its calibration report, and the evaluator
reproduces at least 18 of the 20 lines' dashboards on 95 per cent of their values."""
import json
import os

import pytest

import refeval
import runbox

NEED = 18
CODES = runbox.lines()
CLASSES = ["c%d" % k for k in range(6)]


def sheet(code):
    with open(os.path.join(runbox.BATCH, "truth", code, "build.json"), encoding="utf-8") as fh:
        return json.load(fh)


def folder(code, *parts):
    return os.path.join(runbox.BATCH, "lines", code, *parts)


@pytest.mark.parametrize("code", CODES)
def test_sealed_report_is_what_the_build_computes(code):
    build = sheet(code)["build"]
    sealed = refeval.read_report(os.path.join(runbox.BATCH, "truth", code, "expected.csv"))
    assert len(sealed) == 72
    for dump in ("d1", "d2", "d3"):
        for (c, col), v in refeval.report(folder(code, "dumps", dump), build, CLASSES).items():
            assert refeval.value_ok(v, sealed[(dump, c, col)], 2e-6), (dump, c, col)


@pytest.mark.parametrize("code", CODES)
def test_calibration_report_is_what_the_build_computes(code):
    build = sheet(code)["build"]
    given = refeval.read_report(folder(code, "calibration", "report.csv"))
    for (c, col), v in refeval.report(folder(code, "calibration"), build, CLASSES).items():
        assert refeval.value_ok(v, given[("", c, col)], 2e-6), (c, col)


@pytest.mark.parametrize("code", CODES)
def test_each_wrong_setting_moves_the_report(code):
    moved = sheet(code)["moved"]
    assert moved and min(moved.values()) >= 12, moved


def test_twenty_lines():
    assert len(CODES) == 20


def test_settings_are_spread():
    seen = {}
    for code in CODES:
        b = sheet(code)["build"]
        for key in (("interp", b["interp"]), ("plus1", b["plus1"]), ("crowd", b["crowd"]), ("iou", b["iou"][0]),
                    ("sizes", "coco" if b["sizes"] == [1024.0, 9216.0] else "own")):
            seen[key] = seen.get(key, 0) + 1
    assert len(seen) == 12 and min(seen.values()) >= 6, seen


def test_evaluator_reproduces_the_dashboards():
    uid = runbox.spare_uid()
    good = []
    for code in CODES:
        filed = runbox.evaluate_line(code, uid)
        expected = refeval.read_report(os.path.join(runbox.BATCH, "truth", code, "expected.csv"))
        if refeval.line_counts(filed, expected):
            good.append(code)
    with open(os.path.join(runbox.VERDICTS, "lines.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join("%s %s" % (c, "pass" if c in good else "fail") for c in CODES) + "\n")
    assert len(good) >= NEED, "%d of %d lines reproduced; %d needed" % (len(good), len(CODES), NEED)
