#!/usr/bin/env bash
# Release-gate grading. The verdict directory is locked to root (chmod 700, verified with stat) before
# any uploaded code exists in a process; stale reward/result/score files and anything not owned by root
# are swept out; the grade starts at 0. Only then do the checks run (the evaluator itself runs inside
# them, under a spare uid). The sweep is repeated before the final grade is written.
set -u
LOGS=/logs/verifier
KEEP=/run/tallying
mode0=$(stat -c %a "$LOGS" 2>/dev/null || echo 755)

sweep() {
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
}
grade() {
    sweep
    (umask 022; echo "$1" > "$LOGS/reward.txt")
}

mkdir -p "$LOGS"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    grade 0
    echo "release gate: verdict directory not locked; evaluator not run" >&2
    chmod "$mode0" "$LOGS" 2>/dev/null
    exit 0
fi
grade 0
chmod 700 /tests; chmod -R go-rwx /tests 2>/dev/null
install -d -o 0 -g 0 -m 700 "$KEEP"
chmod -R a+rX /app/evaluator 2>/dev/null

result=0
(cd /tests && python3 -m pytest -q -p no:cacheprovider --ctrf "$KEEP/ctrf.json" test_tally.py) && result=1
grade "$result"
for f in ctrf.json lines.txt; do
    [ -f "$KEEP/$f" ] && (umask 022; cp "$KEEP/$f" "$LOGS/$f")
done
chmod "$mode0" "$LOGS" 2>/dev/null
exit 0
