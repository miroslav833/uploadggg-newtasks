"""Synthetic inspection images as the dumps record them: 640x480 frames with 2 to 8 objects of six classes
(areas from about 8x8 to 160x160, aspect 0.6 to 1.6, 6 per cent crowd regions), detections from noisy
copies of the objects (now and then a duplicate or a wrong class) plus false positives; boxes to one
decimal, scores to three."""
import numpy as np

CLASSES = 6


def image(rng):
    gts, dets = [], []
    for _ in range(int(rng.integers(2, 9))):
        c = int(rng.integers(CLASSES))
        s = float(np.exp(rng.uniform(np.log(8), np.log(160))))
        w = s * rng.uniform(0.6, 1.6)
        h = s * s / w
        x, y = rng.uniform(0, 640 - w), rng.uniform(0, 480 - h)
        crowd = int(rng.random() < 0.06)
        gts.append((c, round(x, 1), round(y, 1), round(w, 1), round(h, 1), crowd))
        if rng.random() < 0.85:
            for k in range(1 + int(rng.random() < 0.25)):
                j = rng.normal(0, 0.12 * (1 + 8 / s), 4)
                cls = c if rng.random() < 0.93 else int(rng.integers(CLASSES))
                dets.append((cls, round(x + j[0] * w, 1), round(y + j[1] * h, 1), round(w * np.exp(j[2]), 1),
                             round(h * np.exp(j[3]), 1), round(float(rng.beta(4, 2 + k)), 3)))
    for _ in range(int(rng.integers(0, 6))):
        s = float(np.exp(rng.uniform(np.log(8), np.log(120))))
        w = s * rng.uniform(0.6, 1.6)
        dets.append((int(rng.integers(CLASSES)), round(rng.uniform(0, 600), 1), round(rng.uniform(0, 440), 1),
                     round(w, 1), round(s * s / w, 1), round(float(rng.beta(2, 4)), 3)))
    return gts, dets


def dump(rng, n):
    return [image(rng) for _ in range(n)]
