"""The product lines' evaluation harness builds: per-class average precision of a detection dump against its
ground truth, overall and for small, medium and large objects.

A build is a dict:
  interp   "voc11" (11 recall points), "all" (area under the monotone precision envelope), "coco101" (101
           recall points, precision at the first rank reaching each)
  iou      ["fixed", 0.5] | ["coco", None] (mean AP over 0.50, 0.55, ..., 0.95) | ["table", {class: t}]
  plus1    True: widths and heights of an overlap count one extra pixel (x2 - x1 + 1); False: continuous
  crowd    "ignore" (crowd boxes are never positives; detections they absorb are not counted) or "count"
           (crowd boxes are ordinary ground truth)
  sizes    [a1, a2]: an object is small below area a1, medium below a2, large from a2 (area = w * h as stored)
Matching (as COCO's): detections of a class in order of score (stable on ties); ground truth is scanned with
boxes that are not ignored first; each detection takes the unmatched box of highest overlap at or above the
threshold, and stops scanning at the ignored boxes once it holds one that is not; crowd boxes under
"ignore" may absorb any number of detections. In a size range, ground truth outside the
range is ignored and an unmatched detection outside the range is not counted. A class with no positive
in the range reports -1."""
import numpy as np

COCO_THRESHOLDS = [0.5 + 0.05 * k for k in range(10)]
RANGES = ("all", "small", "medium", "large")


def overlaps(dets, gts, plus1):
    if not len(dets) or not len(gts):
        return np.zeros((len(dets), len(gts)))
    e = 1.0 if plus1 else 0.0
    d = np.asarray(dets, float)
    g = np.asarray(gts, float)
    x1 = np.maximum(d[:, None, 0], g[None, :, 0])
    y1 = np.maximum(d[:, None, 1], g[None, :, 1])
    x2 = np.minimum(d[:, None, 0] + d[:, None, 2], g[None, :, 0] + g[None, :, 2])
    y2 = np.minimum(d[:, None, 1] + d[:, None, 3], g[None, :, 1] + g[None, :, 3])
    inter = np.maximum(0.0, x2 - x1 + e) * np.maximum(0.0, y2 - y1 + e)
    area_d = (d[:, 2] + e) * (d[:, 3] + e)
    area_g = (g[:, 2] + e) * (g[:, 3] + e)
    return inter / (area_d[:, None] + area_g[None, :] - inter)


def precision_at(tp, npos, interp):
    if npos == 0:
        return -1.0
    tp = np.asarray(tp, float)
    if not len(tp):
        return 0.0
    ctp = np.cumsum(tp)
    rec = ctp / npos
    prec = ctp / np.arange(1, len(tp) + 1)
    if interp == "voc11":
        return float(np.mean([prec[rec >= t].max() if (rec >= t).any() else 0.0 for t in np.arange(0.0, 1.1, 0.1)]))
    env = np.maximum.accumulate(prec[::-1])[::-1]
    if interp == "all":
        prev = np.concatenate([[0.0], rec[:-1]])
        return float(np.sum((rec - prev) * env))
    idx = np.searchsorted(rec, np.linspace(0, 1, 101), side="left")
    return float(np.mean([env[i] if i < len(env) else 0.0 for i in idx]))


class Cache:
    """Per image and class: the boxes, crowd flags, scores and overlap matrices, built once per dump."""

    def __init__(self, images, classes):
        self.items = []
        for gts, dets in images:
            for c in classes:
                g = [x for x in gts if x[0] == c]
                d = sorted([x for x in dets if x[0] == c], key=lambda x: -x[5])
                self.items.append((c, [x[1:5] for x in g], [bool(x[5]) for x in g], [x[1:5] for x in d],
                                   [x[5] for x in d], {}))

    def ious(self, item, plus1):
        if plus1 not in item[5]:
            item[5][plus1] = overlaps(item[3], item[1], plus1)
        return item[5][plus1]


def class_ap(cache, cls, threshold, build, rng):
    lo, hi = rng
    plus1, crowd_ignored = build["plus1"], build["crowd"] == "ignore"
    tps, scores, npos = [], [], 0
    for item in cache.items:
        if item[0] != cls:
            continue
        _, gboxes, crowd, dboxes, dscores, _ = item
        g_area = [b[2] * b[3] for b in gboxes]
        ignored = [(crowd[j] and crowd_ignored) or not (lo <= g_area[j] < hi) for j in range(len(gboxes))]
        npos += sum(1 for j in range(len(gboxes)) if not ignored[j])
        if not dboxes:
            continue
        m = cache.ious(item, plus1)
        order_g = sorted(range(len(gboxes)), key=lambda j: ignored[j])
        taken = [False] * len(gboxes)
        for k, box in enumerate(dboxes):
            best, pick = threshold, -1
            for j in order_g:
                if taken[j] and not (crowd[j] and crowd_ignored):
                    continue
                if pick >= 0 and not ignored[pick] and ignored[j]:
                    break
                if m[k, j] < best:
                    continue
                best, pick = m[k, j], j
            if pick >= 0:
                taken[pick] = True
                if ignored[pick]:
                    continue
                tps.append(1)
            else:
                if not (lo <= box[2] * box[3] < hi):
                    continue
                tps.append(0)
            scores.append(dscores[k])
    order = np.argsort(-np.asarray(scores, float), kind="mergesort")
    return precision_at(np.asarray(tps)[order] if tps else [], npos, build["interp"])


def thresholds_for(build, cls):
    kind, value = build["iou"]
    if kind == "fixed":
        return [value]
    if kind == "coco":
        return COCO_THRESHOLDS
    return [value[str(cls)] if isinstance(value, dict) and str(cls) in value else value[cls]]


def size_ranges(build):
    a1, a2 = build["sizes"]
    return {"all": (0.0, float("inf")), "small": (0.0, a1), "medium": (a1, a2), "large": (a2, float("inf"))}


def evaluate(cache, classes, build):
    """{class: [ap_all, ap_small, ap_medium, ap_large]}"""
    out = {}
    ranges = size_ranges(build)
    for c in classes:
        row = []
        for name in RANGES:
            vals = [class_ap(cache, c, t, build, ranges[name]) for t in thresholds_for(build, c)]
            row.append(-1.0 if vals[0] < 0 else float(np.mean(vals)))
        out[c] = row
    return out
