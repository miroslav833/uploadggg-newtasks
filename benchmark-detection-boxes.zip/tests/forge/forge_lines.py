"""Forges the product lines' evaluation folders and the sealed reports for their new dumps.

    forge_lines.py graded LINES_DIR TRUTH_DIR [SEED]    # the twenty graded lines (verifier image)
    forge_lines.py samples LINES_DIR [SEED]             # the two shipped sample lines

A line is kept only when it is settled by what the program is given:
- every build within two changes of its discrete settings misses the calibration report by more than
  APART somewhere;
- each own threshold (per class) and own size boundary is pinned: walking it across the calibration
  dump's breakpoints (overlaps, areas) in both directions, the range that still reproduces the report
  holds no breakpoint of the new dumps, so any value in it gives the same new reports;
- each single wrong setting moves at least MIN_MOVED of the 72 graded values by more than MOVE."""
import csv
import itertools
import json
import os
import string
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import apeval as A  # noqa: E402
import scenes as S  # noqa: E402

CLASSES = list(range(S.CLASSES))
CALIBRATION = 300
DUMP = 120
DUMPS = 3
APART = 1e-3
MOVE = 1e-3
MIN_MOVED = 12
LINES = 20
COCO_SIZES = [1024.0, 9216.0]
SAMPLE = {"interp": "all", "iou": ["fixed", 0.5], "plus1": False, "crowd": "ignore", "sizes": COCO_SIZES}


def discrete_neighbours(build, steps):
    """Builds within `steps` changes of the discrete settings (own thresholds and boundaries are not
    invented for a neighbour: a neighbour may drop them for the standard ones)."""
    options = {
        "interp": ["voc11", "all", "coco101"],
        "plus1": [False, True],
        "crowd": ["ignore", "count"],
        "iou": [["fixed", 0.5], ["coco", None]] + ([build["iou"]] if build["iou"][0] == "table" else []),
        "sizes": [COCO_SIZES] + ([build["sizes"]] if build["sizes"] != COCO_SIZES else []),
    }
    for fields in itertools.combinations(sorted(options), steps):
        for values in itertools.product(*(options[f] for f in fields)):
            if all(v != build[f] for f, v in zip(fields, values)):
                alt = dict(build)
                alt.update(zip(fields, values))
                yield "+".join("%s=%s" % (f, v[0] if isinstance(v, list) and isinstance(v[0], str) else v)
                               for f, v in zip(fields, values)), alt


def flat(report):
    return np.array([report[c][k] for c in CLASSES for k in range(4)])


def overlap_breaks(images, cls, plus1):
    vals = []
    for gts, dets in images:
        g = [x[1:5] for x in gts if x[0] == cls]
        d = [x[1:5] for x in dets if x[0] == cls]
        vals.extend(A.overlaps(d, g, plus1).ravel().tolist())
    return sorted(set(v for v in vals if v > 0))


def area_breaks(images):
    vals = set()
    for gts, dets in images:
        vals.update(x[3] * x[4] for x in gts)
        vals.update(x[3] * x[4] for x in dets)
    return sorted(vals)


def consistent_range(value, breaks, same):
    """The range of settings around `value` that keeps `same(setting)` true, as (low, high): the setting
    can be anything in (low, high]. Walks breakpoint by breakpoint."""
    below = [b for b in breaks if b < value]
    above = [b for b in breaks if b >= value]
    low = below[-1] if below else 0.0
    i = len(below) - 1
    while i >= 1 and same((breaks[i - 1] + breaks[i]) / 2):
        i -= 1
        low = breaks[i]
    if i == 0 and below and same(breaks[0] / 2):
        low = 0.0
    j = 0
    high = above[0] if above else float("inf")
    while j + 1 < len(above) and same((above[j] + above[j + 1]) / 2):
        j += 1
        high = above[j]
    return low, high


def pinned(lo, hi, breaks):
    return not any(lo < b < hi for b in breaks)


def settle(build, rng, tries=40):
    for _ in range(tries):
        cal = S.dump(rng, CALIBRATION)
        new = [S.dump(rng, DUMP) for _ in range(DUMPS)]
        cal_c = A.Cache(cal, CLASSES)
        new_c = [A.Cache(d, CLASSES) for d in new]
        if build["iou"][0] == "table":
            table = {}
            for c in CLASSES:
                for _ in range(30):
                    t = round(float(rng.uniform(0.40, 0.75)), 3)
                    trial = dict(build, iou=["table", dict(table, **{str(c): t}, **{str(k): 0.5 for k in CLASSES if k > c})])
                    want = A.evaluate(cal_c, [c], trial)[c]
                    same = lambda v: np.allclose(A.evaluate(cal_c, [c], dict(trial, iou=["table", dict(trial["iou"][1], **{str(c): v})]))[c], want, atol=1e-9)
                    lo, hi = consistent_range(t, overlap_breaks(cal, c, build["plus1"]), same)
                    if all(pinned(lo, hi, overlap_breaks(d, c, build["plus1"])) for d in new):
                        table[str(c)] = t
                        break
                else:
                    break
            if len(table) != len(CLASSES):
                continue
            build = dict(build, iou=["table", table])
        if build["sizes"] != COCO_SIZES:
            ok = False
            for _ in range(30):
                a1 = round(float(rng.uniform(300, 1600)), 1)
                a2 = round(float(rng.uniform(4000, 15000)), 1)
                trial = dict(build, sizes=[a1, a2])
                want = flat(A.evaluate(cal_c, CLASSES, trial))
                fine = True
                for k, value in ((0, a1), (1, a2)):
                    def same(v, k=k):
                        s = list(trial["sizes"])
                        s[k] = v
                        return np.allclose(flat(A.evaluate(cal_c, CLASSES, dict(trial, sizes=s))), want, atol=1e-9)
                    lo, hi = consistent_range(value, area_breaks(cal), same)
                    if not all(pinned(lo, hi, area_breaks(d)) for d in new):
                        fine = False
                        break
                if fine:
                    build = trial
                    ok = True
                    break
            if not ok:
                continue
        cal_rep = flat(A.evaluate(cal_c, CLASSES, build))
        if any(np.abs(flat(A.evaluate(cal_c, CLASSES, alt)) - cal_rep).max() <= APART
               for steps in (1, 2) for _, alt in discrete_neighbours(build, steps)):
            continue
        truth = [flat(A.evaluate(nc, CLASSES, build)) for nc in new_c]
        moved = {}
        for name, alt in discrete_neighbours(build, 1):
            moved[name] = int(sum((np.abs(flat(A.evaluate(nc, CLASSES, alt)) - tr) > MOVE).sum()
                                  for nc, tr in zip(new_c, truth)))
        if min(moved.values()) < MIN_MOVED:
            continue
        return dict(build=build, cal=cal, cal_report=A.evaluate(cal_c, CLASSES, build), new=new,
                    truth=[A.evaluate(nc, CLASSES, build) for nc in new_c], moved=moved)
    return None


def write_boxes(path, images):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["image", "class", "x", "y", "w", "h", "crowd"])
        for i, (gts, _) in enumerate(images):
            for c, x, y, bw, bh, crowd in gts:
                w.writerow(["im%04d" % (i + 1), "c%d" % c, x, y, bw, bh, crowd])


def write_detections(path, images):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["image", "class", "x", "y", "w", "h", "score"])
        for i, (_, dets) in enumerate(images):
            for c, x, y, bw, bh, score in dets:
                w.writerow(["im%04d" % (i + 1), "c%d" % c, x, y, bw, bh, "%.3f" % score])


def fmt(v):
    return "-1" if v < 0 else "%.6f" % v


def write_report(path, rows):
    """rows: [(dump or None, report)]"""
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        head = ["class", "ap", "ap_small", "ap_medium", "ap_large"]
        w.writerow((["dump"] if rows[0][0] else []) + head)
        for dump, report in rows:
            for c in CLASSES:
                w.writerow(([dump] if dump else []) + ["c%d" % c] + [fmt(v) for v in report[c]])


def code_for(rng, taken):
    while True:
        c = "PL-" + "".join(rng.choice(list(string.ascii_uppercase + string.digits), 4))
        if c not in taken:
            return c


def write_line(folder, code, got, rng):
    os.makedirs(os.path.join(folder, "calibration"))
    write_boxes(os.path.join(folder, "calibration", "boxes.csv"), got["cal"])
    write_detections(os.path.join(folder, "calibration", "detections.csv"), got["cal"])
    write_report(os.path.join(folder, "calibration", "report.csv"), [(None, got["cal_report"])])
    for k, d in enumerate(got["new"]):
        sub = os.path.join(folder, "dumps", "d%d" % (k + 1))
        os.makedirs(sub)
        write_boxes(os.path.join(sub, "boxes.csv"), d)
        write_detections(os.path.join(sub, "detections.csv"), d)
    with open(os.path.join(folder, "LINE.md"), "w", encoding="utf-8") as fh:
        fh.write("# Product line %s\n\n" % code)
        fh.write("- product: %s\n" % rng.choice(["shelf scanner", "parcel sorter", "weld inspector", "orchard drone",
                                               "dock camera", "pallet counter"]))
        fh.write("- classes: %s\n" % ", ".join("c%d" % c for c in CLASSES))
        fh.write("- calibration dump: %d images, with the line's report for it\n" % CALIBRATION)
        fh.write("- new dumps: d1, d2, d3, %d images each\n" % DUMP)


def deal(rng):
    counts = {"interp": (("voc11", 7), ("all", 7), ("coco101", 6)), "plus1": ((False, 10), (True, 10)),
              "crowd": (("ignore", 10), ("count", 10)), "iou": (("fixed", 7), ("coco", 7), ("table", 6)),
              "sizes": (("coco", 13), ("own", 7))}
    cols = {f: [v for v, n in pairs for _ in range(n)] for f, pairs in counts.items()}
    cols = {f: [col[i] for i in rng.permutation(LINES)] for f, col in cols.items()}
    out = []
    for i in range(LINES):
        iou = {"fixed": ["fixed", 0.5], "coco": ["coco", None], "table": ["table", None]}[cols["iou"][i]]
        out.append({"interp": cols["interp"][i], "plus1": cols["plus1"][i], "crowd": cols["crowd"][i], "iou": iou,
                    "sizes": COCO_SIZES if cols["sizes"][i] == "coco" else [0.0, 0.0]})
    return out


def graded(lines_dir, truth_dir, seed):
    rng = np.random.default_rng(seed)
    taken = set()
    for i, build in enumerate(deal(rng)):
        lrng = np.random.default_rng([seed, i])
        got = settle(build, lrng)
        if got is None:
            raise SystemExit("line %d (%s) would not settle" % (i, build))
        code = code_for(rng, taken)
        taken.add(code)
        write_line(os.path.join(lines_dir, code), code, got, lrng)
        os.makedirs(os.path.join(truth_dir, code))
        write_report(os.path.join(truth_dir, code, "expected.csv"),
                     [("d%d" % (k + 1), r) for k, r in enumerate(got["truth"])])
        with open(os.path.join(truth_dir, code, "build.json"), "w", encoding="utf-8") as fh:
            json.dump({"code": code, "build": got["build"], "moved": got["moved"]}, fh, indent=1)
        print(code, got["build"], "least moved", min(got["moved"].values()), flush=True)


def samples(lines_dir, seed):
    rng = np.random.default_rng(seed)
    taken = set()
    for k in range(2):
        lrng = np.random.default_rng([seed, 100 + k])
        got = settle(dict(SAMPLE), lrng)
        code = code_for(rng, taken)
        taken.add(code)
        folder = os.path.join(lines_dir, code)
        write_line(folder, code, got, lrng)
        write_report(os.path.join(folder, "expected.csv"), [("d%d" % (j + 1), r) for j, r in enumerate(got["truth"])])
        print(code, "least moved", min(got["moved"].values()), flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "graded":
        graded(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 20261024)
    elif sys.argv[1] == "samples":
        samples(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 31)
    else:
        raise SystemExit(__doc__)
