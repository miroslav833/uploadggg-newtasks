"""The verifier's own evaluator, written apart from the forge: plain Python over the CSV files, its own
overlap, matching and interpolation code, driven by a line's sealed build sheet."""
import csv
import math
import os

import numpy as np

# the recall levels as the devkits write them (VOC: np.arange(0, 1.1, 0.1); COCO: np.linspace(0, 1, 101))
VOC_LEVELS = [float(v) for v in np.arange(0.0, 1.1, 0.1)]
COCO_LEVELS = [float(v) for v in np.linspace(0.0, 1.0, 101)]

RANGES = ("ap", "ap_small", "ap_medium", "ap_large")


def read_boxes(path, last):
    by_image = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            rec = (r["class"], float(r["x"]), float(r["y"]), float(r["w"]), float(r["h"]),
                   float(r[last]) if last == "score" else int(r[last]))
            by_image.setdefault(r["image"], []).append(rec)
    return by_image


def iou(a, b, extra):
    w = min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]) + extra
    h = min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]) + extra
    if w <= 0 or h <= 0:
        return 0.0
    inter = w * h
    return inter / ((a[2] + extra) * (a[3] + extra) + (b[2] + extra) * (b[3] + extra) - inter)


def average_precision(hits, positives, scheme):
    if positives == 0:
        return -1.0
    prec, rec, tp = [], [], 0
    for k, h in enumerate(hits, 1):
        tp += h
        prec.append(tp / k)
        rec.append(tp / positives)
    if not hits:
        return 0.0
    if scheme == "voc11":
        total = 0.0
        for t in VOC_LEVELS:
            cands = [p for p, r in zip(prec, rec) if r >= t]
            total += max(cands) if cands else 0.0
        return total / len(VOC_LEVELS)
    env = prec[:]
    for i in range(len(env) - 2, -1, -1):
        env[i] = max(env[i], env[i + 1])
    if scheme == "all":
        area, last = 0.0, 0.0
        for p, r in zip(env, rec):
            area += (r - last) * p
            last = r
        return area
    total = 0.0
    for t in COCO_LEVELS:
        k = next((j for j, r in enumerate(rec) if r >= t), None)
        total += env[k] if k is not None else 0.0
    return total / len(COCO_LEVELS)


def ap_for(gt, dt, cls, thr, build, lo, hi):
    extra = 1.0 if build["plus1"] else 0.0
    ignore_crowd = build["crowd"] == "ignore"
    scored, positives = [], 0
    for image in sorted(set(gt) | set(dt)):
        g = [b for b in gt.get(image, []) if b[0] == cls]
        d = sorted([b for b in dt.get(image, []) if b[0] == cls], key=lambda b: -b[5])
        skip = [(b[5] == 1 and ignore_crowd) or not (lo <= b[3] * b[4] < hi) for b in g]
        positives += skip.count(False)
        scan = [j for j in range(len(g)) if not skip[j]] + [j for j in range(len(g)) if skip[j]]
        used = [False] * len(g)
        for det in d:
            best, pick = thr, None
            for j in scan:
                if used[j] and not (g[j][5] == 1 and ignore_crowd):
                    continue
                if pick is not None and not skip[pick] and skip[j]:
                    break
                o = iou(det[1:5], g[j][1:5], extra)
                if o >= best:
                    best, pick = o, j
            if pick is not None:
                used[pick] = True
                if not skip[pick]:
                    scored.append((det[5], 1))
            elif lo <= det[3] * det[4] < hi:
                scored.append((det[5], 0))
    # sorted() is stable, so equal scores keep image order, then score order within the image
    hits = [h for _, h in sorted(scored, key=lambda s: -s[0])]
    return average_precision(hits, positives, build["interp"])


def report(folder, build, classes):
    """{(class, column): value} for one dump folder holding boxes.csv and detections.csv."""
    gt = read_boxes(os.path.join(folder, "boxes.csv"), "crowd")
    dt = read_boxes(os.path.join(folder, "detections.csv"), "score")
    a1, a2 = build["sizes"]
    spans = {"ap": (0.0, math.inf), "ap_small": (0.0, a1), "ap_medium": (a1, a2), "ap_large": (a2, math.inf)}
    kind, value = build["iou"]
    out = {}
    for c in classes:
        if kind == "fixed":
            thrs = [value]
        elif kind == "coco":
            thrs = [0.5 + 0.05 * k for k in range(10)]
        else:
            thrs = [value[c[1:]]]
        for col in RANGES:
            vals = [ap_for(gt, dt, c, t, build, *spans[col]) for t in thrs]
            out[(c, col)] = -1.0 if vals[0] < 0 else sum(vals) / len(vals)
    return out


def read_report(path):
    out = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            for col in RANGES:
                out[(r.get("dump", ""), r["class"], col)] = float(r[col])
    return out


def value_ok(got, want, tol=1e-4):
    if want < 0:
        return got == -1.0
    return math.isfinite(got) and math.isfinite(want) and abs(got - want) <= tol


def line_counts(filed, expected, share=0.95):
    if filed is None:
        return False
    good = sum(1 for k, v in expected.items() if k in filed and value_ok(filed[k], v))
    return good >= math.ceil(share * len(expected))
