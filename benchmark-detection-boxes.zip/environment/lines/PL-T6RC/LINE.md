# Product line PL-T6RC

- product: dock camera
- classes: c0, c1, c2, c3, c4, c5
- calibration dump: 300 images, with the line's report for it
- new dumps: d1, d2, d3, 120 images each
