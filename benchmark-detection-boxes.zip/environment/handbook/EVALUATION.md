# Perception programme: product-line evaluation

## The programme

One detector family serves six product lines (shelf scanners, parcel sorters, weld inspectors and so
on). Each line keeps its own evaluation harness and dashboard, and a model release is gated on the
numbers those dashboards report. The harnesses were written by different teams at different times. They
all compute per-class average precision (AP) from a dump of ground-truth boxes and detections, but they
do not all compute it the same way, and the dashboards are the reference.

## A dump

A dump is a set of images with their ground truth and the detector's output.

`boxes.csv` holds one row per ground-truth box. `x,y` is the top-left corner, `w,h` the size in pixels,
and `crowd` is 1 for a region covering a crowd of objects:

    image,class,x,y,w,h,crowd
    im0001,c3,212.4,87.0,41.3,29.8,0

`detections.csv` holds one row per detection, with a score in [0, 1] to three decimals:

    image,class,x,y,w,h,score
    im0001,c3,214.0,85.2,39.9,31.5,0.913

There are six classes, `c0` to `c5`.

## What a harness computes

For every class, a harness runs the class's detections across the whole dump in order of score
(equal scores keep their order in the file). Each detection is matched to a ground-truth box of its class
in the same image whose overlap (intersection over union) meets the harness's requirement. A matched
detection is a true positive and an unmatched one a false positive. Each ground-truth box takes at most
one detection, but a crowd region can absorb any number. AP is read off the precision-recall curve of
that ordering, with recall = true positives / ground-truth boxes of the class.

Every line also reports AP for small, medium and large objects. An object's size is its box area w x h.
For a size range, ground truth outside the range does not count as a positive, a detection matched to such
a box counts as neither kind, and an unmatched detection outside the range is not counted at all. A
class with no ground truth in a range reports -1.

Builds differ in how they turn the curve into a number (devkits interpolate precision at the recall
levels `np.arange(0, 1.1, 0.1)` or `np.linspace(0, 1, 101)`, or take the area under the curve), in the
overlap a match needs, in whether box widths and heights count an extra pixel, in what they do with crowd
regions, and in where the size ranges end. Some lines set the overlap requirement class by class, and
some draw their own size boundaries instead of COCO's 32 x 32 and 96 x 96. A line's settings are not
written down anywhere except in what its harness reports.

## A line folder

- `LINE.md`: the line code, product and classes, and the dumps it holds.
- `calibration/boxes.csv`, `calibration/detections.csv`: the calibration dump.
- `calibration/report.csv`: the line's own report for the calibration dump. -1 means no ground truth in
  that range:

      class,ap,ap_small,ap_medium,ap_large
      c0,0.512833,0.301422,0.618070,0.590112

- `dumps/d1`, `dumps/d2`, `dumps/d3`: new dumps, each with `boxes.csv` and `detections.csv`.
- `expected.csv` (sample lines only): the line's report for the new dumps, in the output format below.

`/app/lines` holds two sample lines.

## The evaluator

    python3 /app/evaluator/tally.py LINE_DIR OUT_CSV

`OUT_CSV` has one row per new dump and class:

    dump,class,ap,ap_small,ap_medium,ap_large
    d1,c0,0.498210,0.287500,0.603917,-1
