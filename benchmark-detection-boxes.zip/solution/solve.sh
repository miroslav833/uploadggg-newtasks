#!/bin/bash
# Installs the reference evaluator and checks it against both sample lines' expected.csv.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
install -d /app/evaluator
install -m 644 "$HERE/evaluator/tally.py" /app/evaluator/tally.py
status=0
for line in /app/lines/*/; do
    out="$(mktemp)"
    python3 /app/evaluator/tally.py "$line" "$out"
    python3 - "$line/expected.csv" "$out" <<'PY' || status=1
import csv, sys
def read(p):
    return {(r["dump"], r["class"], k): float(r[k]) for r in csv.DictReader(open(p))
            for k in ("ap", "ap_small", "ap_medium", "ap_large")}
want, got = read(sys.argv[1]), read(sys.argv[2])
ok = sum(1 for k, v in want.items() if k in got and abs(got[k] - v) <= 1e-4)
print("%s: %d of %d values match" % (sys.argv[1], ok, len(want)))
sys.exit(0 if ok == len(want) else 1)
PY
done
exit $status
