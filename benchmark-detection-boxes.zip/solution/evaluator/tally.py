"""Reproduces a product line's evaluation harness on new dumps.

    python3 /app/evaluator/tally.py LINE_DIR OUT_CSV

The calibration report fixes the harness build in three steps.
1. The overall AP column does not depend on the size boundaries. For every interpolation (VOC 11-point,
   all-point, COCO 101-point), pixel convention and crowd handling, it is compared with the fixed 0.5
   overlap, the COCO average over 0.50:0.95, and a per-class threshold: each class's candidates are
   searched on a 0.01 grid, then exactly between the calibration dump's own overlap values near the
   best grid points (AP only changes where the threshold crosses an overlap); the candidate kept is the
   one that also reproduces the class's small, medium and large columns.
2. With that fixed, the small and large columns are compared with COCO's 1024 and 9216; if they do not
   fit, each boundary is searched the same way over the calibration dump's box areas (the small column
   depends on the first boundary only, the large column on the second).
3. Every new dump is evaluated with the build and written as dump,class,ap,ap_small,ap_medium,ap_large."""
import csv
import itertools
import math
import os
import sys

import numpy as np

COCO_IOUS = [0.5 + 0.05 * k for k in range(10)]
VOC_LEVELS = np.arange(0.0, 1.1, 0.1)
COCO_LEVELS = np.linspace(0.0, 1.0, 101)
COLUMNS = ("ap", "ap_small", "ap_medium", "ap_large")
EXACT = 2e-6


def load(folder):
    def rows(name):
        with open(os.path.join(folder, name), newline="", encoding="utf-8") as fh:
            return list(csv.DictReader(fh))
    images = {}
    for r in rows("boxes.csv"):
        images.setdefault(r["image"], ([], []))[0].append(
            (r["class"], float(r["x"]), float(r["y"]), float(r["w"]), float(r["h"]), int(r["crowd"])))
    for r in rows("detections.csv"):
        images.setdefault(r["image"], ([], []))[1].append(
            (r["class"], float(r["x"]), float(r["y"]), float(r["w"]), float(r["h"]), float(r["score"])))
    return [images[k] for k in sorted(images)]


def iou_matrix(d, g, e):
    if not d or not g:
        return np.zeros((len(d), len(g)))
    d = np.array(d)
    g = np.array(g)
    w = np.minimum(d[:, None, 0] + d[:, None, 2], g[None, :, 0] + g[None, :, 2]) - np.maximum(d[:, None, 0], g[None, :, 0]) + e
    h = np.minimum(d[:, None, 1] + d[:, None, 3], g[None, :, 1] + g[None, :, 3]) - np.maximum(d[:, None, 1], g[None, :, 1]) + e
    inter = np.where((w > 0) & (h > 0), w * h, 0.0)
    return inter / (((d[:, 2] + e) * (d[:, 3] + e))[:, None] + ((g[:, 2] + e) * (g[:, 3] + e))[None, :] - inter)


class Dump:
    def __init__(self, images, classes):
        self.per_class = {c: [] for c in classes}
        for gts, dets in images:
            for c in classes:
                g = [x for x in gts if x[0] == c]
                d = sorted([x for x in dets if x[0] == c], key=lambda x: -x[5])
                if g or d:
                    self.per_class[c].append(([x[1:5] for x in g], [x[5] == 1 for x in g],
                                              [x[1:5] for x in d], [x[5] for x in d], {}))

    def ious(self, entry, plus1):
        if plus1 not in entry[4]:
            entry[4][plus1] = iou_matrix(entry[2], entry[0], 1.0 if plus1 else 0.0)
        return entry[4][plus1]

    def overlaps(self, c, plus1):
        vals = set()
        for entry in self.per_class[c]:
            vals.update(self.ious(entry, plus1).ravel().tolist())
        return sorted(v for v in vals if v > 0)

    def areas(self):
        vals = set()
        for entries in self.per_class.values():
            for g, _, d, _, _ in entries:
                vals.update(b[2] * b[3] for b in g)
                vals.update(b[2] * b[3] for b in d)
        return sorted(vals)


def ap_value(hits, npos, interp):
    if npos == 0:
        return -1.0
    if not len(hits):
        return 0.0
    ctp = np.cumsum(hits)
    rec = ctp / npos
    prec = ctp / np.arange(1, len(hits) + 1)
    if interp == "voc11":
        return float(np.mean([prec[rec >= t].max() if (rec >= t).any() else 0.0 for t in VOC_LEVELS]))
    env = np.maximum.accumulate(prec[::-1])[::-1]
    if interp == "all":
        return float(np.sum(np.diff(np.concatenate([[0.0], rec])) * env))
    idx = np.searchsorted(rec, COCO_LEVELS, side="left")
    return float(np.mean(np.where(idx < len(env), env[np.minimum(idx, len(env) - 1)], 0.0)))


def class_ap(dump, c, thr, interp, plus1, crowd_ignored, lo=0.0, hi=math.inf):
    hits, scores, npos = [], [], 0
    for entry in dump.per_class[c]:
        g, crowd, d, sc, _ = entry
        skip = [(crowd[j] and crowd_ignored) or not (lo <= g[j][2] * g[j][3] < hi) for j in range(len(g))]
        npos += skip.count(False)
        if not d:
            continue
        m = dump.ious(entry, plus1)
        scan = sorted(range(len(g)), key=lambda j: skip[j])
        used = [False] * len(g)
        for k in range(len(d)):
            best, pick = thr, -1
            for j in scan:
                if used[j] and not (crowd[j] and crowd_ignored):
                    continue
                if pick >= 0 and not skip[pick] and skip[j]:
                    break
                if m[k, j] >= best:
                    best, pick = m[k, j], j
            if pick >= 0:
                used[pick] = True
                if skip[pick]:
                    continue
                hits.append(1)
            elif lo <= d[k][2] * d[k][3] < hi:
                hits.append(0)
            else:
                continue
            scores.append(sc[k])
    order = np.argsort(-np.array(scores, float), kind="mergesort")
    return ap_value(np.array(hits, float)[order] if hits else np.array([]), npos, interp)


def column(dump, c, build, lo, hi):
    interp, plus1, crowd_ignored, iou = build
    thrs = COCO_IOUS if iou == "coco" else [0.5 if iou == "fixed" else iou[c]]
    vals = [class_ap(dump, c, t, interp, plus1, crowd_ignored, lo, hi) for t in thrs]
    return -1.0 if vals[0] < 0 else float(np.mean(vals))


def close(a, b):
    return (a < 0 and b < 0) or abs(a - b) <= EXACT


def threshold_candidates(dump, c, want, interp, plus1, crowd_ignored):
    """Every threshold (grid point, or midpoint between the dump's own overlaps near the best grid points)
    whose overall AP for class c equals the report's."""
    grid = [round(0.30 + 0.01 * k, 2) for k in range(61)]
    vals = [class_ap(dump, c, t, interp, plus1, crowd_ignored) for t in grid]
    found = [t for t, v in zip(grid, vals) if close(v, want)]
    near = sorted(range(len(grid)), key=lambda k: abs(vals[k] - want))[:4]
    breaks = dump.overlaps(c, plus1)
    for k in sorted(set(near) | {grid.index(t) for t in found}):
        lo, hi = grid[max(0, k - 1)], grid[min(len(grid) - 1, k + 1)]
        inside = [b for b in breaks if lo <= b <= hi]
        for a, b in zip(inside, inside[1:]):
            t = (a + b) / 2
            if close(class_ap(dump, c, t, interp, plus1, crowd_ignored), want):
                found.append(t)
    return sorted(set(found))


def fit_core(dump, report, classes):
    """(interp, plus1, crowd_ignored, iou) where iou is "fixed", "coco" or {class: [candidate thresholds]}."""
    for interp, plus1, crowd_ignored in itertools.product(("all", "voc11", "coco101"), (False, True), (True, False)):
        for iou in ("fixed", "coco"):
            build = (interp, plus1, crowd_ignored, iou)
            if all(close(column(dump, c, build, 0.0, math.inf), report[(c, "ap")]) for c in classes):
                return build
    for interp, plus1, crowd_ignored in itertools.product(("all", "voc11", "coco101"), (False, True), (True, False)):
        table = {}
        for c in classes:
            cands = threshold_candidates(dump, c, report[(c, "ap")], interp, plus1, crowd_ignored)
            if not cands:
                break
            table[c] = cands
        if len(table) == len(classes):
            return (interp, plus1, crowd_ignored, table)
    return ("all", False, True, "fixed")


def settle_table(dump, build, report, classes, sizes):
    """Pick, for each class, the candidate threshold that reproduces all four report columns."""
    interp, plus1, crowd_ignored, cands = build
    spans = {"ap": (0.0, math.inf), "ap_small": (0.0, sizes[0]), "ap_medium": (sizes[0], sizes[1]),
             "ap_large": (sizes[1], math.inf)}
    table = {}
    for c in classes:
        table[c] = cands[c][0]
        for t in cands[c]:
            trial = (interp, plus1, crowd_ignored, {c: t})
            if all(close(column(dump, c, trial, *spans[col]), report[(c, col)]) for col in COLUMNS):
                table[c] = t
                break
    return (interp, plus1, crowd_ignored, table)


def fit_boundary(dump, build, report, classes, col, areas):
    def fits(a):
        lo, hi = (0.0, a) if col == "ap_small" else (a, math.inf)
        return all(close(column(dump, c, build, lo, hi), report[(c, col)]) for c in classes)
    grid = np.exp(np.linspace(np.log(min(areas)), np.log(max(areas)), 120))
    misses = []
    for k, a in enumerate(grid):
        lo, hi = (0.0, a) if col == "ap_small" else (a, math.inf)
        misses.append(sum(abs(column(dump, c, build, lo, hi) - report[(c, col)]) for c in classes))
    for k in sorted(range(len(grid)), key=lambda k: misses[k])[:4]:
        lo, hi = grid[max(0, k - 1)], grid[min(len(grid) - 1, k + 1)]
        inside = [b for b in areas if lo <= b <= hi]
        for a, b in zip(inside, inside[1:]):
            if fits((a + b) / 2):
                return (a + b) / 2
    return None


def main():
    line, out = sys.argv[1], sys.argv[2]
    cal_images = load(os.path.join(line, "calibration"))
    with open(os.path.join(line, "calibration", "report.csv"), newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    classes = [r["class"] for r in rows]
    report = {(r["class"], col): float(r[col]) for r in rows for col in COLUMNS}
    cal = Dump(cal_images, classes)
    core = fit_core(cal, report, classes)
    tabled = isinstance(core[3], dict)
    sizes = [1024.0, 9216.0]
    build = settle_table(cal, core, report, classes, sizes) if tabled else core
    if not all(close(column(cal, c, build, 0.0, sizes[0]), report[(c, "ap_small")]) and
               close(column(cal, c, build, sizes[1], math.inf), report[(c, "ap_large")]) for c in classes):
        areas = cal.areas()
        a1 = fit_boundary(cal, build, report, classes, "ap_small", areas)
        a2 = fit_boundary(cal, build, report, classes, "ap_large", areas)
        sizes = [a1 or sizes[0], a2 or sizes[1]]
        if tabled:
            build = settle_table(cal, core, report, classes, sizes)
    print("build", build, "sizes", sizes, file=sys.stderr)
    spans = {"ap": (0.0, math.inf), "ap_small": (0.0, sizes[0]), "ap_medium": (sizes[0], sizes[1]),
             "ap_large": (sizes[1], math.inf)}
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["dump"] + ["class"] + list(COLUMNS))
        for name in sorted(os.listdir(os.path.join(line, "dumps"))):
            dump = Dump(load(os.path.join(line, "dumps", name)), classes)
            for c in classes:
                vals = [column(dump, c, build, *spans[col]) for col in COLUMNS]
                w.writerow([name, c] + ["-1" if v < 0 else "%.6f" % v for v in vals])


if __name__ == "__main__":
    main()
