Before a detector release goes out, every product line checks it on its own evaluation dashboard, and those dashboards don't agree with each other about how AP is computed. I need an evaluator that gives, for new detection dumps, exactly the numbers a given line's dashboard would show. It should be /app/evaluator/tally.py and be called as

```
python3 /app/evaluator/tally.py LINE_DIR OUT_CSV
```

LINE_DIR is one product line. Inside are a calibration dump together with the report that line's harness produced for it, and three new dumps (dumps/d1, d2, d3) with no report. Read /app/handbook/EVALUATION.md for what the harnesses compute and how the files look. /app/lines has two sample lines, each with an expected.csv of the line's numbers for its new dumps.

OUT_CSV needs the header dump,class,ap,ap_small,ap_medium,ap_large and a row for each new dump and class. Write -1 where a size range has no ground truth, same as the reports do. Example row: `d1,c0,0.498210,0.287500,0.603917,-1`.

For grading, a value is correct when it is within 0.0001 of the line's (or is -1 where the line's is -1), and a line passes if 95% or more of its 72 values are correct. Rows that are missing, unparseable or non-finite are wrong. We grade on 20 lines you haven't seen, generated in the grading image, and their harnesses are set up differently from the two samples in ways the samples don't show. 18 of the 20 need to pass.

Your evaluator gets one run per line on a fresh copy of the folder, as a regular user without root. It runs under the python3 installed in the image; apart from the standard library, numpy 2.2.6 is all there is to import. A line may take up to 120 seconds. Anything it needs has to be in /app/evaluator, because that folder is what gets kept for grading.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
