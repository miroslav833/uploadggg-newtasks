# The edition's diplomatic files

The edition publishes fifteenth-century polyphony from its manuscript and printed sources. Before a
piece is transcribed, every voice is encoded symbol by symbol as the source writes it: the note and
rest shapes, the dots, the blackening, the ligatures and whatever mensuration signs the source gives.
This note describes those files and the transcription files the engraver sets from.

## The piece file

One CSV per piece, `NAME.csv`, header

```
voice,section,n,kind,value,pitch,colour,lig,lig_pos,form,stem
```

Rows are grouped by voice (Superius, Contratenor, Tenor, Bassus as the source names them) and run in
the source's order. `section` numbers the piece's sections from 1: a section begins where the sources
set a new signature in the voices, and every voice of a section spans the same music, so the voices
end each section together. `n` counts a voice's rows from 1 across all its sections. `kind` is `sign`,
`note`, `rest` or `dot`.

A sign row opens a voice's section when the source gives that voice a sign there. The glyphs are
written as `O` (tempus perfectum, the breve of three semibreves), `C` (tempus imperfectum, the breve
of two), with a central dot `O.` `C.` (prolatio maior, the semibreve of three minims; without the dot
the semibreve has two) and with a stroke through the sign `O|` `C|` `O.|` `C.|`. Where a source gives a
voice no sign at a section, the file carries no sign row for that voice there.

```
Superius,1,1,sign,O.,,,,,,
```

A note row gives its shape in `value` (`L` long, `B` breve, `S` semibreve, `M` minim, `Sm`
semiminim), its `pitch` (letter and octave, `c4` being middle c), and its `colour`: `void` for a
hollow note, `full` for a note the source blackens. The sources blacken notes to take a third from a
perfect value (three blackened breves under O fill the time of two hollow ones); a blackened note whose
value is imperfect under the sign keeps that value and only marks the group it belongs to.

```
Tenor,1,7,note,B,d4,void,,,,
Tenor,1,8,note,S,f4,full,,,,
```

A rest row gives the rest's shape in `value`; a dot row has no other field. A dot stands in the row
after the symbol it follows; the sources write every dot with the same mark.

```
Tenor,1,9,rest,S,,,,,,
Tenor,1,10,dot,,,,,,,
```

Notes the source joins in one ligature share a `lig` number (counted afresh in each section of a voice) and are
numbered along it in `lig_pos`. `form` is `square` or `oblique`; an oblique element spans two notes,
and both carry `oblique`. `stem` records the stem drawn at the left of the ligature's first note:
`none`, `down` or `up`; later notes carry `none`. The direction between members is read from the
pitches.

```
Bassus,2,31,note,B,g3,void,2,1,square,down
Bassus,2,32,note,B,e3,void,2,2,square,none
Bassus,2,33,note,L,d3,void,2,3,square,none
```

## The transcription file

The engraver sets a piece from `NAME.csv` in the transcription folder, header

```
voice,n,onset,duration
```

with one row per note and rest, in the voice's order. `onset` is the time from the start of the voice
(sections follow one another without a gap) and `duration` the symbol's length, both in minims of
integer valor, written as integers or reduced fractions (`27/2`).

```
Tenor,7,12,4
Tenor,8,16,2
```

The sample pieces in `samples/` come with their transcriptions as `NAME.transcription.csv`.
