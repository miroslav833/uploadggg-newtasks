#!/bin/bash
set -e
mkdir -p /app/edition
cp "$(dirname "$0")"/edition/transcribe.py /app/edition/transcribe.py
