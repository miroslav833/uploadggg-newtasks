"""Transcribe white mensural sources into modern rhythm.

    python3 transcribe.py IN_DIR OUT_DIR

Every piece file in IN_DIR gets a transcription in OUT_DIR (voice,n,onset,duration), onset and
duration in minims of integer valor as reduced fractions. Ligature values come from propriety and
perfection; under each voice-section's sign the symbols are read by the rules of the notation
(imperfection a parte post unless a dot of division forbids it, alteration of the second of two
smaller notes before a larger one, perfections of three, dots that add or divide as the count
requires, blackened notes and rests fixed), enumerating the readings of the dots; an unsigned
voice-section is read under the sign whose reading spans the same music as the signed voices.
"""
import csv
import os
import sys
from fractions import Fraction as Fr

SIGNS = {"O": (3, 2, False), "C": (2, 2, False), "O.": (3, 3, False), "C.": (2, 3, False),
         "O|": (3, 2, True), "C|": (2, 2, True), "O.|": (3, 3, True), "C.|": (2, 3, True)}
STEP = {"c": 0, "d": 1, "e": 2, "f": 3, "g": 4, "a": 5, "b": 6}


def pnum(p):
    return STEP[p[0]] + 7 * int(p[1:])


def base(letter, T, P):
    return {"L": Fr(2 * T * P), "B": Fr(T * P), "S": Fr(P), "M": Fr(1), "Sm": Fr(1, 2)}[letter]


# --- ligatures --------------------------------------------------------------------------------

def ligature_values(members):
    """members: [(pitch, form, stem)] -> value letters. First note: a stem up makes the first two
    semibreves; otherwise with propriety (stem down when descending, none when ascending) the first is
    a breve, without it a long. Last note: descending and square is a long, otherwise a breve."""
    n = len(members)
    out = ["B"] * n
    if n < 2:
        return out
    ps = [pnum(m[0]) for m in members]
    stem = members[0][2]
    if stem == "up":
        out[0] = out[1] = "S"
    elif ps[1] < ps[0]:
        out[0] = "B" if stem == "down" else "L"
    else:
        out[0] = "L" if stem == "down" else "B"
    if not (stem == "up" and n == 2):
        out[-1] = "L" if (ps[-1] < ps[-2] and members[-1][1] == "square") else "B"
    return out


# --- the reading of one voice-section under one sign -------------------------------------------

class Sym:
    __slots__ = ("n", "kind", "letter", "black", "val", "dotted", "role", "roles", "imp", "alt")

    def __init__(self, n, kind, letter, black):
        self.n, self.kind, self.letter, self.black = n, kind, letter, black
        self.val = None
        self.dotted = False
        self.role = None       # for dots: 'add' | 'div'
        self.roles = None
        self.imp = False
        self.alt = False


def prepare(symbols, T, P):
    """symbols: list of (n, kind, letter, black). Returns Sym list with base values and forced dots."""
    out = []
    prev = None
    for n, kind, letter, black in symbols:
        s = Sym(n, kind, letter, black)
        if kind in ("note", "rest"):
            s.val = base(letter, T, P)
            if kind == "note" and black and ((letter in ("B", "L") and T == 3) or (letter == "S" and P == 3)):
                s.val = s.val * Fr(2, 3)
            prev = s
        else:
            if prev is None or prev.kind != "note" or prev.black or prev.dotted:
                s.roles = ["div"]
            elif prev.letter == "L" or (prev.letter == "B" and T == 3) or (prev.letter == "S" and P == 3):
                s.roles = ["div"]
            elif (T == 2 and P == 2) or prev.letter == "B":
                prev.val = prev.val * Fr(3, 2)
                prev.dotted = True
                s.role = "add"
            else:
                s.roles = ["add", "div"]
        out.append(s)
    return out


class Bound:
    __slots__ = ("sym", "imperfectable", "blocked", "already")

    def __init__(self, sym, imperfectable, blocked):
        self.sym, self.imperfectable, self.blocked, self.already = sym, imperfectable, blocked, False


def plan(content, unit, left, right):
    """content: list of (sym, val); returns list of (values {sym: val}, left_delta, right_delta)."""
    total = sum(v for _, v in content)
    if total == 0:
        return [({}, Fr(0), Fr(0))]
    k = total / unit
    prefix, acc = set(), Fr(0)
    for _, v in content:
        acc += v
        prefix.add(acc)
    post_ok = left is not None and left.imperfectable and not left.blocked and not left.already
    ante_ok = right is not None and right.imperfectable and not right.blocked

    def lands(post, alt, ante):
        pos, need = Fr(0), []
        if post:
            pos += unit
            need.append(pos)
        while total - pos > ante * unit + (2 * unit if alt else 0):
            pos += 3 * unit
            need.append(pos)
        if alt:
            pos += 2 * unit
            need.append(pos)
        if ante:
            pos += unit
            need.append(pos)
        return pos == total and all(p in prefix for p in need)

    def plain(sv):
        s, v = sv
        return s.kind == "note" and not s.black and not s.dotted and v == unit

    alt_ok = len(content) >= 2 and plain(content[-1]) and plain(content[-2])

    def vals(alt):
        d = {s: v for s, v in content}
        if alt:
            d[content[-1][0]] = content[-1][1] * 2
        return d

    outs = []
    if k.denominator != 1:
        for post in (1, 0):
            for ante in (0, 1):
                for alt in (0, 1):
                    if (alt and ante) or (post and not post_ok) or (ante and not ante_ok) or (alt and not alt_ok):
                        continue
                    m = k + alt - post - ante
                    if m.denominator == 1 and m % 3 == 0 and lands(post, alt, ante):
                        outs.append((vals(alt), Fr(post) * unit, Fr(ante) * unit))
        return outs
    r = k % 3
    if r == 0:
        return [(vals(0), Fr(0), Fr(0))] if lands(0, 0, 0) else []
    if r == 1:
        if post_ok and lands(1, 0, 0):
            return [(vals(0), unit, Fr(0))]
        if ante_ok and lands(0, 0, 1):
            return [(vals(0), Fr(0), unit)]
        return []
    if alt_ok and lands(0, 1, 0):
        return [(vals(1), Fr(0), Fr(0))]
    if post_ok and ante_ok and lands(1, 0, 1):
        return [(vals(0), unit, unit)]
    return []


def level(syms, T, P, which):
    """Enumerate readings at one level; returns list of assignment lists."""
    unit = Fr(1) if which == "prolatio" else Fr(P)
    perfect = "S" if which == "prolatio" else "B"
    results = []

    def is_bound(s):
        if s.kind == "dot":
            return s.role == "div"
        if which == "prolatio":
            return s.letter in ("L", "B", "S") or s.black
        return s.letter in ("L", "B") or s.black

    def bound_of(s):
        if s.kind == "dot":
            return Bound(s, False, True)
        if s.kind != "note" or s.black or s.dotted or s.letter != perfect:
            return Bound(s, False, False)
        return Bound(s, True, False)

    def scan(i, content, left, acc):
        while i < len(syms):
            s = syms[i]
            if s.kind == "dot":
                if s.role == "add":
                    i += 1
                    continue
                opts = s.roles if s.role is None else [s.role]
                if "add" in opts and content and content[-1][0].kind == "note" and not content[-1][0].dotted:
                    c = content[-1][0]
                    scan(i + 1, content[:-1] + [(c, content[-1][1] * Fr(3, 2))], left, acc + [(s, "add", c)])
                if "div" in opts:
                    finish(content, left, s, i, acc)
                return
            if is_bound(s):
                finish(content, left, s, i, acc)
                return
            content = content + [(s, s.val)]
            i += 1
        finish(content, left, None, len(syms), acc)

    def finish(content, left, bsym, bpos, acc):
        right = bound_of(bsym) if bsym is not None else None
        for values, ld, rd in plan(content, unit, left, right):
            acc2 = list(acc) + [(s, v, None) for s, v in values.items()]
            if ld:
                acc2.append((left.sym, "imp", ld))
            if bsym is None:
                results.append(acc2)
                continue
            if bsym.kind == "dot":
                acc2.append((bsym, "div", None))
                nl = Bound(bsym, False, True)
            else:
                nl = Bound(bsym, right.imperfectable, False)
                if rd:
                    nl.already = True
                    acc2.append((bsym, "imp", rd))
                nxt = syms[bpos + 1] if bpos + 1 < len(syms) else None
                if nxt is not None and nxt.kind == "dot" and nxt.role != "add":
                    nl.blocked = True
            scan(bpos + 1, [], nl, acc2)

    scan(0, [], None, [])
    return results


def clone(syms):
    out = []
    for s in syms:
        t = Sym(s.n, s.kind, s.letter, s.black)
        t.val, t.dotted, t.role, t.roles, t.imp, t.alt = s.val, s.dotted, s.role, s.roles, s.imp, s.alt
        out.append(t)
    return out


def apply(syms, acc):
    new = clone(syms)
    by = {id(s): t for s, t in zip(syms, new)}
    for s, what, extra in acc:
        t = by[id(s)]
        if what == "add":
            t.role = "add"
            c = by[id(extra)]
            if not c.dotted:
                c.val = c.val * Fr(3, 2)
                c.dotted = True
        elif what == "div":
            t.role = "div"
        elif what == "imp":
            t.val = t.val - extra
            t.imp = True
        elif what != t.val:
            if what == t.val * 2:
                t.alt = True
            t.val = what
    return new


def readings(symbols, T, P):
    """All readings of a voice-section under (T, P): list of dicts n -> written value."""
    syms = prepare(symbols, T, P)
    out, seen = [], set()
    for acc1 in (level(syms, T, P, "prolatio") if P == 3 else [[]]):
        s1 = apply(syms, acc1)
        for acc2 in (level(s1, T, P, "tempus") if T == 3 else [[]]):
            s2 = apply(s1, acc2)
            if any(s.kind == "dot" and s.role is None for s in s2):
                continue
            vals = {s.n: s.val for s in s2 if s.kind in ("note", "rest")}
            key = tuple(sorted(vals.items()))
            if key not in seen:
                seen.add(key)
                out.append(vals)
    return out


# --- a piece ----------------------------------------------------------------------------------

def read_piece(path):
    voices = {}      # voice -> section -> {"sign": str|None, "rows": [...]}
    order = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            v = r["voice"]
            if v not in voices:
                voices[v] = {}
                order.append(v)
            sec = int(r["section"])
            d = voices[v].setdefault(sec, {"sign": None, "rows": []})
            if r["kind"] == "sign":
                d["sign"] = r["value"]
            else:
                d["rows"].append(r)
    return order, voices


def symbols_of(rows):
    ligs = {}
    for r in rows:
        if r["kind"] == "note" and r["lig"]:
            ligs.setdefault(r["lig"], []).append(r)
    letters = {}
    for members in ligs.values():
        members.sort(key=lambda r: int(r["lig_pos"]))
        vals = ligature_values([(r["pitch"], r["form"], r["stem"]) for r in members])
        for r, v in zip(members, vals):
            letters[r["n"]] = v
    out = []
    for r in rows:
        if r["kind"] == "dot":
            out.append((int(r["n"]), "dot", None, False))
        else:
            out.append((int(r["n"]), r["kind"], letters.get(r["n"], r["value"]), r["colour"] == "full"))
    return out


def sounding(vals, stroke):
    return {n: (v / 2 if stroke else v) for n, v in vals.items()}


def transcribe(path):
    order, voices = read_piece(path)
    sections = sorted({s for v in voices.values() for s in v})
    chosen = {}       # (voice, section) -> sounding values
    for sec in sections:
        totals = []
        pending = []
        for v in order:
            d = voices[v].get(sec)
            if d is None:
                continue
            syms = symbols_of(d["rows"])
            if d["sign"] in SIGNS:
                T, P, stroke = SIGNS[d["sign"]]
                rs = readings(syms, T, P)
                if not rs:
                    rs = [{n: base(l, T, P) for n, k, l, b in syms if k in ("note", "rest")}]
                cands = [sounding(r, stroke) for r in rs]
                chosen[(v, sec)] = cands
                totals.append([sum(c.values()) for c in cands])
            else:
                pending.append((v, syms))
        # the section's span: the total every signed voice agrees on
        span = None
        for tl in totals:
            common = set(tl) if span is None else span & set(tl)
            span = common if common else span
        if span:
            span_val = sorted(span)[0]
            for key, cands in list(chosen.items()):
                if key[1] == sec and isinstance(cands, list):
                    fit = [c for c in cands if sum(c.values()) == span_val] or cands
                    chosen[key] = fit[0]
        else:
            span_val = None
            for key, cands in list(chosen.items()):
                if key[1] == sec and isinstance(cands, list):
                    chosen[key] = cands[0]
        for v, syms in pending:
            best = None
            for sign, (T, P, stroke) in SIGNS.items():
                for r in readings(syms, T, P):
                    c = sounding(r, stroke)
                    if span_val is None or sum(c.values()) == span_val:
                        if best is None:
                            best = c
            if best is None:
                T, P, stroke = SIGNS["C"]
                best = sounding({n: base(l, T, P) for n, k, l, b in syms if k in ("note", "rest")}, stroke)
            chosen[(v, sec)] = best
    rows = []
    for v in order:
        t = Fr(0)
        for sec in sorted(voices[v]):
            vals = chosen[(v, sec)]
            for n, kind, letter, black in symbols_of(voices[v][sec]["rows"]):
                if kind in ("note", "rest"):
                    d = vals[n]
                    rows.append((v, n, t, d))
                    t += d
    return rows


def fmt(x):
    return str(x.numerator) if x.denominator == 1 else "%d/%d" % (x.numerator, x.denominator)


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    indir, outdir = argv[1], argv[2]
    os.makedirs(outdir, exist_ok=True)
    for name in sorted(os.listdir(indir)):
        if not name.endswith(".csv") or name.endswith(".transcription.csv"):
            continue
        rows = transcribe(os.path.join(indir, name))
        with open(os.path.join(outdir, name), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["voice", "n", "onset", "duration"])
            for v, n, t, d in rows:
                w.writerow([v, n, fmt(t), fmt(d)])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
