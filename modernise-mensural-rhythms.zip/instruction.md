Write a transcriber that turns the edition's diplomatic files of white mensural sources into modern rhythm. It is run as

```
python3 /app/edition/transcribe.py IN_DIR OUT_DIR
```

IN_DIR holds one piece file per piece, laid out as `/app/CORPUS.md` describes (one row per symbol: signs, notes, rests and dots, with pitch, colour and ligature fields). For each piece file `NAME.csv`, OUT_DIR must get `NAME.csv` with a header row and one row per note and rest:

```
voice,n,onset,duration
Tenor,14,27/2,3/2
```

`onset` is the time from the start of the voice (sections follow one another) and `duration` the symbol's length, both in minims of integer valor, written as integers or reduced fractions. Values follow the rules of white mensural notation under the sign in force, with these conventions: a stroke through a sign halves every value of that voice-section; modus is imperfect, so a long is two breves; a rest keeps its written value; blackening takes a third only from a perfect value; a voice-section with no sign row is read under the sign that makes it span the same music as the signed voices of its section.

Four pieces are in `/app/samples`, each with its transcription. Grading uses 20 other pieces, which carry signs, colours, ligature forms and dot usages these four do not all show; every one follows the corpus notes.

A symbol is right when its onset and duration both equal the edition's. A piece counts when at most 2 of its symbols are wrong, a missing row counting as wrong. At least 18 of the 20 pieces must count. The transcriber runs once over all the pieces, as an unprivileged user with the image's python3 and standard library, within 420 seconds; everything it needs must be under `/app/edition`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
