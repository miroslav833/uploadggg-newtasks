#!/bin/bash
# Scores the solver's transcriber on the sealed pieces. The reward folder is locked to root before any
# solver code runs, emptied, and left holding reward.txt and the report only.
umask 077
LOGS=/logs/verifier
mkdir -p "$LOGS"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS"
if [ "$(stat -c %u:%a "$LOGS")" != "0:700" ]; then
    echo "the reward folder could not be locked; nothing is scored" >&2
    exit 0
fi
find "$LOGS" -mindepth 1 -exec rm -rf {} + 2>/dev/null
rm -f "$LOGS/reward.json"
echo 0 > "$LOGS/reward.txt"
REPORT=$(mktemp -d /run/edition-report.XXXXXX)
cd /tests || exit 0
verdict=0
python3 -m pytest -q -rA -p no:cacheprovider -s --ctrf "$REPORT/ctrf.json" test_transcription.py && verdict=1
find "$LOGS" -mindepth 1 ! -user 0 -exec rm -rf {} + 2>/dev/null
rm -f "$LOGS/reward.json"
cp "$REPORT/ctrf.json" "$LOGS/ctrf.json" 2>/dev/null
echo "$verdict" > "$LOGS/reward.txt"
find "$LOGS" -mindepth 1 -type f -exec chmod 644 {} +
chmod 755 "$LOGS"
exit 0
