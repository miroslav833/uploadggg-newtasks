"""The verifier's own forward model of a sealed piece.

Each sealed piece carries, beside its diplomatic file, a state file: the sign every voice-section was
read under (signed or not), and for every note or rest its value letter and whether it stands plain,
imperfected, altered, dotted or blackened, for every dot whether it adds or divides. From those states
alone this module rebuilds every written value, places it on the grid of perfections of its level,
checks that the voices of each section span the same music, and lays out the onsets. It shares no code
with the reference transcriber; test 1 asserts that what it rebuilds is the sealed transcription.
"""
import csv
import json
import os
from fractions import Fraction as Fr

SIGNS = {"O": (3, 2, False), "C": (2, 2, False), "O.": (3, 3, False), "C.": (2, 3, False),
         "O|": (3, 2, True), "C|": (2, 2, True), "O.|": (3, 3, True), "C.|": (2, 3, True)}


def written_value(letter, state, T, P):
    base = {"L": Fr(2 * T * P), "B": Fr(T * P), "S": Fr(P), "M": Fr(1), "Sm": Fr(1, 2)}[letter]
    if state == "plain":
        return base
    if state == "imperfected":
        return base - (Fr(P) if letter in ("B", "L") else Fr(1))
    if state == "altered":
        return base * 2
    if state == "dotted":
        return base * Fr(3, 2)
    if state == "black":
        perfect_level = (letter in ("B", "L") and T == 3) or (letter == "S" and P == 3)
        return base * Fr(2, 3) if perfect_level else base
    raise ValueError(state)


def load_piece(path):
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows


def rebuild(piece_path, state_path):
    """Returns ([(voice, n, onset, duration)], problems)."""
    rows = load_piece(piece_path)
    with open(state_path, encoding="utf-8") as f:
        st = json.load(f)
    signs = {(s["voice"], s["section"]): s for s in st["sections"]}
    sym = st["symbols"]
    out, problems = [], []
    voices = []
    for r in rows:
        if r["voice"] not in voices:
            voices.append(r["voice"])
    spans = {}
    for v in voices:
        onset = Fr(0)
        secs = sorted({int(r["section"]) for r in rows if r["voice"] == v})
        for sec in secs:
            info = signs[(v, sec)]
            T, P, stroke = SIGNS[info["sign"]]
            t = Fr(0)          # written minims from the section's start
            for r in rows:
                if r["voice"] != v or int(r["section"]) != sec:
                    continue
                key = "%s:%s" % (v, r["n"])
                if r["kind"] == "sign":
                    if not info["signed"] or r["value"] != info["sign"]:
                        problems.append("%s: sign row disagrees with the sealed state" % key)
                    continue
                if r["kind"] == "dot":
                    role = sym[key]["dot"]
                    if role == "div":
                        grid = 3 if P == 3 else 3 * P
                        if t % grid != 0:
                            problems.append("%s: dot of division off the grid at %s" % (key, t))
                    continue
                s = sym[key]
                val = written_value(s["letter"], s["state"], T, P)
                if Fr(s["written"]) != val:
                    problems.append("%s: written value %s is not %s" % (key, s["written"], val))
                # grid checks at the symbol's own level
                L = s["letter"]
                white = r["kind"] == "note" and r["colour"] != "full"
                if L in ("B", "L") and T == 3 and white:
                    if s["state"] == "plain" and t % (3 * P) != 0:
                        problems.append("%s: perfect breve off its perfection at %s" % (key, t))
                    if s["state"] == "imperfected" and t % (3 * P) != 0 and (t + val) % (3 * P) != 0:
                        problems.append("%s: imperfected breve neither opens nor closes a perfection" % key)
                if L == "S" and P == 3 and white:
                    if s["state"] == "plain" and t % 3 != 0:
                        problems.append("%s: perfect semibreve off its perfection at %s" % (key, t))
                    if s["state"] == "imperfected" and t % 3 != 0 and (t + val) % 3 != 0:
                        problems.append("%s: imperfected semibreve neither opens nor closes a perfection" % key)
                if s["state"] == "altered":
                    unit = Fr(P) if L == "S" else Fr(1)
                    if (t + val) % (3 * unit) != 0:
                        problems.append("%s: altered note does not close a perfection" % key)
                dur = val / 2 if stroke else val
                out.append((v, int(r["n"]), onset, dur))
                onset += dur
                t += val
            sounding = t / 2 if stroke else t
            if Fr(info["total"]) != sounding:
                problems.append("%s section %d: span %s, sealed %s" % (v, sec, sounding, info["total"]))
            spans.setdefault(sec, set()).add(sounding)
    for sec, vals in spans.items():
        if len(vals) != 1:
            problems.append("section %d: voices span %s" % (sec, sorted(vals)))
    return out, problems


def load_key(path):
    key = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            key[(r["voice"], int(r["n"]))] = (Fr(r["onset"]), Fr(r["duration"]))
    return key


def vault_pieces(vault):
    return sorted(n[:-4] for n in os.listdir(vault)
                  if n.endswith(".csv") and not n.endswith(".transcription.csv"))
