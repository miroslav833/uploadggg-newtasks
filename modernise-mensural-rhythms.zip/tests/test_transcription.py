import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import grade_edition   # noqa: E402
import mensura         # noqa: E402

VAULT = grade_edition.VAULT


def test_sealed_transcriptions_follow_from_the_sealed_states():
    names = mensura.vault_pieces(VAULT)
    assert len(names) == 20
    for name in names:
        rows, problems = mensura.rebuild(os.path.join(VAULT, name + ".csv"),
                                         os.path.join(VAULT, name + ".state.json"))
        assert not problems, (name, problems[:5])
        key = mensura.load_key(os.path.join(VAULT, name + ".transcription.csv"))
        assert len(rows) == len(key), name
        for voice, n, onset, dur in rows:
            assert key[(voice, n)] == (onset, dur), (name, voice, n, onset, dur, key[(voice, n)])


def test_transcriber_counts_enough_pieces():
    assert os.path.isfile(grade_edition.TOOL), "no /app/edition/transcribe.py"
    wrong = grade_edition.run_transcriber()
    counted = [p for p, w in wrong.items() if w <= grade_edition.WRONG_ALLOWED]
    print("pieces counted %d of %d (wrong symbols: %s)"
          % (len(counted), len(wrong), ", ".join("%s %d" % kv for kv in sorted(wrong.items()))))
    assert len(counted) >= grade_edition.NEEDED, \
        "%d of 20 pieces counted; %d needed" % (len(counted), grade_edition.NEEDED)
