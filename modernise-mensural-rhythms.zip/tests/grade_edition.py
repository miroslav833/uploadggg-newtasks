"""Run the solver's transcriber once over the sealed pieces and count the symbols it gets wrong.

The pieces are copied, without their transcriptions or states, into a root-owned folder that anyone
can read; the output folder belongs to a numeric account no user or process holds. The transcriber runs
under that account in its own session with memory, file-size and wall-time limits, and every process of
the account is killed before anything is read. Each output is read as text through O_NOFOLLOW, only as
a regular file of at most 4 MiB, and nothing in it is executed.
"""
import csv
import os
import pwd
import resource
import shutil
import signal
import subprocess
import time
from fractions import Fraction as Fr

VAULT = "/tests/vault"
WORK = "/var/tmp/edition-run"
TOOL = "/app/edition/transcribe.py"
LIMIT_S = 420            # the transcriber's wall-clock budget for all pieces
WRONG_ALLOWED = 2        # symbols a piece may have wrong and still count
NEEDED = 18              # pieces of 20
CAP = 4 << 20


def pieces():
    return sorted(n[:-4] for n in os.listdir(VAULT)
                  if n.endswith(".csv") and not n.endswith(".transcription.csv"))


def account_in_use(uid):
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    return True
            except FileNotFoundError:
                pass
    return False


def spare_account(start=61000):
    taken = {p.pw_uid for p in pwd.getpwall()}
    uid = start
    while uid in taken or account_in_use(uid):
        uid += 1
    return uid


def kill_account(uid):
    for _ in range(200):
        alive = False
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    alive = True
                    os.kill(int(d), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError):
                pass
        if not alive:
            return
        time.sleep(0.05)


def key_of(piece):
    key = {}
    with open(os.path.join(VAULT, piece + ".transcription.csv"), newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            key[(r["voice"], int(r["n"]))] = (Fr(r["onset"]), Fr(r["duration"]))
    return key


def filed_rows(path):
    """{(voice, n): (onset, duration)} read as text; rows that do not parse are dropped."""
    out = {}
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return out
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > CAP:
        return out
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, newline="", encoding="utf-8", errors="replace") as fh:
        try:
            for rec in csv.DictReader(fh):
                try:
                    n = int(str(rec["n"]).strip())
                    onset = Fr(str(rec["onset"]).strip())
                    dur = Fr(str(rec["duration"]).strip())
                except (TypeError, ValueError, KeyError, ZeroDivisionError):
                    continue
                out[(str(rec["voice"]).strip(), n)] = (onset, dur)
        except csv.Error:
            return out
    return out


def wrong_symbols(filed, key):
    """Symbols of the edition the filing misses or values differently (a missing row counts)."""
    return sum(1 for k, v in key.items() if filed.get(k) != v)


def score_dir(out_dir, vault=VAULT):
    """{piece: wrong symbols} for a folder of transcriptions, used by the tests and by the author's
    readings."""
    result = {}
    for piece in sorted(n[:-4] for n in os.listdir(vault)
                        if n.endswith(".csv") and not n.endswith(".transcription.csv")):
        key = {}
        with open(os.path.join(vault, piece + ".transcription.csv"), newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                key[(r["voice"], int(r["n"]))] = (Fr(r["onset"]), Fr(r["duration"]))
        result[piece] = wrong_symbols(filed_rows(os.path.join(out_dir, piece + ".csv")), key)
    return result


def run_transcriber():
    """Copy the pieces, run the tool once under a spare account, return {piece: wrong symbols}."""
    shutil.rmtree(WORK, ignore_errors=True)
    src = os.path.join(WORK, "pieces")
    out = os.path.join(WORK, "transcriptions")
    os.makedirs(src)
    os.makedirs(out)
    for piece in pieces():
        shutil.copyfile(os.path.join(VAULT, piece + ".csv"), os.path.join(src, piece + ".csv"))
    for root, dirs, files in os.walk(WORK):
        os.chown(root, 0, 0)
        os.chmod(root, 0o755)
        for f in files:
            os.chown(os.path.join(root, f), 0, 0)
            os.chmod(os.path.join(root, f), 0o644)
    uid = spare_account()
    os.chown(out, uid, uid)
    os.chmod(out, 0o700)

    def demote():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": out, "TMPDIR": out, "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        subprocess.run(["python3", TOOL, src, out], preexec_fn=demote, env=env, cwd=out,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=LIMIT_S)
    except subprocess.TimeoutExpired:
        pass
    kill_account(uid)
    return {piece: wrong_symbols(filed_rows(os.path.join(out, piece + ".csv")), key_of(piece))
            for piece in pieces()}
