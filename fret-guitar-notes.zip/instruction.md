Write a program that labels every event of a recorded guitar take (a single note, a double stop or a strummed chord) with each string that sounds, the fret it was held at and the semitones it was bent, as training targets for a tablature model. It runs as

```
python3 /app/fretter/fret.py TAKE_DIR OUT_CSV
```

where TAKE_DIR holds one take: `setup.csv` (guitar, string count, string set, scale length), `events.csv` (event codes in onset order) and `lines.csv` (the spectral lines the tracker listed for each event: frequency and level). `/app/corpus/HANDBOOK.md` describes the capture, the tracker's output, the set-up sheet, the string sets and the tab conventions; `/app/corpus/strings.csv` is the string-set table, present wherever the program runs. Four labelled sample takes are in `/app/corpus/takes`, each with its `tab.csv`.

OUT_CSV gets a header row and one row per sounding string of each event:

```
event,string,fret,bend
K7QD,2,3,0
R2MX,2,3,0
R2MX,3,2,0
```

`string` counts from 1 at the highest-pitched string as strung; `fret` counts from the nut, 0 for an open string; `bend` is 0, 1 or 2, the whole semitones the note was bent above its fret. In every take each string sounds at least two unbent single notes, the open pitches of any two strings lie at least three semitones apart, every string sits inside its set's rated tension window, a string sounds at most once in an event, and no note of a chord is bent. An event is right when its set of rows equals the reference's exactly; a missing or unparseable row is wrong.

Grading runs the program on 20 other takes that are not on this machine, on string sets, string counts, scale lengths, open pitches, chords and playing the samples do not all show. A take counts when at most 3 of its events are wrong, and at least 18 of the 20 takes must count. The program runs once per take on a fresh copy of the folder, as an unprivileged user, with python3, the standard library and numpy 2.2.6, and 120 seconds per take. Anything else it needs must be inside `/app/fretter`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
