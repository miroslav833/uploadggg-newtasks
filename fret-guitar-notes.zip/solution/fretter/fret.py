#!/usr/bin/env python3
"""Labels every event of a take with the strings that sound, their frets and bends.

    python3 fret.py TAKE_DIR OUT_CSV

Each sounding string contributes a stiff-string series f_k = k f1 sqrt(1 + B k^2) to an event's
lines. B over f1^2 is one constant along a string, set by the string's core, mass and tension; a
bent note carries the constant of a higher tension. A single note's constant gives its string's
tension through the table, and so the open pitch; the take's open pitches are the one set, one per
string, that explains its single notes once with every string sounding an unbent note. Under those
open pitches every (string, fret, bend) predicts a series, and an event's sounding notes are the
candidates whose own lines fit their string's tension and together account for every line.
"""
import csv
import math
import os
import sys

E_STEEL = 2.0e11
INCH = 0.0254
TABLE = os.environ.get("FRET_STRING_TABLE", "/app/corpus/strings.csv")
BAND = (100.0, 12000.0)
MERGE_HZ = 1.5
MAX_FRET = 15
FRET_TOL = 0.3
PITCH_TOL = 0.3
WINDOW_SLACK = 0.08
RES_TOL = 0.3           # semitones: a candidate's tension reading against its string
OWN_LINES = 3           # lines a candidate must own to be read at all
PRESENCE = 0.6          # share of a candidate's partials up to order 12 that some line must match
STRONG = 12


def read_table(set_code):
    rows = []
    with open(TABLE, newline="") as fh:
        for r in csv.DictReader(fh):
            if r["string_set"] == set_code:
                rows.append(dict(string=int(r["string"]), core=float(r["core_in"]) * INCH,
                                 mu=float(r["mass_kg_per_m"]), lo=float(r["rated_tension_min_n"]),
                                 hi=float(r["rated_tension_max_n"])))
    rows.sort(key=lambda r: r["string"])
    return rows


def read_take(take_dir):
    with open(os.path.join(take_dir, "setup.csv"), newline="") as fh:
        setup = next(csv.DictReader(fh))
    order = []
    with open(os.path.join(take_dir, "events.csv"), newline="") as fh:
        for r in csv.DictReader(fh):
            order.append(r["event"])
    lines = {}
    with open(os.path.join(take_dir, "lines.csv"), newline="") as fh:
        for r in csv.DictReader(fh):
            lines.setdefault(r["event"], []).append(float(r["freq_hz"]))
    for v in lines.values():
        v.sort()
    return setup, order, lines


def tol(f):
    return 0.002 * f + 1.6


# --- one series -----------------------------------------------------------------------------

def stiff_fit(pairs):
    xs = [k * k for _, k in pairs]
    ys = [(f / k) ** 2 for f, k in pairs]
    n = len(pairs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    c = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx > 0 else 0.0
    a0 = my - c * mx
    if a0 <= 0:
        return None
    return math.sqrt(a0), max(0.0, c / a0)


def assign(freqs, f1, B):
    chosen = {}
    for f in freqs:
        r = (f / f1) ** 2
        k = math.sqrt((math.sqrt(1.0 + 4.0 * B * r) - 1.0) / (2.0 * B)) if B > 0 else math.sqrt(r)
        k = max(1, int(round(k)))
        pred = k * f1 * math.sqrt(1.0 + B * k * k)
        if abs(f - pred) < tol(pred) and (k not in chosen or abs(chosen[k][1]) > abs(f - pred)):
            chosen[k] = (f, f - pred)
    return [(f, k) for k, (f, _) in chosen.items()]


def series(freqs):
    """(f1, B, lines explained) of the one series that explains the most lines."""
    best = None
    for a in (1, 2, 3):
        for base in freqs[:2]:
            f1 = base / a
            low = [(f, round(f / f1)) for f in freqs
                   if f <= 7.5 * f1 and round(f / f1) >= 1 and abs(f / f1 - round(f / f1)) < 0.06]
            if len(set(k for _, k in low)) < 3:
                continue
            fit = stiff_fit(low)
            if fit is None:
                continue
            f1b, B = fit
            pairs = low
            for _ in range(4):
                pairs = assign(freqs, f1b, B)
                if len(pairs) < 3:
                    break
                fit = stiff_fit(pairs)
                if fit is None:
                    break
                f1b, B = fit
            if len(pairs) >= 3 and (best is None or len(pairs) > best[2] or (len(pairs) == best[2] and f1b > best[0])):
                best = (f1b, B, len(pairs))
    return best if best else (None, None, 0)


# --- single notes: readings and the take's open pitches -------------------------------------

def readings(table, L0, f1, B):
    """Every (string, fret, bend, open pitch as a MIDI number) the stiff-string law allows a
    single note."""
    out = []
    if not f1 or not B or not (math.isfinite(f1) and math.isfinite(B)) or B <= 0:
        return out
    K = B / (f1 * f1)
    for row in table:
        for b in (0, 1, 2):
            Ks = K * 2.0 ** (b / 3.0)
            tension = math.sqrt(math.pi ** 3 * E_STEEL * row["core"] ** 4 * row["mu"] / (16.0 * Ks))
            if not (1 - WINDOW_SLACK) * row["lo"] <= tension <= (1 + WINDOW_SLACK) * row["hi"]:
                continue
            f_open = math.sqrt(tension / row["mu"]) / (2.0 * L0)
            n = 12.0 * math.log2(f1 / (f_open * 2.0 ** (b / 12.0)))
            if abs(n - round(n)) > FRET_TOL or not 0 <= round(n) <= 22:
                continue
            p = 69.0 + 12.0 * math.log2(f_open / 440.0)
            if abs(p - round(p)) > PITCH_TOL:
                continue
            out.append((row["string"], int(round(n)), b, int(round(p))))
    return out


def choose_open_pitches(n_strings, per_note):
    """One open pitch per string, at least three semitones apart, each sounding an unbent note,
    explaining the most single notes."""
    cand, unbent = {}, set()
    for i, reads in enumerate(per_note):
        for s, n, b, p in reads:
            cand.setdefault((s, p), set()).add(i)
            if b == 0:
                unbent.add((s, p))
    per_string = {s: [] for s in range(1, n_strings + 1)}
    for (s, p), ids in cand.items():
        if (s, p) in unbent:
            per_string[s].append((p, frozenset(ids)))
    best = [None, -1]

    def search(s, chosen, explained):
        if s > n_strings:
            if len(explained) > best[1]:
                best[0], best[1] = chosen, len(explained)
            return
        options = per_string[s] or [(None, frozenset())]
        for p, ids in options:
            if p is not None and any(q is not None and abs(p - q) < 3 for q in chosen):
                continue
            search(s + 1, chosen + (p,), explained | ids)

    search(1, (), frozenset())
    return best[0]


# --- events: the candidates under the open pitches ------------------------------------------

def nominal(row, L0, base_hz, fret, bend):
    L = L0 * 2.0 ** (-fret / 12.0)
    f1 = base_hz * 2.0 ** ((fret + bend) / 12.0)
    tension = row["mu"] * (2.0 * L * f1) ** 2
    return f1, math.pi ** 3 * E_STEEL * row["core"] ** 4 / (64.0 * tension * L * L)


def candidates(table, L0, bases):
    """Every (string, fret, bend) with its nominal pitch and stretch."""
    out = []
    for row in table:
        base = bases[row["string"] - 1]
        if base is None:
            continue
        base_hz = 440.0 * 2.0 ** ((base - 69) / 12.0)
        for fret in range(0, MAX_FRET + 1):
            for bend in ((0, 1, 2) if row["string"] <= 3 and fret >= 2 else (0,)):
                f1, B = nominal(row, L0, base_hz, fret, bend)
                out.append((row["string"], fret, bend, f1, B))
    return out


def partials(f1, B, kmax=None):
    ps = []
    k = 1
    while True:
        p = k * f1 * math.sqrt(1.0 + B * k * k)
        if p > BAND[1] or (kmax and k > kmax):
            break
        ps.append((k, p))
        k += 1
    return ps


def anchor(freqs, f1n, Bn):
    """The candidate's pitch read off the lines nearest its lowest orders (within 16 cents)."""
    est = []
    for k, p in partials(f1n, Bn, 6):
        if p < BAND[0]:
            continue
        near = [f for f in freqs if abs(f - p) < 0.0095 * p + 0.5]
        if near:
            est.append(min(near, key=lambda x: abs(x - p)) / (k * math.sqrt(1.0 + Bn * k * k)))
    if len(est) < 2:
        return None
    f1 = sorted(est)[len(est) // 2]
    return f1 if abs(1200 * math.log2(f1 / f1n)) <= 20 else None


def owned_lines(freqs, f1, B, others):
    """(line index, frequency, order) of the lines nearer this series than any series in `others`
    and outside the tracker's merge window of them."""
    out = []
    for k, p in partials(f1, B):
        if p < BAND[0]:
            continue
        best = None
        for i, f in enumerate(freqs):
            if abs(f - p) < tol(p) and (best is None or abs(f - p) < abs(freqs[best] - p)):
                best = i
        if best is None:
            continue
        f = freqs[best]
        clash = False
        for of1, oB in others:
            for _, q in partials(of1, oB):
                if abs(f - q) <= abs(f - p) or abs(f - q) <= 2 * MERGE_HZ:
                    clash = True
                    break
            if clash:
                break
        if not clash:
            out.append((best, f, k))
    return out


def reading(freqs, cand, others):
    """(fitted f1, fitted B, tension residual in semitones, owned lines) of a candidate against
    the series in `others`, or None when no series is there. The series is found in the data:
    starting from the candidate's pitch and nominal stretch, the lines it owns are assigned and
    the stretch refitted until stable, so the stretch is measured, not assumed."""
    s, fret, bend, f1n, Bn, f1a = cand
    f1, B = f1a, Bn
    own = []
    for _ in range(6):
        own = owned_lines(freqs, f1, B, others)
        if len(own) < OWN_LINES:
            return None
        fit = stiff_fit([(f, k) for _, f, k in own])
        if fit is None or fit[1] <= 0:
            return None
        if abs(fit[0] - f1) < 0.01 and abs(fit[1] - B) < 1e-3 * B:
            f1, B = fit
            break
        f1, B = fit
    if abs(1200 * math.log2(f1 / f1n)) > 20:
        return None
    strong = [p for k, p in partials(f1, B, STRONG) if p >= BAND[0]]
    if sum(1 for p in strong if any(abs(f - p) < tol(p) for f in freqs)) < PRESENCE * len(strong):
        return None
    if max(k for _, _, k in own) < 6:
        return None
    res = 3.0 * math.log2((B / (f1 * f1)) / (Bn / (f1n * f1n)))
    share = sum(1 for _, _, k in own if k <= STRONG) / max(1, len(strong))
    return f1, B, res, own, share


def decompose(freqs, cands):
    """The sounding notes of an event: candidates added while they own at least three
    unexplained lines and read as their string's tension, most lines first, one per string,
    until every line is accounted for; then each note is re-read against the others and
    exchanged for the same-pitch candidate that fits best."""
    live = []
    for s, fret, bend, f1n, Bn in cands:
        f1a = anchor(freqs, f1n, Bn)
        if f1a is not None:
            live.append((s, fret, bend, f1n, Bn, f1a))
    chosen = []             # (candidate, fitted f1, fitted B)
    while True:
        best = None
        others = [(f1x, Bx) for _, f1x, Bx in chosen]
        for c in live:
            if any(cc[0] == c[0] for cc, _, _ in chosen):
                continue
            r = reading(freqs, c, others)
            if r is None or abs(r[2]) > RES_TOL:
                continue
            # most owned lines first; between equals the larger share of its own strong
            # partials, then the higher pitch (a sub-harmonic never wins a tie)
            score = (len(r[3]), round(r[4], 2), c[3], -abs(r[2]))
            if best is None or score > best[0]:
                best = (score, c, r)
        if best is None:
            break
        chosen.append((best[1], best[2][0], best[2][1]))
    for _ in range(2):
        for i in range(len(chosen)):
            cand, f1x, Bx = chosen[i]
            others = [(g1, gB) for j, (_, g1, gB) in enumerate(chosen) if j != i]
            used = {cc[0] for j, (cc, _, _) in enumerate(chosen) if j != i}
            pick = None
            for c in live:
                if c[0] in used:
                    continue
                r = reading(freqs, c, others)
                if r is None or abs(r[2]) > RES_TOL:
                    continue
                score = (len(r[3]), round(r[4], 2), c[3], -abs(r[2]))
                if pick is None or score > pick[0]:
                    pick = (score, c, r)
            if pick is not None:
                chosen[i] = (pick[1], pick[2][0], pick[2][1])
    return [(c[0], c[1], c[2]) for c, _, _ in chosen]


def label(take_dir):
    setup, order, lines = read_take(take_dir)
    table = read_table(setup["string_set"])
    n_strings = int(setup["strings"])
    L0 = float(setup["scale_in"]) * INCH
    # the take's open pitches from its single notes
    singles = []
    for code in order:
        freqs = lines.get(code, [])
        f1, B, n = series(freqs)
        if f1 and n >= 0.7 * len(freqs):
            singles.append(readings(table, L0, f1, B))
    bases = choose_open_pitches(n_strings, singles) or tuple([None] * n_strings)
    cands = candidates(table, L0, bases)
    out = []
    for code in order:
        notes = decompose(lines.get(code, []), cands)
        if not notes:
            notes = [(1, 0, 0)]
        for s, fret, bend in sorted(notes):
            out.append((code, s, fret, bend))
    return out


def main(argv):
    take_dir, out_csv = argv[0], argv[1]
    rows = label(take_dir)
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)
    with open(out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["event", "string", "fret", "bend"])
        for r in rows:
            w.writerow(r)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
