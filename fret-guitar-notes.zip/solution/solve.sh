#!/bin/bash
# Installs the labelling program where the grader expects it and runs it over the sample takes,
# checking each against the labels the corpus carries.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/fretter /app/out
cp "$HERE/fretter/fret.py" /app/fretter/fret.py
for take in /app/corpus/takes/*/; do
    code="$(basename "$take")"
    python3 /app/fretter/fret.py "$take" "/app/out/$code.csv"
    python3 - "$take/tab.csv" "/app/out/$code.csv" <<'PY'
import csv, sys
from collections import defaultdict
def rows(path):
    by = defaultdict(set)
    for r in csv.DictReader(open(path)):
        by[r["event"]].add((r["string"], r["fret"], r["bend"]))
    return by
want, got = rows(sys.argv[1]), rows(sys.argv[2])
wrong = sum(1 for ev in want if got.get(ev, set()) != want[ev])
print("%s: %d of %d events differ from the labelled tab" % (sys.argv[2], wrong, len(want)))
PY
done
