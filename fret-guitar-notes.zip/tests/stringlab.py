"""The verifier's own string model: under a held-out take's sealed open pitches, the sounding notes
of each event are the only candidates whose own lines fit their string's tension, and together
they account for every line. Test 1 asserts the sealed labels are exactly these, so the key is
what the data implies and nothing else."""
import csv
import math
import os

E_STEEL = 2.0e11
INCH = 0.0254
BAND = (100.0, 12000.0)
MERGE_HZ = 1.5
MAX_FRET = 15
OWN_LINES = 3          # lines a sounding note must own outright
RES_TRUE = 0.3         # semitones: a sounding note's tension reading against its string
RES_FALSE = 0.3        # ... and every other candidate at its pitch at least this far


def table(path, set_code):
    rows = []
    with open(path, newline="") as fh:
        for r in csv.DictReader(fh):
            if r["string_set"] == set_code:
                rows.append((int(r["string"]), float(r["core_in"]) * INCH, float(r["mass_kg_per_m"])))
    return sorted(rows)


def lines_of(take_dir):
    out = {}
    with open(os.path.join(take_dir, "lines.csv"), newline="") as fh:
        for r in csv.DictReader(fh):
            out.setdefault(r["event"], []).append(float(r["freq_hz"]))
    for v in out.values():
        v.sort()
    return out


def tol(f):
    return 0.006 * f + 0.5


def nominal(rows, L0, base, s, fret, bend):
    """Pitch and inharmonicity of (string, fret, bend) at the sealed open pitch, no set-back."""
    _, core, mu = rows[s - 1]
    L = L0 * 2.0 ** (-fret / 12.0)
    f1 = base * 2.0 ** ((fret + bend) / 12.0)
    tension = mu * (2.0 * L * f1) ** 2
    return f1, math.pi ** 3 * E_STEEL * core ** 4 / (64.0 * tension * L * L)


def stretch_fit(pairs):
    xs = [k * k for _, k in pairs]
    ys = [(f / k) ** 2 for f, k in pairs]
    n = len(pairs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx > 0 else 0.0
    icpt = my - slope * mx
    return (math.sqrt(icpt), max(0.0, slope / icpt)) if icpt > 0 else None


def reckon(truth, take_dir, table_path):
    """{event: frozenset of (string, fret, bend)} implied by the sealed open pitches and lines."""
    rows = table(table_path, truth["set"])
    L0 = truth["scale_in"] * INCH
    freqs_by_event = lines_of(take_dir)
    out = {}
    for ev in truth["events"]:
        freqs = freqs_by_event[ev["event"]]
        assert all(math.isfinite(f) for f in freqs), ev["event"]
        notes = ev["notes"]
        series = {}
        for n in notes:
            assert math.isfinite(n["f1"]) and math.isfinite(n["B"]) and n["B"] > 0, ev["event"]
            key = (n["string"], n["fret"], n["bend"])
            series[key] = [k * n["f1"] * math.sqrt(1.0 + n["B"] * k * k)
                           for k in range(1, int(BAND[1] / n["f1"]) + 2)]
        # every line belongs to some sounding note
        for f in freqs:
            assert any(abs(f - q) < tol(f) for qs in series.values() for q in qs), (ev["event"], f)
        labels = set()
        for key, qs in series.items():
            others = [q for k2, qs2 in series.items() if k2 != key for q in qs2]
            owned = []
            for k, p in enumerate(qs, 1):
                if not BAND[0] <= p <= BAND[1] or k > 20:
                    continue
                near = [f for f in freqs if abs(f - p) < tol(p)
                        and all(abs(f - p) < abs(f - q) and abs(f - q) > 2 * MERGE_HZ for q in others)]
                if near:
                    owned.append((min(near, key=lambda x: abs(x - p)), k))
            assert len(owned) >= OWN_LINES, (ev["event"], key, len(owned))
            fit = stretch_fit(owned)
            assert fit is not None and fit[1] > 0, (ev["event"], key)
            f1x, Bx = fit
            K = Bx / (f1x * f1x)
            s, fret, bend = key
            f1n, Bn = nominal(rows, L0, truth["bases"][s - 1], s, fret, bend)
            res = 3.0 * math.log2(K / (Bn / (f1n * f1n)))
            assert abs(res) <= RES_TRUE and abs(1200 * math.log2(f1x / f1n)) <= 20, (ev["event"], key, res)
            # no other candidate at this pitch reads as its own string's tension
            for s2 in range(1, len(rows) + 1):
                for fret2 in range(0, MAX_FRET + 1):
                    for bend2 in ((0, 1, 2) if s2 <= 3 and fret2 >= 2 else (0,)):
                        if (s2, fret2, bend2) == key:
                            continue
                        f1c, Bc = nominal(rows, L0, truth["bases"][s2 - 1], s2, fret2, bend2)
                        if abs(1200 * math.log2(f1x / f1c)) > 30:
                            continue
                        res2 = 3.0 * math.log2(K / (Bc / (f1c * f1c)))
                        assert abs(res2) >= RES_FALSE, (ev["event"], key, (s2, fret2, bend2), res2)
            labels.add(key)
        out[ev["event"]] = frozenset(labels)
    return out
