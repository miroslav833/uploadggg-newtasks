"""Two tests: the sealed labels are what the verifier's string model derives from each take's own
lines under its sealed open pitches, and the uploaded program labels enough held-out takes."""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import holdout    # noqa: E402
import stringlab  # noqa: E402

TAKES = 20
WRONG_EVENTS_ALLOWED = 3  # a take counts when at most this many of its events are wrong (instruction.md)
TAKES_NEEDED = 18         # takes that must count, of 20 (instruction.md)
TABLE = "/app/corpus/strings.csv"


def sealed(code):
    with open(os.path.join(holdout.VAULT, "sealed", code + ".json"), encoding="utf-8") as fh:
        return json.load(fh)


def key_of(truth):
    return {ev["event"]: frozenset((n["string"], n["fret"], n["bend"]) for n in ev["notes"]) for ev in truth["events"]}


def test_sealed_labels_follow_the_string_model():
    codes = holdout.takes()
    assert len(codes) == TAKES
    for code in codes:
        truth = sealed(code)
        reckoned = stringlab.reckon(truth, os.path.join(holdout.VAULT, "takes", code), TABLE)
        assert reckoned == key_of(truth), code


@pytest.fixture(scope="module")
def wrong_per_take():
    uid = holdout.spare_uid()
    tally = {}
    for code in holdout.takes():
        key = key_of(sealed(code))
        filed = holdout.run_take(code, uid)
        tally[code] = sum(1 for event, want in key.items() if filed.get(event) != want)
    with open(os.path.join(holdout.PRIVATE, "takes.json"), "w", encoding="utf-8") as fh:
        json.dump(tally, fh, indent=1)
    print(json.dumps(tally))
    return tally


def test_enough_takes_labelled(wrong_per_take):
    counted = [c for c, wrong in wrong_per_take.items() if wrong <= WRONG_EVENTS_ALLOWED]
    assert len(counted) >= TAKES_NEEDED, "%d of %d takes counted (%s); %d needed" % (
        len(counted), TAKES, wrong_per_take, TAKES_NEEDED)
