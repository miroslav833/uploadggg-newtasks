"""Builds takes of the tablature corpus.

A take is one guitar, its open pitches and a few dozen events: single plucked notes, double stops
and strummed chords, captured from the room microphone and run through the line tracker, which
lists every stable line of an event whatever sounds. The sample takes ship with the task; the
held-out takes are built inside the verifier image and sealed with their labels.

    python3 forge.py samples OUT_DIR            # the four labelled sample takes
    python3 forge.py held OUT_DIR SEALED_DIR    # the twenty graded takes and their sealed truth
    python3 forge.py table OUT_CSV              # the string-set table
"""
import csv
import json
import math
import os
import random
import string as _string
import sys

E_STEEL = 2.0e11          # Pa, the maker's figure for the steel
INCH = 0.0254
MIN_LEVEL_DB = -50.0      # the tracker keeps lines within 50 dB of the event's strongest line
MAX_LINES = 80            # ... and at most this many, the strongest kept
MERGE_HZ = 1.5            # lines closer than this are reported as one
BAND = (100.0, 12000.0)   # Hz
MAX_FRET = 15
TRUE_RES = 0.2            # a true note's tension reading sits within this of its string's (semitones)
FALSE_RES = 0.35          # every other candidate that shows enough lines sits at least this far
TRUE_PRESENCE = 0.3       # share of a true note's strong partials it owns outright (chords share many)
ANY_PRESENCE = 0.75       # share of a true note's strong partials that some line matches at all
FALSE_PRESENCE = 0.6      # a false candidate with more than this share present must fail the tension test
MIN_EXCLUSIVE = 3         # lines of a sounding note that no other sounding note shares

# string sets: number 1 is the highest-pitched string as strung
# (kind, gauge in, core in, mass per metre kg/m)
SETS = {
    "L09": {"window": (40, 85), "strings": [
        ("plain", 0.0095, 0.0095, 3.5898e-4), ("plain", 0.0115, 0.0115, 5.2604e-4),
        ("plain", 0.0170, 0.0170, 1.1495e-3), ("wound", 0.0240, 0.0125, 1.9008e-3),
        ("wound", 0.0320, 0.0170, 3.5142e-3), ("wound", 0.0420, 0.0187, 5.4301e-3)]},
    "L10": {"window": (55, 100), "strings": [
        ("plain", 0.0100, 0.0100, 3.9777e-4), ("plain", 0.0135, 0.0135, 7.2493e-4),
        ("plain", 0.0170, 0.0170, 1.1495e-3), ("wound", 0.0260, 0.0157, 2.3652e-3),
        ("wound", 0.0360, 0.0171, 4.2873e-3), ("wound", 0.0460, 0.0199, 6.7025e-3)]},
    "H12": {"window": (80, 135), "strings": [
        ("plain", 0.0125, 0.0125, 6.2151e-4), ("plain", 0.0160, 0.0160, 1.0183e-3),
        ("wound", 0.0240, 0.0113, 1.8641e-3), ("wound", 0.0320, 0.0168, 3.3535e-3),
        ("wound", 0.0420, 0.0186, 6.0689e-3), ("wound", 0.0540, 0.0218, 9.6494e-3)]},
    "S7": {"window": (45, 100), "strings": [
        ("plain", 0.0100, 0.0100, 3.9777e-4), ("plain", 0.0130, 0.0130, 6.7222e-4),
        ("plain", 0.0170, 0.0170, 1.1495e-3), ("wound", 0.0260, 0.0153, 2.1332e-3),
        ("wound", 0.0360, 0.0176, 4.5295e-3), ("wound", 0.0460, 0.0197, 6.5450e-3),
        ("wound", 0.0560, 0.0229, 9.6061e-3)]},
    "B13": {"window": (60, 110), "strings": [
        ("plain", 0.0130, 0.0130, 6.7222e-4), ("plain", 0.0175, 0.0175, 1.2182e-3),
        ("wound", 0.0260, 0.0123, 2.4188e-3), ("wound", 0.0360, 0.0173, 4.3974e-3),
        ("wound", 0.0460, 0.0182, 6.8797e-3), ("wound", 0.0620, 0.0199, 1.1616e-2)]},
}
# open pitches as MIDI numbers, string 1 first; no two strings within two semitones
TUNINGS = {
    "std6": [64, 59, 55, 50, 45, 40], "eb6": [63, 58, 54, 49, 44, 39], "d6": [62, 57, 53, 48, 43, 38],
    "dropd": [64, 59, 55, 50, 45, 38], "ddropd": [62, 59, 55, 50, 45, 38],
    "openg": [62, 59, 55, 50, 43, 38], "opend": [62, 57, 54, 50, 45, 38],
    "std7": [64, 59, 55, 50, 45, 40, 35], "dropa7": [64, 59, 55, 50, 45, 40, 33],
    "barib": [59, 54, 50, 45, 40, 35], "baridropa": [59, 54, 50, 45, 40, 33],
}

# (code, set, scale in, open pitches, bent notes, strings never sounded open, chord events, events, seed)
SAMPLES = [
    ("A", "L10", 25.5, "std6", 0, 0, 10, 84, 1101),
    ("B", "L10", 25.5, "std6", 0, 0, 0, 96, 1102),
    ("C", "L09", 25.5, "std6", 0, 0, 0, 78, 1103),
    ("D", "L10", 25.5, "std6", 0, 0, 14, 90, 1104),
]
HELD = [
    ("H01", "L10", 25.5, "eb6", 10, 2, 0, 90, 2201),
    ("H02", "L10", 25.5, "std6", 0, 0, 30, 84, 2202),
    ("H03", "L10", 24.75, "dropd", 8, 0, 24, 96, 2203),
    ("H04", "S7", 24.75, "std7", 0, 3, 28, 88, 2204),
    ("H05", "L10", 25.5, "std6", 12, 2, 0, 100, 2205),
    ("H06", "L09", 24.75, "d6", 0, 3, 26, 80, 2206),
    ("H07", "L09", 25.5, "std6", 9, 3, 0, 92, 2207),
    ("H08", "L09", 25.5, "ddropd", 0, 0, 32, 86, 2208),
    ("H09", "H12", 24.75, "std6", 0, 2, 30, 90, 2209),
    ("H10", "H12", 25.5, "dropd", 11, 0, 0, 98, 2210),
    ("H11", "H12", 25.5, "opend", 0, 3, 34, 82, 2211),
    ("H12", "H12", 24.75, "eb6", 7, 2, 0, 94, 2212),
    ("H13", "S7", 25.5, "std7", 0, 3, 36, 104, 2213),
    ("H14", "S7", 25.5, "dropa7", 10, 0, 0, 96, 2214),
    ("H15", "S7", 25.5, "std7", 0, 2, 30, 100, 2215),
    ("H16", "S7", 24.75, "std7", 13, 0, 0, 108, 2216),
    ("H17", "S7", 25.5, "dropa7", 0, 3, 32, 92, 2217),
    ("H18", "B13", 27.0, "barib", 0, 0, 28, 84, 2218),
    ("H19", "B13", 27.0, "baridropa", 8, 2, 0, 90, 2219),
    ("H20", "B13", 27.0, "barib", 0, 3, 30, 88, 2220),
]


def midi_hz(m):
    return 440.0 * 2.0 ** ((m - 69) / 12.0)


# ----------------------------------------------------------------------------------------------
# events

def chord_shape(rng, n_strings, closed_set):
    """(string, fret) pairs of one strummed chord or double stop: two to four strings."""
    low = n_strings            # the lowest string the shape may use
    kind = rng.choice(["power", "power", "power3", "barre4", "barre4", "barre4m", "triad", "triad",
                       "dyad", "dyad", "dyad", "four"])
    while True:
        if kind in ("power", "power3"):
            root = rng.randint(3, low)
            pos = rng.randint(0, 11)
            pairs = [(root, pos), (root - 1, pos + 2)] + ([(root - 2, pos + 2)] if kind == "power3" else [])
        elif kind in ("barre4", "barre4m"):
            # the lowest four strings of a barre shape: root, fifth, octave, third
            top = rng.choice([low, low - 1]) if low == 7 else rng.choice([low, low - 1])
            offs = [0, 2, 2, 1] if kind == "barre4" else [0, 2, 2, 0]
            pos = rng.choice([0, 1, 2, 3, 3, 5, 5, 7, 7, 8, 10])
            pairs = [(top - i, pos + o) for i, o in enumerate(offs)]
        elif kind == "four":
            top = rng.randint(4, low)
            pos = rng.randint(0, 11)
            pairs = [(top - i, pos + rng.randint(0, 3)) for i in range(4)]
        elif kind == "triad":
            top = rng.randint(3, low)
            pos = rng.randint(0, 12)
            pairs = [(top - i, pos + rng.randint(0, 3)) for i in range(3)]
        else:
            a = rng.randint(2, low)
            b = a - rng.choice([1, 1, 2])
            pos = rng.randint(0, 12)
            pairs = [(a, pos + rng.randint(0, 4)), (b, pos + rng.randint(0, 4))]
        pairs = [(s, min(n, MAX_FRET)) for s, n in pairs if 1 <= s <= n_strings]
        if len(set(s for s, _ in pairs)) == len(pairs) and len(pairs) >= 2 \
                and not any(n == 0 and s in closed_set for s, n in pairs):
            return pairs
        kind = rng.choice(["power", "triad", "dyad"])


def draw_events(rng, n_strings, count, bends, closed, chords):
    """Events of a take: each a list of (string, fret, bend). Every string gets at least one unbent
    sounding; `closed` strings are never sounded open; bends of 1-2 semitones go on single notes
    of the top three strings at fret 2 or above; `chords` events are strums or double stops."""
    closed_set = set(rng.sample(range(1, n_strings + 1), closed)) if closed else set()
    events = []
    while len(events) < count:
        pos = rng.choice([0, 0, 1, 2, 3, 4, 5, 5, 7, 7, 8, 9, 10, 12])
        span = rng.choice([3, 4, 4, 5])
        lead = rng.random() < 0.55
        for _ in range(rng.randint(4, 10)):
            s = rng.choice([1, 1, 2, 2, 3, 3, 4]) if lead else rng.randint(1, n_strings)
            s = min(s, n_strings)
            if pos == 0 and rng.random() < 0.35 and s not in closed_set:
                fret = 0
            else:
                fret = max(1, pos) + rng.randint(0, span) if s in closed_set else pos + rng.randint(0, span)
            events.append([[s, min(fret, MAX_FRET), 0]])
            if len(events) >= count:
                break
    if chords:
        slots = rng.sample(range(count), min(chords, count))
        for i in slots:
            events[i] = [[s, n, 0] for s, n in chord_shape(rng, n_strings, closed_set)]
    singles = [i for i, ev in enumerate(events) if len(ev) == 1]
    rng.shuffle(singles)
    for s in range(1, n_strings + 1):
        # every string sounds at least two unbent single notes
        have = [i for i in singles if events[i][0][0] == s]
        while len(have) < 2 and singles:
            i = singles.pop()
            events[i] = [[s, rng.randint(1, 7), 0]]
            have.append(i)
        singles = [i for i in singles if i not in have]
    if bends:
        picks = [i for i, ev in enumerate(events) if len(ev) == 1 and ev[0][0] <= 3 and ev[0][1] >= 2]
        rng.shuffle(picks)
        for i in picks[:bends]:
            events[i][0][2] = rng.choice([1, 1, 2])
    for ev in events:
        for x in ev:
            if x[0] in closed_set and x[1] == 0:
                x[1] = rng.randint(1, 5)
    for s in range(1, n_strings + 1):
        unbent = [ev for ev in events if len(ev) == 1 and ev[0][0] == s and ev[0][2] == 0]
        if len(unbent) < 2:
            for ev in events:
                if len(ev) == 1 and ev[0][0] == s and ev[0][2] != 0 and len(unbent) < 2:
                    ev[0][2] = 0
                    unbent.append(ev)
    return events


def take_physics(rng, set_code, scale_in, tuning_name):
    strings = SETS[set_code]["strings"]
    midis = TUNINGS[tuning_name]
    assert len(midis) == len(strings)
    return dict(L0=scale_in * INCH, comp=rng.uniform(0.5, 2.0) * 1e-3,
                bases=[midi_hz(m) * 2.0 ** (rng.uniform(-3, 3) / 1200.0) for m in midis],
                sharp=rng.uniform(0.0, 4.0), pick=rng.uniform(0.12, 0.25), alpha=rng.uniform(1.2, 1.6),
                strings=strings, midis=midis)


def note_partials(rng, phys, s, fret, bend):
    """The partials of one sounding note: (frequency, level relative to its strongest, order), with
    the true pitch and inharmonicity."""
    kind, gauge, core, mu = phys["strings"][s - 1]
    L = phys["L0"] * 2.0 ** (-fret / 12.0) + phys["comp"]
    cents = (phys["sharp"] if fret > 0 else 0.0) + rng.gauss(0, 2.0) + (rng.uniform(-9, 9) if bend else 0.0)
    f1 = phys["bases"][s - 1] * 2.0 ** ((fret + bend) / 12.0) * 2.0 ** (cents / 1200.0)
    tension = mu * (2.0 * L * f1) ** 2
    B = math.pi ** 3 * E_STEEL * (core * INCH) ** 4 / (64.0 * tension * L * L)
    p = min(0.45, max(0.05, phys["pick"] + rng.gauss(0, 0.015)))
    partials = []
    k = 1
    while True:
        fk = k * f1 * math.sqrt(1.0 + B * k * k)
        if fk > BAND[1] + 50:
            break
        amp = abs(math.sin(k * math.pi * p)) / k ** phys["alpha"]
        if amp > 0:
            partials.append((fk, 20 * math.log10(amp), k))
        k += 1
    top = max(db for _, db, _ in partials)
    return [(f, db - top, k) for f, db, k in partials], f1, B


def event_lines(rng, phys, notes):
    """The tracker's list for one event: every sounding note's partials merged, the strongest
    lines kept, with the tracker's noise. Returns the lines and per-note truth."""
    pool = []
    truth = []
    for j, (s, fret, bend) in enumerate(notes):
        partials, f1, B = note_partials(rng, phys, s, fret, bend)
        gain = 0.0 if len(notes) == 1 else rng.uniform(-8.0, 0.0)
        for f, db, k in partials:
            pool.append((f, db + gain, j))
        truth.append(dict(string=s, fret=fret, bend=bend, f1=f1, B=B))
    pool.sort()
    merged = []
    for f, db, j in pool:
        if merged and f - merged[-1][0] < MERGE_HZ:
            pf, pdb, pj = merged[-1]
            merged[-1] = ((f, db, j) if db > pdb else (pf, pdb, pj))
        else:
            merged.append((f, db, j))
    top = max(db for _, db, _ in merged)
    out = []
    for f, db, j in merged:
        fz = f + rng.gauss(0, 0.05 + 2e-5 * f)
        dbz = db - top + rng.gauss(0, 0.5)
        if BAND[0] <= fz <= BAND[1] and dbz >= MIN_LEVEL_DB:
            out.append((fz, dbz))
    out.sort(key=lambda x: -x[1])
    out = out[:MAX_LINES]
    out.sort(key=lambda x: x[0])
    return out, truth


def build_take(code, set_code, scale_in, tuning_name, bends, closed, chords, count, seed):
    rng = random.Random(seed)
    for attempt in range(200):
        phys = take_physics(rng, set_code, scale_in, tuning_name)
        n_strings = len(phys["strings"])
        events = draw_events(rng, n_strings, count, bends, closed, chords)
        rows = []
        for ev in events:
            lines, truth = event_lines(rng, phys, ev)
            rows.append(dict(notes=truth, lines=lines))
        problem = evidence_problem(set_code, scale_in, phys, rows)
        if problem:
            continue
        codes = set()
        t = rng.uniform(0.4, 1.2)
        for r in rows:
            while True:
                c = "".join(rng.choice(_string.ascii_uppercase + _string.digits) for _ in range(4))
                if c not in codes and c[0].isalpha():
                    codes.add(c)
                    break
            r["event"] = c
            r["onset"] = round(t, 3)
            t += rng.uniform(0.22, 1.1)
        return dict(take=code, guitar="G-%02d" % rng.randint(1, 40), set=set_code, strings=n_strings,
                    scale_in=scale_in, tuning=tuning_name, L0=phys["L0"], comp=phys["comp"],
                    bases=phys["bases"], sharp=phys["sharp"], pick=phys["pick"], events=rows,
                    attempts=attempt + 1)
    raise RuntimeError("no take for %s after 200 attempts" % code)


# ----------------------------------------------------------------------------------------------
# the evidence check, in the solver's position: every sounding note is the only candidate on its
# string that both shows its partials and carries its string's tension; every other candidate
# either lacks its partials or carries a tension well off every string's; each sounding note has
# lines of its own; and no other set of open pitches explains the take

def predicted_series(set_code, L0, comp, base, s, fret, bend, f1_override=None):
    kind, gauge, core, mu = SETS[set_code]["strings"][s - 1]
    L = L0 * 2.0 ** (-fret / 12.0) + comp
    f1 = f1_override if f1_override else base * 2.0 ** ((fret + bend) / 12.0)
    tension = mu * (2.0 * L * f1) ** 2
    B = math.pi ** 3 * E_STEEL * (core * INCH) ** 4 / (64.0 * tension * L * L)
    return f1, B


def tol(f):
    return 0.006 * f + 0.5


def stiff_fit(pairs):
    """(f1, B) by least squares of (f/k)^2 = f1^2 (1 + B k^2) over (frequency, order) pairs."""
    xs = [k * k for _, k in pairs]
    ys = [(f / k) ** 2 for f, k in pairs]
    n = len(pairs)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    c = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx > 0 else 0.0
    a0 = my - c * mx
    if a0 <= 0:
        return None
    return math.sqrt(a0), max(0.0, c / a0)


STRONG_ORDERS = 12        # the partials a solver can count on seeing


def candidate_view(freqs, set_code, L0, base, s, fret, bend):
    """How a solver sees candidate (string, fret, bend) in an event's lines: the share of its strong
    partials present, its fitted pitch and stretch, and its tension reading against its string
    (semitones). None when too few lines match."""
    f1n, Bn = predicted_series(set_code, L0, 0.0, base, s, fret, bend)
    if not all(math.isfinite(x) for x in (f1n, Bn)):
        return None
    pairs = []
    for k in range(1, 21):
        pred = k * f1n * math.sqrt(1.0 + Bn * k * k)
        if pred > BAND[1]:
            break
        if pred < BAND[0]:
            continue
        # the pitch may sit up to 16 cents off nominal
        near = [f for f in freqs if abs(f - pred) < 0.0095 * pred + 0.5]
        if near:
            pairs.append((min(near, key=lambda x: abs(x - pred)), k))
    if len(set(k for _, k in pairs)) < 3:
        return None
    fit = stiff_fit(pairs)
    if fit is None:
        return None
    f1, B = fit
    if abs(1200 * math.log2(f1 / f1n)) > 20:
        return None
    present, strong, pairs = 0, 0, []
    for k in range(1, 21):
        pred = k * f1 * math.sqrt(1.0 + B * k * k)
        if pred > BAND[1]:
            break
        if pred < BAND[0]:
            continue
        near = [f for f in freqs if abs(f - pred) < tol(pred)]
        if k <= STRONG_ORDERS:
            strong += 1
            present += bool(near)
        if near:
            pairs.append((min(near, key=lambda x: abs(x - pred)), k))
    if strong == 0 or len(pairs) < 3:
        return None
    fit = stiff_fit(pairs)
    if fit is None or fit[1] <= 0:
        return None
    f1, B = fit
    # lines another note pushed off the series are dropped and the series refitted
    resid = [abs(f - k * f1 * math.sqrt(1.0 + B * k * k)) for f, k in pairs]
    cut = max(1.0, 2.5 * sorted(resid)[len(resid) // 2])
    kept = [pk for pk, r in zip(pairs, resid) if r <= cut]
    if len(kept) >= 3:
        fit = stiff_fit(kept)
        if fit is not None and fit[1] > 0:
            f1, B = fit
    K_pred = Bn / (f1n * f1n)
    res = 3.0 * math.log2((B / (f1 * f1)) / K_pred)
    return present / strong, f1, B, abs(res)


def evidence_problem(set_code, scale_in, phys, rows):
    strings = phys["strings"]
    midis = phys["midis"]
    n_strings = len(strings)
    lo, hi = SETS[set_code]["window"]
    L0 = scale_in * INCH
    for s in range(1, n_strings + 1):
        kind, gauge, core, mu = strings[s - 1]
        tension = mu * (2.0 * L0 * phys["bases"][s - 1]) ** 2
        if not lo <= tension <= hi:
            return "string %d tension %.0f outside window" % (s, tension)
        if sum(1 for r in rows if len(r["notes"]) == 1 and r["notes"][0]["string"] == s
               and r["notes"][0]["bend"] == 0) < 2:
            return "string %d has fewer than two unbent single notes" % s
    for r in rows:
        freqs = [f for f, _ in r["lines"]]
        if not all(math.isfinite(f) for f in freqs) or not all(
                math.isfinite(n["f1"]) and math.isfinite(n["B"]) for n in r["notes"]):
            return "non-finite value"
        truth = {(n["string"], n["fret"], n["bend"]) for n in r["notes"]}
        # each sounding note's partials, and the lines no other sounding note shares
        pred, every = {}, {}
        for n in r["notes"]:
            key = (n["string"], n["fret"], n["bend"])
            every[key] = [k * n["f1"] * math.sqrt(1.0 + n["B"] * k * k) for k in range(1, int(BAND[1] / n["f1"]) + 2)]
            pred[key] = [(k, q) for k, q in enumerate(every[key], 1) if k <= 20 and BAND[0] <= q <= BAND[1]]
        fits = {}
        for key, ps in pred.items():
            others = [q for k2, qs in every.items() if k2 != key for q in qs]
            pairs, present, strong, anyhit = [], 0, 0, 0
            for k, p in ps:
                if k <= STRONG_ORDERS and any(abs(f - p) < tol(p) for f in freqs):
                    anyhit += 1
                # a line is this note's when it is nearer this partial than any other note's, and
                # no other partial sits within the tracker's merge window of it
                near = [f for f in freqs if abs(f - p) < tol(p)
                        and all(abs(f - p) < abs(f - q) and abs(f - q) > 2 * MERGE_HZ for q in others)]
                if k <= STRONG_ORDERS:
                    strong += 1
                    present += bool(near)
                if near:
                    pairs.append((min(near, key=lambda x: abs(x - p)), k))
            if len(pairs) < MIN_EXCLUSIVE:
                return "note %s has %d exclusive lines" % (key, len(pairs))
            if strong == 0 or present / strong < TRUE_PRESENCE:
                return "note %s owns %d of %d strong partials" % (key, present, strong)
            if anyhit / strong < ANY_PRESENCE:
                return "note %s shows %d of %d strong partials" % (key, anyhit, strong)
            fit = stiff_fit(pairs)
            if fit is None or fit[1] <= 0:
                return "note %s does not fit" % (key,)
            f1x, Bx = fit
            s, fret, bend = key
            f1n, Bn = predicted_series(set_code, L0, 0.0, phys["bases"][s - 1], s, fret, bend)
            res = 3.0 * math.log2((Bx / (f1x * f1x)) / (Bn / (f1n * f1n)))
            if abs(res) > TRUE_RES or abs(1200 * math.log2(f1x / f1n)) > 18:
                return "true note %s reads %.2f semitones off its string" % (key, res)
            fits[key] = (f1x, Bx)
        # every other candidate at a sounding pitch, on any string, sits well off its string's
        # tension when read on that note's own lines
        for key, (f1x, Bx) in fits.items():
            for s in range(1, n_strings + 1):
                for fret in range(0, MAX_FRET + 1):
                    for bend in ((0, 1, 2) if s <= 3 and fret >= 2 else (0,)):
                        cand = (s, fret, bend)
                        if cand == key:
                            continue
                        f1n, Bn = predicted_series(set_code, L0, 0.0, phys["bases"][s - 1], s, fret, bend)
                        if abs(1200 * math.log2(f1x / f1n)) > 30:
                            continue
                        res = 3.0 * math.log2((Bx / (f1x * f1x)) / (Bn / (f1n * f1n)))
                        if abs(res) < FALSE_RES:
                            return "candidate %s reads %.2f against true %s" % (cand, res, key)
    # no other choice of open pitches explains the take: single-note events read under every
    # string's tension, as in the earlier joint check
    cand, unbent = {}, set()
    per_note = []
    for i, r in enumerate(rows):
        if len(r["notes"]) != 1:
            continue
        freqs = [f for f, _ in r["lines"]]
        n = r["notes"][0]
        reads = single_readings(set_code, scale_in, n["f1"], n["B"])
        per_note.append(reads)
        for s, fret, b, p in reads:
            cand.setdefault((s, p), set()).add(i)
            if b == 0:
                unbent.add((s, p))
    per_string = {}
    for (s, p), ids in cand.items():
        if (s, p) in unbent:
            per_string.setdefault(s, []).append((p, ids))
    N = len(per_note)
    limit = N - int(math.ceil(0.08 * N))
    truth_bases = tuple(midis)

    def search(s, chosen, explained):
        if s > n_strings:
            if chosen != truth_bases and len(explained) > limit:
                return "assignment %s explains %d of %d single notes" % (chosen, len(explained), N)
            return None
        for p, ids in per_string.get(s, []):
            if not math.isfinite(p) or any(abs(p - q) < 3 for q in chosen):
                continue
            res = search(s + 1, chosen + (p,), explained | ids)
            if res:
                return res
        return None

    return search(1, (), frozenset())


def single_readings(set_code, scale_in, f1, B, tolerance=0.3):
    """(string, fret, bend, open pitch) readings of a single note from its pitch and stretch."""
    strings = SETS[set_code]["strings"]
    lo, hi = SETS[set_code]["window"]
    L0 = scale_in * INCH
    out = []
    if not (math.isfinite(f1) and math.isfinite(B)) or B <= 0:
        return out
    K = B / (f1 * f1)
    for s in range(1, len(strings) + 1):
        kind, gauge, core, mu = strings[s - 1]
        for b in (0, 1, 2):
            Ks = K * 2.0 ** (b / 3.0)
            tension = math.sqrt(math.pi ** 3 * E_STEEL * (core * INCH) ** 4 * mu / (16.0 * Ks))
            if not 0.92 * lo <= tension <= 1.08 * hi:
                continue
            f_open = math.sqrt(tension / mu) / (2.0 * L0)
            n = 12.0 * math.log2(f1 / (f_open * 2.0 ** (b / 12.0)))
            if abs(n - round(n)) > tolerance or not 0 <= round(n) <= 22:
                continue
            p = 69.0 + 12.0 * math.log2(f_open / 440.0)
            if abs(p - round(p)) > tolerance:
                continue
            out.append((s, int(round(n)), b, int(round(p))))
    return out


# ----------------------------------------------------------------------------------------------
# writing

def write_take(take, out_dir, with_tab):
    d = os.path.join(out_dir, take["take"])
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "setup.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["take", "guitar", "strings", "string_set", "scale_in"])
        w.writerow([take["take"], take["guitar"], take["strings"], take["set"], "%.2f" % take["scale_in"]])
    with open(os.path.join(d, "events.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["event", "onset_s"])
        for r in take["events"]:
            w.writerow([r["event"], "%.3f" % r["onset"]])
    with open(os.path.join(d, "lines.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["event", "freq_hz", "level_db"])
        for r in take["events"]:
            for f, db in r["lines"]:
                w.writerow([r["event"], "%.2f" % f, "%.1f" % db])
    if with_tab:
        with open(os.path.join(d, "tab.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["event", "string", "fret", "bend"])
            for r in take["events"]:
                for n in sorted(r["notes"], key=lambda n: n["string"]):
                    w.writerow([r["event"], n["string"], n["fret"], n["bend"]])


def write_sealed(take, sealed_dir):
    os.makedirs(sealed_dir, exist_ok=True)
    truth = dict(take=take["take"], set=take["set"], strings=take["strings"], scale_in=take["scale_in"],
                 tuning=take["tuning"], L0=take["L0"], comp=take["comp"], bases=take["bases"],
                 events=[dict(event=r["event"], notes=[dict(string=n["string"], fret=n["fret"], bend=n["bend"],
                                                           f1=n["f1"], B=n["B"]) for n in r["notes"]])
                         for r in take["events"]])
    with open(os.path.join(sealed_dir, take["take"] + ".json"), "w") as fh:
        json.dump(truth, fh, indent=1)


def write_strings_table(path):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["string_set", "string", "kind", "gauge_in", "core_in", "mass_kg_per_m",
                    "rated_tension_min_n", "rated_tension_max_n"])
        for code in ("L09", "L10", "H12", "S7", "B13"):
            lo, hi = SETS[code]["window"]
            for i, (kind, gauge, core, mu) in enumerate(SETS[code]["strings"]):
                w.writerow([code, i + 1, kind, "%.4f" % gauge, "%.4f" % core, "%.6f" % mu, lo, hi])


def main(argv):
    if argv[0] == "samples":
        out = argv[1]
        os.makedirs(out, exist_ok=True)
        for spec in SAMPLES:
            t = build_take(*spec)
            write_take(t, out, True)
            print(t["take"], t["set"], t["tuning"], len(t["events"]), "events, attempts", t["attempts"])
        return 0
    if argv[0] == "held":
        out, sealed = argv[1], argv[2]
        os.makedirs(out, exist_ok=True)
        for spec in HELD:
            t = build_take(*spec)
            write_take(t, out, False)
            write_sealed(t, sealed)
            print(t["take"], t["set"], t["tuning"], len(t["events"]), "events, attempts", t["attempts"])
        return 0
    if argv[0] == "table":
        write_strings_table(argv[1])
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
