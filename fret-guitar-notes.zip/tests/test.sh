#!/usr/bin/env bash
# Grades the uploaded labelling program. The reward channel is sealed before any uploaded code
# runs: /logs/verifier becomes root-only, anything reward-shaped in it is removed and reward.txt is
# set to 0. The program then runs as an unprivileged account (tests/holdout.py). At the end
# everything root did not write is removed from /logs/verifier and reward.txt alone is written,
# 1 only when both tests passed.
set -u
VERIFIER_DIR=/logs/verifier
REPORT_DIR=/run/verifier

mkdir -p /logs/verifier
saved_mode="$(stat -c %a /logs/verifier 2>/dev/null || echo 755)"
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier 2>/dev/null

sweep() {
    find "$VERIFIER_DIR" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) -exec rm -rf {} + 2>/dev/null
    find "$VERIFIER_DIR" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    rm -f "$VERIFIER_DIR/reward.json"
}
write_reward() {
    sweep
    (umask 022; printf '%s\n' "$1" > "$VERIFIER_DIR/reward.txt")
}
leave() {
    chmod "$saved_mode" "$VERIFIER_DIR" 2>/dev/null
    exit 0
}

write_reward 0
if [ "$(stat -c '%u:%a' /logs/verifier 2>/dev/null)" != "0:700" ]; then
    echo "grader: /logs/verifier is not root-only (0:700); nothing is run" >&2
    leave
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$REPORT_DIR" && chown 0:0 "$REPORT_DIR" && chmod 700 "$REPORT_DIR"
chmod -R a+rX /app/fretter 2>/dev/null

verdict=1
if ( cd /tests && python3 -m pytest test_fretting.py -q -p no:cacheprovider --ctrf "$REPORT_DIR/ctrf.json" ); then
    verdict=0
fi

if [ "$verdict" -eq 0 ]; then write_reward 1; else write_reward 0; fi
for f in ctrf.json takes.json; do
    [ -f "$REPORT_DIR/$f" ] && (umask 022; cp "$REPORT_DIR/$f" "$VERIFIER_DIR/$f")
done
leave
