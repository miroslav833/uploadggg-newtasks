"""Runs the uploaded labelling program over the held-out takes and reads what it wrote.

Each take is copied to a scratch folder owned by a numeric account invented for the run; the
program runs there under setsid with no groups, 2 GiB of address space and 120 s of wall clock,
writing one CSV. Every process of that account is stopped before the CSV is read, and the CSV is
read as text through a descriptor that refuses links; nothing in it is executed.
"""
import csv
import os
import resource
import shutil
import signal
import subprocess
import time

VAULT = "/tests/vault"
PRIVATE = "/run/verifier"
SCRATCH = "/var/tmp/takes"
PROGRAM = "/app/fretter/fret.py"
WALL_SECONDS = 120
MAX_OUTPUT = 1 << 20


def takes():
    return sorted(os.listdir(os.path.join(VAULT, "takes")))


def spare_uid():
    """The first numeric account from 52000 up that owns no process."""
    owners = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                owners.add(os.stat("/proc/" + d).st_uid)
            except FileNotFoundError:
                pass
    uid = 52000
    while uid in owners:
        uid += 1
    return uid


def halt_account(uid):
    for _ in range(200):
        alive = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    if os.stat("/proc/" + d).st_uid == uid:
                        alive.append(int(d))
                except FileNotFoundError:
                    pass
        if not alive:
            return
        for pid in alive:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def parse_filing(path):
    """{event: frozenset of (string, fret, bend)} from the CSV; a row that does not parse is left out."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
            text = fh.read(MAX_OUTPUT + 1)
    except OSError:
        return {}
    if len(text) > MAX_OUTPUT:
        return {}
    out = {}
    for row in csv.DictReader(text.splitlines()):
        try:
            code = (row.get("event") or "").strip()
            triple = tuple(int((row.get(k) or "").strip()) for k in ("string", "fret", "bend"))
        except (ValueError, AttributeError):
            continue
        if code:
            out.setdefault(code, set()).add(triple)
    return {k: frozenset(v) for k, v in out.items()}


def run_take(code, uid):
    work = os.path.join(SCRATCH, code)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, mode=0o755)
    src = os.path.join(work, "take")
    tmp = os.path.join(work, "tmp")
    shutil.copytree(os.path.join(VAULT, "takes", code), src, symlinks=False)
    os.makedirs(tmp)
    for base, dirs, files in os.walk(work):
        for name in dirs + files:
            os.chown(os.path.join(base, name), uid, uid)
    os.chown(work, uid, uid)
    target = os.path.join(work, "tab.csv")

    def drop_privileges():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": tmp, "TMPDIR": tmp, "LANG": "C.UTF-8"}
    with open(os.path.join(PRIVATE, code + ".log"), "wb") as log:
        proc = subprocess.Popen(["python3", PROGRAM, src, target], stdin=subprocess.DEVNULL,
                                stdout=log, stderr=log, cwd=tmp, env=env, preexec_fn=drop_privileges)
        try:
            proc.wait(timeout=WALL_SECONDS)
        except subprocess.TimeoutExpired:
            pass
    halt_account(uid)
    filed = {}
    try:
        st = os.lstat(target)
        if not os.path.islink(target) and os.path.isfile(target) and st.st_size <= MAX_OUTPUT:
            filed = parse_filing(target)
    except OSError:
        filed = {}
    shutil.rmtree(work, ignore_errors=True)
    return filed
