# Tablature corpus: capture, files and conventions

## The corpus

The tablature model we train takes a recorded guitar event, a single note, a double stop or a
strummed chord, and predicts for every string that sounds the fret it was held at and how far it
was bent. Its training targets come from this corpus: takes recorded in the studio, one player and
one guitar per take, played from a chart. The guitars were recorded through one microphone
channel; no per-string pickup was used. Each take was segmented into events at their onsets, and
every event was run through the line tracker.

Four takes were labelled by hand from the session video and ship with their labels in `tab.csv`.
Every other take in the corpus is labelled by the labelling program this handbook accompanies.

## The line tracker

The tracker takes the steady part of an event and lists its stable spectral lines, whatever is
sounding. It keeps every line between 100 Hz and 12 kHz whose level is within 50 dB of the event's
strongest line, at most 80 lines per event (the strongest are kept when more qualify), in
ascending frequency; two lines closer than 1.5 Hz are reported as one, at the stronger's
frequency. Lines are not numbered, classified or assigned to strings: the tracker reports what it
finds and nothing about which partial of which string a line is. Frequencies are given to 0.01 Hz,
levels in dB relative to the event's strongest line, so the strongest line of an event has level
0.0. The partials of a plucked steel string follow the stiff-string law, f_k = k f_1 sqrt(1 + B
k^2), where f_1 is the pitch, k the order of the partial and B the string's inharmonicity
coefficient for that note; the lines an event shows are the partials of every string that sounds,
less whatever the tracker's floor removed. Partials near a node of the pick position are weak and
often fall under the floor, and the lowest partials of the low strings fall under 100 Hz.

`lines.csv`, one row per line:

```
event,freq_hz,level_db
K7QD,329.71,0.0
K7QD,659.44,-3.1
```

`events.csv`, one row per event, in order of onset:

```
event,onset_s
K7QD,0.812
```

Event codes are arbitrary four-character labels unique within a take.

## The set-up sheet

Each take's `setup.csv` records the guitar, how many strings it carries, the string set fitted and
the scale length (nut to the theoretical saddle position) in inches:

```
take,guitar,strings,string_set,scale_in
A,G-17,6,L10,25.50
```

Players tuned by an electronic tuner at A = 440 Hz before each take, to whatever open pitches the
chart called for, and used no capo. The open pitches were not written on the sheet. Every string
was kept inside the rated tension window of its set.

## The string sets

`strings.csv` lists every set the studio stocks, one row per string, string 1 being the
highest-pitched string as strung. Columns: `string_set`, `string`, `kind` (`plain` steel or
`wound`, a steel core under a round winding), `gauge_in` (overall diameter, inches), `core_in` (the
steel core's diameter; for a plain string the same as the gauge), `mass_kg_per_m` (mass per
metre), and the maker's rated tension window at pitch, `rated_tension_min_n` and
`rated_tension_max_n`, in newtons. The maker quotes the steel's modulus as E = 2.0 x 10^11 Pa.

```
string_set,string,kind,gauge_in,core_in,mass_kg_per_m,rated_tension_min_n,rated_tension_max_n
L10,1,plain,0.0100,0.0100,0.000398,55,100
L10,4,wound,0.0260,0.0157,0.002365,55,100
```

Sets in the studio: L09 and L10 (six strings, plain third), H12 (six strings, wound third), S7
(seven strings) and B13 (six strings, for baritone scale lengths).

## Playing

Takes are played in whatever positions the chart calls for; a string may never sound open in a
take. Events are single notes, double stops and strummed chords of up to six strings at once, each
string sounding once in an event. Players bend single notes, pushing the string across the
fretboard to raise the pitch by one or two semitones above the fret they hold; no bend is wider
than two semitones, no note of a chord is bent, and every string sounds at least two unbent single
notes in every take. There are no slides, harmonics, hammer-ons or muted strums in the corpus.

## The tab

`tab.csv` for a labelled take, one row per sounding string of each event:

```
event,string,fret,bend
K7QD,1,0,0
R2MX,2,3,0
R2MX,3,2,0
R2MX,4,0,0
```

`string` counts from 1 at the highest-pitched string as strung; `fret` counts from the nut, 0 for
an open string; `bend` is the whole number of semitones the note was bent above its fret, 0 for an
unbent note. An event has one row per string that sounds and none for a string that does not.
