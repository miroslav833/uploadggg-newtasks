#!/bin/bash
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests || exit 0
if [ -f /app/sheet.csv ] && python3 -m pytest -q -p no:cacheprovider test_sheet.py --ctrf /logs/verifier/ctrf.json; then
  echo 1 > /logs/verifier/reward.txt
fi
exit 0
