"""Checks /app/sheet.csv against the label's own sheet for the beat tape."""
import csv
import io
import itertools
import json
import math
import os

import pytest

SHEET = "/app/sheet.csv"
TRUTH = os.path.join(os.path.dirname(__file__), "truth.json")
COLUMNS = ["track", "master", "from", "to", "speed", "semitones", "reversed"]
TOL_T = 0.15      # seconds, from/to
TOL_SPEED = 0.006  # relative
TOL_SEMI = 0.2    # semitones
NEEDED = 14


def read_sheet():
    fd = os.open(SHEET, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as fh:
        raw = fh.read(2_000_001)
    assert len(raw) <= 2_000_000, "sheet is larger than 2 MB"
    text = raw.decode("utf-8-sig")
    rd = csv.reader(io.StringIO(text))
    rows = [r for r in rd if any(c.strip() for c in r)]
    assert rows, "sheet is empty"
    head = [c.strip().lower() for c in rows[0]]
    assert head == COLUMNS, f"header must be {','.join(COLUMNS)}, got {','.join(head)}"
    out = {}
    for n, r in enumerate(rows[1:], start=2):
        assert len(r) == len(COLUMNS), f"line {n}: expected {len(COLUMNS)} fields"
        r = [c.strip() for c in r]
        flag = r[6].lower()
        assert flag in ("yes", "no"), f"line {n}: reversed must be yes or no"
        try:
            nums = [float(r[2]), float(r[3]), float(r[4]), float(r[5])]
        except ValueError:
            raise AssertionError(f"line {n}: from/to/speed/semitones must be numbers")
        assert all(math.isfinite(v) for v in nums), f"line {n}: numbers must be finite"
        out.setdefault(r[0], []).append(dict(master=r[1], f=nums[0], t=nums[1], speed=nums[2], semi=nums[3],
                                             rev=flag == "yes"))
    return out


def row_matches(s, t):
    if s["master"] != t["master"] or s["rev"] != bool(t["reversed"]):
        return False
    d_speed = abs(s["speed"] - t["speed"]) / t["speed"]
    if not (math.isfinite(d_speed) and d_speed <= TOL_SPEED):
        return False
    d_semi = abs(s["semi"] - t["semitones"])
    if not (math.isfinite(d_semi) and d_semi <= TOL_SEMI):
        return False
    span = t["to"] - t["from"]
    for start in [t["from"]] + list(t.get("also", [])):
        d_from, d_to = abs(s["f"] - start), abs(s["t"] - (start + span))
        if math.isfinite(d_from) and math.isfinite(d_to) and d_from <= TOL_T and d_to <= TOL_T:
            return True
    return False


def track_right(mine, ours):
    if len(mine) != len(ours):
        return False
    return any(all(row_matches(mine[i], t) for i, t in zip(perm, ours))
               for perm in itertools.permutations(range(len(mine))))


@pytest.fixture(scope="module")
def sheet():
    return read_sheet()


@pytest.fixture(scope="module")
def truth():
    with open(TRUTH) as fh:
        return json.load(fh)


def test_sheet_names_only_tape_tracks(sheet, truth):
    extra = sorted(set(sheet) - set(truth))
    assert not extra, f"rows for tracks that are not on the tape: {extra}"


def test_enough_tracks_cleared(sheet, truth):
    right = {name: track_right(sheet.get(name, []), rows) for name, rows in sorted(truth.items())}
    for name, ok in right.items():
        print(f"{name}: {'right' if ok else 'wrong'}")
    count = sum(right.values())
    assert count >= NEEDED, f"{count} of {len(right)} tracks right, need {NEEDED}"
