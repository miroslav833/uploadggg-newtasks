"""Turn performed parts into audio: MIDI file -> FluidSynth -> studio/era character."""
import os
import subprocess
import tempfile

import mido
import numpy as np
import soundfile as sf
from scipy import signal

SR = 44100
SF2 = "/usr/share/sounds/sf2/FluidR3_GM.sf2"
PAN = dict(drums=64, bass=64, keys=44, lead=80, horns=90, pad=34)
VOL = dict(drums=110, bass=104, keys=86, lead=96, horns=92, pad=74)


def write_midi(parts, bpm, path, pan=None, vol=None, tpb=480):
    pan = pan or PAN
    vol = vol or VOL
    mid = mido.MidiFile(ticks_per_beat=tpb)
    meta = mido.MidiTrack()
    meta.append(mido.MetaMessage("set_tempo", tempo=int(round(60e6 / bpm)), time=0))
    mid.tracks.append(meta)
    for name, part in parts.items():
        tr = mido.MidiTrack()
        ch = part["channel"]
        tr.append(mido.Message("program_change", channel=ch, program=part["program"], time=0))
        tr.append(mido.Message("control_change", channel=ch, control=10, value=pan.get(name, 64), time=0))
        tr.append(mido.Message("control_change", channel=ch, control=7, value=vol.get(name, 100), time=0))
        ev = []
        for b, l, p, v in part["notes"]:
            on = int(round(b * tpb))
            off = int(round((b + l) * tpb))
            ev.append((on, 1, p, v))
            ev.append((max(off, on + 1), 0, p, 0))
        ev.sort(key=lambda e: (e[0], e[1]))
        now = 0
        for t, kind, p, v in ev:
            msg = "note_on" if kind else "note_off"
            tr.append(mido.Message(msg, channel=ch, note=p, velocity=v, time=t - now))
            now = t
        mid.tracks.append(tr)
    mid.save(path)


def synth(parts, bpm, seconds, pan=None, vol=None):
    with tempfile.TemporaryDirectory() as td:
        mp, wp = os.path.join(td, "s.mid"), os.path.join(td, "s.wav")
        write_midi(parts, bpm, mp, pan, vol)
        subprocess.run(["fluidsynth", "-ni", "-q", "-C0", "-R0", "-g", "0.5", "-r", str(SR),
                        "-T", "wav", "-O", "float",
                        "-F", wp, SF2, mp], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        x, sr = sf.read(wp, dtype="float64", always_2d=True)
    n = int(round(seconds * SR))
    if len(x) < n:
        x = np.vstack([x, np.zeros((n - len(x), 2))])
    return x[:n]


def room_ir(rng, rt60, sr=SR, predelay=0.012):
    n = int(sr * min(2.5, rt60 * 1.2))
    t = np.arange(n) / sr
    env = np.exp(-6.9 * t / rt60)
    ir = np.zeros((n + int(predelay * sr), 2))
    noise = rng.standard_normal((n, 2))
    b, a = signal.butter(2, [200 / (sr / 2), 7000 / (sr / 2)], "band")
    noise = signal.lfilter(b, a, noise, axis=0)
    ir[int(predelay * sr):] = noise * env[:, None]
    ir /= np.sqrt((ir ** 2).sum(axis=0, keepdims=True)) + 1e-12
    return ir


def character(x, rng, era):
    """Era/studio colour.  era: dict(hp, lp, drive, rt60, wet, mono, hiss_db, vinyl)."""
    sos_hp = signal.butter(2, era["hp"] / (SR / 2), "high", output="sos")
    sos_lp = signal.butter(4, era["lp"] / (SR / 2), "low", output="sos")
    y = signal.sosfilt(sos_hp, x, axis=0)
    y = signal.sosfilt(sos_lp, y, axis=0)
    if era["mono"]:
        y = np.repeat(y.mean(axis=1, keepdims=True), 2, axis=1)
    ir = room_ir(rng, era["rt60"])
    wet = np.stack([signal.fftconvolve(y[:, c], ir[:, c])[: len(y)] for c in range(2)], axis=1)
    y = y + era["wet"] * wet
    pk = np.abs(y).max() + 1e-9
    y = y / pk * 0.8
    d = era["drive"]
    y = np.tanh(d * y) / np.tanh(d)
    n = len(y)
    if era["hiss_db"] is not None:
        h = rng.standard_normal((n, 2))
        h = signal.lfilter([1, -0.6], [1], h, axis=0)
        y = y + h * 10 ** (era["hiss_db"] / 20)
    if era["vinyl"]:
        cr = np.zeros((n, 2))
        k = rng.poisson(n / SR * 9)
        pos = rng.integers(0, n, k)
        amp = rng.exponential(0.05, k) * np.sign(rng.standard_normal(k))
        cr[pos, :] = amp[:, None]
        b, a = signal.butter(2, 1500 / (SR / 2), "high")
        cr = signal.lfilter(b, a, cr, axis=0)
        rumble = signal.lfilter([1], [1, -0.999], rng.standard_normal((n, 2)) * 2e-4, axis=0)
        y = y + cr + rumble
    rms = np.sqrt((y ** 2).mean())
    y = y * (10 ** (-16 / 20) / (rms + 1e-12))
    pk = np.abs(y).max()
    if pk > 0.98:
        y = y * 0.98 / pk
    return y


def era_for(year, rng, vinyl=False):
    old = year < 1970
    return dict(
        hp=float(rng.uniform(45, 90) if old else rng.uniform(30, 55)),
        lp=float(rng.uniform(7000, 10500) if old else rng.uniform(11000, 15500)),
        drive=float(rng.uniform(1.4, 2.4) if old else rng.uniform(1.05, 1.6)),
        rt60=float(rng.uniform(0.5, 1.3)),
        wet=float(rng.uniform(0.12, 0.3)),
        mono=bool(old and rng.random() < 0.7),
        hiss_db=float(rng.uniform(-62, -54)) if old or rng.random() < 0.5 else None,
        vinyl=bool(vinyl),
    )


def peaking(x, f0, gain_db, q):
    a = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * f0 / SR
    alpha = np.sin(w0) / (2 * q)
    b = [1 + alpha * a, -2 * np.cos(w0), 1 - alpha * a]
    den = [1 + alpha / a, -2 * np.cos(w0), 1 - alpha / a]
    return signal.lfilter(b, den, x, axis=0)


def tune(x, semis):
    """retune a stem without changing its timing (each session's drummer tunes the kit their own way)"""
    import tempfile as _tf
    with _tf.TemporaryDirectory() as td:
        a, b = os.path.join(td, "a.wav"), os.path.join(td, "b.wav")
        sf.write(a, x, SR, subtype="FLOAT")
        subprocess.run(["rubberband", "-q", "-c", "6", "-p", f"{semis:.4f}", a, b], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        y, _ = sf.read(b, dtype="float64", always_2d=True)
    n = len(x)
    if len(y) < n:
        y = np.vstack([y, np.zeros((n - len(y), y.shape[1]))])
    return y[:n]


def drum_colour(x, rng):
    """the drum sound of one session: tuning, shell/room resonances, mic EQ and some tape drive"""
    x = tune(x, float(rng.choice([-1, 1]) * rng.uniform(0.35, 1.4)))
    for _ in range(3):
        x = peaking(x, float(rng.uniform(120, 7000)), float(rng.uniform(-7, 7)), float(rng.uniform(0.7, 2.5)))
    pk = np.abs(x).max() + 1e-9
    d = float(rng.uniform(1.2, 2.6))
    x = np.tanh(d * x / pk) / np.tanh(d) * pk
    ir = room_ir(rng, float(rng.uniform(0.25, 0.7)), predelay=float(rng.uniform(0.004, 0.02)))
    wet = np.stack([signal.fftconvolve(x[:, c], ir[:, c])[: len(x)] for c in range(2)], axis=1)
    return x + float(rng.uniform(0.15, 0.4)) * wet
