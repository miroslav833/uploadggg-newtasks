"""Procedural session material for the label's catalogue.

A song is a dict of parts; each part is a list of notes (start_beat, length_beats, pitch, velocity) plus a GM
program.  The same song spec can be performed several times (takes) with different timing and small changes.
"""
import numpy as np

SCALES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "dorian": [0, 2, 3, 5, 7, 9, 10],
}

# chord = (degree in scale 0..6, seventh?)
PROGRESSIONS = {
    "soul": [[0, 5, 3, 4], [0, 2, 3, 4], [3, 4, 2, 5], [0, 3, 0, 4]],
    "funk": [[0, 0, 3, 3], [0, 6, 0, 6], [0, 0, 0, 3]],
    "jazz": [[1, 4, 0, 5], [0, 5, 1, 4], [2, 5, 1, 4]],
    "library": [[0, 3, 0, 3], [0, 5, 6, 0], [0, 1, 0, 6]],
    "latin": [[0, 1, 2, 1], [0, 3, 1, 4], [1, 4, 0, 0]],
    "gospel": [[0, 3, 0, 4], [3, 0, 4, 5], [0, 5, 3, 4]],
}

STYLE_MODES = {
    "soul": ["major", "minor"], "funk": ["dorian", "minor"], "jazz": ["major", "dorian"],
    "library": ["major", "minor", "dorian"], "latin": ["major", "minor"], "gospel": ["major"],
}

# 16-step grooves: kick, snare, hat (velocity 0 = rest)
GROOVES = {
    "soul": ([100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 105, 0, 0, 0, 0, 0, 0, 0, 105, 0, 0, 0],
             [80, 0, 60, 0, 80, 0, 60, 0, 80, 0, 60, 0, 80, 0, 60, 0]),
    "funk": ([110, 0, 0, 90, 0, 0, 0, 95, 0, 0, 100, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 110, 0, 35, 0, 0, 35, 0, 0, 110, 0, 35, 0],
             [85, 50, 70, 50, 85, 50, 70, 50, 85, 50, 70, 50, 85, 50, 70, 50]),
    "jazz": ([70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 55, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0, 30, 0],
             [85, 0, 0, 0, 80, 0, 60, 0, 85, 0, 0, 0, 80, 0, 60, 0]),
    "library": ([100, 0, 0, 0, 0, 0, 0, 0, 95, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0],
                [75, 0, 75, 0, 75, 0, 75, 0, 75, 0, 75, 0, 75, 0, 75, 0]),
    "latin": ([100, 0, 0, 80, 0, 0, 0, 0, 100, 0, 0, 80, 0, 0, 0, 0],
              [0, 0, 0, 70, 0, 0, 70, 0, 0, 0, 70, 0, 0, 70, 0, 0],
              [60, 45, 60, 45, 60, 45, 60, 45, 60, 45, 60, 45, 60, 45, 60, 45]),
    "gospel": ([100, 0, 0, 0, 0, 0, 0, 70, 90, 0, 0, 0, 0, 0, 0, 0],
               [0, 0, 0, 0, 110, 0, 0, 0, 0, 0, 0, 0, 110, 0, 0, 40],
               [80, 0, 0, 55, 80, 0, 0, 55, 80, 0, 0, 55, 80, 0, 0, 55]),
}

KITS = {"standard": 0, "room": 8, "jazz": 32, "brush": 40, "power": 16}
SNARE_NOTE = {"latin": 37}  # side stick for bossa
HAT_NOTE = {"jazz": 51}     # ride

PALETTES = {
    "soul": dict(bass=[33, 34], keys=[4, 0, 16], lead=[11, 65, 56, 53], horns=[61, 56], pad=[48, 49]),
    "funk": dict(bass=[33, 36], keys=[7, 4, 17], lead=[66, 56, 27], horns=[61, 66], pad=[50, 48]),
    "jazz": dict(bass=[32], keys=[0, 4, 11], lead=[65, 66, 73, 56], horns=[57, 65], pad=[49, 48]),
    "library": dict(bass=[33, 32], keys=[11, 4, 6, 19], lead=[73, 68, 11, 52], horns=[61, 60], pad=[49, 50, 48]),
    "latin": dict(bass=[32, 33], keys=[24, 0, 4], lead=[73, 65, 11], horns=[56, 61], pad=[49, 48]),
    "gospel": dict(bass=[33], keys=[16, 0, 18], lead=[52, 53, 65], horns=[61], pad=[52, 49]),
}


def chord_pitches(root_pc, mode, degree, seventh=True):
    sc = SCALES[mode]
    out = []
    for k in (0, 2, 4, 6) if seventh else (0, 2, 4):
        d = degree + k
        out.append(root_pc + sc[d % 7] + 12 * (d // 7))
    return out


def make_spec(rng, style=None):
    """Everything about a tune that stays the same across takes."""
    style = style or rng.choice(list(PROGRESSIONS))
    mode = rng.choice(STYLE_MODES[style])
    pal = PALETTES[style]
    spec = dict(
        style=str(style), mode=str(mode),
        root=int(rng.integers(0, 12)),
        bpm=float(round(rng.uniform(78, 116), 1)),
        swing=float(rng.choice([0.0, 0.0, 0.08, 0.16]) if style in ("soul", "jazz", "gospel") else 0.0),
        kit=str(rng.choice(["brush", "jazz"]) if style == "jazz" else rng.choice(["standard", "room", "power"])),
        bass=int(rng.choice(pal["bass"])), keys=int(rng.choice(pal["keys"])),
        lead=int(rng.choice(pal["lead"])), horns=int(rng.choice(pal["horns"])), pad=int(rng.choice(pal["pad"])),
        prog_a=[int(x) for x in PROGRESSIONS[style][rng.integers(len(PROGRESSIONS[style]))]],
        prog_b=[int(x) for x in PROGRESSIONS[style][rng.integers(len(PROGRESSIONS[style]))]],
        seed=int(rng.integers(1 << 30)),
    )
    # form: list of (section, bars)
    form = [("intro", 2)]
    if rng.random() < 0.5:
        form.append(("break", 2))
    form += [("a", 4), ("b", 4), ("a", 4)]
    if rng.random() < 0.6:
        form.append(("break", 2))
    form += [("b", 4), ("outro", 2)]
    spec["form"] = form
    spec["has_horns"] = bool(rng.random() < 0.6)
    spec["has_pad"] = bool(rng.random() < 0.55)
    spec["has_lead"] = bool(rng.random() < 0.8)
    return spec


def _motif(rng, length_steps=32):
    """Rhythm + scale-step contour for a two-bar melodic idea (16th steps)."""
    steps, t = [], 0
    while t < length_steps:
        dur = int(rng.choice([2, 2, 4, 4, 6, 8, 3]))
        if rng.random() < 0.22:
            t += dur
            continue
        steps.append((t, min(dur, length_steps - t), int(rng.choice([-2, -1, -1, 0, 1, 1, 2, 3, -3]))))
        t += dur
    return steps


def perform(spec, take_seed, variant=None):
    """Return dict part -> dict(program, channel, notes[(beat, len, pitch, vel)], drum bool).

    variant: optional dict of small arrangement changes for an alternate take:
      fill_bars (set of bar indices that get a different fill), lead_shift (semitone tweaks at bars),
      tempo_scale (float)
    """
    variant = variant or {}
    rng = np.random.default_rng(spec["seed"])          # arrangement decisions shared by takes
    hum = np.random.default_rng(take_seed)             # performance (timing/velocity) per take
    root, mode, style = spec["root"], spec["mode"], spec["style"]
    swing = spec["swing"]
    kick_v, snare_v, hat_v = (list(g) for g in GROOVES[style])
    grng = np.random.default_rng(spec["seed"] + 99)   # the drummer's own version of the groove
    for s in grng.choice([2, 3, 5, 6, 7, 9, 11, 13, 14, 15], int(grng.integers(1, 3)), replace=False):
        if not kick_v[s] and not snare_v[s]:
            kick_v[s] = int(grng.integers(70, 96))
    for s in grng.choice([1, 3, 7, 9, 11, 15], int(grng.integers(0, 3)), replace=False):
        if not kick_v[s] and not snare_v[s]:
            snare_v[s] = int(grng.integers(28, 42))
    if grng.random() < 0.4:
        hat_v[int(grng.choice([6, 14]))] = 0
    sn_note = SNARE_NOTE.get(style, 38)
    hat_note = HAT_NOTE.get(style, 42)
    parts = {k: [] for k in ("drums", "bass", "keys", "lead", "horns", "pad")}

    def jit(sd):
        return float(hum.normal(0, sd))

    def vel(v, sd=7):
        return int(np.clip(v + hum.normal(0, sd), 12, 127))

    def step_beat(bar, s):
        b = bar * 4 + s / 4.0
        if swing and s % 2 == 1:
            b += swing * 0.25 * 2
        return b

    motif_a, motif_b = _motif(rng), _motif(rng)
    bar = 0
    fills = variant.get("fill_bars", set())
    lead_shift = variant.get("lead_shift", {})
    comps = [[0, 6, 10], [2, 6, 10, 14], [0, 3, 8, 11], [4, 12], [0, 8]]
    hits = [[6, 12], [3, 10], [14], [4, 7, 12]]
    comp_pattern = comps[int(rng.integers(len(comps)))]
    horn_hits = hits[int(rng.integers(len(hits)))]
    for section, nbars in spec["form"]:
        prog = spec["prog_a"] if section in ("a", "intro") else spec["prog_b"]
        for i in range(nbars):
            deg = prog[(i) % len(prog)]
            ch = chord_pitches(root, mode, deg, seventh=style in ("jazz", "library", "latin", "funk"))
            last_of_section = i == nbars - 1
            # drums
            play_drums = section != "intro" or rng.random() < 0.5
            if play_drums:
                fill_here = (last_of_section and section in ("a", "b") and rng.random() < 0.8) or bar in fills
                for s in range(16):
                    t = step_beat(bar, s)
                    if fill_here and s >= 8:
                        if (s % 2 == 0) or (bar in fills and s % 3 == 0):
                            tom = [50, 48, 47, 45, 43, 41][(s - 8 + (3 if bar in fills else 0)) % 6]
                            parts["drums"].append((t + jit(0.012), 0.2, tom if s > 9 else sn_note, vel(95)))
                        continue
                    if kick_v[s]:
                        parts["drums"].append((t + jit(0.01), 0.2, 36, vel(kick_v[s])))
                    if snare_v[s]:
                        parts["drums"].append((t + jit(0.01), 0.2, sn_note, vel(snare_v[s])))
                    if hat_v[s] and section != "break" or (section == "break" and hat_v[s] and s % 2 == 0):
                        parts["drums"].append((t + jit(0.008), 0.15, hat_note, vel(hat_v[s], 10)))
            if section == "break":
                bar += 1
                continue
            # bass
            r = 36 + ch[0] % 12
            bpat = {"funk": [(0, 2, 0), (3, 1, 12), (6, 2, 7), (10, 2, 0), (14, 2, 10)],
                    "jazz": [(0, 4, 0), (4, 4, 4), (8, 4, 7), (12, 4, 5)],
                    "latin": [(0, 6, 0), (6, 2, 7), (8, 6, 7), (14, 2, 0)]}.get(
                style, [(0, 6, 0), (6, 2, 0), (8, 4, 7), (12, 4, 12)])
            for s, d, iv in bpat:
                if section == "intro" and s > 0:
                    continue
                parts["bass"].append((step_beat(bar, s) + jit(0.012), d / 4.0 * 0.9, r + iv, vel(92)))
            # keys comping
            for s in comp_pattern:
                d = 2 if style in ("funk", "latin") else 4
                for p in ch:
                    parts["keys"].append((step_beat(bar, s) + jit(0.014), d / 4.0, 55 + (p - 55) % 12, vel(70)))
            # pad
            if spec["has_pad"] and section in ("b", "outro", "intro"):
                for p in ch[:3]:
                    parts["pad"].append((bar * 4 + jit(0.02), 3.9, 48 + (p % 12) + 12, vel(62, 4)))
            # horns
            if spec["has_horns"] and section in ("a", "b"):
                for s in horn_hits:
                    for p in ch[:3]:
                        parts["horns"].append((step_beat(bar, s) + jit(0.01), 0.45, 60 + (p % 12), vel(100)))
            # lead melody (two-bar motif over sections a/b)
            if spec["has_lead"] and section in ("a", "b"):
                motif = motif_a if section == "a" else motif_b
                sc = SCALES[mode]
                base_deg = 4 if section == "a" else 2
                for (t0, d, step) in motif:
                    if (t0 // 16) != (i % 2):
                        continue
                    s = t0 % 16
                    dd = base_deg + step + (i // 2)
                    p = 72 + root % 12 + sc[dd % 7] + 12 * (dd // 7) - 12
                    p += lead_shift.get(bar, 0)
                    parts["lead"].append((step_beat(bar, s) + jit(0.012), d / 4.0 * 0.92, int(p), vel(88)))
            bar += 1
    total_beats = bar * 4
    out = {}
    progs = dict(bass=spec["bass"], keys=spec["keys"], lead=spec["lead"], horns=spec["horns"], pad=spec["pad"])
    for k, notes in parts.items():
        if not notes:
            continue
        notes = sorted((max(0.0, b), l, int(p), int(v)) for b, l, p, v in notes)
        if k == "drums":
            out[k] = dict(program=KITS[spec["kit"]], channel=9, notes=notes, drum=True)
        else:
            out[k] = dict(program=progs[k], channel=["bass", "keys", "lead", "horns", "pad"].index(k), notes=notes,
                          drum=False)
    return out, total_beats
