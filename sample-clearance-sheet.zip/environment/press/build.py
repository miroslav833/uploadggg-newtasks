"""Press the label catalogue: one WAV per catalogue id plus catalogue.csv.

    python3 build.py OUT_DIR [--meta META.json]
"""
import csv
import json
import os
import sys
from multiprocessing import Pool

import numpy as np
import soundfile as sf

import compose
import render

SEED = 41077
N_MASTERS = 40

WORDS_A = ["Velvet", "Midnight", "Copper", "Sunday", "Harbour", "Paper", "Silver", "Lantern", "Quiet", "Golden",
           "Northside", "Blue", "Satin", "Second", "Low", "Easy", "Crystal", "Summer", "Rainy", "Long"]
WORDS_B = ["Avenue", "Strut", "Lament", "Groove", "Waltz", "Shuffle", "Theme", "Walk", "Promise", "Drive",
           "Song", "Signal", "Corner", "Glow", "Hours", "Weather", "Steps", "Garden", "Story", "Run"]
ARTISTS = ["The Delmonts", "Ruth Calloway", "Lenny Sparks Quartet", "Orchestra Mirabel", "The Fairview Five",
           "Odessa Lane", "Marcus Hale Trio", "The Brass Union", "Carol & The Keys", "Jimmy Tolliver",
           "Sound Workshop Ensemble", "The Westmore Singers", "Hector Vale", "Little Ada Reed"]


def catalogue_plan():
    rng = np.random.default_rng(SEED)
    items = []
    used_titles = set()
    for i in range(N_MASTERS):
        spec = compose.make_spec(rng)
        while True:
            title = f"{rng.choice(WORDS_A)} {rng.choice(WORDS_B)}"
            if title not in used_titles:
                used_titles.add(title)
                break
        year = int(rng.integers(1964, 1984))
        items.append(dict(id=f"HW-{1001 + i * 3}", title=title, artist=str(rng.choice(ARTISTS)), year=year,
                          spec=spec, take_seed=int(rng.integers(1 << 30)), variant={}, tempo_scale=1.0,
                          vinyl=bool(rng.random() < 0.15), notes="", era_seed=int(rng.integers(1 << 30))))
    for it in items:
        if it["vinyl"]:
            it["notes"] = "transferred from a vinyl copy (tapes lost)"
    base = list(items)
    # vault alternate takes
    alt_of = rng.choice(len(base), 8, replace=False)
    for k, j in enumerate(alt_of):
        m = base[j]
        nbars = sum(b for _, b in m["spec"]["form"])
        fills = set(int(x) for x in rng.choice(np.arange(2, nbars - 1), 2, replace=False))
        lead = {int(rng.integers(2, nbars - 2)): int(rng.choice([-2, -1, 1, 2]))}
        items.append(dict(id=f"{m['id']}-T{int(rng.integers(2, 6))}", title=m["title"] + " (alternate take)",
                          artist=m["artist"], year=m["year"], spec=m["spec"], take_seed=int(rng.integers(1 << 30)),
                          variant=dict(fill_bars=sorted(fills), lead_shift=lead),
                          tempo_scale=round(m["spec"]["bpm"] * (rng.choice([-1, 1]) * rng.uniform(0.012, 0.03) + 1), 1)
                          / m["spec"]["bpm"],
                          vinyl=False, notes=f"vault alternate take of {m['id']}", era_seed=m["era_seed"]))
    # re-recordings: same tune, new band and studio, later year
    rer_of = [j for j in rng.permutation(len(base)) if j not in set(alt_of)][:3]
    for k, j in enumerate(rer_of):
        m = base[j]
        spec = dict(m["spec"])
        pal = compose.PALETTES[spec["style"]]
        spec["keys"] = int(rng.choice(pal["keys"]))
        spec["lead"] = int(rng.choice([p for p in pal["lead"] if p != m["spec"]["lead"]] or pal["lead"]))
        spec["kit"] = "power" if spec["kit"] != "power" else "room"
        spec["bpm"] = float(round(spec["bpm"] * rng.uniform(1.03, 1.07), 1))
        items.append(dict(id=f"HW-{2101 + k * 7}", title=m["title"] + " (re-recorded)", artist=m["artist"],
                          year=int(m["year"] + rng.integers(12, 22)), spec=spec,
                          take_seed=int(rng.integers(1 << 30)), variant={}, tempo_scale=1.0, vinyl=False,
                          notes=f"re-recording of {m['id']}", era_seed=int(rng.integers(1 << 30))))
    return items


def bar_seconds(item):
    return 4 * 60.0 / (item["spec"]["bpm"] * item["tempo_scale"])


def section_bars(spec):
    out, b = [], 0
    for name, n in spec["form"]:
        out.append((name, b, n))
        b += n
    return out


def press_one(item):
    parts, beats = compose.perform(item["spec"], item["take_seed"],
                                   dict(fill_bars=set(item["variant"].get("fill_bars", [])),
                                        lead_shift={int(k): v for k, v in item["variant"].get("lead_shift", {}).items()}))
    bpm = item["spec"]["bpm"] * item["tempo_scale"]
    secs = beats * 60.0 / bpm + 2.5
    drums = {k: v for k, v in parts.items() if v["drum"]}
    band = {k: v for k, v in parts.items() if not v["drum"]}
    x = render.synth(band, bpm, secs) if band else 0.0
    if drums:
        # each session's kit was tuned, miked and compressed its own way
        kit_rng = np.random.default_rng(item["era_seed"] + 5)
        x = x + render.drum_colour(render.synth(drums, bpm, secs), kit_rng)
    rng = np.random.default_rng(item["era_seed"])
    era = render.era_for(item["year"], rng, item["vinyl"])
    if item["notes"].startswith("vault alternate"):
        rng = np.random.default_rng(item["take_seed"])
    y = render.character(x, rng, era)
    return y


def main():
    out = sys.argv[1]
    meta_path = sys.argv[sys.argv.index("--meta") + 1] if "--meta" in sys.argv else None
    os.makedirs(out, exist_ok=True)
    items = catalogue_plan()
    with Pool(min(4, os.cpu_count() or 1)) as pool:
        audio = pool.map(press_one, items)
    rows = []
    for it, y in zip(items, audio):
        sf.write(os.path.join(out, it["id"] + ".wav"), y, render.SR, subtype="PCM_16")
        it["seconds"] = len(y) / render.SR
    # compilation of drum breaks lifted from the masters
    rng = np.random.default_rng(SEED + 7)
    twinned = {it["notes"].split()[-1] for it in items if it["notes"].startswith(("vault", "re-recording"))}
    with_breaks = [i for i, it in enumerate(items[:N_MASTERS])
                   if any(n == "break" for n, _, _ in section_bars(it["spec"])) and it["id"] not in twinned]
    pick = sorted(rng.choice(with_breaks, 6, replace=False))
    comp, listing, sources = [], [], []
    for j in pick:
        it = items[j]
        bs = bar_seconds(it)
        name, b0, n = next(s for s in section_bars(it["spec"]) if s[0] == "break")
        a = int(round(b0 * bs * render.SR))
        e = int(round((b0 + n) * bs * render.SR))
        seg = audio[j][a:e].copy()
        f = int(0.01 * render.SR)
        seg[:f] *= np.linspace(0, 1, f)[:, None]
        seg[-f:] *= np.linspace(1, 0, f)[:, None]
        start = sum(len(c) for c in comp) / render.SR
        comp += [seg, np.zeros((int(0.8 * render.SR), 2))]
        listing.append(it["id"])
        sources.append(dict(master=it["id"], comp_start=start, master_start=a / render.SR,
                            seconds=(e - a) / render.SR))
    comp = np.vstack(comp)
    sf.write(os.path.join(out, "HW-BRK1.wav"), comp, render.SR, subtype="PCM_16")
    for it in items:
        rows.append(dict(id=it["id"], title=it["title"], artist=it["artist"], year=it["year"],
                         bpm=round(it["spec"]["bpm"] * it["tempo_scale"], 1), seconds=round(it["seconds"], 2),
                         notes=it["notes"]))
    rows.append(dict(id="HW-BRK1", title="Breaks & Beats Vol. 1", artist="Various", year=1999, bpm="",
                     seconds=round(len(comp) / render.SR, 2),
                     notes="compilation reissue; breaks taken from " + ", ".join(listing)))
    with open(os.path.join(out, "catalogue.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "title", "artist", "year", "bpm", "seconds", "notes"])
        w.writeheader()
        w.writerows(rows)
    if meta_path:
        meta = dict(items=[{k: v for k, v in it.items()} for it in items], compilation=sources)
        with open(meta_path, "w") as fh:
            json.dump(meta, fh, indent=1, default=lambda o: sorted(o) if isinstance(o, set) else str(o))


if __name__ == "__main__":
    main()
