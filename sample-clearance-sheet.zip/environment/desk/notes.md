Clearance desk: how we list samples

Every track on a release gets a sheet before it goes out. The sheet lists audio taken from our masters, so the
licensing team knows what to clear and against which recording.

What goes on the sheet

- Any stretch of a catalogue master whose recorded audio is in the track, however it was cut up, re-ordered,
  repeated, pitched, stretched, filtered or reversed.
- Not on the sheet: parts the producer played or programmed again, even when they copy a master's tune or
  chords note for note. Those are interpolations; publishing handles them, not us. If it is not audio from the
  master, leave it off.
- HW-BRK1 (Breaks & Beats Vol. 1) is a reissue. Its breaks are lifted from the masters named in the catalogue,
  so a break taken from it is listed against the original master, with the times in that master. Never list
  HW-BRK1 itself.
- Vault alternate takes (ids ending in -T2, -T3 and so on) and re-recordings are separate masters with their own
  owners. List the one whose audio is actually in the track.

One row per use

- A use is one stretch of one master played one way: one speed, one pitch, one direction. Pieces chopped from
  the same stretch and re-ordered or repeated are still one row.
- The same master used again in a track is another row if it is played at a different speed or pitch, played
  backwards, or comes from a part of the master more than 4 s away from the first.
- A stretch heard forwards in one place and backwards in another is two rows.

Columns (comma separated, with the header line, as in the filed sheets under `cleared/`)

- `track`: the tape track (`t01` ... `t16`)
- `master`: the catalogue id
- `from`, `to`: the first and last second of the master that the row's audio comes from, in master time
- `speed`: master seconds played per second of the track (1 means original speed, 1.5 means half as fast
  again)
- `semitones`: how far the pitch moved, up is positive. Audio that was only sped up or slowed down, the way a
  sampler or a turntable does it, moves by 12 x log2(speed). Time-stretched audio can move by any amount, or not
  at all.
- `reversed`: `yes` or `no`

How the label checks a sheet

- `from` and `to` within 0.15 s, `speed` within 0.6 %, `semitones` within 0.2 of ours.
- Where a master repeats a passage note for note, any of the repeats is accepted.
- A track's sheet is right only when it has exactly the right rows: nothing missing and nothing extra. A track
  with nothing to list has no rows.

Catalogue times are seconds from the start of each master's WAV in `/srv/catalogue/`. The bpm column is the
tempo the band played at.
