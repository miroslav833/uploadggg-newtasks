Halcyon Wax's clearance desk lists every catalogue sample in a release before it ships. The next release is a beat tape of sixteen short tracks, delivered as Ogg Opus reference files in `/srv/tape/`. The label's masters are the WAV files in `/srv/catalogue/`, described in `/srv/catalogue/catalogue.csv`.

The desk's rules for what to list, and how, are in `/srv/desk/notes.md`. Four tracks from an earlier release are in `/srv/desk/cleared/` together with the sheets that were filed for them, and `/srv/desk/cleared/log.txt` has the clerk's remarks on those four.

Write the sheet for the beat tape to `/app/sheet.csv`. Use the same columns and header line as the filed sheets, one row per use:

```
track,master,from,to,speed,semitones,reversed
```

A track counts when its rows are exactly right under the checks described in the notes. At least 14 of the 16 tracks have to count.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
