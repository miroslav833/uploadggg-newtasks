"""Check a candidate use by playing the master the way the producer would have and finding it in the track.

A real use is a copy of the master's audio, so after the right speed, pitch and direction it correlates with the
track waveform far above chance; an interpolation, a drum machine shared with a master or the other take of a
tune does not.  Presence is measured per master half-beat, which also gives the edges of the stretch used.
"""
import os
import subprocess
import tempfile
from fractions import Fraction

import numpy as np
import soundfile as sf
from scipy import signal

SR = 22050
_SOS = signal.butter(4, [150 / (SR / 2), 4000 / (SR / 2)], "band", output="sos")


def band(x):
    return signal.sosfiltfilt(_SOS, x).astype(np.float32)


_FULL = {}


def full_rate(path):
    """a master at its own sample rate, mono (time-stretchers work on the file as it is)"""
    if path not in _FULL:
        x, sr = sf.read(path, dtype="float32", always_2d=True)
        _FULL[path] = (x.mean(axis=1), sr)
    return _FULL[path]


def render_portion(path, x22, a, e, v, semi, rev):
    """master [a, e) seconds played at speed v with the given pitch, at 22.05 kHz"""
    if abs(semi - 12 * np.log2(v)) < 0.05:
        return render(x22[int(a * SR):int(e * SR)], v, semi, rev)
    xf, sr = full_rate(path)
    y = stretch(xf[int(round(a * sr)):int(round(e * sr))], sr, v, semi)
    y = signal.resample_poly(y, SR, sr) if sr != SR else y
    return y[::-1].copy() if rev else y


def stretch(x, sr, v, semi):
    with tempfile.TemporaryDirectory() as td:
        a, b = os.path.join(td, "a.wav"), os.path.join(td, "b.wav")
        sf.write(a, np.stack([x, x], axis=1), sr, subtype="FLOAT")
        subprocess.run(["rubberband", "-q", "-t", f"{1 / v:.6f}", "-p", f"{semi:.4f}", a, b], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        y, _ = sf.read(b, dtype="float64", always_2d=True)
    return y.mean(axis=1)


def render(x, v, semi, rev):
    """x played at speed v: sampler-style if the pitch is what the speed implies, else time-stretched"""
    if abs(semi - 12 * np.log2(v)) < 0.05:
        fr = Fraction(1 / v).limit_denominator(4000)
        y = signal.resample_poly(x, fr.numerator, fr.denominator)
    else:
        with tempfile.TemporaryDirectory() as td:
            a, b = os.path.join(td, "a.wav"), os.path.join(td, "b.wav")
            sf.write(a, x, SR, subtype="FLOAT")
            subprocess.run(["rubberband", "-q", "-t", f"{1 / v:.6f}", "-p", f"{semi:.4f}", a, b], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            y, _ = sf.read(b, dtype="float64")
            if y.ndim > 1:
                y = y.mean(axis=1)
    return y[::-1].copy() if rev else y


class TrackWave:
    def __init__(self, x):
        self.x = band(x)
        self.n = len(self.x)
        self.nfft = 1 << int(np.ceil(np.log2(self.n + SR)))
        self.X = np.fft.rfft(self.x, self.nfft)
        self.cs = np.concatenate([[0.0], np.cumsum(self.x.astype(np.float64) ** 2)])

    def presence(self, s, lo=None, hi=None, top=24):
        """highest normalised correlation of snippet s anywhere in the track (or with start in [lo, hi) s)"""
        m = len(s)
        if m < 64:
            return 0.0, 0
        c = np.fft.irfft(self.X * np.conj(np.fft.rfft(s, self.nfft)), self.nfft)[: self.n - m]
        e = np.maximum(self.cs[m:self.n] - self.cs[: self.n - m], 0)
        floor = 1e-3 * np.median(e[e > 0]) if np.any(e > 0) else 1e-12
        approx = c / np.sqrt(np.maximum(e, floor))
        a = 0 if lo is None else max(0, int(lo * SR))
        b = len(c) if hi is None else min(len(c), int(hi * SR))
        if b <= a:
            return 0.0, 0
        seg = approx[a:b]
        cand = a + np.argpartition(-seg, min(top, len(seg) - 1))[:top]
        sn = np.linalg.norm(s) + 1e-12
        best, bi = -1.0, 0
        for i in cand:
            w = self.x[i:i + m].astype(np.float64)
            en = np.linalg.norm(w)
            if en <= 1e-9:
                continue
            r = float(w @ s) / (en * sn)
            if r > best:
                best, bi = r, int(i)
        return best, bi


def heard(tw, master_x, bpm_m, v, semi, rev, q_lo, q_hi, pad=4):
    """presence of every master half-beat in [q_lo - pad, q_hi + pad] (indices of the half-beat grid)"""
    hb = 30.0 / bpm_m
    a = max(0, q_lo - pad - 2)
    b = min(int(len(master_x) / SR / hb) - 1, q_hi + pad + 2)
    seg = master_x[int(a * hb * SR):int((b + 1) * hb * SR)]
    y = band(render(seg, v, semi, rev))
    out = {}
    for q in range(max(0, q_lo - pad), min(b, q_hi + pad) + 1):
        t0 = (q - a) * hb / v
        if rev:
            t0 = len(y) / SR - (q - a + 1) * hb / v
        i0, i1 = int(round(t0 * SR)), int(round((t0 + hb / v) * SR))
        if i0 < 0 or i1 > len(y) or i1 - i0 < 64:
            continue
        out[q] = tw.presence(y[i0:i1])[0]
    return out


_RENDERS = {}


def rendered(mid, master_x, bpm_m, v, semi, rev, q_lo, q_hi, pad=6):
    """cached Rendered for a master region (regions are widened to whole bars so nearby requests share one)"""
    a = max(0, (q_lo - pad) // 8 * 8)
    b = (q_hi + pad) // 8 * 8 + 7
    key = (mid, round(v, 5), round(semi, 3), rev, a, b)
    if key not in _RENDERS:
        if len(_RENDERS) > 200:
            _RENDERS.clear()
        _RENDERS[key] = Rendered(master_x, bpm_m, v, semi, rev, a, b, pad=0)
    return _RENDERS[key]


class Rendered:
    """one master region played one way, cut into master half-beats"""

    def __init__(self, master_x, bpm_m, v, semi, rev, q_lo, q_hi, pad=6):
        self.hb = 30.0 / bpm_m
        self.v, self.rev = v, rev
        self.a = max(0, q_lo - pad)
        self.b = min(int(len(master_x) / SR / self.hb) - 1, q_hi + pad)
        seg = master_x[int(self.a * self.hb * SR):int((self.b + 1) * self.hb * SR)]
        self.y = band(render(seg, v, semi, rev))

    def snippet(self, q, n=1):
        """master half-beats q .. q+n-1 as heard (backwards if reversed)"""
        if q < self.a or q + n - 1 > self.b:
            return None
        t0 = (q - self.a) * self.hb / self.v
        if self.rev:
            t0 = len(self.y) / SR - (q - self.a + n) * self.hb / self.v
        i0, i1 = int(round(t0 * SR)), int(round((t0 + n * self.hb / self.v) * SR))
        if i0 < 0 or i1 > len(self.y) or i1 - i0 < 64:
            return None
        return self.y[i0:i1]


def local(tw, s, t, lag=0.012):
    """normalised correlation of snippet s with the track near time t (seconds)"""
    if s is None:
        return 0.0
    m = len(s)
    a = int(round((t - lag) * SR))
    b = int(round((t + lag) * SR)) + m
    if a < 0 or b > tw.n or m < 64:
        return 0.0
    w = tw.x[a:b]
    c = signal.correlate(w, s, mode="valid", method="fft")
    cs = np.concatenate([[0.0], np.cumsum(w.astype(np.float64) ** 2)])
    e = np.sqrt(np.maximum(cs[m:] - cs[:-m], 1e-12))
    r = c / (e * (np.linalg.norm(s) + 1e-12))
    return float(r.max())
