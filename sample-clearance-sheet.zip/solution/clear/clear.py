"""Reference clearance: find every catalogue master used in each tape track.

    python3 clear.py CATALOGUE_DIR TAPE_DIR OUT.csv [TRACK ...]

Every master is compared with the track half-beat by half-beat on whitened log-frequency spectra.  A producer
can have played a master at the track's tempo (sampler-style, so the pitch follows the speed, or time-stretched
with its own pitch shift), or as one-shots tuned in semitones, forwards or backwards; each of those is a change
of time scale plus a shift along the log-frequency axis, so it is simulated on the master's spectrogram rather
than rendered.  Each track half-beat is then credited to the single best explanation, and a master's credited
half-beats give the stretch of the master that was used.
"""
import csv
import os
import subprocess
import sys

import numpy as np

import verify
from verify import SR as _VSR  # noqa: F401

SR = 22050
NFFT = 2048
HOP = 128
FPS = SR / HOP
BPO = 36
FMIN, FMAX = 110.0, 10000.0
NB = int(np.floor(BPO * np.log2(FMAX / FMIN)))
NF = 8                   # frames per half-beat window
NFX = 8                  # onset-flux bands
NFF = 24                 # flux frames per half-beat window
WHITEN = int(os.environ.get("WHITEN", "1"))
PEAK = 9                 # width (bins) of the local mean removed along frequency, 0 = off
THR = 0.72               # a window this similar to a master window is a candidate explanation


def load(path):
    out = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                         check=True, capture_output=True).stdout
    return np.frombuffer(out, dtype=np.float32).astype(np.float64)


_FB = None


def filterbank():
    global _FB
    if _FB is None:
        f = np.fft.rfftfreq(NFFT, 1 / SR)
        c = FMIN * 2 ** (np.arange(NB) / BPO)
        fb = np.zeros((NB, len(f)))
        for i, ci in enumerate(c):
            bw = max(ci * (2 ** (1 / BPO) - 1), 1.5 * SR / NFFT)
            fb[i] = np.clip(1 - np.abs(f - ci) / bw, 0, None)
        _FB = (fb / (fb.sum(axis=1, keepdims=True) + 1e-12)).T.astype(np.float32)
    return _FB


def spectrum(x):
    """whitened sqrt-magnitude on a 1/3-semitone axis plus its local-peak part (frames, 2*NB), banded onset flux
    from a short window (frames, NFX), and per-frame energy; all on the same HOP grid"""
    pad = np.concatenate([np.zeros(NFFT // 2), x, np.zeros(NFFT)])
    n = 1 + (len(pad) - NFFT) // HOP
    win = np.hanning(NFFT).astype(np.float32)
    short = np.zeros(NFFT, dtype=np.float32)
    short[NFFT // 2 - 256:NFFT // 2 + 256] = np.hanning(512)
    out = np.empty((n, NB), dtype=np.float32)
    sh = np.empty((n, NFX), dtype=np.float32)
    en = np.empty(n)
    idx = np.arange(NFFT)[None, :]
    bands = bandbank()
    for a in range(0, n, 1024):
        b = min(n, a + 1024)
        fr = pad[idx + HOP * np.arange(a, b)[:, None]].astype(np.float32)
        en[a:b] = ((fr * win) ** 2).mean(axis=1)
        out[a:b] = np.sqrt(np.abs(np.fft.rfft(fr * win, axis=1)) @ filterbank())
        sh[a:b] = np.log1p(100 * (np.abs(np.fft.rfft(fr * short, axis=1)) @ bands))
    if WHITEN:
        out = out - out.mean(axis=0)
    k = np.ones(PEAK, dtype=np.float32) / PEAK
    loc = np.apply_along_axis(lambda r: np.convolve(r, k, mode="same"), 1, out)
    d = np.diff(sh, axis=0, prepend=sh[:1])
    return np.concatenate([out, out - loc], axis=1), (np.clip(d, 0, None), np.clip(-d, 0, None)), en


_BB = None


def bandbank():
    global _BB
    if _BB is None:
        f = np.fft.rfftfreq(NFFT, 1 / SR)
        edges = np.geomspace(60, 10000, NFX + 1)
        _BB = np.stack([((f >= edges[i]) & (f < edges[i + 1])).astype(np.float32) for i in range(NFX)], axis=1)
    return _BB


def frames_at(S, times):
    """linear interpolation of spectrogram rows at arbitrary times (s); shape times.shape + (NB,)"""
    pos = np.clip(np.asarray(times) * FPS, 0, len(S) - 1.001)
    i = np.floor(pos).astype(int)
    w = (pos - i)[..., None].astype(np.float32)
    return S[i] * (1 - w) + S[i + 1] * w


def _unit(W):
    W = W.reshape(len(W), -1)
    W = W - W.mean(axis=1, keepdims=True)
    return (W / (np.linalg.norm(W, axis=1, keepdims=True) + np.float32(1e-9))).astype(np.float32)


def unit(W, F):
    """broadband, peak and onset parts normalised separately: the cosine is the mean of the three"""
    return np.concatenate([_unit(W[..., :NB]), _unit(W[..., NB:]), _unit(F)], axis=1) * np.float32(3 ** -0.5)


def shift_bins(W, k):
    """shift spectra up by k bins (fractional allowed) along the last axis"""
    if abs(k - round(k)) < 1e-6:
        k = int(round(k))
        out = np.zeros_like(W)
        if k > 0:
            out[..., k:] = W[..., :-k]
        elif k < 0:
            out[..., :k] = W[..., -k:]
        else:
            out[...] = W
        return out
    lo = int(np.floor(k))
    f = np.float32(k - lo)
    return (1 - f) * shift_bins(W, lo) + f * shift_bins(W, lo + 1)


# ---------------------------------------------------------------- tempo
def tempo(x, lo=70, hi=145):
    from scipy import signal
    _, _, Z = signal.stft(x, SR, nperseg=1024, noverlap=1024 - HOP, boundary="even", padded=True)
    S = np.log1p(200 * np.abs(Z)).T
    env = np.clip(np.diff(S, axis=0, prepend=S[:1]), 0, None).sum(axis=1)
    env = np.clip(env - signal.medfilt(env, 31), 0, None)
    t = np.arange(len(env)) / FPS

    def comb(bpm, d):
        ph = ((t - d) * bpm / 60) % 1
        w = np.exp(-(np.minimum(ph, 1 - ph) ** 2) / (2 * 0.02 ** 2))
        ph2 = ((t - d) * bpm / 30) % 1
        w2 = np.exp(-(np.minimum(ph2, 1 - ph2) ** 2) / (2 * 0.03 ** 2))
        return float((env * (w + 0.5 * w2)).sum())

    ac = signal.fftconvolve(env, env[::-1])[len(env) - 1:]
    grid = np.arange(lo, hi, 0.25)
    sc = [sum(np.interp(60 * FPS / b * m, np.arange(len(ac)), ac) for m in (1, 2, 4, 8)) for b in grid]
    best = None
    for c0 in grid[np.argsort(sc)[-3:]]:
        for d in np.arange(-0.06, 0.06, 0.005):
            for bpm in np.arange(c0 - 0.5, c0 + 0.5, 0.01):
                s = comb(bpm, d)
                if best is None or s > best[0]:
                    best = (s, bpm, d)
    _, c0, d0 = best
    for d in np.arange(d0 - 0.005, d0 + 0.0051, 0.001):
        for bpm in np.arange(c0 - 0.02, c0 + 0.0201, 0.002):
            s = comb(bpm, d)
            if s > best[0]:
                best = (s, bpm, d)
    return float(best[1])


# ---------------------------------------------------------------- catalogue / track
class Master:
    def __init__(self, cid, bpm, path, notes=""):
        self.id, self.bpm, self.notes = cid, bpm, notes
        x = load(path)
        self.x = x.astype(np.float32)
        self.path = path
        self.sec = len(x) / SR
        self.S, (self.F, self.Fneg), en = spectrum(x)
        self.hb = 30.0 / bpm
        self.q = np.arange(0, self.sec - 2 * self.hb, self.hb)
        qe = np.array([en[int(a * FPS):int((a + self.hb) * FPS)].mean() for a in self.q])
        self.loud = qe > 0.02 * np.median(qe)

    def windows(self, span, halves, rev):
        """windows starting at each master half beat covering `span` master seconds"""
        out = []
        # heard backwards, a master's decays are the rises the track shows: use its falling-energy flux
        for S, nf in ((self.S, NF * halves), (self.Fneg if rev else self.F, NFF * halves)):
            step = span / nf
            j = np.arange(nf)
            if rev:   # heard backwards: the window's first frame is the end of [q, q + span]
                t = self.q[:, None] + (nf - j[None, :]) * step - step / 2
            else:
                t = self.q[:, None] + j[None, :] * step + step / 2
            out.append(frames_at(S, t))
        return out


class Track:
    def __init__(self, path):
        x = load(path)
        self.wave = verify.TrackWave(x)
        self.bpm = tempo(x)
        self.hb = 30.0 / self.bpm
        self.S, (self.F, _), en = spectrum(x)
        sec = len(x) / SR
        self.p = np.arange(0, sec - 3 * self.hb, self.hb)
        pe = np.array([en[int(a * FPS):int((a + self.hb) * FPS)].mean() for a in self.p])
        self.loud = pe > 0.01 * np.median(pe)
        self._cache = {}

    def windows(self, span, halves, k):
        """unit windows at every track half beat covering `span` track seconds, spectra shifted down k bins"""
        key = (round(span, 5), halves, round(k, 4))
        if key not in self._cache:
            parts = []
            for S, nf in ((self.S, NF * halves), (self.F, NFF * halves)):
                step = span / nf
                parts.append(frames_at(S, self.p[:, None] + np.arange(nf)[None, :] * step + step / 2))
            W = parts[0]
            W = np.concatenate([shift_bins(W[..., :NB], -k), shift_bins(W[..., NB:], -k)], axis=-1)
            self._cache[key] = unit(W, parts[1])
            if len(self._cache) > 400:
                self._cache.pop(next(iter(self._cache)))
        return self._cache[key]


def read_catalogue(d):
    out = []
    for r in csv.DictReader(open(os.path.join(d, "catalogue.csv"))):
        if r["bpm"]:      # reissue compilations carry no bpm; their audio is found in the original masters
            out.append((r["id"], float(r["bpm"]), os.path.join(d, r["id"] + ".wav"), r["notes"]))
    return out


# ---------------------------------------------------------------- search
def candidates(track, m):
    """(speed, semitones, reversed, label)"""
    out = []
    base = track.bpm / m.bpm
    for k in (-1, 0, 1):
        v = base * 2 ** k
        if not 0.66 <= v <= 1.5:
            continue
        for rev in (False, True):
            out.append((v, 12 * np.log2(v), rev, "tempo"))
            for s in range(-7, 8):
                if abs(s - 12 * np.log2(v)) > 0.3:
                    out.append((v, float(s), rev, "tempo"))
    for s in range(-7, 8):
        v = 2 ** (s / 12)
        if all(abs(v - o[0]) > 0.025 * v for o in out):   # near a tempo speed, the tempo reading explains it
            out.append((v, float(s), False, "oneshot"))
    return out


def combine(T, Q, halves):
    """similarity of unit windows: the mean of the broadband, peak and onset cosines, or, where pitch carries
    nothing (drums), of broadband and onsets alone - whichever is higher"""
    d1 = NF * halves * NB
    b = (T[:, :d1] @ Q[:d1]) * 3
    p = (T[:, d1:2 * d1] @ Q[d1:2 * d1]) * 3
    f = (T[:, 2 * d1:] @ Q[2 * d1:]) * 3
    return np.maximum((b + p + f) / 3, (b + f) / 2)


def score(track, m, v, semi, rev, lab, halves, cache):
    """cosine of every track window with every master window under one way of playing the master.
    tempo uses: windows of `halves` track half-beats; one-shots: half a track beat"""
    if lab != "tempo":
        halves = 1
    key = (round(v, 6), rev, halves)
    if key not in cache:
        W, F = m.windows(v * track.hb * halves, halves, rev)
        cache[key] = unit(W, F).T.copy()
    C = combine(track.windows(track.hb * halves, halves, semi * BPO / 12), cache[key], halves)
    C[:, ~m.loud] = np.nan
    C[~track.loud] = np.nan
    return C


def scan(track, masters):
    """per candidate: for each track half-beat the best master half-beat and its similarity"""
    res = []
    idx = np.arange(len(track.p))
    for m in masters:
        groups = {}
        for v, semi, rev, lab in candidates(track, m):
            halves = 2 if lab == "tempo" else 1
            groups.setdefault((round(v, 6), rev, halves), []).append((v, semi, rev, lab))
        for (vk, rev, halves), cands in groups.items():
            v = cands[0][0]
            W, F = m.windows(v * track.hb * halves, halves, rev)
            Q = unit(W, F).T.copy()
            T = np.concatenate([track.windows(track.hb * halves, halves, s * BPO / 12) for _, s, _, _ in cands])
            C = combine(T, Q, halves).reshape(len(cands), len(track.p), -1)
            C[:, :, ~m.loud] = -1
            C[:, ~track.loud, :] = -1
            top = np.argpartition(-C, 3, axis=2)[..., :3]
            tv = np.take_along_axis(C, top, axis=2)
            o = np.argsort(-tv, axis=2)
            top = np.take_along_axis(top, o, axis=2)
            arg = top[..., 0]
            raw = np.take_along_axis(C, arg[..., None], axis=2)[..., 0]
            for i, (v, semi, rev, lab) in enumerate(cands):
                res.append(dict(m=m, v=v, semi=semi, rev=rev, lab=lab, halves=halves, arg=arg[i], raw=raw[i],
                                top=top[i], adv=(v * track.hb / m.hb) * (-1 if rev else 1)))
    return res


def runs(r, ok):
    """maximal runs of consecutive track windows whose master windows advance as the playing speed says"""
    out, cur = [], []
    for p in range(len(ok)):
        if ok[p] and cur and abs((r["arg"][p] - r["arg"][cur[-1]]) - r["adv"]) <= 0.6:
            cur.append(p)
            continue
        if cur:
            out.append(cur)
        cur = [p] if ok[p] else []
    if cur:
        out.append(cur)
    return out


def structured(r, alive):
    """windows of one candidate that sit in a structure: a run along the master (long runs may be faint), or
    one master window heard again and again"""
    raw, arg = r["raw"], r["arg"]
    keep = np.zeros(len(raw), bool)
    for run in runs(r, alive & (raw >= RAW_LO)):
        sc = raw[run]
        if (len(run) >= 4 and sc.mean() >= RAW_RUN) or (len(run) >= 2 and sc.min() >= RAW):
            keep[run] = True
    # pieces chopped from one stretch: several strong windows pointing into the same few bars of the master
    cl = np.nonzero(alive & (raw >= RAW_CL))[0]
    if len(cl) >= CL_N:
        q = arg[cl]
        for i in range(len(cl)):
            near = cl[np.abs(q - q[i]) <= CL_SPAN]
            if len(near) >= CL_N and len(np.unique(arg[near])) >= CL_N:
                keep[near] = True
    strong = np.nonzero(alive & (raw >= RAW_REP))[0]
    if len(strong):
        qs, counts = np.unique(arg[strong], return_counts=True)
        for q in qs[counts >= 3]:
            hits = strong[arg[strong] == q]
            if hits.max() - hits.min() >= 2:
                keep[hits] = True
    return keep


def twin_map(masters):
    """alternate takes and re-recordings of the same tune, from the catalogue notes"""
    tw = {}
    for m in masters:
        note = m.notes
        if note.startswith(("vault alternate take of", "re-recording of")):
            o = note.split()[-1]
            tw.setdefault(m.id, set()).add(o)
            tw.setdefault(o, set()).add(m.id)
    for k in list(tw):
        for o in list(tw[k]):
            tw[k] |= tw.get(o, set()) - {k}
    return tw


def clear_track(track, masters):
    res = scan(track, masters)
    twins = twin_map(masters)
    alive = np.ones(len(track.p), bool)
    tried = set()
    rows = []
    misses = 0
    taken = np.zeros(len(track.p), bool)
    while True:
        best = None
        for i, r in enumerate(res):
            if i in tried:
                continue
            k = structured(r, alive)
            e = float(r["raw"][k].sum())
            # backwards audio matches spectra less well; the waveform check below keeps the bar high anyway
            e_eff = e * (EMIN / EMIN_REV) if r["rev"] else e
            if best is None or e_eff > best[0]:
                best = (e_eff, k, i)
        if best is None or best[0] < EMIN:
            break
        e, k, i = best
        tried.add(i)
        # the same tune may be in the catalogue more than once: hear which take it really is
        options = [i] + [j for j, o in enumerate(res) if o["m"].id in twins.get(res[i]["m"].id, ())
                         and o["rev"] == res[i]["rev"] and o["lab"] == res[i]["lab"]
                         and abs(o["semi"] - res[i]["semi"]) < 0.3 and abs(abs(o["adv"]) - abs(res[i]["adv"])) < 0.05]
        made = [(rows_for(track, res[j], k), j) for j in options]
        scored = sorted(((rw[0]["support"] if rw else 0.0, j, rw) for rw, j in made), key=lambda z: -z[0])
        sc, j, found = scored[0]
        need = VERIFY_ONESHOT if res[j]["lab"] == "oneshot" else (VERIFY_FEW if k.sum() <= 8 else VERIFY)
        misses = misses + 1 if sc < need else 0
        if misses > 30:
            break
        if sc < 0.3:
            # the master is not there at this speed at all: its other pitch readings are not tried
            for o in options:
                g = (res[o]["m"].id, round(res[o]["v"], 3), res[o]["rev"], res[o]["lab"])
                tried.update(x for x, rr in enumerate(res) if (rr["m"].id, round(rr["v"], 3), rr["rev"], rr["lab"]) == g)
        if DEBUG:
            print("   cand", res[j]["m"].id, round(res[j]["v"], 4), res[j]["semi"], res[j]["rev"], res[j]["lab"],
                  "E %.1f n %d confirm %.2f" % (e, k.sum(), sc), flush=True)
        if sc < need:
            continue
        if res[j]["lab"] == "oneshot" and taken.any():
            hits = np.nonzero(k)[0]
            if np.mean(taken[hits]) >= 0.75:      # heard only inside another use of the track: part of that audio
                continue
        rows += found
        alive &= ~k
        taken |= k
        tried.update(o for _, o, _ in scored)
    return merge(rows)


def pairs(track, r, k):
    """(track time, master half-beat) of every claimed window; one-shots and tempo uses alike"""
    ps = np.nonzero(k)[0]
    return [(track.p[p], int(r["arg"][p])) for p in ps]


def rendered(track, r, k):
    q = r["arg"][k]
    return verify.rendered(r["m"].id, r["m"].x, r["m"].bpm, r["v"], r["semi"], r["rev"], int(q.min()), int(q.max()) + 2)


def confirm(track, r, k):
    """median local waveform correlation of the claimed windows, played the candidate's way"""
    R = rendered(track, r, k)
    sc = [verify.local(track.wave, R.snippet(q, 2), t) for t, q in pairs(track, r, k)]
    return float(np.median(sc)) if sc else 0.0


def rows_for(track, r, k):
    """the row for one confirmed candidate.  Stretches are whole bars of the master (one-shots: a few half-beats
    from a half-beat), so the few portions near the evidence are played exactly the way the producer would have
    played them, and the portion whose audio lines up best with the claimed windows is the one used."""
    m = r["m"]
    ps = np.nonzero(k)[0]
    if len(ps) > 16:                       # a sample of the claimed windows is plenty to place the stretch
        ps = ps[np.linspace(0, len(ps) - 1, 16).round().astype(int)]
    pr = [(track.p[p], [int(q) for q in r["top"][p][:2]]) for p in ps]
    step = m.hb / r["v"]
    if r["lab"] == "oneshot":
        q0 = int(np.bincount(r["arg"][ps]).argmax())
        hits = [t for p, t in zip(ps, track.p[ps]) if q0 in r["top"][p]]
        sc = {}
        for n in range(1, 5):
            y = verify.band(verify.render_portion(m.path, m.x, m.q[q0], m.q[q0] + n * m.hb, r["v"], r["semi"], False))
            sc[n] = float(np.median([verify.local(track.wave, y, t) for t in hits]))
        best = max(sc.values())
        n = max(nn for nn, s in sc.items() if s >= best - 0.05)
        return [dict(master=m.id, frm=float(m.q[q0]), to=float(m.q[q0] + n * m.hb), speed=r["v"], semi=r["semi"],
                     rev=False, n=len(hits), support=best, lab=r["lab"])]
    bar = 8 * m.hb
    kk = np.nonzero(k)[0]
    centre = float(np.median(m.q[r["arg"][kk]]))
    # every beat-aligned track window across the stretch of track where this use was heard, not only the ones the
    # spectral pass claimed: pieces from the far bar of a chopped stretch must get their say
    lo_p = max(0, kk.min() - (kk.min() % 2) - 8)
    span_p = np.arange(lo_p, min(len(track.p), kk.max() + 9), 2)
    if len(span_p) > 48:
        span_p = span_p[np.linspace(0, len(span_p) - 1, 48).round().astype(int)]
    times = [track.p[p] for p in span_p if track.loud[p]]
    claimed = {round(t, 4) for t, _ in pr}
    times = sorted(set(times) | {t for t, _ in pr})
    best = None
    for b0 in range(max(0, int(centre / bar) - 2), int(centre / bar) + 3):
        for nb in (1, 2):
            a, e = b0 * bar, (b0 + nb) * bar
            if e > m.sec:
                continue
            y = verify.band(verify.render_portion(m.path, m.x, a, e, r["v"], r["semi"], r["rev"]))
            L = len(y) / SR
            xs = [x for x in range(len(m.q)) if a - 1e-6 <= m.q[x] <= e - 2 * m.hb + 1e-6]
            snips = {}
            for x in xs:
                off = m.q[x] - a
                t0 = (L - (off + 2 * m.hb) / r["v"]) if r["rev"] else off / r["v"]
                i0, i1 = int(round(t0 * SR)), int(round((t0 + 2 * step) * SR))
                if 0 <= i0 and i1 <= len(y):
                    snips[x] = y[i0:i1]
            if not snips:
                continue
            got, hit = [], set()
            for t in times:
                sc = {x: verify.local(track.wave, s, t) for x, s in snips.items()}
                x = max(sc, key=sc.get)
                got.append(sc[x])
                if sc[x] >= 0.5:
                    hit |= {x, x + 1}
            n_half = int(round((e - a) / m.hb))
            unused = n_half - len([h for h in hit if a - 1e-6 <= m.q[min(h, len(m.q) - 1)] < e - 1e-6])
            score = sum(max(0.0, g - 0.5) for g in got) - 0.1 * unused
            mine = [g for g, t in zip(got, times) if round(t, 4) in claimed]
            if best is None or score > best[0] + 1e-6:
                best = (score, a, e, float(np.median(mine)) if mine else 0.0)
    if best is None:
        return []
    _, a, e, support = best
    return [dict(master=m.id, frm=float(a), to=float(e), speed=r["v"], semi=r["semi"], rev=r["rev"], n=len(pr),
                 support=support, lab=r["lab"])]


def split_far(qs, gap=None):
    """groups of master half-beats more than 4 s apart are separate stretches"""
    order = np.sort(np.unique(qs))
    out, cur = [], [order[0]]
    for q in order[1:]:
        if q - cur[-1] > 16:
            out.append(np.array(cur))
            cur = [q]
        else:
            cur.append(q)
    out.append(np.array(cur))
    return out


def match_at(track, m, t, q, span_m, v, semi, rev):
    """cosine of the track from time t with master [q, q+span_m] played at speed v (and pitch/direction)"""
    nf, nff = NF, NFF
    st, sf = span_m / v / nf, span_m / v / nff
    tw = frames_at(track.S, t + np.arange(nf) * st + st / 2)[None]
    tw = np.concatenate([shift_bins(tw[..., :NB], -semi * BPO / 12), shift_bins(tw[..., NB:], -semi * BPO / 12)], -1)
    tf = frames_at(track.F, t + np.arange(nff) * sf + sf / 2)[None]
    jm, jf = np.arange(nf), np.arange(nff)
    if rev:
        mt, mf = q + span_m - (jm + 0.5) * span_m / nf, q + span_m - (jf + 0.5) * span_m / nff
        mF = m.Fneg
    else:
        mt, mf = q + (jm + 0.5) * span_m / nf, q + (jf + 0.5) * span_m / nff
        mF = m.F
    a = unit(tw, tf)
    b = unit(frames_at(m.S, mt)[None], frames_at(mF, mf)[None])
    return float((a * b).sum())


def blocks_of(qs, sc, gap=1):
    """contiguous runs of master half-beats (gaps of `gap` allowed) with their support"""
    order = np.argsort(qs)
    out, cur = [], [order[0]]
    for i in order[1:]:
        if qs[i] - qs[cur[-1]] <= gap + 1:
            cur.append(i)
        else:
            out.append(cur)
            cur = [i]
    out.append(cur)
    return sorted(out, key=lambda b: -sc[b].sum())


def same_passage(m, a0, b0, n):
    """master half-beats a0.. and b0.. (n long) are a note-for-note repeat of each other"""
    if a0 + n > len(m.q) or b0 + n > len(m.q):
        return False
    W, F = m.windows(m.hb * n, n, False)
    U = unit(W, F)
    return float(U[a0] @ U[b0]) >= 0.85


def make_rows(track, r, win):
    """one row per stretch of the master the claimed windows point at; repeats of one passage are one row"""
    m = r["m"]
    ps = np.nonzero(win)[0]
    qs, sc = r["arg"][ps], r["raw"][ps]
    bl = blocks_of(qs, sc)
    main = bl[0]
    rows = [make_row(track, r, ps[main])]
    n = int(qs[main].max() - qs[main].min()) + 1
    for b in bl[1:]:
        if sc[b].sum() < 0.4 * sc[main].sum() or len(b) < 3:
            continue
        if same_passage(m, int(qs[main].min()), int(qs[b].min()), n):
            continue
        rows.append(make_row(track, r, ps[b]))
    return rows


def make_row(track, r, ps):
    m = r["m"]
    win = np.zeros(len(r["raw"]), bool)
    win[ps] = True
    q = r["arg"][win]
    lo, hi = int(q.min()), int(q.max())
    v, semi, rev = r["v"], r["semi"], r["rev"]
    if r["lab"] == "oneshot":
        # a one-shot: find where the producer cut it, half a master beat at a time
        hits = np.nonzero(win)[0]
        L = 1
        while L < 6:
            sc = np.mean([match_at(track, m, track.p[p] + L * m.hb / v, m.q[lo] + L * m.hb, m.hb, v, semi, rev)
                          for p in hits])
            if sc < CUT:
                break
            L += 1
        frm, to = m.q[lo], m.q[lo] + L * m.hb
    else:
        frm, to = used_span(track, r, win)
    return dict(master=m.id, frm=float(frm), to=float(to), speed=v, semi=semi, rev=rev,
                n=int(win.sum()), support=float(r["raw"][win].sum()), lab=r["lab"])


def used_span(track, r, win):
    """master half-beats actually heard: score the claimed track half-beats against single master half-beats"""
    m = r["m"]
    C = np.nan_to_num(score(track, m, r["v"], r["semi"], r["rev"], "tempo", 1, {}), nan=-1)
    ps = np.nonzero(win)[0]
    P = np.unique(np.concatenate([ps, ps + 1]))
    P = P[P < len(C)]
    used = np.zeros(C.shape[1], bool)
    for p in P:
        q = int(C[p].argmax())
        if C[p, q] >= USED:
            used[q] = True
    centre = int(np.median(r["arg"][ps]))
    # the stretch is the run of heard half-beats around the bulk of the evidence
    js = np.nonzero(used)[0]
    if len(js) == 0:
        return m.q[centre], m.q[centre] + 2 * m.hb
    j0 = js[np.argmin(np.abs(js - centre))]
    lo = hi = j0
    while lo - 1 >= 0 and (used[lo - 1] or (lo - 2 >= 0 and used[lo - 2])):
        lo -= 1 if used[lo - 1] else 2
    while hi + 1 < len(used) and (used[hi + 1] or (hi + 2 < len(used) and used[hi + 2])):
        hi += 1 if used[hi + 1] else 2
    return m.q[lo], m.q[hi] + m.hb


def merge(rows):
    """same master played the same way from places less than 4 s apart is one row"""
    rows.sort(key=lambda r: (r["master"], round(r["speed"], 4), round(r["semi"], 2), r["rev"], r["frm"]))
    out = []
    for r in rows:
        if out:
            o = out[-1]
            if (o["master"], round(o["speed"], 4), round(o["semi"], 2), o["rev"]) == \
               (r["master"], round(r["speed"], 4), round(r["semi"], 2), r["rev"]) and r["frm"] - o["to"] <= 4.0:
                o["frm"] = min(o["frm"], r["frm"])
                o["to"] = max(o["to"], r["to"])
                o["n"] += r["n"]
                o["support"] += r["support"]
                continue
        out.append(dict(r))
    return out


RAW = 0.55       # a short run or a repeated window must be at least this similar
RAW_LO = 0.40    # weakest window that can still be part of a long run
RAW_RUN = 0.45   # mean similarity of a run of four or more
RAW_REP = 0.70   # a master window heard more than once
EMIN = 2.2       # least evidence for a row
EMIN_REV = 1.4   # ... for audio played backwards
RAW_CL = 0.65    # a chopped piece
CL_N = 4         # pieces (from different master half-beats) that make a chopped stretch
CL_SPAN = 16     # ... all within this many master half-beats
CUT = 0.40       # a half-beat below this similarity is past the end of what was used
USED = 0.55      # a master half-beat heard in the track at least this clearly is part of the stretch
VERIFY = 0.45    # median local waveform correlation that confirms a use
VERIFY_ONESHOT = 0.85   # a one-shot is a short exact copy: it has to correlate almost perfectly
VERIFY_FEW = 0.70       # so does a use heard in only a few windows (a reversed bar, a short chopped stretch)
DEBUG = bool(os.environ.get("CLEAR_DEBUG"))
EDGE = 0.30      # a master half-beat this well correlated where it should be heard belongs to the stretch


_MASTERS = None
_TAPE = None


def _one(name):
    tr = Track(os.path.join(_TAPE, name + ".opus"))
    rows = clear_track(tr, _MASTERS)
    print(name, round(tr.bpm, 3), [(r["master"], round(r["frm"], 2), round(r["to"], 2), round(r["speed"], 4),
                                    round(r["semi"], 2), r["rev"], r["n"]) for r in rows], flush=True)
    return name, rows


def main():
    global _MASTERS, _TAPE
    cat_dir, tape_dir, out = sys.argv[1], sys.argv[2], sys.argv[3]
    only = sys.argv[4:]
    _MASTERS = [Master(*row) for row in read_catalogue(cat_dir)]
    _TAPE = tape_dir
    names = sorted(f[:-5] for f in os.listdir(tape_dir) if f.endswith(".opus"))
    if only:
        names = [n for n in names if n in only]
    workers = int(os.environ.get("CLEAR_WORKERS", min(4, os.cpu_count() or 1)))
    if workers > 1:
        import multiprocessing as mp
        with mp.get_context("fork").Pool(workers) as pool:
            done = dict(pool.map(_one, names, chunksize=1))
    else:
        done = dict(_one(n) for n in names)
    with open(out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["track", "master", "from", "to", "speed", "semitones", "reversed"])
        for name in names:
            for r in done[name]:
                w.writerow([name, r["master"], f"{r['frm']:.2f}", f"{r['to']:.2f}", f"{r['speed']:.4f}",
                            f"{r['semi']:.2f}", "yes" if r["rev"] else "no"])


if __name__ == "__main__":
    main()
