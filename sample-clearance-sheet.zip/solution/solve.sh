#!/bin/bash
# Reference clearance: match every master against each tape track and write the sheet.
set -e
apt-get update -qq && apt-get install -y -qq --no-install-recommends rubberband-cli >/dev/null
rm -rf /var/lib/apt/lists/*
pip install --no-cache-dir -q numpy==2.3.3 scipy==1.16.2 soundfile==0.13.1
# one track per process; keep each process's maths single-threaded
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 /solution/clear/clear.py /srv/catalogue /srv/tape /app/sheet.csv
