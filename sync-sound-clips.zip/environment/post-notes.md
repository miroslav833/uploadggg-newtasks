# Post-production notes, reel 3 music conform

Reel 3 of the concert film is the festival weekend. Its music session runs at 48 kHz on a 23.976
timeline whose timecode starts at 01:00:00:00 at sample 0. `cut-list.csv` is the picture
department's cut list for the reel as the editorial system exported it: one event per music
clip (a stretch of a song's performance the cut uses), with the multitrack roll it was cut from,
the source in and out timecodes on that roll and the record in and out timecodes on the
timeline. `sound-report.csv` is the music recording crew's roll list: for each multitrack roll,
the day it was recorded, the unit, the recorder, the timecode frame rate the recorder was set
to, the sample rate the files are stamped with, the number of tracks, the roll's start and end
timecode as the recordist logged them from the recorder's display when the roll was started and
stopped, the size of the file's audio data in bytes from the transfer house's listing (every
file is a 24-bit polyphonic WAV), and the song it covers.

The first unit filmed the main-stage sets on 35 mm at 24 fps from 4 to 8 September; the negative
was scanned and transferred to 23.976 for the cut. The second unit filmed the side-stage sets
digitally at 23.976 from 9 to 13 September. A pickup crew filmed rehearsals and the encore on
video at 29.97 on 15, 16 and 17 September with the crew's second recorder, whose firmware was
updated on the evening of 15 September. The club set's backing track was captured from the
band's playback rig at 44.1 kHz on 11 September. The headline sets on 5 and 16 September ran past
midnight. Every recorder was jammed to time of day each morning.

The sound files are delivered as the recorders stamped them, untouched. Timecodes in both lists
are copied as the systems display them: the recorders' displays on the roll list, the editorial
system's on the cut list, which shows every timecode with colons. In-points and out-points are on
frame boundaries.
