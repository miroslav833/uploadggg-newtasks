# Post-production notes, reel 3 dialogue conform

The dialogue session for reel 3 runs at 48 kHz on a 23.976 timeline whose timecode starts at
01:00:00:00 at sample 0. `cut-list.csv` is the picture department's cut list for the reel as the
editorial system exported it: one event per dialogue clip, with the sound roll it was cut from,
the source in and out timecodes on that roll and the record in and out timecodes on the
timeline. `sound-report.csv` is the location mixer's roll list: for each sound roll, the shoot
day, the unit, the recorder, the timecode frame rate the recorder was set to, the sample rate the
files are stamped with, the number of tracks, the roll's start and end timecode as the mixer
logged them from the recorder's display when the roll was started and stopped, the size of the
file's audio data in bytes from the transfer house's listing (every file is a 24-bit polyphonic
WAV), and the scene it covers.

The first unit shot 35 mm film at 24 fps from 4 to 8 September; the negative was scanned and
transferred to 23.976 for the cut. The second unit shot digital at 23.976 from 9 to 13 September.
A pickup crew shot video at 29.97 on 15, 16 and 17 September with the mixer's second recorder,
whose firmware was updated on the evening of 15 September.
The party scene's playback was captured on a music recorder at 44.1 kHz on 11 September. The
night shoots on 5 and 16 September ran past midnight. Every recorder was jammed to time of day
each morning.

The sound files are delivered as the recorders stamped them, untouched. Timecodes in both lists
are copied as the systems display them: the recorders' displays on the roll list, the editorial
system's on the cut list, which shows every timecode with colons. In-points and out-points are on
frame boundaries.
