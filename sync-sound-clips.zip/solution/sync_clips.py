#!/usr/bin/env python3
"""Reference: where each cut-list clip lies in its sound roll, and where it sits in the session.

Usage: sync_clips.py /app  -> /app/out/clips.csv
"""
import csv
import os
import sys
from fractions import Fraction

SESSION_FPS = Fraction(24000, 1001)
SESSION_RATE = 48000
SESSION_START = "01:00:00:00"
FPS = {"24": Fraction(24), "23.976": Fraction(24000, 1001), "29.97": Fraction(30000, 1001)}


def parse(tc):
    """-> (frame count since midnight on the roll's own counting, base frames per second, drop)"""
    drop = ";" in tc
    h, m, s, f = [int(x) for x in tc.replace(";", ":").split(":")]
    base = 30 if (drop or f >= 24) else None
    return (h, m, s, f), drop


def count(tc, base, drop):
    """Frames since midnight as the roll's counter counts them: a drop-frame counter has no
    frames 0 and 1 at the start of any minute except the tenth, so those labels are not frames.
    Whether the counter drops is the roll's property, read from the recorder's own display."""
    (h, m, s, f), _ = parse(tc)
    n = ((h * 60 + m) * 60 + s) * base + f
    if drop:
        mins = h * 60 + m
        n -= 2 * (mins - mins // 10)
    return n


def day(base, drop):
    return 86400 * base - (2 * (1440 - 144) if drop else 0)


RATES = (44100, 48000, 48048)


def recorder_rate(roll):
    """The rate the recorder ran at and the samples the file holds before the logged start.
    The file's samples (24-bit polyphonic) over the logged span fit one recorder rate with a
    lead-in of whole seconds: a pre-record buffer, or none."""
    fps = FPS[roll["tc_fps"]]
    base = 30 if roll["tc_fps"] == "29.97" else 24
    drop = ";" in roll["start_tc"]
    span = count(roll["end_tc"], base, drop) - count(roll["start_tc"], base, drop)
    if span < 0:
        span += day(base, drop)
    seconds = Fraction(span) / fps
    samples = int(roll["audio_bytes"]) // (3 * int(roll["tracks"]))
    best = None
    for rate in RATES:
        lead = samples / rate - seconds          # seconds of audio before the logged start
        err = abs(lead - round(lead))
        if lead > -0.01 and (best is None or err < best[0]):
            best = (err, rate, int(round(lead)) * rate)
    return best[1], best[2]


def main(root):
    with open(os.path.join(root, "sound-report.csv"), newline="", encoding="utf-8") as f:
        rolls = {r["roll"]: r for r in csv.DictReader(f)}
    with open(os.path.join(root, "cut-list.csv"), newline="", encoding="utf-8") as f:
        events = list(csv.DictReader(f))
    fit = {rid: recorder_rate(r) for rid, r in rolls.items()}
    session_spf = Fraction(SESSION_RATE) / SESSION_FPS
    rows = []
    for e in events:
        r = rolls[e["roll"]]
        fps = FPS[r["tc_fps"]]
        base = 30 if r["tc_fps"] == "29.97" else 24
        drop = ";" in r["start_tc"]
        rate, lead = fit[e["roll"]]
        spf = Fraction(rate) / fps
        off = count(e["source_in"], base, drop) - count(r["start_tc"], base, drop)
        if off < 0 and -off * spf > lead:      # earlier than the logged start and not within the lead-in
            off += day(base, drop)
        length = count(e["source_out"], base, drop) - count(e["source_in"], base, drop)
        sess = (count(e["record_in"], 24, False) - count(SESSION_START, 24, False)) * session_spf
        rows.append((e["event"], int(round(off * spf)) + lead, int(round(length * spf)), int(round(sess))))
    rows.sort()
    os.makedirs(os.path.join(root, "out"), exist_ok=True)
    with open(os.path.join(root, "out", "clips.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["clip", "source_sample", "length_samples", "session_sample"])
        w.writerows(rows)
    print("wrote %d rows" % len(rows))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/app")
