#!/bin/bash
python3 "$(dirname "$0")/sync_clips.py" /app
