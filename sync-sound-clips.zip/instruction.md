For each of the 60 music clips in the reel 3 cut list of a concert film, file where the clip's audio lies in its multitrack roll and where it is placed in the music session, so that the music editor can cut each performance from its roll and lay it in sync against the picture.

Inputs:

- `/app/cut-list.csv`: one event per clip: `event`, `roll`, `source_in`, `source_out`, `record_in`, `record_out`, `track`. Source timecodes are on the roll's own timecode; record timecodes are on the session timeline.
- `/app/sound-report.csv`: one row per sound roll: `roll`, `shoot_day`, `unit`, `recorder`, `tc_fps` (the timecode frame rate the recorder was set to), `sample_rate` (the rate the file is stamped with), `tracks`, `start_tc` and `end_tc` (as the recordist logged them), `audio_bytes` (the size of the file's 24-bit polyphonic audio data), `song`.
- `/app/post-notes.md`: how the reel was filmed and recorded and how the files and lists were delivered.

The music session runs at 48 kHz on a 23.976 timeline whose timecode starts at 01:00:00:00 at sample 0.

Write `/app/out/clips.csv` with a header row and one row per event, keyed by the event code:

```
clip,source_sample,length_samples,session_sample
q7xz,2977975,1681680,6472466
```

`source_sample` is the index, in the roll's file, of the sample that sounds at the clip's source in-point. `length_samples` is the number of samples of that file from the source in-point to the source out-point. `session_sample` is the session sample at which the clip begins, from its record in-point. All three are integers.

A row is right when each of its three numbers is within 100 samples of the key. At least 54 of the 60 rows must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
