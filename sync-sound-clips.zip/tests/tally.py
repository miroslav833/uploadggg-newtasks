"""Reads the sealed key and a filing as text and tallies the rows. Nothing in a filing is executed."""
import csv
import math

SLACK = 100
COLUMNS = ("source_sample", "length_samples", "session_sample")


def read_key(path):
    with open(path, newline="", encoding="utf-8") as f:
        return {r["clip"]: tuple(int(r[c]) for c in COLUMNS) for r in csv.DictReader(f)}


def read_filing(path):
    """-> {clip: (numbers) or None if unreadable}, count of duplicated ids"""
    rows, dup = {}, 0
    try:
        with open(path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                cid = (r.get("clip") or "").strip()
                if not cid:
                    continue
                if cid in rows:
                    dup += 1
                    rows[cid] = None
                    continue
                try:
                    vals = tuple(float(r[c]) for c in COLUMNS)
                    rows[cid] = vals if all(math.isfinite(v) for v in vals) else None
                except (KeyError, TypeError, ValueError):
                    rows[cid] = None
    except OSError:
        pass
    return rows, dup


def tally(key, filing_path):
    rows, dup = read_filing(filing_path)
    right = wrong = missing = 0
    for cid, truth in key.items():
        got = rows.get(cid)
        if got is None:
            missing += 1 if cid not in rows else 0
            wrong += 1 if cid in rows else 0
            continue
        if all(math.isfinite(g) and abs(g - t) <= SLACK for g, t in zip(got, truth)):
            right += 1
        else:
            wrong += 1
    return dict(right=right, wrong=wrong, missing=missing, duplicated=dup)
