"""Test 1: the sealed key is what the verifier's own timecode model rebuilds from the sealed world.
Test 2: the filing at /app/out/clips.csv reaches the mark printed in the instruction."""
import os

import tally
import timecode

HERE = os.path.dirname(os.path.abspath(__file__))
SEALED = os.path.join(HERE, "sealed")
FILING = "/app/out/clips.csv"
MARK = 54
CLIPS = 60


def test_sealed_key_matches_timecode_model():
    key = tally.read_key(os.path.join(SEALED, "key.csv"))
    rebuilt = timecode.rebuild(timecode.load_world(os.path.join(SEALED, "world.json")))
    assert len(key) == CLIPS and set(key) == set(rebuilt)
    for cid, truth in key.items():
        assert rebuilt[cid] == truth, cid


def test_filed_positions_reach_the_mark():
    key = tally.read_key(os.path.join(SEALED, "key.csv"))
    report = tally.tally(key, FILING)
    print("tally: %r (mark %d of %d)" % (report, MARK, CLIPS))
    assert report["right"] >= MARK
