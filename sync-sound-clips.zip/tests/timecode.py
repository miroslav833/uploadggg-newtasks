"""The verifier's own forward model: the key rebuilt from the sealed world (tests/sealed/world.json).

Each sealed clip carries its source in and out timecode, its record in timecode, its roll's start
timecode, the roll counter's base (24 or 30 frames per labelled second), whether the counter drops
labels, the counter's true frame rate as a fraction, the rate the recorder ran at and the samples
the file holds before its logged start. The model counts frames the way the counter does, wraps
at the day, converts frames to samples at the recorder's rate and adds the lead-in; a clip less than the
lead-in before the logged start lies in the lead-in, not on the previous day. It shares no
code with the reference.
"""
import json
from fractions import Fraction

SESSION_SAMPLES_PER_FRAME = Fraction(48000 * 1001, 24000)
SESSION_ORIGIN = 1 * 3600 * 24          # 01:00:00:00 on a 24-base counter


def load_world(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _labels(tc, base):
    h, m, s, f = [int(x) for x in tc.replace(";", ":").split(":")]
    return ((h * 60 + m) * 60 + s) * base + f, h * 60 + m


def _frames(tc, base, drop):
    n, mins = _labels(tc, base)
    return n - (2 * (mins - mins // 10) if drop else 0)


def _day(base, drop):
    return 86400 * base - (2 * 1296 if drop else 0)


def rebuild(world):
    """-> {clip id: (source_sample, length_samples, session_sample)}"""
    key = {}
    for c in world["clips"]:
        base, drop = c["base"], c["drop"]
        per_frame = Fraction(c["rate"]) / Fraction(c["fps"])
        start = _frames(c["roll_start"], base, drop)
        a, b = _frames(c["src_in"], base, drop), _frames(c["src_out"], base, drop)
        off = a - start
        if off < 0 and -off * per_frame > c["preroll"]:      # before the start and not in the lead-in: the day before
            off += _day(base, drop)
        rec = _frames(c["rec_in"], 24, False) - SESSION_ORIGIN
        key[c["id"]] = (round(off * per_frame) + c["preroll"], round((b - a) * per_frame),
                        round(rec * SESSION_SAMPLES_PER_FRAME))
    return key
