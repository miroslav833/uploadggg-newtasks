When a new piece comes into our production queue, the senior engraver sets the first bars of each section by hand and the rest gets engraved to match. I'd like that second part automated. Write me /app/engraver/beams.py, to be called as

```
python3 /app/engraver/beams.py PIECE_DIR OUT_TSV
```

Inside PIECE_DIR you'll find PIECE.md (the metres, and which bars were set by hand), notes.tsv (every note and rest) and hand.tsv (the stem direction and beam code the engraver gave each note of those hand-set bars). The file layouts and the way beam codes are written are in /app/house/HANDBOOK.md. Three completed pieces sit in /app/pieces; each one also has a truth.tsv with the engraving of all its remaining bars, which you can compare your own output against.

OUT_TSV: a tab-separated header of bar, position, pitch, stem, beam, then one row for every note in every bar that was not set by hand, following the order of notes.tsv. For instance `9	1/8	A4	up	1e`. Stem is `up` or `down`. The beam code follows the handbook, and a note with no beam gets `-`.

The grading: 20 further pieces, from the same houses, generated inside the grading image where you can't see them, and not all of those houses engrave the way the three completed pieces do. A note is correct if stem and beam code both agree with the house. A piece is correct if at most 3 of its notes are wrong; a row that's absent is a wrong note, and a file that doesn't parse gives that piece nothing. I need 18 of the 20 pieces correct.

For each piece the program is started fresh on a copy of the folder, by an account with no privileges, with the python3 in the image and nothing beyond the standard library, and it has 120 seconds. Nothing outside /app/engraver is kept, so put everything the program depends on in there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
