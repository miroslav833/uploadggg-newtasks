# Piece S03

- House: K683
- Bars: 40
- Metres:
  - bars 1 to 15: 4/4
  - bars 16 to 23: 9/8
  - bars 24 to 40: 2/2
- Engraved by hand: bars 1 to 3, 16 to 18, 24 to 26
