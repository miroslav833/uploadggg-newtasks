# Piece S01

- House: S818
- Bars: 40
- Metres:
  - bars 1 to 18: 4/4
  - bars 19 to 40: 6/8
- Engraved by hand: bars 1 to 3, 19 to 21
