# Piece S02

- House: L768
- Bars: 40
- Metres:
  - bars 1 to 15: 3/4
  - bars 16 to 24: 2/4
  - bars 25 to 40: 12/8
- Engraved by hand: bars 1 to 3, 16 to 18, 25 to 27
