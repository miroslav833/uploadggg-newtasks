# Production queue handbook: beaming and stems

The house publishes performing editions. A piece reaches the production queue as a list of notes and
rests exported from the editorial system, with its metres. The senior engraver sets the piece's
opening system by hand, bar 1 to bar 8, deciding every stem direction and every beam, and the rest of
the piece is engraved to match that opening and the house's practice. This handbook describes what a
piece folder holds, how the engraving record is written, and the program the production department
needs.

## Pieces and houses

Each piece belongs to one of the publishing houses the department serves. The houses engrave to the
same body of notation practice but make their own choices on the points that practice leaves open:
how notes shorter than a quarter are grouped under beams in some metres, whether a beam may run over
a short rest, where the inner beams of sixteenths break, how the stem of a chord or group is chosen
when its outer notes balance, how the irregular and compound metres are divided, and how a
syncopated figure is grouped. No house publishes a style sheet; its choices show in the pages it has
already engraved, and for a new piece in the opening system its engraver set.

## The engraving record

Every note of a piece has a stem direction, `up` or `down`, and a beam code. Notes that sound
together as a chord share one stem and one beam code. Rests carry neither. A beam group never
crosses a barline.

The beam code lists the beam levels the note takes part in, from level 1 (the outer beam joining
eighths) upward (level 2 joins sixteenths), each level followed by one letter:

- `b` the beam at that level begins on this note,
- `c` it continues through this note,
- `e` it ends on this note,
- `f` the note carries a partial beam at that level pointing forward,
- `h` it carries a partial beam at that level pointing back.

A note under no beam has the code `-`. For example, four beamed sixteenths are coded `1b2b`,
`1c2c`, `1c2c`, `1e2e`; a dotted eighth followed by a beamed sixteenth is `1b` then `1e2h`; a
sixteenth followed by a dotted eighth is `1b2f` then `1e`; an eighth, two sixteenths and an eighth
under one beam are `1b`, `1c2b`, `1c2e`, `1e`.

## What a piece folder holds

`PIECE.md`, for example:

```
# Piece S01

- House: M418
- Bars: 40
- Opening system: bars 1 to 8
- Metres:
  - bars 1 to 22: 4/4
  - bars 23 to 40: 6/8
```

`notes.tsv` lists every note and rest of the piece: `bar` from 1, `position` as a fraction of a
whole note from the start of the bar, `duration` as a fraction of a whole note, `kind` as `note` or
`rest`, and `pitch` as a letter with octave (`C4` is middle C, `B4` the treble staff's middle line)
or `-` for a rest. Notes of a chord appear as several rows with one bar, position and duration:

```
bar	position	duration	kind	pitch
1	0	1/8	note	G4
1	1/8	1/8	note	A4
1	1/4	1/4	rest	-
1	1/2	1/2	note	C5
1	1/2	1/2	note	E5
```

`opening.tsv` is the engraver's record of the opening system, bars 1 to 8: one row per note, with
`bar`, `position`, `pitch`, `stem` and `beam`:

```
bar	position	pitch	stem	beam
1	0	G4	up	1b
1	1/8	A4	up	1e
```

The three sample pieces also carry `truth.tsv`, the engraving of bars 9 to 40 in the same form.

## The program

The department runs `python3 /app/engraver/beams.py PIECE_DIR OUT_TSV` once per piece. The program
writes `OUT_TSV` with one row per note of bars 9 to 40, in the order of `notes.tsv`, giving the stem
and beam code the piece's house gives that note:

```
bar	position	pitch	stem	beam
9	0	G4	up	1b
9	1/8	A4	up	1e
```

The program runs under the image's python3 with the standard library only, with no network access.
