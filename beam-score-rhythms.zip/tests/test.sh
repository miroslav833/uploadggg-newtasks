#!/bin/bash
# Grades the engraving program at /app/engraver on the 20 held-out pieces. The reward channel is closed
# to everyone but root before the program runs, the test report goes to a private root-only directory,
# and the reward is written only after every process of the program's account has been stopped.
LOGS=/logs/verifier
PRIVATE=/run/platerun-results

put_reward() {
  rm -f "$LOGS/reward.txt" "$LOGS/reward.json"
  (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}

mkdir -p "$LOGS"
logs_mode="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null
find "$LOGS" -mindepth 1 -exec rm -rf {} + 2>/dev/null
put_reward 0

leave() {
  chmod "$logs_mode" "$LOGS" 2>/dev/null
  exit 0
}

if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
  echo "grading: $LOGS is not root-only; the program is not run" >&2
  leave
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
if [ "$(stat -c '%u:%a' /tests 2>/dev/null)" != "0:700" ]; then
  echo "grading: /tests is not root-only; the program is not run" >&2
  leave
fi
rm -rf "$PRIVATE"
mkdir -p "$PRIVATE"
chown 0:0 "$PRIVATE"
chmod 700 "$PRIVATE"
if [ -d /app/engraver ]; then
  chown -R 0:0 /app/engraver
  chmod -R u+rwX,go+rX,go-w /app/engraver
fi

cd /tests || leave
PLATERUN_RESULTS="$PRIVATE" python3 -m pytest -q -p no:cacheprovider test_beams.py --ctrf "$PRIVATE/ctrf.json"
status=$?

# nothing the program's account owns survives into the reward channel
find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
if [ "$status" -eq 0 ]; then put_reward 1; else put_reward 0; fi
for f in ctrf.json pieces.json; do
  if [ -f "$PRIVATE/$f" ] && [ ! -L "$PRIVATE/$f" ]; then
    rm -rf "$LOGS/$f"
    (umask 022; cp --no-dereference "$PRIVATE/$f" "$LOGS/$f")
  fi
done
leave
