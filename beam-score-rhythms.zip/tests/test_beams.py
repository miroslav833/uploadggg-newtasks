"""Two checks on the held-out pieces. First, the sealed engraving of every piece is rebuilt by an
independent forward model from the sealed house choices and the piece's notes, so the key is what the
house engraves and nothing else. Second, the program is run on every piece and enough pieces come out
right (at most 3 notes wrong per piece; 18 of 20 pieces)."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import platerun   # noqa: E402
import recheck    # noqa: E402

PIECES = 20
MARK = 18          # pieces that must count, of 20; printed in instruction.md

_table = None


def table():
    global _table
    if _table is None:
        _table = platerun.grade_pieces()
        where = os.environ.get("PLATERUN_RESULTS", "/logs/verifier")
        with open(os.path.join(where, "pieces.json"), "w", encoding="utf-8") as fh:
            json.dump(_table, fh, indent=1)
    return _table


def test_sealed_engraving_follows_from_the_houses():
    with open(os.path.join(platerun.VAULT, "engraving.json"), encoding="utf-8") as fh:
        sealed = json.load(fh)
    with open(os.path.join(platerun.VAULT, "houses.json"), encoding="utf-8") as fh:
        houses = json.load(fh)
    assert len(sealed) == PIECES
    for piece in sorted(sealed):
        rebuilt = recheck.rebuild(os.path.join(platerun.VAULT, "pieces", piece), houses[piece])
        assert rebuilt == sealed[piece], "piece %s: sealed engraving differs from the house state" % piece


def test_enough_pieces_engraved_right():
    rows = table()
    assert len(rows) == PIECES
    counted = sum(1 for r in rows if r["counts"])
    assert counted >= MARK, "%d of %d pieces right, %d needed" % (counted, PIECES, MARK)
