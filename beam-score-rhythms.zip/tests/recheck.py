"""An independent forward model of a house's engraving, used by the first test to rebuild every sealed
engraving from the sealed house choices and the piece's notes. It shares no code with the minter's
engraver: bars are read from the piece folder's files, groups are found by scanning spans with explicit
break tests, and the beam codes are assembled from neighbour relations.
"""
import csv
import os
from fractions import Fraction as F

E8, S16, Q4 = F(1, 8), F(1, 16), F(1, 4)
LETTERS = "CDEFGAB"


def steps_from_middle(pitch):
    return (int(pitch[-1]) - 4) * 7 + LETTERS.index(pitch[0]) - 6


def load(piece_dir):
    metres, hand = [], set()
    with open(os.path.join(piece_dir, "PIECE.md"), encoding="utf-8") as fh:
        for line in fh:
            s = line.strip()
            if s.startswith("- bars ") and ":" in s:
                left, right = s[2:].split(":")
                a, b = [int(x) for x in left.replace("bars", "").split("to")]
                n, d = right.strip().split("/")
                metres.append((a, b, int(n), int(d)))
            if s.startswith("- Engraved by hand:"):
                for part in s.split(":", 1)[1].split(","):
                    a, b = [int(x) for x in part.replace("bars", "").split("to")]
                    hand.update(range(a, b + 1))
    bars = {}
    with open(os.path.join(piece_dir, "notes.tsv"), encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            b = int(row["bar"])
            key = (F(row["position"]), F(row["duration"]), row["kind"])
            slot = bars.setdefault(b, {})
            slot.setdefault(key, []).append(row["pitch"])
    events = {}
    for b, slot in bars.items():
        evs = []
        for (pos, dur, kind), pitches in sorted(slot.items(), key=lambda kv: (kv[0][0], kv[0][2] != "note")):
            evs.append({"pos": pos, "dur": dur, "kind": kind, "pitches": [p for p in pitches if p != "-"]})
        events[b] = evs
    return metres, hand, events


def metre_for(metres, b):
    for a, z, n, d in metres:
        if a <= b <= z:
            return n, d
    raise KeyError(b)


def primary_spans(n, d, h):
    if (n, d) == (4, 4):
        u = F(1, 2) if h["four_four"] == "half" else Q4
    elif (n, d) == (3, 4):
        u = F(3, 4) if h["three_four"] == "bar" else Q4
    elif (n, d) == (2, 4):
        u = Q4
    elif d == 2:
        u = F(1, 2)
    elif (n, d) in ((6, 8), (9, 8), (12, 8)):
        u = F(3, 8)
    elif (n, d) == (6, 4):
        u = F(3, 4) if h["six_four"] == "compound" else F(1, 2)
    elif (n, d) == (5, 8):
        ps = (2, 3) if h["five"] == "2+3" else (3, 2)
        return cumulative(ps)
    elif (n, d) == (7, 8):
        return cumulative(tuple(int(x) for x in h["seven"].split("+")))
    else:
        raise KeyError((n, d))
    total = F(n, d)
    k = int(total / u)
    return [(i * u, (i + 1) * u) for i in range(k)]


def cumulative(ps):
    edges, t = [], F(0)
    for p in ps:
        edges.append((t, t + F(p, 8)))
        t += F(p, 8)
    return edges


def stem_of(pitches, h):
    st = [steps_from_middle(p) for p in pitches]
    top, bottom = max(st), min(st)
    if top > -bottom:
        return "down"
    if -bottom > top:
        return "up"
    if top == 0:
        return "down"
    if h["balanced"] == "majority":
        up_side = sum(1 for s in st if s > 0)
        down_side = sum(1 for s in st if s < 0)
        if up_side > down_side:
            return "down"
        if down_side > up_side:
            return "up"
    return "down"


def groups_of(evs, n, d, h):
    """Beam groups as lists of event indices (notes and spanned rests)."""
    out = []
    used = set()
    if d in (2, 4) and h["sync"] == "across":
        for i in range(len(evs) - 2):
            trio = evs[i:i + 3]
            if (all(e["kind"] == "note" for e in trio) and [e["dur"] for e in trio] == [E8, Q4, E8]
                    and trio[1]["pos"] == trio[0]["pos"] + E8 and trio[2]["pos"] == trio[1]["pos"] + Q4
                    and trio[0]["pos"] % Q4 == 0 and not any(j in used for j in range(i, i + 3))):
                out.append([i, i + 1, i + 2])
                used.update(range(i, i + 3))
    for s, e in primary_spans(n, d, h):
        members = [i for i, ev in enumerate(evs) if s <= ev["pos"] < e and i not in used]
        current = []
        for i in members:
            ev = evs[i]
            if ev["kind"] == "note" and ev["dur"] <= E8:
                current.append(i)
            elif ev["kind"] == "rest" and ev["dur"] < Q4 and h["rests"] == "span" and current:
                current.append(i)
            else:
                out.append(current)
                current = []
        out.append(current)
    cleaned = []
    for g in out:
        while g and evs[g[-1]]["kind"] == "rest":
            g = g[:-1]
        if sum(1 for i in g if evs[i]["kind"] == "note") >= 2:
            cleaned.append(g)
    return cleaned


def secondary_unit(n, d):
    return E8 if d == 8 else Q4


def codes_for_group(g, evs, n, d, h):
    notes = [i for i in g if evs[i]["kind"] == "note"]
    unit = secondary_unit(n, d)
    code = {}
    for k, i in enumerate(notes):
        c = "1b" if k == 0 else ("1e" if k == len(notes) - 1 else "1c")
        ev = evs[i]
        if ev["dur"] <= S16:
            def linked(j):
                if j not in (i - 1, i + 1) or evs[j]["dur"] > S16:
                    return False
                return h["secondary"] == "through" or evs[j]["pos"] // unit == ev["pos"] // unit
            left = k > 0 and linked(notes[k - 1])
            right = k + 1 < len(notes) and linked(notes[k + 1])
            if left and right:
                c += "2c"
            elif left:
                c += "2e"
            elif right:
                c += "2b"
            else:
                before = [j for j in g if j < i and evs[j]["kind"] == "note"]
                same_sub = any(evs[j]["pos"] // unit == ev["pos"] // unit for j in before)
                c += "2h" if same_sub else "2f"
        code[i] = c
    return notes, code


def rebuild(piece_dir, house):
    h = {k: (v if v is not None else {"four_four": "beat", "three_four": "beat", "rests": "break",
                                       "secondary": "beat", "sync": "broken", "balanced": "down",
                                       "five": "2+3", "seven": "2+2+3", "six_four": "duple"}[k])
         for k, v in house.items() if k not in ("metres", "hand")}
    metres, hand, events = load(piece_dir)
    out = {}
    for b in sorted(events):
        if b in hand:
            continue
        evs = events[b]
        n, d = metre_for(metres, b)
        stems = {}
        beams = {}
        for g in groups_of(evs, n, d, h):
            notes, code = codes_for_group(g, evs, n, d, h)
            s = stem_of([p for i in notes for p in evs[i]["pitches"]], h)
            for i in notes:
                stems[i] = s
                beams[i] = code[i]
        for i, ev in enumerate(evs):
            if ev["kind"] != "note":
                continue
            s = stems.get(i, stem_of(ev["pitches"], h))
            bm = beams.get(i, "-")
            pos = ev["pos"]
            pos_s = "%d/%d" % (pos.numerator, pos.denominator) if pos.denominator != 1 else str(pos.numerator)
            for p in ev["pitches"]:
                out["%d:%s:%s" % (b, pos_s, p)] = [s, bm]
    return out
