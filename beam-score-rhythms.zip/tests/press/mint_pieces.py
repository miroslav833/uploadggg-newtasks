#!/usr/bin/env python3
"""Mints pieces for the production queue: notes, the house's hand-engraved bars (the first three bars of
every metre section) and the sealed engraving of the other bars. Run inside the verifier image at build
time; deleted afterwards.

    python3 mint_pieces.py samples OUT_DIR TRUTH_JSON
    python3 mint_pieces.py graded  OUT_DIR TRUTH_JSON [SEED]

A piece is kept only when its house choices are settled by its own hand-engraved bars: every choice
that changes any graded note also changes a hand-engraved note, among every assignment of those
choices only the true one reproduces the hand-engraved bars, and every single wrong choice changes at
least four graded notes.
"""
import itertools
import json
import os
import random
import sys
from fractions import Fraction as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import compose   # noqa: E402
import engrave   # noqa: E402

BARS, HAND = 40, 3
MIN_COST = 4
Q, E, S = F(1, 4), F(1, 8), F(1, 16)


def metre_plan(rng, chosen):
    """Two or three metre sections over 40 bars, each at least 8 bars long."""
    chosen = list(chosen)
    rng.shuffle(chosen)
    n = len(chosen)
    while True:
        cuts = sorted(rng.sample(range(8, BARS - 7), n - 1)) if n > 1 else []
        bounds = [0] + cuts + [BARS]
        if all(bounds[k + 1] - bounds[k] >= 8 for k in range(n)):
            break
    return [(bounds[k], bounds[k + 1], chosen[k]) for k in range(n)]


def metre_of(plan, bar):
    for s, e, m in plan:
        if s <= bar < e:
            return m
    raise ValueError(bar)


def hand_bars(plan):
    out = set()
    for s, e, m in plan:
        out.update(range(s, s + HAND))
    return out


def quarter_first(unit):
    """A span pattern whose first event is an unbeamed quarter (for a balanced chord)."""
    if unit == "q":
        return [(Q, "n")]
    if unit == "d":
        return [(Q, "n"), (E, "n")]
    if unit == "h":
        return [(Q, "n"), (E, "n"), (E, "n")]
    if unit == "5":
        return [(Q, "n"), (E, "n"), (E, "n"), (E, "n")]
    return [(Q, "n"), (Q, "n"), (E, "n"), (E, "n"), (E, "n")]


def triggers_for(rng, metre, region_bars, reps, forced):
    """Force the patterns that evidence each house choice into bars of one metre."""
    units = compose.span_units(metre)

    def add(bar, spans, balanced=None):
        forced.setdefault(bar, {"spans": {}, "balanced": None})
        forced[bar]["spans"].update(spans)
        if balanced is not None:
            forced[bar]["balanced"] = balanced

    def pick():
        return rng.choice(region_bars)

    for _ in range(reps):
        if metre == (4, 4):
            add(pick(), {rng.choice((0, 1)): compose.EIGHTS})
        if metre == (3, 4):
            add(pick(), {0: [(E, "n")] * 2, 1: [(E, "n")] * 2, 2: [(E, "n")] * 2})
            add(pick(), {0: compose.SYNC})
            add(pick(), {rng.choice((0, 1, 2)): compose.REST_INQ})
        if "h" in units:
            add(pick(), {rng.choice([k for k, u in enumerate(units) if u == "h"]): compose.SYNC})
            add(pick(), {rng.choice([k for k, u in enumerate(units) if u == "h"]): compose.RUN16})
            add(pick(), {rng.choice([k for k, u in enumerate(units) if u == "h"]): compose.REST_IN})
        if "d" in units:
            add(pick(), {rng.choice([k for k, u in enumerate(units) if u == "d"]): compose.RUN16C})
            add(pick(), {rng.choice([k for k, u in enumerate(units) if u == "d"]): [(E, "n"), (E, "r"), (E, "n")]})
        if metre == (5, 8):
            add(pick(), {0: [(E, "n")] * 5})
            add(pick(), {0: [(E, "n")] * 2 + list(compose.RUN16C)})
            add(pick(), {0: [(E, "n"), (E, "r"), (E, "n"), (E, "n"), (E, "n")]})
            add(pick(), {0: [(E, "n"), (E, "n"), (E, "n"), (E, "r"), (E, "n")]})
        if metre == (7, 8):
            add(pick(), {0: [(E, "n")] * 7})
            add(pick(), {0: [(E, "n")] * 2 + list(compose.RUN16C) + [(E, "n")] * 2})
            for pat in ([(E, "n"), (E, "r"), (E, "n"), (E, "n"), (E, "n"), (E, "n"), (E, "n")],
                        [(E, "n"), (E, "n"), (E, "n"), (E, "r"), (E, "n"), (E, "n"), (E, "n")],
                        [(E, "n"), (E, "n"), (E, "n"), (E, "n"), (E, "n"), (E, "r"), (E, "n")]):
                add(pick(), {0: pat})
        if metre == (6, 4):
            add(pick(), {0: [(E, "n")] * 4, 1: [(E, "n")] * 4, 2: [(E, "n")] * 4})
        if metre in ((2, 2), (3, 2)):
            add(pick(), {0: [(E, "n")] * 4})
        add(pick(), {0: quarter_first(units[0])}, balanced=0)


def build_piece(rng, house, plan):
    forced = {}
    hand = hand_bars(plan)
    for s, e, m in plan:
        hand_region = [b for b in range(s, e) if b in hand]
        graded_region = [b for b in range(s, e) if b not in hand]
        triggers_for(rng, m, hand_region, 1, forced)
        triggers_for(rng, m, graded_region, 2, forced)
    state = {"step": rng.choice((-3, -1, 1, 3))}
    bars = []
    for b in range(BARS):
        metre = metre_of(plan, b)
        f = forced.get(b)
        events = compose.compose_bar(rng, metre, state, forced=f["spans"] if f else None,
                                     balanced_at=f["balanced"] if f else None)
        bars.append((metre, events))
    return bars


def split_rows(rows, hand):
    h = [r for r in rows if (r[0] - 1) in hand]
    g = [r for r in rows if (r[0] - 1) not in hand]
    return h, g


def settled(bars, house, hand):
    truth = engrave.engrave_piece(bars, house)
    t_hand, t_graded = split_rows(truth, hand)
    evidenced = []
    for k, values in engrave.MENU.items():
        for v in values:
            if v == house[k]:
                continue
            o_hand, o_graded = split_rows(engrave.engrave_piece(bars, dict(house, **{k: v})), hand)
            moved = sum(1 for a, b in zip(t_graded, o_graded) if a[2:] != b[2:])
            if o_hand == t_hand:
                if moved:
                    return False, None, "%s=%s moves %d graded notes but no hand-engraved one" % (k, v, moved)
                continue        # this value is told apart only by bars that do not matter: irrelevant
            if moved < MIN_COST:
                return False, None, "%s=%s moves only %d notes" % (k, v, moved)
            if k not in evidenced:
                evidenced.append(k)
    for combo in itertools.product(*[engrave.MENU[k] for k in evidenced]):
        other = dict(house, **dict(zip(evidenced, combo)))
        if all(other[k] == house[k] for k in evidenced):
            continue
        o_hand, _ = split_rows(engrave.engrave_piece(bars, other), hand)
        if o_hand == t_hand:
            return False, None, "combo %s matches the hand-engraved bars" % dict(zip(evidenced, combo))
    return True, (truth, evidenced), None


def metre_sets(rng):
    """Twenty metre sets: 4/4 and 3/4 on 12 pieces each, every irregular metre on 6, the rest spread."""
    while True:
        slots = ([(4, 4)] * 12 + [(3, 4)] * 12 + [(5, 8)] * 6 + [(7, 8)] * 6 + [(6, 4)] * 6 +
                 [(6, 8)] * 2 + [(9, 8)] * 2 + [(12, 8)] * 2 + [(2, 2)] * 2 + [(3, 2)] * 2 + [(2, 4)] * 2)
        rng.shuffle(slots)
        sizes = [3] * 14 + [2] * 6
        rng.shuffle(sizes)
        sets, ok = [], True
        for n in sizes:
            s = slots[:n]
            slots = slots[n:]
            if len(set(s)) != n:
                ok = False
                break
            sets.append(s)
        if ok:
            return sets


def graded_houses(rng):
    """Twenty houses: each binary choice on 10 pieces, irregular metres on 12 pieces."""
    while True:
        cols = {}
        for k, vals in engrave.MENU.items():
            if len(vals) == 2:
                col = [vals[0]] * 10 + [vals[1]] * 10
            else:
                col = [vals[0]] * 7 + [vals[1]] * 7 + [vals[2]] * 6
            rng.shuffle(col)
            cols[k] = col
        houses = [dict((k, cols[k][i]) for k in cols) for i in range(20)]
        sets = metre_sets(rng)
        # the choices a metre brings are split evenly over the pieces that carry that metre
        for key, metre in (("four_four", (4, 4)), ("three_four", (3, 4)), ("five", (5, 8)),
                           ("seven", (7, 8)), ("six_four", (6, 4))):
            carriers = [i for i, s in enumerate(sets) if metre in s]
            rng.shuffle(carriers)
            vals = engrave.MENU[key]
            for j, i in enumerate(carriers):
                houses[i][key] = vals[j % len(vals)]
        if all(sum(h[k] != engrave.TRIVIAL[k] for k in ("four_four", "three_four", "rests", "secondary",
                                                          "sync", "balanced")) >= 2 for h in houses):
            return houses, sets


def fmt(fr):
    return "%d/%d" % (fr.numerator, fr.denominator) if fr.denominator != 1 else "%d" % fr.numerator


def hand_ranges(plan):
    return ", ".join("%d to %d" % (s + 1, s + HAND) for s, e, m in plan)


def write_piece(out_dir, name, house_code, plan, bars, truth, with_truth):
    hand = hand_bars(plan)
    d = os.path.join(out_dir, name)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "PIECE.md"), "w", encoding="utf-8") as fh:
        fh.write("# Piece %s\n\n- House: %s\n- Bars: %d\n- Metres:\n" % (name, house_code, BARS))
        for s, e, m in plan:
            fh.write("  - bars %d to %d: %d/%d\n" % (s + 1, e, m[0], m[1]))
        fh.write("- Engraved by hand: bars %s\n" % hand_ranges(plan))
    with open(os.path.join(d, "notes.tsv"), "w", encoding="utf-8") as fh:
        fh.write("bar\tposition\tduration\tkind\tpitch\n")
        for b, (metre, events) in enumerate(bars):
            for ev in events:
                if ev["kind"] == "note":
                    for p in ev["pitches"]:
                        fh.write("%d\t%s\t%s\tnote\t%s\n" % (b + 1, fmt(ev["position"]), fmt(ev["duration"]), p))
                else:
                    fh.write("%d\t%s\t%s\trest\t-\n" % (b + 1, fmt(ev["position"]), fmt(ev["duration"])))
    rows = {(r[0], r[1]): r for r in truth}
    for fname, in_hand in (("hand.tsv", True), ("truth.tsv", False)):
        if fname == "truth.tsv" and not with_truth:
            continue
        with open(os.path.join(d, fname), "w", encoding="utf-8") as fh:
            fh.write("bar\tposition\tpitch\tstem\tbeam\n")
            for b, (metre, events) in enumerate(bars):
                if (b in hand) != in_hand:
                    continue
                for i, ev in enumerate(events):
                    if ev["kind"] == "note":
                        r = rows[(b + 1, i)]
                        for p in ev["pitches"]:
                            fh.write("%d\t%s\t%s\t%s\t%s\n" % (b + 1, fmt(ev["position"]), p, r[2], r[3]))


def sealed_table(bars, truth, hand):
    rows = {(r[0], r[1]): r for r in truth}
    out = {}
    for b, (metre, events) in enumerate(bars):
        if b in hand:
            continue
        for i, ev in enumerate(events):
            if ev["kind"] == "note":
                r = rows[(b + 1, i)]
                for p in ev["pitches"]:
                    out["%d:%s:%s" % (b + 1, fmt(ev["position"]), p)] = [r[2], r[3]]
    return out


def mint(house, metres, out_dir, name, seed, with_truth):
    rng = random.Random(seed)
    code = "%s%d" % (rng.choice("KLMNPRST"), rng.randrange(100, 999))
    for attempt in range(120):
        plan = metre_plan(rng, metres)
        bars = build_piece(rng, house, plan)
        hand = hand_bars(plan)
        good, info, why = settled(bars, house, hand)
        if not good:
            sys.stderr.write("%s attempt %d: %s\n" % (name, attempt, why))
            continue
        truth, evidenced = info
        write_piece(out_dir, name, code, plan, bars, truth, with_truth)
        state = {k: (house[k] if k in evidenced else None) for k in engrave.MENU}
        state["metres"] = ["%d/%d" % m for _, _, m in plan]
        state["hand"] = sorted(b + 1 for b in hand)
        return sealed_table(bars, truth, hand), state
    raise RuntimeError("%s: no settled piece in 120 attempts" % name)


def mint_many(houses, metres, prefix, out_dir, truth_path, base_seed, with_truth=False):
    truth, states = {}, {}
    for i, h in enumerate(houses):
        name = "%s%02d" % (prefix, i + 1)
        truth[name], states[name] = mint(h, metres[i], out_dir, name, base_seed + 131 * i, with_truth)
        sys.stderr.write("minted %s %s\n" % (name, {k: v for k, v in states[name].items() if v is not None}))
    os.makedirs(os.path.dirname(truth_path) or ".", exist_ok=True)
    with open(truth_path, "w", encoding="utf-8") as fh:
        json.dump(truth, fh)
    with open(os.path.splitext(truth_path)[0] + "_houses.json", "w", encoding="utf-8") as fh:
        json.dump(states, fh, indent=1)
    return truth, states


def sample_houses():
    t = dict(engrave.TRIVIAL)
    return [dict(t), dict(t), dict(t)], [[(4, 4), (6, 8)], [(3, 4), (2, 4), (12, 8)], [(2, 2), (4, 4), (9, 8)]]


if __name__ == "__main__":
    what, out_dir, truth_path = sys.argv[1], sys.argv[2], sys.argv[3]
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 4400
    if what == "samples":
        h, irr = sample_houses()
        mint_many(h, irr, "S", out_dir, truth_path, seed + 9000, with_truth=True)
    else:
        rng = random.Random(seed)
        h, irr = graded_houses(rng)
        mint_many(h, irr, "H", out_dir, truth_path, seed)
