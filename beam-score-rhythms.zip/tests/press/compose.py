"""Composes the notes and rests of a piece: 40 bars over one to three metre ranges, rhythms built span by
span from a pattern vocabulary, pitches on a treble staff, with some chords. Patterns that trigger the
house choices can be forced into chosen bars.
"""
from fractions import Fraction as F

import engrave

METRES = [(2, 4), (3, 4), (4, 4), (2, 2), (3, 2), (6, 8), (9, 8), (12, 8), (6, 4), (5, 8), (7, 8)]
E, S, Q, DE = F(1, 8), F(1, 16), F(1, 4), F(3, 16)

# patterns per span: list of (duration, kind)
QUARTER_SPAN = [
    [(Q, "n")], [(E, "n"), (E, "n")], [(E, "n"), (E, "n")], [(S, "n"), (S, "n"), (E, "n")],
    [(E, "n"), (S, "n"), (S, "n")], [(DE, "n"), (S, "n")], [(S, "n"), (DE, "n")],
    [(S, "n"), (S, "n"), (S, "n"), (S, "n")], [(E, "r"), (E, "n")], [(E, "n"), (E, "r")], [(Q, "r")],
    [(S, "n"), (S, "r"), (E, "n")], [(S, "n"), (E, "n"), (S, "n")], [(S, "n"), (S, "r"), (S, "n"), (S, "n")],
]
DOTTED_SPAN = [
    [(E, "n"), (E, "n"), (E, "n")], [(F(3, 8), "n")], [(Q, "n"), (E, "n")], [(E, "n"), (Q, "n")],
    [(E, "n"), (E, "r"), (E, "n")], [(E, "n"), (S, "n"), (S, "n"), (E, "n")], [(S, "n"), (S, "n"), (E, "n"), (E, "n")],
    [(E, "n"), (E, "n"), (S, "n"), (S, "n")], [(S, "n"), (S, "n"), (S, "n"), (S, "n"), (E, "n")],
    [(E, "n"), (E, "n"), (E, "r")], [(E, "r"), (E, "n"), (E, "n")], [(F(3, 8), "r")],
]
SYNC = [(E, "n"), (Q, "n"), (E, "n")]           # over a half
EIGHTS = [(E, "n")] * 4                           # four eighths over a half
RUN16 = [(E, "n"), (S, "n"), (S, "n"), (S, "n"), (S, "n"), (E, "n")]   # 16ths across a quarter boundary (half)
RUN16C = [(S, "n"), (S, "n"), (S, "n"), (S, "n"), (E, "n")]            # 16ths across an eighth boundary (3/8)
REST_IN = [(E, "n"), (E, "r"), (E, "n"), (E, "n")]                     # internal rest in a half
REST_INQ = [(S, "n"), (S, "r"), (S, "n"), (S, "n")]                    # internal rest in a quarter


def span_units(metre):
    """The composing spans of a bar: lists of span lengths; 'q' quarter spans, 'd' dotted spans, 'h' halves."""
    num, den = metre
    if metre == (4, 4):
        return ["h", "h"]
    if metre == (2, 4):
        return ["h"]
    if metre == (3, 4):
        return ["q", "q", "q"]
    if metre == (2, 2):
        return ["h", "h"]
    if metre == (3, 2):
        return ["h", "h", "h"]
    if metre in ((6, 8), (9, 8), (12, 8)):
        return ["d"] * (num // 3)
    if metre == (6, 4):
        return ["h", "h", "h"]
    if metre == (5, 8):
        return ["5"]
    if metre == (7, 8):
        return ["7"]
    raise ValueError(metre)


def fill_span(rng, unit, force=None):
    """Durations and kinds for one composing span."""
    if force is not None:
        return list(force)
    if unit == "q":
        return list(QUARTER_SPAN[rng.randrange(len(QUARTER_SPAN))])
    if unit == "d":
        return list(DOTTED_SPAN[rng.randrange(len(DOTTED_SPAN))])
    if unit == "h":
        r = rng.random()
        if r < 0.12:
            return list(EIGHTS)
        if r < 0.20:
            return list(RUN16)
        if r < 0.26:
            return list(REST_IN)
        if r < 0.30:
            return list(SYNC)
        return fill_span(rng, "q") + fill_span(rng, "q")
    if unit == "5":
        r = rng.random()
        if r < 0.35:
            return [(E, "n")] * 5
        if r < 0.5:
            return [(E, "n")] * 2 + list(RUN16C)
        return fill_span(rng, "q") + fill_span(rng, "d")
    if unit == "7":
        r = rng.random()
        if r < 0.35:
            return [(E, "n")] * 7
        return fill_span(rng, "q") + fill_span(rng, "q") + fill_span(rng, "d")
    raise ValueError(unit)


def walk_pitches(rng, state, count):
    """A random walk in staff steps from G3 (-9) to E6 (+10) around the middle line."""
    out = []
    for _ in range(count):
        step = state["step"] + rng.choice((-3, -2, -1, -1, 0, 1, 1, 2, 3))
        step = max(-9, min(10, step))
        state["step"] = step
        out.append(step)
    return out


def pitch_name(step):
    octave = 4 + (step + 6) // 7
    letter = engrave.STEPS[(step + 6) % 7]
    return "%s%d" % (letter, octave)


def chord_for(rng, step, balanced=False):
    if balanced:
        m = max(2, min(6, abs(step)))
        return [-m, -1, m]          # outer notes balance; the inner note tips the majority below
    size = 2 if rng.random() < 0.7 else 3
    notes = [step]
    for _ in range(size - 1):
        notes.append(max(-9, min(10, notes[-1] + rng.choice((2, 2, 3, 4)))))
    return sorted(set(notes))


def off_beat_figure(durs):
    """True when an eighth, quarter, eighth run starts off the quarter beat (an ambiguous figure the
    pieces never carry)."""
    t = F(0)
    for k in range(len(durs) - 2):
        kinds = [durs[k + j][1] for j in range(3)]
        ds = [durs[k + j][0] for j in range(3)]
        if kinds == ["n", "n", "n"] and ds == [E, Q, E] and t % Q != 0:
            return True
        t += durs[k][0]
    return False


def compose_bar(rng, metre, state, forced=None, balanced_at=None):
    """forced: dict span_index -> pattern. Returns the bar's events."""
    for _ in range(200):
        events, durs = _compose_bar(rng, metre, state, forced, balanced_at)
        if not off_beat_figure(durs):
            return events
    return events


def _compose_bar(rng, metre, state, forced=None, balanced_at=None):
    units = span_units(metre)
    lengths = {"q": F(1, 4), "d": F(3, 8), "h": F(1, 2), "5": F(5, 8), "7": F(7, 8)}
    durs = []
    covered = F(0)
    k = 0
    while k < len(units):
        pat = forced.get(k) if forced else None
        if pat is not None:
            durs += list(pat)
            span_len = sum(d for d, _ in pat)
            covered += span_len
            # a forced pattern longer than its unit consumes the following units
            used = F(0)
            while k < len(units) and used < span_len:
                used += lengths[units[k]]
                k += 1
            continue
        durs += fill_span(rng, units[k], None)
        k += 1
    events = []
    t = F(0)
    note_count = sum(1 for d, k in durs if k == "n")
    steps = walk_pitches(rng, state, note_count)
    si = 0
    for idx, (d, k) in enumerate(durs):
        if k == "n":
            step = steps[si]
            si += 1
            if balanced_at is not None and idx == balanced_at:
                pitches = chord_for(rng, step if step != 0 else 2, balanced=True)
            elif rng.random() < 0.12:
                pitches = chord_for(rng, step)
            else:
                pitches = [step]
            events.append(dict(position=t, duration=d, kind="note", pitches=[pitch_name(s) for s in pitches]))
        else:
            events.append(dict(position=t, duration=d, kind="rest", pitches=[]))
        t += d
    return events, durs
