"""The house engraving of a piece: stem directions and beam codes under the standard rules of print
notation and a house's choices on the points the rules leave open.

Positions and durations are Fractions of a whole note. A bar's events are notes and rests; notes at one
position with one duration form a chord. Beamable notes are those of an eighth or shorter.

Standard rules (always applied):
  - beam groups lie inside one primary span of the metre (a beat, or a larger span the house groups by),
    never cross a barline, and hold at least two notes; a note longer than an eighth and a rest of a
    quarter or longer end a group;
  - level-2 beams join consecutive sixteenth-level notes of a group that lie in one secondary
    subdivision (a quarter in simple metres, an eighth in compound ones); a sixteenth-level note with no
    level-2 neighbour takes a partial beam that points forward when it is the first note of its
    subdivision and back otherwise; a rest always breaks a level-2 connection;
  - a stem points away from the middle line (B4): a single note on or above it stems down, below it up;
    a chord or beamed group takes the direction of its note farthest from the middle line (in staff
    steps).

House choices (the menu):
  four_four   'beat' | 'half'      eighths in 4/4 grouped by quarter beat or by half-bar
  three_four  'beat' | 'bar'       eighths in 3/4 grouped by beat or across the bar
  rests       'break' | 'span'     a rest shorter than a quarter inside a span breaks a group or is spanned
  secondary   'beat' | 'through'   level-2 beams break at each subdivision or carry through the group
  sync        'broken' | 'across'  eighth-quarter-eighth over a half: broken, or beamed across the quarter
  balanced    'down' | 'majority'  equidistant farthest notes: stem down, or follow the majority side
  five        '2+3' | '3+2'        division of 5/8
  seven       '2+2+3' | '3+2+2' | '2+3+2'
  six_four    'duple' | 'compound' 6/4 as three halves or two dotted halves
"""
from fractions import Fraction as F

MENU = {
    "four_four": ("beat", "half"),
    "three_four": ("beat", "bar"),
    "rests": ("break", "span"),
    "secondary": ("beat", "through"),
    "sync": ("broken", "across"),
    "balanced": ("down", "majority"),
    "five": ("2+3", "3+2"),
    "seven": ("2+2+3", "3+2+2", "2+3+2"),
    "six_four": ("duple", "compound"),
}
TRIVIAL = dict(four_four="beat", three_four="beat", rests="break", secondary="beat", sync="broken",
               balanced="down", five="2+3", seven="2+2+3", six_four="duple")
STEPS = "CDEFGAB"
EIGHTH, SIXTEENTH, QUARTER = F(1, 8), F(1, 16), F(1, 4)


def step_index(pitch):
    """Diatonic staff step of a pitch like 'B4' or 'C#5' relative to B4 (0); C5 is +1, A4 is -1."""
    letter = pitch[0]
    octave = int(pitch[-1])
    return (octave - 4) * 7 + STEPS.index(letter) - STEPS.index("B")


def spans(metre, house):
    """Primary spans of one bar as (start, end) fractions, and the secondary subdivision unit."""
    num, den = metre
    bar = F(num, den)
    if (num, den) == (4, 4):
        unit = F(1, 2) if house["four_four"] == "half" else F(1, 4)
        return _even(bar, unit), QUARTER
    if (num, den) == (3, 4):
        unit = F(3, 4) if house["three_four"] == "bar" else F(1, 4)
        return _even(bar, unit), QUARTER
    if (num, den) == (2, 4):
        return _even(bar, F(1, 4)), QUARTER
    if (num, den) in ((2, 2), (3, 2)):
        return _even(bar, F(1, 2)), QUARTER
    if (num, den) in ((6, 8), (9, 8), (12, 8)):
        return _even(bar, F(3, 8)), EIGHTH
    if (num, den) == (6, 4):
        if house["six_four"] == "compound":
            return _even(bar, F(3, 4)), QUARTER
        return _even(bar, F(1, 2)), QUARTER
    if (num, den) == (5, 8):
        parts = [2, 3] if house["five"] == "2+3" else [3, 2]
        return _parts(parts), EIGHTH
    if (num, den) == (7, 8):
        parts = [int(x) for x in house["seven"].split("+")]
        return _parts(parts), EIGHTH
    raise ValueError("metre %s" % (metre,))


def _even(bar, unit):
    out = []
    t = F(0)
    while t < bar:
        out.append((t, t + unit))
        t += unit
    return out


def _parts(parts):
    out = []
    t = F(0)
    for p in parts:
        out.append((t, t + F(p, 8)))
        t += F(p, 8)
    return out


def is_simple(metre):
    return metre[1] in (2, 4)


def engrave_bar(events, metre, house):
    """events: list of dicts with position, duration, kind ('note'|'rest'), pitches (list, notes only),
    sorted by position. Returns per event: stem ('up'|'down'|'-') and beam code string ('-' if none)."""
    n = len(events)
    stem = ["-"] * n
    beam = ["-"] * n
    primary, sub_unit = spans(metre, house)
    groups = []
    # syncopated figure: eighth, quarter, eighth filling a half that starts on a quarter beat (simple metres)
    sync_members = set()
    if is_simple(metre) and house["sync"] == "across":
        for i in range(n - 2):
            a, b, c = events[i], events[i + 1], events[i + 2]
            if (a["kind"] == b["kind"] == c["kind"] == "note" and a["duration"] == EIGHTH and
                    b["duration"] == QUARTER and c["duration"] == EIGHTH and
                    b["position"] == a["position"] + EIGHTH and c["position"] == b["position"] + QUARTER and
                    a["position"] % QUARTER == 0 and
                    not any(k in sync_members for k in (i, i + 1, i + 2))):
                groups.append([i, i + 1, i + 2])
                sync_members.update((i, i + 1, i + 2))
    for (s, e) in primary:
        run = []
        for i, ev in enumerate(events):
            if ev["position"] < s or ev["position"] >= e or i in sync_members:
                continue
            beamable = ev["kind"] == "note" and ev["duration"] <= EIGHTH
            if beamable:
                run.append(i)
            elif ev["kind"] == "rest" and ev["duration"] < QUARTER and house["rests"] == "span" and run:
                run.append(i)          # may be spanned; trimmed below if it ends the run
            else:
                groups.append(run)
                run = []
        groups.append(run)
    final = []
    for g in groups:
        while g and events[g[-1]]["kind"] == "rest":
            g = g[:-1]
        notes_in = [i for i in g if events[i]["kind"] == "note"]
        if len(notes_in) >= 2:
            final.append(g)
    for g in final:
        notes_in = [i for i in g if events[i]["kind"] == "note"]
        # level 1
        for k, i in enumerate(notes_in):
            code = "1b" if k == 0 else ("1e" if k == len(notes_in) - 1 else "1c")
            beam[i] = code
        # level 2: between consecutive members with no rest between, both sixteenth-level, same subdivision
        for k, i in enumerate(notes_in):
            ev = events[i]
            if ev["duration"] > SIXTEENTH:
                continue
            prev_ok = next_ok = False
            if k > 0:
                j = notes_in[k - 1]
                prev_ok = (events[j]["duration"] <= SIXTEENTH and j == i - 1 and
                           _same_sub(events[j], ev, sub_unit, house))
            if k < len(notes_in) - 1:
                j = notes_in[k + 1]
                next_ok = (events[j]["duration"] <= SIXTEENTH and j == i + 1 and
                           _same_sub(ev, events[j], sub_unit, house))
            if prev_ok and next_ok:
                beam[i] += "2c"
            elif prev_ok:
                beam[i] += "2e"
            elif next_ok:
                beam[i] += "2b"
            else:
                first_in_sub = all(events[j]["position"] // sub_unit != ev["position"] // sub_unit
                                   for j in g[:g.index(i)] if events[j]["kind"] == "note")
                beam[i] += "2f" if first_in_sub else "2h"
        # stems for the group
        d = _direction([p for i in notes_in for p in events[i]["pitches"]], house)
        for i in notes_in:
            stem[i] = d
    for i, ev in enumerate(events):
        if ev["kind"] == "note" and stem[i] == "-":
            stem[i] = _direction(ev["pitches"], house)
    return stem, beam


def _same_sub(a, b, sub_unit, house):
    if house["secondary"] == "through":
        return True
    return a["position"] // sub_unit == b["position"] // sub_unit


def _direction(pitches, house):
    steps = [step_index(p) for p in pitches]
    far = max(abs(s) for s in steps)
    above = any(s == far for s in steps)
    below = any(s == -far for s in steps)
    if far == 0:
        return "down"
    if above and not below:
        return "down"
    if below and not above:
        return "up"
    if house["balanced"] == "majority":
        up_count = sum(1 for s in steps if s > 0)
        down_count = sum(1 for s in steps if s < 0)
        if up_count > down_count:
            return "down"
        if down_count > up_count:
            return "up"
    return "down"


def engrave_piece(bars, house):
    """bars: list of (metre, events). Returns list of (bar_no, event_index, stem, beam)."""
    out = []
    for b, (metre, events) in enumerate(bars):
        stem, beam = engrave_bar(events, metre, house)
        for i, ev in enumerate(events):
            if ev["kind"] == "note":
                out.append((b + 1, i, stem[i], beam[i]))
    return out
