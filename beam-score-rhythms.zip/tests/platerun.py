"""Runs the engraving program at /app/engraver on every held-out piece and scores its rows against the
sealed engraving.

Each piece is copied to a scratch directory owned by a numeric account made up for the run; the
program runs as that account in its own session with an address-space limit, a process limit and a
wall-clock budget, and every process of the account is stopped before anything it wrote is read. The
output is read as text: a regular file under the size cap, rows that parse; nothing in it is executed.
The sealed engraving stays under /tests, which is root-only.
"""
import csv
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import time

VAULT = "/tests/vault"
SCRATCH = "/var/tmp/platerun"
PROGRAM = "/app/engraver/beams.py"
SECONDS = 120
MEMORY_BYTES = 3 * 1024 ** 3
OUT_CAP = 1 << 20
WRONG_ALLOWED = 3      # notes a piece may have wrong; printed in instruction.md


def fresh_uid(index):
    taken = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                taken.add(os.stat("/proc/" + d).st_uid)
            except FileNotFoundError:
                pass
    uid = 47000 + 3 * index
    while uid in taken:
        uid += 1
    return uid


def pids_of(uid):
    out = []
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    out.append(int(d))
            except FileNotFoundError:
                pass
    return out


def halt(uid):
    calm = 0
    for _ in range(400):
        pids = pids_of(uid)
        if not pids:
            calm += 1
            if calm >= 3:
                return
            time.sleep(0.05)
            continue
        calm = 0
        for sig in (signal.SIGSTOP, signal.SIGKILL):
            for p in pids:
                try:
                    os.kill(p, sig)
                except ProcessLookupError:
                    pass
        time.sleep(0.05)


def run_program(piece, uid):
    work = os.path.join(SCRATCH, piece)
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, mode=0o755)
    copy = os.path.join(work, "piece")
    shutil.copytree(os.path.join(VAULT, "pieces", piece), copy, symlinks=False)
    os.makedirs(os.path.join(work, "out"))
    for root, dirs, files in os.walk(work):
        os.chown(root, uid, uid)
        for f in files:
            os.chown(os.path.join(root, f), uid, uid)
    out_tsv = os.path.join(work, "out", "engraving.tsv")
    log = open(os.path.join(work, "run.log"), "wb")

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (MEMORY_BYTES, MEMORY_BYTES))
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
        resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": work, "LANG": "C.UTF-8",
           "PYTHONDONTWRITEBYTECODE": "1", "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2"}
    try:
        proc = subprocess.Popen([sys.executable, PROGRAM, copy, out_tsv], cwd=work, stdout=log, stderr=log,
                                env=env, preexec_fn=drop)
        try:
            proc.wait(timeout=SECONDS)
        except subprocess.TimeoutExpired:
            pass
    except OSError:
        pass
    finally:
        log.close()
    halt(uid)
    try:
        with open(os.path.join(work, "run.log"), "rb") as fh:
            tail = fh.read()[-600:].decode("utf-8", "replace")
    except OSError:
        tail = ""
    return out_tsv, tail


def read_rows(path):
    """{'bar:position:pitch': (stem, beam)} from the first row per key; None when the file is unusable."""
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > OUT_CAP:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    rows = {}
    with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
        try:
            for row in csv.DictReader(fh, delimiter="\t"):
                key = "%s:%s:%s" % ((row.get("bar") or "").strip(), (row.get("position") or "").strip(),
                                    (row.get("pitch") or "").strip())
                if key.count(":") != 2 or key in rows:
                    continue
                rows[key] = ((row.get("stem") or "").strip(), (row.get("beam") or "").strip())
        except csv.Error:
            return None
    return rows


def wrong_notes(rows, sealed):
    if not rows:
        return len(sealed)
    n = 0
    for key, (stem, beam) in sealed.items():
        got = rows.get(key)
        if got is None or got[0] != stem or got[1] != beam:
            n += 1
    return n


def grade_pieces():
    with open(os.path.join(VAULT, "engraving.json"), encoding="utf-8") as fh:
        sealed = json.load(fh)
    os.makedirs(SCRATCH, mode=0o755, exist_ok=True)
    table = []
    for index, piece in enumerate(sorted(sealed)):
        uid = fresh_uid(index)
        out_tsv, tail = run_program(piece, uid)
        rows = read_rows(out_tsv)
        wrong = wrong_notes(rows, sealed[piece])
        row = dict(piece=piece, parsed=rows is not None and len(rows) > 0, notes=len(sealed[piece]),
                   wrong=wrong, counts=wrong <= WRONG_ALLOWED)
        if not row["counts"]:
            row["stderr_tail"] = tail
        table.append(row)
        shutil.rmtree(os.path.join(SCRATCH, piece), ignore_errors=True)
    return table


if __name__ == "__main__":
    for r in grade_pieces():
        print(r)
