#!/bin/bash
# Installs the reference engraver at /app/engraver and runs it on the three sample pieces, checking its
# rows against each piece's truth.tsv.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/engraver /app/out
cp "$HERE/engraver/beams.py" /app/engraver/beams.py
for piece in /app/pieces/*/; do
  name="$(basename "$piece")"
  python3 /app/engraver/beams.py "$piece" "/app/out/$name.tsv"
  python3 - "$piece/truth.tsv" "/app/out/$name.tsv" <<'EOF'
import csv, sys
def load(p):
    return {(r["bar"], r["position"], r["pitch"]): (r["stem"], r["beam"]) for r in csv.DictReader(open(p), delimiter="\t")}
want, got = load(sys.argv[1]), load(sys.argv[2])
wrong = sum(1 for k, v in want.items() if got.get(k) != v)
print("%s: %d of %d notes wrong" % (sys.argv[2], wrong, len(want)))
EOF
done
