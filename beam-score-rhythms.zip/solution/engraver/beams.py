#!/usr/bin/env python3
"""Engraves the stems and beams of a piece's remaining bars to match its house.

    python3 beams.py PIECE_DIR OUT_TSV

The standard rules of beaming and stem direction are applied everywhere; on each point the rules leave
to the house (eighths in 4/4 by beat or half-bar, in 3/4 by beat or bar; beams over short rests; secondary
beams broken at the subdivision or carried through; the syncopated eighth-quarter-eighth beamed across or
broken; balanced stems down or by majority; the division of 5/8, 7/8 and 6/4) every combination is tried
and the one that reproduces the hand-engraved bars exactly is kept; choices no bar of the piece can tell
apart are left at the common default.
"""
import csv
import itertools
import os
import sys
from fractions import Fraction as F

MENU = {
    "four_four": ("beat", "half"), "three_four": ("beat", "bar"), "rests": ("break", "span"),
    "secondary": ("beat", "through"), "sync": ("broken", "across"), "balanced": ("down", "majority"),
    "five": ("2+3", "3+2"), "seven": ("2+2+3", "3+2+2", "2+3+2"), "six_four": ("duple", "compound"),
}
DEFAULT = {k: v[0] for k, v in MENU.items()}
GROUP_STEMS = True        # a beamed group takes one stem direction from all its notes
STOP_AT_FIRST = False     # stop the search at the first house that reproduces the hand bars
SYNC_ANYWHERE = False     # recognise the syncopated figure wherever it starts, not only on a beat
STEPS = "CDEFGAB"
E, S, Q = F(1, 8), F(1, 16), F(1, 4)


def step_index(pitch):
    return (int(pitch[-1]) - 4) * 7 + STEPS.index(pitch[0]) - STEPS.index("B")


def frac(s):
    return F(s)


def read_piece(d):
    metres = []
    hand = set()
    with open(os.path.join(d, "PIECE.md"), encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("- bars ") and ":" in line:
                rng_part, m = line[2:].split(":")
                a, b = rng_part.replace("bars", "").split("to")
                num, den = m.strip().split("/")
                metres.append((int(a), int(b), (int(num), int(den))))
            if line.startswith("- Engraved by hand:"):
                for part in line.split(":", 1)[1].split(","):
                    a, b = part.replace("bars", "").split("to")
                    hand.update(range(int(a), int(b) + 1))
    bars = {}
    with open(os.path.join(d, "notes.tsv"), encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            b = int(row["bar"])
            pos, dur = frac(row["position"]), frac(row["duration"])
            evs = bars.setdefault(b, [])
            if row["kind"] == "note":
                for ev in evs:
                    if ev["position"] == pos and ev["kind"] == "note" and ev["duration"] == dur:
                        ev["pitches"].append(row["pitch"])
                        break
                else:
                    evs.append(dict(position=pos, duration=dur, kind="note", pitches=[row["pitch"]]))
            else:
                evs.append(dict(position=pos, duration=dur, kind="rest", pitches=[]))
    for b in bars:
        bars[b].sort(key=lambda e: (e["position"], e["kind"] != "note"))
    hand_rows = {}
    with open(os.path.join(d, "hand.tsv"), encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh, delimiter="\t"):
            hand_rows[(int(row["bar"]), row["position"], row["pitch"])] = (row["stem"], row["beam"])
    return metres, hand, bars, hand_rows


def metre_at(metres, b):
    for a, z, m in metres:
        if a <= b <= z:
            return m
    raise ValueError(b)


def spans(metre, house):
    num, den = metre
    bar = F(num, den)
    if metre == (4, 4):
        return even(bar, F(1, 2) if house["four_four"] == "half" else Q), Q
    if metre == (3, 4):
        return even(bar, F(3, 4) if house["three_four"] == "bar" else Q), Q
    if metre == (2, 4):
        return even(bar, Q), Q
    if metre in ((2, 2), (3, 2)):
        return even(bar, F(1, 2)), Q
    if metre in ((6, 8), (9, 8), (12, 8)):
        return even(bar, F(3, 8)), E
    if metre == (6, 4):
        return even(bar, F(3, 4) if house["six_four"] == "compound" else F(1, 2)), Q
    if metre == (5, 8):
        return parts([2, 3] if house["five"] == "2+3" else [3, 2]), E
    if metre == (7, 8):
        return parts([int(x) for x in house["seven"].split("+")]), E
    raise ValueError(metre)


def even(bar, unit):
    out, t = [], F(0)
    while t < bar:
        out.append((t, t + unit))
        t += unit
    return out


def parts(ps):
    out, t = [], F(0)
    for p in ps:
        out.append((t, t + F(p, 8)))
        t += F(p, 8)
    return out


def direction(pitches, house):
    steps = [step_index(p) for p in pitches]
    far = max(abs(s) for s in steps)
    if far == 0:
        return "down"
    above, below = any(s == far for s in steps), any(s == -far for s in steps)
    if above and not below:
        return "down"
    if below and not above:
        return "up"
    if house["balanced"] == "majority":
        ups, downs = sum(1 for s in steps if s > 0), sum(1 for s in steps if s < 0)
        if ups != downs:
            return "down" if ups > downs else "up"
    return "down"


def engrave_bar(events, metre, house):
    n = len(events)
    stem, beam = ["-"] * n, ["-"] * n
    primary, sub = spans(metre, house)
    groups, taken = [], set()
    if metre[1] in (2, 4) and house["sync"] == "across":
        for i in range(n - 2):
            a, b, c = events[i], events[i + 1], events[i + 2]
            if (a["kind"] == b["kind"] == c["kind"] == "note" and (a["duration"], b["duration"], c["duration"]) == (E, Q, E)
                    and b["position"] == a["position"] + E and c["position"] == b["position"] + Q
                    and (SYNC_ANYWHERE or a["position"] % Q == 0) and not taken & {i, i + 1, i + 2}):
                groups.append([i, i + 1, i + 2])
                taken |= {i, i + 1, i + 2}
    for s, e in primary:
        run = []
        for i, ev in enumerate(events):
            if not (s <= ev["position"] < e) or i in taken:
                continue
            if ev["kind"] == "note" and ev["duration"] <= E:
                run.append(i)
            elif ev["kind"] == "rest" and ev["duration"] < Q and house["rests"] == "span" and run:
                run.append(i)
            else:
                groups.append(run)
                run = []
        groups.append(run)
    for g in groups:
        while g and events[g[-1]]["kind"] == "rest":
            g = g[:-1]
        notes = [i for i in g if events[i]["kind"] == "note"]
        if len(notes) < 2:
            continue
        for k, i in enumerate(notes):
            beam[i] = "1b" if k == 0 else ("1e" if k == len(notes) - 1 else "1c")
        for k, i in enumerate(notes):
            ev = events[i]
            if ev["duration"] > S:
                continue

            def joined(j):
                o = events[j]
                if o["duration"] > S or abs(j - i) != 1:
                    return False
                return house["secondary"] == "through" or o["position"] // sub == ev["position"] // sub
            prev_ok = k > 0 and joined(notes[k - 1])
            next_ok = k < len(notes) - 1 and joined(notes[k + 1])
            if prev_ok and next_ok:
                beam[i] += "2c"
            elif prev_ok:
                beam[i] += "2e"
            elif next_ok:
                beam[i] += "2b"
            else:
                earlier = [j for j in g[:g.index(i)] if events[j]["kind"] == "note"]
                first = all(events[j]["position"] // sub != ev["position"] // sub for j in earlier)
                beam[i] += "2f" if first else "2h"
        if GROUP_STEMS:
            d = direction([p for i in notes for p in events[i]["pitches"]], house)
            for i in notes:
                stem[i] = d
    for i, ev in enumerate(events):
        if ev["kind"] == "note" and stem[i] == "-":
            stem[i] = direction(ev["pitches"], house)
    return stem, beam


def fmt(fr):
    return "%d/%d" % (fr.numerator, fr.denominator) if fr.denominator != 1 else "%d" % fr.numerator


def engrave(bars, metres, house, which):
    out = {}
    for b in sorted(bars):
        if b not in which:
            continue
        stem, beam = engrave_bar(bars[b], metre_at(metres, b), house)
        for i, ev in enumerate(bars[b]):
            if ev["kind"] == "note":
                for p in ev["pitches"]:
                    out[(b, fmt(ev["position"]), p)] = (stem[i], beam[i])
    return out


def main(piece_dir, out_tsv):
    metres, hand, bars, hand_rows = read_piece(piece_dir)
    keys = list(MENU)
    best, best_miss = None, None
    for combo in itertools.product(*[MENU[k] for k in keys]):
        house = dict(zip(keys, combo))
        got = engrave(bars, metres, house, hand)
        miss = sum(1 for key, v in hand_rows.items() if got.get(key) != v)
        if best_miss is None or miss < best_miss or (miss == best_miss and
                                                    sum(house[k] != DEFAULT[k] for k in keys) <
                                                    sum(best[k] != DEFAULT[k] for k in keys)):
            best, best_miss = house, miss
        if miss == 0 and (STOP_AT_FIRST or all(house[k] == DEFAULT[k] for k in keys)):
            break
    rest = {b for b in bars if b not in hand}
    got = engrave(bars, metres, best, rest)
    with open(out_tsv, "w", encoding="utf-8", newline="") as fh:
        fh.write("bar\tposition\tpitch\tstem\tbeam\n")
        for b in sorted(rest):
            for ev in bars[b]:
                if ev["kind"] == "note":
                    for p in ev["pitches"]:
                        s, bm = got[(b, fmt(ev["position"]), p)]
                        fh.write("%d\t%s\t%s\t%s\t%s\n" % (b, fmt(ev["position"]), p, s, bm))
    sys.stderr.write("house %s (hand misses %d)\n" % (best, best_miss))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
