The motet edition I look after supplies musica ficta above the staff, and every volume's editor supplies it a little differently. Before a volume goes to the engraver I have to confirm that each motet carries the accidentals its own editor would have put there, and I would rather have a program work that out from the editor's opening section than read every cadence myself. The program is /app/ficta/supply.py:

```
python3 /app/ficta/supply.py MOTET_DIR OUT_CSV
```

MOTET_DIR is a motet folder: notes.csv with the voices as the choirbook has them, signature.csv, and opening.csv listing the editor's supplied accidentals for the notes of the opening section. The file formats, the pitch spelling and the way an accidental is filed are in /app/edition/HANDBOOK.md. The three motets under /app/edition/motets each carry a ficta.csv with their editor's accidentals for the whole piece.

OUT_CSV takes the same columns as ficta.csv, with a row for each note that opening.csv leaves out, holding the accidental the editor supplies there or none.

Twenty more motets, built inside the grading image, are kept back for marking. Each comes from a different volume, so its opening section settles the handbook's six questions in its own way, and the three samples between them do not cover every settlement. A motet is marked right only when every one of its later notes agrees with the editor's file; a row that is absent is a disagreement. Eighteen of the twenty must be right.

The marking run copies the folder to a clean location and runs the program under an unprivileged account on the image's python3, with numpy 2.2.6 installed and otherwise the standard library; after 60 seconds a run is killed. Keep everything the program needs inside /app/ficta, since nothing outside it is kept.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
