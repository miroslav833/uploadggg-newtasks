"""Supplies the edition's accidentals for the later notes of a motet.

    python3 supply.py MOTET_DIR OUT_CSV

The volume's practice (six respects) is read from the editor's own accidentals over the opening:
every practice is tried, and the one that reproduces opening.csv exactly is applied to the rest.
"""
import csv
import itertools
import math
import os
import sys

LETTERS = "CDEFGAB"
SEMI = [0, 2, 4, 5, 7, 9, 11]
VOICE_NAMES = ["cantus", "altus", "tenor", "bassus"]
RANGES = {"cantus": (29, 39), "altus": (25, 35), "tenor": (22, 32), "bassus": (18, 28)}
RESPECTS = ["unsuspended", "leap", "remedy", "filled", "fa_super_la", "forgo_cross"]
VALUES = {"unsuspended": ["no", "yes"], "leap": ["no", "yes"], "remedy": ["flat", "raise"],
          "filled": ["no", "yes"], "fa_super_la": ["no", "yes"], "forgo_cross": ["no", "yes"]}
PRACTICES = [dict(zip(RESPECTS, vals)) for vals in itertools.product(*[VALUES[r] for r in RESPECTS])]
WORDS = {1: "sharp", -1: "flat", 0: "natural"}


def span(a, b):
    """The diatonic distance between two pitches, both finite integers."""
    if not (math.isfinite(a) and math.isfinite(b)):
        raise ValueError("pitch is not finite")
    return abs(a - b)


def L(p):
    return p % 7


def sig_infl(p, signature):
    return -1 if (signature == "flat" and L(p) == 6) else 0


def midi(p, infl):
    return 12 * (p // 7) + SEMI[L(p)] + 12 + infl


def interval_ok(plo, ilo, phi, ihi, bass):
    """Consonance of two sounding pitches, plo the lower; bass: plo is the lowest voice."""
    steps = (phi - plo) % 7
    semis = (midi(phi, ihi) - midi(plo, ilo)) % 12
    if steps == 0:
        return semis == 0
    if steps == 2:
        return semis in (3, 4)
    if steps == 3:
        return semis == 5 and not bass
    if steps == 4:
        return semis == 7
    if steps == 5:
        return semis in (8, 9)
    return False


def tritone(pa, ia, pb, ib):
    steps = span(pa, pb) % 7
    return steps in (3, 4) and (midi(pa, ia) - midi(pb, ib)) % 12 == 6


def by_voice(motet):
    out = [[] for _ in motet["voices"]]
    for n in motet["notes"]:
        out[n["voice"]].append(n)
    for v in out:
        v.sort(key=lambda n: n["onset"])
    return out


def sounding(voices, t):
    """One note per voice sounding at minim t (None if none)."""
    out = []
    for notes in voices:
        hit = None
        lo, hi = 0, len(notes)
        while lo < hi:
            mid = (lo + hi) // 2
            if notes[mid]["onset"] <= t:
                lo = mid + 1
            else:
                hi = mid
        if lo and notes[lo - 1]["onset"] + notes[lo - 1]["dur"] > t:
            hit = notes[lo - 1]
        out.append(hit)
    return out


def find_cadences(motet, voices):
    """Each cadence: dict(t, goal, cant, voice, susp, kind in {"vera", "leap", "phrygian"})."""
    sig = motet["signature"]
    phryg = 2 if sig == "none" else 5  # E or A
    out = []
    ends = {}
    for vi, notes in enumerate(voices):
        for k, n in enumerate(notes):
            ends.setdefault(n["onset"] + n["dur"], []).append((vi, k))
    for ci, cnotes in enumerate(voices):
        for k in range(1, len(cnotes)):
            g = cnotes[k]
            T = g["onset"]
            if T % 2 or g["dur"] < 2:
                continue
            l = cnotes[k - 1]
            if l["onset"] + l["dur"] != T or l["dur"] > 2 or l["p"] != g["p"] - 1:
                continue
            susp = (l["dur"] == 1 and k >= 2 and cnotes[k - 2]["onset"] == T - 3 and cnotes[k - 2]["dur"] == 2
                    and cnotes[k - 2]["p"] == g["p"])
            ten = None
            bas = None
            others = set()
            for vi, k2 in ends.get(T, []):
                if vi == ci:
                    continue
                prev = voices[vi][k2]
                nxt = voices[vi][k2 + 1] if k2 + 1 < len(voices[vi]) else None
                if nxt is None or nxt["onset"] != T or L(nxt["p"]) != L(g["p"]):
                    continue
                if prev["p"] == nxt["p"] + 1 and prev["dur"] >= 2:
                    ten = vi
                    others.update({(vi, prev["index"]), (vi, nxt["index"])})
                if (prev["p"] - nxt["p"]) % 7 == 4 and vi == len(voices) - 1:
                    bas = vi
                    others.update({(vi, prev["index"]), (vi, nxt["index"])})
            if ten is not None:
                kind = "phrygian" if L(g["p"]) == phryg else "vera"
            elif bas is not None and susp:
                kind = "leap"
            else:
                continue
            out.append({"t": T, "goal": g, "cant": l, "voice": ci, "susp": susp, "kind": kind, "others": others})
    return out


def supply(motet, practice, alt=frozenset()):
    """Inflection per note (parallel to motet["notes"]) and the event log."""
    sig = motet["signature"]
    notes = motet["notes"]
    voices = by_voice(motet)
    infl = {}
    fixed = set()
    for n in notes:
        key = (n["voice"], n["index"])
        if n["written"] is not None:
            infl[key] = n["written"]
            fixed.add(key)
        else:
            infl[key] = sig_infl(n["p"], sig)
    log = []
    cad_notes = set()
    for c in find_cadences(motet, voices):
        l, g = c["cant"], c["goal"]
        kl = (l["voice"], l["index"])
        cad_notes.add(kl)
        cad_notes.add((g["voice"], g["index"]))
        cad_notes.update(c["others"])
        whole = (midi(g["p"], infl[(g["voice"], g["index"])]) - midi(l["p"], infl[kl])) == 2
        if c["kind"] == "phrygian" or not whole or kl in fixed:
            continue
        if c["kind"] == "vera":
            raise_it = c["susp"] or practice["unsuspended"] == "yes"
        else:
            raise_it = practice["leap"] == "yes"
        if not raise_it:
            continue
        natural = sig_infl(l["p"], sig)
        T = c["t"]
        if "breve_window" in alt:
            lo, hi = 4 * ((T - 1) // 4), 4 * ((T - 1) // 4) + 4
        else:
            lo, hi = T - 3, T + 2
        clash = False
        for vi, vn in enumerate(voices):
            if vi == l["voice"]:
                continue
            for n in vn:
                if L(n["p"]) == L(l["p"]) and infl[(vi, n["index"])] == natural:
                    a, b = n["onset"], n["onset"] + n["dur"]
                    if a < hi and b > lo and not (a < T and b > T - 1):
                        clash = True
        if clash and practice["forgo_cross"] == "yes":
            log.append(("forgone", kl))
            continue
        infl[kl] = natural + 1
        fixed.add(kl)
        log.append(("raise", kl))
    fixed |= cad_notes
    base = dict(infl)
    seen = infl if "no_chain" not in alt else base
    end = max(n["onset"] + n["dur"] for n in notes)
    times = range(0, end, 1 if "all_minims" in alt else 2)
    fa_letter = 6 if sig == "none" else 2  # B in durus, E in mollis
    rounds = 3 if "depth3" in alt else 6
    for _ in range(rounds):
        changed = False
        for t in times:
            snd = sounding(voices, t)
            if "onset_only" in alt:
                snd = [n if (n is not None and n["onset"] == t) else None for n in snd]
            present = [n for n in snd if n is not None]
            for a, b in itertools.combinations(present, 2):
                ka, kb = (a["voice"], a["index"]), (b["voice"], b["index"])
                if not tritone(a["p"], seen[ka], b["p"], seen[kb]):
                    continue
                if infl[ka] != seen[ka] or infl[kb] != seen[kb]:
                    continue
                free = [k for k, n in ((ka, a), (kb, b)) if k not in fixed]
                if not free:
                    raise ValueError("tritone between fixed notes at %d" % t)
                # mi is the note whose lowering perfects the pair (the lower note of a diminished
                # fifth, the upper of an augmented fourth); fa the one whose raising does
                lo_k, hi_k = (ka, kb) if a["p"] < b["p"] else (kb, ka)
                fifth = (span(a["p"], b["p"]) % 7) == 4
                mi, fa = (lo_k, hi_k) if fifth else (hi_k, lo_k)
                if len(free) == 2:
                    if practice["remedy"] == "flat":
                        infl[mi] -= 1
                        fixed.add(mi)
                        log.append(("flat", mi))
                    else:
                        infl[fa] += 1
                        fixed.add(fa)
                        log.append(("raise", fa))
                else:
                    k = free[0]
                    if k == mi:
                        infl[k] -= 1
                        log.append(("chain-flat", k))
                    else:
                        infl[k] += 1
                        log.append(("chain-raise", k))
                    fixed.add(k)
                changed = True
        for vi, vn in enumerate(voices):
            for k in range(1, len(vn)):
                key = (vi, vn[k]["index"])
                if key in fixed:
                    continue
                p = vn[k]["p"]
                if L(p) != fa_letter or infl[key] != sig_infl(p, sig):
                    continue
                nxt = vn[k + 1]["p"] if k + 1 < len(vn) else None
                peak = (nxt is not None and nxt < p) or "no_peak" in alt
                direct = vn[k - 1]["p"] == p - 3 and infl[(vi, vn[k - 1]["index"])] == sig_infl(p - 3, sig)
                filled = (k >= 3 and all(vn[k - j]["p"] == p - j for j in (1, 2, 3))
                          and infl[(vi, vn[k - 3]["index"])] == sig_infl(p - 3, sig))
                if "wide_outline" in alt and wide_outline(vn, k, infl, sig, practice):
                    direct = peak = True
                if peak and (direct or (filled and practice["filled"] == "yes")):
                    infl[key] -= 1
                    fixed.add(key)
                    log.append(("outline", key))
                    changed = True
                    continue
                if (practice["fa_super_la"] == "yes" and vn[k]["dur"] <= 2 and nxt == p - 1
                        and vn[k - 1]["p"] == p - 1):
                    infl[key] -= 1
                    fixed.add(key)
                    log.append(("super-la", key))
                    changed = True
        if not changed:
            break
    else:
        if rounds > 3:
            raise ValueError("no fixed point")
    return [infl[(n["voice"], n["index"])] for n in notes], log


def wide_outline(vn, k, infl, sig, practice):
    """The reading that counts a tritone outlined in either direction, as a fourth or a fifth, by
    leap or (under the practice) by step, with no turn required: True when note k is its fa."""
    vi = vn[k]["voice"]
    p = vn[k]["p"]
    lo_letter = 3 if sig == "none" else 6

    def natural(j):
        return infl[(vi, vn[j]["index"])] == sig_infl(vn[j]["p"], sig)

    for j in (k - 1, k + 1):
        if 0 <= j < len(vn) and L(vn[j]["p"]) == lo_letter and span(vn[j]["p"], p) in (3, 4) and natural(j):
            return True
    if practice["filled"] != "yes":
        return False
    for d in (-1, 1):
        for n in (3, 4):
            j = k + d * n
            if not (0 <= j < len(vn)) or L(vn[j]["p"]) != lo_letter or not natural(j):
                continue
            sgn = 1 if vn[j]["p"] > p else -1
            if span(vn[j]["p"], p) == n and all(vn[k + d * m]["p"] == p + sgn * m for m in range(1, n + 1)):
                return True
    return False


def filed(motet, infl):
    """The accidental word per note as the edition files it."""
    out = []
    for n, i in zip(motet["notes"], infl):
        if n["written"] is not None or i == sig_infl(n["p"], motet["signature"]):
            out.append("none")
        else:
            out.append(WORDS[i])
    return out


# ----------------------------------------------------------------------------------------------
# Files and the fit
# ----------------------------------------------------------------------------------------------

ACC = {"none": None, "sharp": 1, "flat": -1, "natural": 0}


def read_motet(folder):
    rows = list(csv.DictReader(open(os.path.join(folder, "notes.csv"), newline="")))
    sig = {r["voice"]: r["signature"] for r in csv.DictReader(open(os.path.join(folder, "signature.csv"), newline=""))}
    voices = [v for v in VOICE_NAMES if any(r["voice"] == v for r in rows)]
    notes = []
    for r in rows:
        notes.append({"voice": voices.index(r["voice"]), "index": int(r["index"]), "onset": int(r["onset"]),
                      "dur": int(r["duration"]), "p": 7 * int(r["octave"]) + LETTERS.index(r["letter"]),
                      "written": ACC[r["accidental"]]})
    notes.sort(key=lambda n: (n["voice"], n["index"]))
    signature = sig[voices[0]]
    opening = {}
    for r in csv.DictReader(open(os.path.join(folder, "opening.csv"), newline="")):
        opening[(voices.index(r["voice"]), int(r["index"]))] = r["accidental"]
    return {"signature": signature, "voices": voices, "notes": notes}, opening


def main():
    folder, out = sys.argv[1], sys.argv[2]
    motet, opening = read_motet(folder)
    keys = [(n["voice"], n["index"]) for n in motet["notes"]]
    fits = []
    for pr in PRACTICES:
        try:
            infl, _ = supply(motet, pr)
        except ValueError:
            continue
        f = filed(motet, infl)
        if all(f[i] == opening[k] for i, k in enumerate(keys) if k in opening):
            fits.append((pr, f))
    if not fits:
        f = filed(motet, [sig_infl(n["p"], motet["signature"]) for n in motet["notes"]])
    else:
        f = fits[0][1]
    with open(out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["voice", "index", "accidental"])
        for i, k in enumerate(keys):
            if k not in opening:
                w.writerow([motet["voices"][k[0]], k[1], f[i]])


if __name__ == "__main__":
    main()
