#!/bin/bash
# Installs the supply program and checks it against the three sample motets' ficta.csv.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/ficta
cp "$HERE/ficta/supply.py" /app/ficta/supply.py
for motet in /app/edition/motets/*/; do
    code=$(basename "$motet")
    python3 /app/ficta/supply.py "$motet" "/tmp/supply_$code.csv"
    python3 - "$motet" "/tmp/supply_$code.csv" <<'EOF'
import csv, sys
motet, out = sys.argv[1], sys.argv[2]
truth = {(r["voice"], r["index"]): r["accidental"] for r in csv.DictReader(open(motet + "/ficta.csv", newline=""))}
opening = {(r["voice"], r["index"]) for r in csv.DictReader(open(motet + "/opening.csv", newline=""))}
got = {(r["voice"], r["index"]): r["accidental"] for r in csv.DictReader(open(out, newline=""))}
later = {k: v for k, v in truth.items() if k not in opening}
wrong = sum(1 for k, v in later.items() if got.get(k) != v)
print("%s: %d later notes, %d differ" % (motet.rstrip("/").split("/")[-1], len(later), wrong))
EOF
done
