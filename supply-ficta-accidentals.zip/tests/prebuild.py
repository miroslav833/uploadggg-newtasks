"""Builds the edition's motets.

    python3 prebuild.py graded MOTETS_DIR TRUTH_DIR [SEED]   # twenty held-back motets and their sealed ficta
    python3 prebuild.py samples MOTETS_DIR [SEED]            # three sample motets with ficta.csv inside

A motet folder holds notes.csv, signature.csv and opening.csv (the editor's accidentals over the
opening section); a truth folder holds ficta.csv (every note) and practice.txt. The plan gives each
respect's two values to ten motets each and mixes three- and four-voice motets.
"""
import csv
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import motet_world as W  # noqa: E402

GRADED_SEED = 20261026
SAMPLE_SEED = 73
WORD = {None: "none", 1: "sharp", -1: "flat", 0: "natural"}


def plan(rng, count):
    """Practices with each respect's values split evenly, in a random order."""
    cols = {}
    for r in W.RESPECTS:
        half = count // 2
        vals = [W.VALUES[r][0]] * half + [W.VALUES[r][1]] * (count - half)
        rng.shuffle(vals)
        cols[r] = vals
    return [{r: cols[r][i] for r in W.RESPECTS} for i in range(count)]


def code(rng, taken):
    while True:
        c = "".join(rng.choice(list("abcdefghjkmnpqrstuvwxyz")) for _ in range(2)) + "%02d" % rng.integers(10, 99)
        if c not in taken:
            taken.add(c)
            return c


def make(rng, practice, nvoices, signature=None):
    while True:
        res, why = W.settle(rng, practice, nvoices=nvoices, signature=signature)
        if res is None:
            continue
        motet, infl, truth, log = res
        W.scribe(rng, motet, infl)
        infl2, _ = W.supply(motet, practice)
        if infl2 != infl:
            continue
        return motet, infl, W.filed(motet, infl)


def write_motet(folder, motet, truth, full):
    os.makedirs(folder, exist_ok=True)
    notes = sorted(motet["notes"], key=lambda n: (n["voice"], n["index"]))
    with open(os.path.join(folder, "notes.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["voice", "index", "onset", "duration", "letter", "octave", "accidental"])
        for n in notes:
            w.writerow([motet["voices"][n["voice"]], n["index"], n["onset"], n["dur"], W.LETTERS[W.L(n["p"])],
                        n["p"] // 7, WORD[n["written"]]])
    with open(os.path.join(folder, "signature.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["voice", "signature"])
        for name in motet["voices"]:
            w.writerow([name, motet["signature"]])
    idx = {(n["voice"], n["index"]): i for i, n in enumerate(motet["notes"])}
    with open(os.path.join(folder, "opening.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["voice", "index", "accidental"])
        for n in notes:
            if n["onset"] < motet["opening_end"]:
                w.writerow([motet["voices"][n["voice"]], n["index"], truth[idx[(n["voice"], n["index"])]]])
    if full:
        with open(os.path.join(folder, "ficta.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["voice", "index", "accidental"])
            for n in notes:
                w.writerow([motet["voices"][n["voice"]], n["index"], truth[idx[(n["voice"], n["index"])]]])


def write_truth(folder, motet, truth, practice):
    os.makedirs(folder, exist_ok=True)
    write_motet(folder, motet, truth, full=True)
    for name in ("notes.csv", "signature.csv", "opening.csv"):
        os.remove(os.path.join(folder, name))
    with open(os.path.join(folder, "practice.txt"), "w") as fh:
        for r in W.RESPECTS:
            fh.write("%s %s\n" % (r, practice[r]))
        fh.write("opening_end %d\n" % motet["opening_end"])
        fh.write("settled yes\n")


def main():
    mode = sys.argv[1]
    if mode == "graded":
        out, truth_dir = sys.argv[2], sys.argv[3]
        seed = int(sys.argv[4]) if len(sys.argv) > 4 else GRADED_SEED
        count = 20
    else:
        out = sys.argv[2]
        seed = int(sys.argv[3]) if len(sys.argv) > 3 else SAMPLE_SEED
        count = 3
    rng = np.random.default_rng(seed)
    practices = plan(rng, count)
    voices = [3, 4] * (count // 2) + [3] * (count % 2)
    rng.shuffle(voices)
    signatures = [None] * count if mode == "graded" else ["none", "flat", "none"]
    taken = set()
    for i, practice in enumerate(practices):
        r = np.random.default_rng([seed, i])
        motet, infl, truth = make(r, practice, int(voices[i]), signatures[i])
        c = code(rng, taken)
        if mode == "graded":
            write_motet(os.path.join(out, c), motet, truth, full=False)
            write_truth(os.path.join(truth_dir, c), motet, truth, practice)
        else:
            write_motet(os.path.join(out, c), motet, truth, full=True)
        rest = W.rest_keys(motet)
        print(c, motet["signature"], len(motet["voices"]), "voices, later accidentals",
              sum(1 for k in rest if truth[k] != "none"), flush=True)


if __name__ == "__main__":
    main()
