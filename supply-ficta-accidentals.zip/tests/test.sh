#!/usr/bin/env bash
# Acceptance run. Root takes /logs/verifier first (chown, chmod 700) and confirms it with stat; if
# that cannot be done the grade is 0 and the uploaded program never starts. Leftover reward, result
# and score entries and anything root does not own are removed, and the grade is set to 0 before the
# checks run. The program only runs inside the checks, under an unused uid. The removal is repeated
# before the grade is written for the last time.
set -u
LOGS=/logs/verifier
JOURNAL=/run/ficta-journal
first_mode=$(stat -c %a "$LOGS" 2>/dev/null || echo 755)

sweep() {
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) -exec rm -rf {} + 2>/dev/null
}
mark() {
    sweep
    (umask 022; echo "$1" > "$LOGS/reward.txt")
}

mkdir -p "$LOGS"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null
owner_mode=$(stat -c '%u:%a' "$LOGS" 2>/dev/null)
if [ "$owner_mode" != "0:700" ]; then
    mark 0
    echo "acceptance: /logs/verifier is $owner_mode, not root-only; program not run" >&2
    chmod "$first_mode" "$LOGS" 2>/dev/null
    exit 0
fi
mark 0
chmod 700 /tests; chmod -R go-rwx /tests 2>/dev/null
install -d -o 0 -g 0 -m 700 "$JOURNAL"
chmod -R a+rX /app/ficta 2>/dev/null

if (cd /tests && python3 -m pytest -q -p no:cacheprovider --ctrf "$JOURNAL/ctrf.json" test_motets.py); then
    mark 1
else
    mark 0
fi
for name in ctrf.json motets.txt; do
    [ -f "$JOURNAL/$name" ] && (umask 022; cp "$JOURNAL/$name" "$LOGS/$name")
done
chmod "$first_mode" "$LOGS" 2>/dev/null
exit 0
