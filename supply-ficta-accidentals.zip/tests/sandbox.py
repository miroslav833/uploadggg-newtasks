"""Runs the uploaded supply program on one queued motet at a time, as a uid nobody uses.

run_motet(code, uid) copies the motet folder into /var/tmp/ficta-runs/<code>, hands the copy to the
uid and starts python3 on the program with a pre-exec function that drops root (new session, no
supplementary groups, setgid, setuid) and sets hard limits. When the program ends or 60 seconds
pass, every process of the uid is killed and the output is read back as text: a regular file of at
most 1 MiB opened without following links, parsed as the rows of ficta.csv."""
import csv
import io
import os
import resource
import shutil
import signal
import subprocess
import time

QUEUE = "/tests/queue"
AREA = "/var/tmp/ficta-runs"
JOURNAL = "/run/ficta-journal"
PROGRAM = "/app/ficta/supply.py"
WAIT = 60
LIMIT = 1 << 20


def motets():
    return sorted(os.listdir(os.path.join(QUEUE, "motets")))


def free_uid(lowest=65400):
    busy = set()
    for pid in os.listdir("/proc"):
        if pid.isdigit():
            try:
                busy.add(os.stat("/proc/" + pid).st_uid)
            except OSError:
                pass
    while lowest in busy:
        lowest += 1
    return lowest


def _drop(uid):
    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        for res, cap in ((resource.RLIMIT_AS, 3 << 30), (resource.RLIMIT_NPROC, 64),
                         (resource.RLIMIT_FSIZE, 32 << 20), (resource.RLIMIT_CORE, 0)):
            resource.setrlimit(res, (cap, cap))
    return drop


def _kill_uid(uid):
    for _ in range(200):
        mine = []
        for pid in os.listdir("/proc"):
            if pid.isdigit():
                try:
                    if os.stat("/proc/" + pid).st_uid == uid:
                        mine.append(int(pid))
                except OSError:
                    pass
        if not mine:
            return
        for pid in mine:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        time.sleep(0.03)


def run_motet(code, uid):
    """{(voice, index): accidental} from the program's output, or None when it wrote nothing usable."""
    place = os.path.join(AREA, code)
    shutil.rmtree(place, ignore_errors=True)
    shutil.copytree(os.path.join(QUEUE, "motets", code), os.path.join(place, "motet"), symlinks=False)
    os.makedirs(os.path.join(place, "scratch"))
    for root, dirs, files in os.walk(place):
        os.chown(root, uid, uid)
        for f in files:
            os.chown(os.path.join(root, f), uid, uid)
    scratch = os.path.join(place, "scratch")
    out = os.path.join(place, "out.csv")
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": scratch, "TMPDIR": scratch, "LANG": "C.UTF-8",
           "OPENBLAS_NUM_THREADS": "2", "OMP_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
    with open(os.path.join(JOURNAL, code + ".log"), "wb") as log:
        proc = subprocess.Popen(["/usr/local/bin/python3", PROGRAM, os.path.join(place, "motet"), out],
                                cwd=scratch, env=env, stdin=subprocess.DEVNULL, stdout=log,
                                stderr=subprocess.STDOUT, preexec_fn=_drop(uid))
        try:
            proc.wait(timeout=WAIT)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    _kill_uid(uid)
    rows = read_rows(out)
    shutil.rmtree(place, ignore_errors=True)
    return rows


def read_rows(path):
    try:
        st = os.lstat(path)
    except OSError:
        return None
    if os.path.islink(path) or not os.path.isfile(path) or st.st_size > LIMIT:
        return None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        text = os.read(fd, LIMIT + 1).decode("utf-8", "replace")
    finally:
        os.close(fd)
    return parse_rows(text)


def parse_rows(text):
    """{(voice, index): accidental}; a row with the wrong shape is skipped."""
    out = {}
    for row in csv.DictReader(io.StringIO(text)):
        if row.get("voice") is None or row.get("index") is None or row.get("accidental") is None:
            continue
        out[(row["voice"].strip(), row["index"].strip())] = row["accidental"].strip()
    return out
