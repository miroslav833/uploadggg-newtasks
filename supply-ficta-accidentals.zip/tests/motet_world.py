"""The edition's motets: the pitch model, the editor's pass, the composer and the settledness check.

A motet is {"signature": "none"|"flat", "voices": [name, ...], "notes": [note, ...], "opening_end": N}
where a note is {"voice": i, "index": k, "onset": minims, "dur": minims, "p": diatonic pitch,
"written": -1|0|1|None}. Diatonic pitch p: letter p % 7 (C D E F G A B), octave p // 7 (C4 = 28).
The breve is four minims; a strong minim is an even onset.

supply(motet, practice) is the editor's pass: every note's inflection (-1 flat, 0 natural, +1 sharp)
under a practice of six respects; filed() turns inflections into the words of ficta.csv.
"""
import itertools
import math

import numpy as np

LETTERS = "CDEFGAB"
SEMI = [0, 2, 4, 5, 7, 9, 11]
VOICE_NAMES = ["cantus", "altus", "tenor", "bassus"]
RANGES = {"cantus": (29, 39), "altus": (25, 35), "tenor": (22, 32), "bassus": (18, 28)}
RESPECTS = ["unsuspended", "leap", "remedy", "filled", "fa_super_la", "forgo_cross"]
VALUES = {"unsuspended": ["no", "yes"], "leap": ["no", "yes"], "remedy": ["flat", "raise"],
          "filled": ["no", "yes"], "fa_super_la": ["no", "yes"], "forgo_cross": ["no", "yes"]}
PRACTICES = [dict(zip(RESPECTS, vals)) for vals in itertools.product(*[VALUES[r] for r in RESPECTS])]
WORDS = {1: "sharp", -1: "flat", 0: "natural"}


def span(a, b):
    """The diatonic distance between two pitches, both finite integers."""
    if not (math.isfinite(a) and math.isfinite(b)):
        raise ValueError("pitch is not finite")
    return abs(a - b)


def L(p):
    return p % 7


def sig_infl(p, signature):
    return -1 if (signature == "flat" and L(p) == 6) else 0


def midi(p, infl):
    return 12 * (p // 7) + SEMI[L(p)] + 12 + infl


def interval_ok(plo, ilo, phi, ihi, bass):
    """Consonance of two sounding pitches, plo the lower; bass: plo is the lowest voice."""
    steps = (phi - plo) % 7
    semis = (midi(phi, ihi) - midi(plo, ilo)) % 12
    if steps == 0:
        return semis == 0
    if steps == 2:
        return semis in (3, 4)
    if steps == 3:
        return semis == 5 and not bass
    if steps == 4:
        return semis == 7
    if steps == 5:
        return semis in (8, 9)
    return False


def tritone(pa, ia, pb, ib):
    steps = span(pa, pb) % 7
    return steps in (3, 4) and (midi(pa, ia) - midi(pb, ib)) % 12 == 6


# ----------------------------------------------------------------------------------------------
# The editor's pass
# ----------------------------------------------------------------------------------------------

def by_voice(motet):
    out = [[] for _ in motet["voices"]]
    for n in motet["notes"]:
        out[n["voice"]].append(n)
    for v in out:
        v.sort(key=lambda n: n["onset"])
    return out


def sounding(voices, t):
    """One note per voice sounding at minim t (None if none)."""
    out = []
    for notes in voices:
        hit = None
        lo, hi = 0, len(notes)
        while lo < hi:
            mid = (lo + hi) // 2
            if notes[mid]["onset"] <= t:
                lo = mid + 1
            else:
                hi = mid
        if lo and notes[lo - 1]["onset"] + notes[lo - 1]["dur"] > t:
            hit = notes[lo - 1]
        out.append(hit)
    return out


def find_cadences(motet, voices):
    """Each cadence: dict(t, goal, cant, voice, susp, kind in {"vera", "leap", "phrygian"})."""
    sig = motet["signature"]
    phryg = 2 if sig == "none" else 5  # E or A
    out = []
    ends = {}
    for vi, notes in enumerate(voices):
        for k, n in enumerate(notes):
            ends.setdefault(n["onset"] + n["dur"], []).append((vi, k))
    for ci, cnotes in enumerate(voices):
        for k in range(1, len(cnotes)):
            g = cnotes[k]
            T = g["onset"]
            if T % 2 or g["dur"] < 2:
                continue
            l = cnotes[k - 1]
            if l["onset"] + l["dur"] != T or l["dur"] > 2 or l["p"] != g["p"] - 1:
                continue
            susp = (l["dur"] == 1 and k >= 2 and cnotes[k - 2]["onset"] == T - 3 and cnotes[k - 2]["dur"] == 2
                    and cnotes[k - 2]["p"] == g["p"])
            ten = None
            bas = None
            others = set()
            for vi, k2 in ends.get(T, []):
                if vi == ci:
                    continue
                prev = voices[vi][k2]
                nxt = voices[vi][k2 + 1] if k2 + 1 < len(voices[vi]) else None
                if nxt is None or nxt["onset"] != T or L(nxt["p"]) != L(g["p"]):
                    continue
                if prev["p"] == nxt["p"] + 1 and prev["dur"] >= 2:
                    ten = vi
                    others.update({(vi, prev["index"]), (vi, nxt["index"])})
                if (prev["p"] - nxt["p"]) % 7 == 4 and vi == len(voices) - 1:
                    bas = vi
                    others.update({(vi, prev["index"]), (vi, nxt["index"])})
            if ten is not None:
                kind = "phrygian" if L(g["p"]) == phryg else "vera"
            elif bas is not None and susp:
                kind = "leap"
            else:
                continue
            out.append({"t": T, "goal": g, "cant": l, "voice": ci, "susp": susp, "kind": kind, "others": others})
    return out


def supply(motet, practice, alt=frozenset()):
    """Inflection per note (parallel to motet["notes"]) and the event log."""
    sig = motet["signature"]
    notes = motet["notes"]
    voices = by_voice(motet)
    infl = {}
    fixed = set()
    for n in notes:
        key = (n["voice"], n["index"])
        if n["written"] is not None:
            infl[key] = n["written"]
            fixed.add(key)
        else:
            infl[key] = sig_infl(n["p"], sig)
    log = []
    cad_notes = set()
    for c in find_cadences(motet, voices):
        l, g = c["cant"], c["goal"]
        kl = (l["voice"], l["index"])
        cad_notes.add(kl)
        cad_notes.add((g["voice"], g["index"]))
        cad_notes.update(c["others"])
        whole = (midi(g["p"], infl[(g["voice"], g["index"])]) - midi(l["p"], infl[kl])) == 2
        if c["kind"] == "phrygian" or not whole or kl in fixed:
            continue
        if c["kind"] == "vera":
            raise_it = c["susp"] or practice["unsuspended"] == "yes"
        else:
            raise_it = practice["leap"] == "yes"
        if not raise_it:
            continue
        natural = sig_infl(l["p"], sig)
        T = c["t"]
        if "breve_window" in alt:
            lo, hi = 4 * ((T - 1) // 4), 4 * ((T - 1) // 4) + 4
        else:
            lo, hi = T - 3, T + 2
        clash = False
        for vi, vn in enumerate(voices):
            if vi == l["voice"]:
                continue
            for n in vn:
                if L(n["p"]) == L(l["p"]) and infl[(vi, n["index"])] == natural:
                    a, b = n["onset"], n["onset"] + n["dur"]
                    if a < hi and b > lo and not (a < T and b > T - 1):
                        clash = True
        if clash and practice["forgo_cross"] == "yes":
            log.append(("forgone", kl))
            continue
        infl[kl] = natural + 1
        fixed.add(kl)
        log.append(("raise", kl))
    fixed |= cad_notes
    base = dict(infl)
    seen = infl if "no_chain" not in alt else base
    end = max(n["onset"] + n["dur"] for n in notes)
    times = range(0, end, 1 if "all_minims" in alt else 2)
    fa_letter = 6 if sig == "none" else 2  # B in durus, E in mollis
    rounds = 3 if "depth3" in alt else 6
    for _ in range(rounds):
        changed = False
        for t in times:
            snd = sounding(voices, t)
            if "onset_only" in alt:
                snd = [n if (n is not None and n["onset"] == t) else None for n in snd]
            present = [n for n in snd if n is not None]
            for a, b in itertools.combinations(present, 2):
                ka, kb = (a["voice"], a["index"]), (b["voice"], b["index"])
                if not tritone(a["p"], seen[ka], b["p"], seen[kb]):
                    continue
                if infl[ka] != seen[ka] or infl[kb] != seen[kb]:
                    continue
                free = [k for k, n in ((ka, a), (kb, b)) if k not in fixed]
                if not free:
                    raise ValueError("tritone between fixed notes at %d" % t)
                # mi is the note whose lowering perfects the pair (the lower note of a diminished
                # fifth, the upper of an augmented fourth); fa the one whose raising does
                lo_k, hi_k = (ka, kb) if a["p"] < b["p"] else (kb, ka)
                fifth = (span(a["p"], b["p"]) % 7) == 4
                mi, fa = (lo_k, hi_k) if fifth else (hi_k, lo_k)
                if len(free) == 2:
                    if practice["remedy"] == "flat":
                        infl[mi] -= 1
                        fixed.add(mi)
                        log.append(("flat", mi))
                    else:
                        infl[fa] += 1
                        fixed.add(fa)
                        log.append(("raise", fa))
                else:
                    k = free[0]
                    if k == mi:
                        infl[k] -= 1
                        log.append(("chain-flat", k))
                    else:
                        infl[k] += 1
                        log.append(("chain-raise", k))
                    fixed.add(k)
                changed = True
        for vi, vn in enumerate(voices):
            for k in range(1, len(vn)):
                key = (vi, vn[k]["index"])
                if key in fixed:
                    continue
                p = vn[k]["p"]
                if L(p) != fa_letter or infl[key] != sig_infl(p, sig):
                    continue
                nxt = vn[k + 1]["p"] if k + 1 < len(vn) else None
                peak = (nxt is not None and nxt < p) or "no_peak" in alt
                direct = vn[k - 1]["p"] == p - 3 and infl[(vi, vn[k - 1]["index"])] == sig_infl(p - 3, sig)
                filled = (k >= 3 and all(vn[k - j]["p"] == p - j for j in (1, 2, 3))
                          and infl[(vi, vn[k - 3]["index"])] == sig_infl(p - 3, sig))
                if "wide_outline" in alt and wide_outline(vn, k, infl, sig, practice):
                    direct = peak = True
                if peak and (direct or (filled and practice["filled"] == "yes")):
                    infl[key] -= 1
                    fixed.add(key)
                    log.append(("outline", key))
                    changed = True
                    continue
                if (practice["fa_super_la"] == "yes" and vn[k]["dur"] <= 2 and nxt == p - 1
                        and vn[k - 1]["p"] == p - 1):
                    infl[key] -= 1
                    fixed.add(key)
                    log.append(("super-la", key))
                    changed = True
        if not changed:
            break
    else:
        if rounds > 3:
            raise ValueError("no fixed point")
    return [infl[(n["voice"], n["index"])] for n in notes], log


def wide_outline(vn, k, infl, sig, practice):
    """The reading that counts a tritone outlined in either direction, as a fourth or a fifth, by
    leap or (under the practice) by step, with no turn required: True when note k is its fa."""
    vi = vn[k]["voice"]
    p = vn[k]["p"]
    lo_letter = 3 if sig == "none" else 6

    def natural(j):
        return infl[(vi, vn[j]["index"])] == sig_infl(vn[j]["p"], sig)

    for j in (k - 1, k + 1):
        if 0 <= j < len(vn) and L(vn[j]["p"]) == lo_letter and span(vn[j]["p"], p) in (3, 4) and natural(j):
            return True
    if practice["filled"] != "yes":
        return False
    for d in (-1, 1):
        for n in (3, 4):
            j = k + d * n
            if not (0 <= j < len(vn)) or L(vn[j]["p"]) != lo_letter or not natural(j):
                continue
            sgn = 1 if vn[j]["p"] > p else -1
            if span(vn[j]["p"], p) == n and all(vn[k + d * m]["p"] == p + sgn * m for m in range(1, n + 1)):
                return True
    return False


def filed(motet, infl):
    """The accidental word per note as the edition files it."""
    out = []
    for n, i in zip(motet["notes"], infl):
        if n["written"] is not None or i == sig_infl(n["p"], motet["signature"]):
            out.append("none")
        else:
            out.append(WORDS[i])
    return out


def check_consonance(motet, infl):
    """Every strong-minim sonority consonant under these inflections (suspension minims excepted)."""
    voices = by_voice(motet)
    key = {(n["voice"], n["index"]): i for n, i in zip(motet["notes"], infl)}
    end = max(n["onset"] + n["dur"] for n in motet["notes"])
    susp = set(motet.get("suspensions", ()))
    for t in range(0, end, 2):
        if t in susp:
            continue
        snd = [n for n in sounding(voices, t) if n is not None]
        snd.sort(key=lambda n: n["p"])
        for i, a in enumerate(snd):
            for b in snd[i + 1:]:
                if not interval_ok(a["p"], key[(a["voice"], a["index"])], b["p"], key[(b["voice"], b["index"])], i == 0):
                    return False
    return True


# ----------------------------------------------------------------------------------------------
# Composer
# ----------------------------------------------------------------------------------------------

GOALS = {"none": {"whole": [1, 4, 5], "cross": [1, 4], "semi": [0], "phryg": 2},
         "flat": {"whole": [4, 0, 1], "cross": [4, 0], "semi": [3], "phryg": 5}}
SPAN = {"vertical": 1, "weak": 2, "chain": 2, "direct": 2, "filled": 3, "superla": 2}


class Phrase:
    def __init__(self, start, breves, goal, kind, susp, cross, plants):
        self.start = start
        self.breves = breves
        self.T = start + 4 * (breves - 1)
        self.goal = goal
        self.kind = kind  # vera, leap, phrygian
        self.susp = susp
        self.cross = cross
        self.plants = plants


def rng_pick(rng, seq):
    return seq[int(rng.integers(len(seq)))]


class Composer:
    def __init__(self, rng, signature, nvoices, practice):
        self.rng = rng
        self.sig = signature
        self.nv = nvoices
        self.names = ["cantus", "tenor", "bassus"] if nvoices == 3 else list(VOICE_NAMES)
        self.practice = practice
        self.fa = 6 if signature == "none" else 2  # B or E: the letter outlines and super-la flatten
        self.lo = 3 if signature == "none" else 6  # F or B(flat): the lower note of the outline
        self.la = 5 if signature == "none" else 1  # A or D
        self.req = {}  # (voice, onset) -> (p, dur or None)
        self.near = {}  # (voice, onset) -> pitch the voice must stay within two steps of
        self.forbid = {}  # onset -> letter no free voice may sing there
        self.avoid = {}  # (voice, onset) -> letters the voice must not sing there (before a plant)
        self.exempt = {}  # onset -> voice whose dissonance is a suspension
        self.tri = set()  # strong minims whose planted tritone pair is allowed
        self.notes = [[] for _ in range(nvoices)]
        self.noplant = set()
        self.suspensions = set()
        self.planted = []

    def place(self, letter, voice, near, lo=None, hi=None):
        a, b = RANGES[self.names[voice]]
        cands = [p for p in range(a, b + 1) if L(p) == letter and (lo is None or p > lo) and (hi is None or p < hi)]
        if not cands:
            return None
        return min(cands, key=lambda p: (abs(p - near), p))

    def last_p(self, voice):
        return self.notes[voice][-1]["p"] if self.notes[voice] else sum(RANGES[self.names[voice]]) // 2

    def recent(self, voice, k):
        return [n["p"] for n in self.notes[voice][-k:]]

    def melodic_ok(self, voice, p, t, pending=()):
        """A free note p for this voice at onset t; pending: strong-minim pitches chosen but not yet
        added (the chord at t - 2 while its weak minim is still open)."""
        pending = list(pending)
        rec = self.recent(voice, 4 - len(pending)) + pending
        if rec:
            prev = rec[-1]
            if span(p, prev) > 7 or span(p, prev) == 6:
                return False
            last_onset = t - 2 if pending else self.notes[voice][-1]["onset"]
            if (voice, last_onset) in self.noplant and p == prev:
                return False
            if L(p) == self.fa and prev == p - 1 and L(prev) == self.la:
                return False
        if any(L(q) == self.lo for q in rec) and L(p) == self.fa:
            return False
        if any(L(q) == self.fa for q in rec) and L(p) == self.lo:
            return False
        if t in self.forbid and L(p) == self.forbid[t]:
            return False
        if L(p) in self.avoid.get((voice, t), ()):
            return False
        if (voice, t) in self.near and span(p, self.near[(voice, t)]) > 3:
            return False
        return True

    def weak_ok(self, q, p_next):
        """A weak-minim note q before the already chosen strong note p_next: no outline, no step
        from la onto the note above it."""
        if L(q) == self.lo and L(p_next) == self.fa:
            return False
        if L(q) == self.fa and L(p_next) == self.lo:
            return False
        if L(q) == self.la and p_next == q + 1:
            return False
        return True

    def converges(self, prev, cur, v):
        """Voice v would step into a letter that another voice steps into by contrary motion: the
        clausula formula, which only the cadence frames may write."""
        if prev[v] is None or cur[v] is None or span(cur[v], prev[v]) != 1:
            return False
        up = cur[v] - prev[v]
        for w in range(self.nv):
            if w == v or prev[w] is None or cur[w] is None:
                continue
            if L(cur[w]) == L(cur[v]) and cur[w] - prev[w] == -up:
                return True
        return False

    def add(self, voice, onset, dur, p, planted=False):
        if self.notes[voice]:
            last = self.notes[voice][-1]
            assert last["onset"] + last["dur"] == onset, (voice, onset, last)
        self.notes[voice].append({"voice": voice, "onset": onset, "dur": dur, "p": p, "written": None})
        if planted:
            self.noplant.add((voice, onset))

    def chord_ok(self, pitches, t):
        placed = sorted((p, v) for v, p in enumerate(pitches) if p is not None)
        lowest = placed[0][0]
        for i, (pa, va) in enumerate(placed):
            for pb, vb in placed[i + 1:]:
                if self.exempt.get(t) in (va, vb):
                    continue
                ia, ib = sig_infl(pa, self.sig), sig_infl(pb, self.sig)
                if t in self.tri and tritone(pa, ia, pb, ib):
                    continue
                if not interval_ok(pa, ia, pb, ib, pa == lowest and i == 0):
                    return False
        return True

    def parallel(self, prev, cur, va, vb):
        if prev[va] is None or prev[vb] is None or cur[va] is None or cur[vb] is None:
            return False
        if prev[va] == cur[va] or prev[vb] == cur[vb]:
            return False
        d0 = (prev[va] - prev[vb]) % 7
        d1 = (cur[va] - cur[vb]) % 7
        return d0 == d1 and d0 in (0, 4) and (cur[va] - prev[va]) * (cur[vb] - prev[vb]) > 0

    def held(self, v, t):
        """The pitch a voice is still holding at strong minim t, or None."""
        if self.notes[v]:
            last = self.notes[v][-1]
            if last["onset"] + last["dur"] > t:
                return last["p"]
        r = self.req.get((v, t - 2))
        if r and r[0] != "letter" and r[1] == 4:
            return r[0]
        return None

    def chord(self, t, prev):
        for _ in range(80):
            cur = [None] * self.nv
            letter_req = {}
            for v in range(self.nv):
                if (v, t) in self.req:
                    if self.req[(v, t)][0] == "letter":
                        letter_req[v] = self.req[(v, t)][1]
                    else:
                        cur[v] = self.req[(v, t)][0]
                else:
                    h = self.held(v, t)
                    if h is not None:
                        cur[v] = h
            ok = True
            for v in range(self.nv - 1, -1, -1):
                if cur[v] is not None:
                    continue
                last = prev[v] if prev[v] is not None else self.last_p(v)
                a, b = RANGES[self.names[v]]
                lower = max([cur[w] for w in range(v + 1, self.nv) if cur[w] is not None], default=None)
                upper = min([cur[w] for w in range(0, v) if cur[w] is not None], default=None)
                cands, weights = [], []
                for d in range(-7, 8):
                    p = last + d
                    if p < a or p > b:
                        continue
                    if v in letter_req and L(p) != letter_req[v]:
                        continue
                    if lower is not None and p < lower:
                        continue
                    if upper is not None and p > upper:
                        continue
                    pend = [prev[v]] if (prev[v] is not None and not (self.notes[v] and self.notes[v][-1]["onset"] + self.notes[v][-1]["dur"] >= t)) else []
                    if not self.melodic_ok(v, p, t, pend):
                        continue
                    trial = list(cur)
                    trial[v] = p
                    if not self.chord_ok(trial, t):
                        continue
                    if any(self.parallel(prev, trial, v, w) for w in range(self.nv) if w != v and cur[w] is not None):
                        continue
                    if self.converges(prev, trial, v):
                        continue
                    w = {0: 3.0, 1: 4.0, 2: 2.5, 3: 1.0, 4: 0.8, 5: 0.3, 7: 0.15}.get(abs(d), 0.0)
                    if v == self.nv - 1 and span(d, 0) in (3, 4):
                        w = 2.0
                    if w > 0:
                        cands.append(p)
                        weights.append(w)
                if not cands:
                    ok = False
                    break
                w = np.array(weights) / sum(weights)
                cur[v] = cands[int(self.rng.choice(len(cands), p=w))]
            if ok:
                return cur
        return None

    def fill(self, v, t, prev, cur):
        """Voice v's notes from strong minim t to t + 2, given the chords at t (prev) and t + 2 (cur)."""
        p_now, p_next = prev[v], cur[v]
        if self.notes[v] and self.notes[v][-1]["onset"] + self.notes[v][-1]["dur"] > t:
            return

        def steps_in(q):
            # a weak note q that steps up into the next strong note while another voice steps down
            # onto the same letter would write the clausula formula
            if p_next is None or q != p_next - 1:
                return False
            return any(w != v and prev[w] is not None and cur[w] is not None and L(cur[w]) == L(p_next)
                       and prev[w] == cur[w] + 1 for w in range(self.nv))

        if (v, t + 1) in self.req:
            q = self.req[(v, t + 1)][0]
            if q == "letter":
                letter = self.req[(v, t + 1)][1]
                q = p_now - 1 if L(p_now - 1) == letter else p_now + 1
            self.add(v, t, 1, p_now, planted=(v, t) in self.req)
            self.add(v, t + 1, 1, q, planted=True)
            return
        if (v, t) in self.req and self.req[(v, t)][0] != "letter":
            q, d = self.req[(v, t)]
            if d in (2, 4):
                self.add(v, t, d, p_now, planted=True)
                return
            if d == 1:
                if p_next is not None and span(p_next, p_now) == 2:
                    mid = (p_now + p_next) // 2
                    if self.melodic_ok(v, mid, t + 1, [p_now]) and self.weak_ok(mid, p_next) and not steps_in(mid):
                        self.add(v, t, 1, p_now, planted=True)
                        self.add(v, t + 1, 1, mid)
                        return
                self.add(v, t, 1, p_now, planted=True)
                self.add(v, t + 1, 1, p_now)
                return
        if p_next is None:
            self.add(v, t, 2, p_now)
            return
        r = self.rng.random()
        if span(p_next, p_now) == 2 and r < 0.6:
            mid = (p_now + p_next) // 2
            if self.melodic_ok(v, mid, t + 1, [p_now]) and self.weak_ok(mid, p_next) and not steps_in(mid):
                self.add(v, t, 1, p_now)
                self.add(v, t + 1, 1, mid)
                return
        if p_next == p_now and r < 0.35:
            for q in self.rng.permutation([p_now - 1, p_now + 1]):
                q = int(q)
                a, b = RANGES[self.names[v]]
                if (a <= q <= b and self.melodic_ok(v, q, t + 1, [p_now]) and self.weak_ok(q, p_next)
                        and not steps_in(q) and not (L(q) == self.fa and q == p_now + 1)):
                    self.add(v, t, 1, p_now)
                    self.add(v, t + 1, 1, q)
                    return
        self.add(v, t, 2, p_now)

    def plant_frames(self, kind, t, roles):
        """Letter frames {onset: {voice: (letter, dur)}} for a body plant at strong minim t."""
        req = {}
        sig = self.sig
        C, D, E, F, G, A, B = range(7)
        bass = self.nv - 1
        others = [v for v in range(self.nv) if v != bass]
        if kind == "vertical":
            x, y = roles
            root, fa_, mi_ = (D, F, B) if sig == "none" else (G, B, E)
            frame = {bass: (root, 2), x: (mi_, 2), y: (fa_, 2)}
            for v in others:
                frame.setdefault(v, (root, 2))
            req[t] = frame
            self.tri.add(t)
        elif kind == "weak":
            x, y = roles
            if sig == "none":
                req[t] = {y: (F, 2), x: (A, 1)}
                req[t + 1] = {x: (B, 1)}
                req[t + 2] = {x: (C, None)}
            else:
                req[t] = {y: (B, 2), x: (D, 1)}
                req[t + 1] = {x: (E, 1)}
                req[t + 2] = {x: (F, None)}
        elif kind == "chain":
            x, y = roles
            if self.practice["remedy"] == "flat":
                if sig == "none":
                    req[t] = {bass: (D, 2), x: (B, 4), y: (F, 2)}
                    req[t + 2] = {bass: (E, 2), y: (G, 2)}
                else:
                    req[t] = {bass: (G, 2), x: (E, 4), y: (B, 2)}
                    req[t + 2] = {bass: (A, 2), y: (C, 2)}
            else:
                if sig == "none":
                    req[t] = {bass: (D, 2), y: (F, 4), x: (B, 2)}
                    req[t + 2] = {bass: (A, 2), x: (C, 2)}
                else:
                    req[t] = {bass: (G, 2), y: (B, 4), x: (E, 2)}
                    req[t + 2] = {bass: (D, 2), x: (F, 2)}
            for v in others:
                if v not in req[t]:
                    req[t][v] = (req[t][bass][0], 2)
                    req[t + 2][v] = (req[t + 2][bass][0], 2)
            self.tri.add(t)
            self.tri.add(t + 2)
        elif kind == "direct":
            x = roles[0]
            req[t] = {x: (self.lo, 1)}
            req[t + 1] = {x: (self.fa, 1)}
            req[t + 2] = {x: ((self.fa - 1) % 7, None)}
        elif kind == "filled":
            x = roles[0]
            req[t] = {x: (self.lo, 1)}
            req[t + 1] = {x: ((self.lo + 1) % 7, 1)}
            req[t + 2] = {x: ((self.lo + 2) % 7, 1)}
            req[t + 3] = {x: (self.fa, 1)}
            req[t + 4] = {x: ((self.fa - 2) % 7, None)}
        elif kind == "superla":
            x = roles[0]
            req[t] = {x: (self.la, 1)}
            req[t + 1] = {x: (self.fa, 1)}
            req[t + 2] = {x: (self.la, None)}
        return req

    def realise(self, frames, anchor):
        """Letter frames into pitch requirements. Each voice's notes are placed in one line: the
        first nearest the voice's position, each later one nearest the one before (so a figure keeps
        its contour and stays in range); the frame's voices never cross at a shared minim."""
        seqs = {}
        for t in sorted(frames):
            for v, (letter, dur) in frames[t].items():
                seqs.setdefault(v, []).append((t, letter, dur))
        order = sorted(seqs, reverse=True)
        chosen = {}

        def options(v):
            a, b = RANGES[self.names[v]]
            firsts = sorted([p for p in range(a, b + 1) if L(p) == seqs[v][0][1]],
                            key=lambda p: (abs(p - anchor[v]), p))
            out = []
            for p0 in firsts:
                seq = [p0]
                for t, letter, dur in seqs[v][1:]:
                    cands = [p for p in range(a, b + 1) if L(p) == letter and span(p, seq[-1]) <= 3]
                    if not cands:
                        break
                    seq.append(min(cands, key=lambda p: (abs(p - seq[-1]), p)))
                else:
                    out.append(seq)
            return out

        def search(i):
            if i == len(order):
                return True
            v = order[i]
            for seq in options(v):
                good = True
                for (t, _, _), p in zip(seqs[v], seq):
                    for w in order[:i]:
                        for (t2, _, _), q in zip(seqs[w], chosen[w]):
                            if t2 == t and q > p:
                                good = False
                if good:
                    chosen[v] = seq
                    if search(i + 1):
                        return True
                    del chosen[v]
            return False

        if not search(0):
            return False
        for v in chosen:
            for (t, letter, dur), p in zip(seqs[v], chosen[v]):
                self.req[(v, t)] = (p, dur)
        return True


def compose(rng, practice, nvoices=None, signature=None):
    """One motet with its phrase plan, or None when the walk fails."""
    sig = signature or rng_pick(rng, ["none", "flat"])
    nv = nvoices or int(rng.choice([3, 4]))
    c = Composer(rng, sig, nv, practice)
    G = GOALS[sig]
    opening_kinds = ["vera-unsusp", "leap", "vera-cross"]
    rng.shuffle(opening_kinds)
    body_pool = ["vertical", "chain", "filled", "superla", "direct", "weak"]
    rng.shuffle(body_pool)
    rest_cads = ["vera-unsusp", "vera-unsusp", "leap", "leap", "vera-cross", "vera-cross", "phrygian", "vera-semi"]
    rng.shuffle(rest_cads)
    rest_body = ["vertical", "vertical", "chain", "chain", "filled", "filled", "superla", "superla", "direct", "weak",
                 "vertical", "filled", "superla", "chain"]
    extra = rest_body[10:]
    rng.shuffle(extra)
    rest_body = rest_body[:10] + extra[: 2 * len(rest_cads) - 10]
    rng.shuffle(rest_body)
    cads = opening_kinds + rest_cads
    bodies = [body_pool[:2], body_pool[2:4], body_pool[4:6]] + [rest_body[2 * i: 2 * i + 2] for i in range(len(rest_cads))]
    plan = []
    t = 0
    for i, kind in enumerate(cads):
        breves = int(rng.integers(5, 8))
        if kind == "phrygian":
            goal, ck, susp, cross = G["phryg"], "phrygian", bool(rng.random() < 0.5), False
        elif kind == "leap":
            goal, ck, susp, cross = rng_pick(rng, G["whole"]), "leap", True, False
        elif kind == "vera-unsusp":
            goal, ck, susp, cross = rng_pick(rng, G["whole"]), "vera", False, False
        elif kind == "vera-cross":
            goal, ck, susp, cross = rng_pick(rng, G["cross"]), "vera", True, True
        else:
            goal, ck, susp, cross = rng_pick(rng, G["semi"]), "vera", bool(rng.random() < 0.5), False
        plan.append(Phrase(t, breves, goal, ck, susp, cross, bodies[i]))
        t += 4 * breves
    opening_end = plan[3].start
    if not build(c, plan):
        return None
    notes = []
    for v in range(nv):
        for k, n in enumerate(c.notes[v]):
            n["index"] = k
            notes.append(n)
    return {"signature": sig, "voices": c.names, "notes": notes, "opening_end": opening_end,
            "suspensions": sorted(c.suspensions), "plants": list(c.planted),
            "plan": [(p.kind, p.T, p.susp, p.cross, list(p.plants)) for p in plan]}


FAILS = []


def build(c, plan):
    nv, bass = c.nv, c.nv - 1
    prev = [None] * nv
    last_T = plan[-1].T
    for ph in plan:
        c.req.clear()
        c.near.clear()
        c.forbid.clear()
        c.exempt.clear()
        c.avoid.clear()
        if ph.kind == "phrygian":
            cant = 0 if nv == 3 else rng_pick(c.rng, [0, 1])
            ten = bass
        elif nv == 3:
            cant, ten = 0, 1
        else:
            cant, ten = rng_pick(c.rng, [(0, 2), (1, 2), (0, 1)])
        T, g = ph.T, ph.goal
        # body plants: slots now, pitches when the walk reaches them
        body_slots = list(range(ph.start + 2, T - 6, 2))
        used = set()
        plants = []
        for kind in ph.plants:
            width = SPAN[kind]
            free = [s for s in body_slots if all((s + 2 * j) not in used and (s + 2 * j) < T - 4 for j in range(width))]
            if not free:
                return False
            s = rng_pick(c.rng, free)
            for j in range(width + 1):
                used.add(s + 2 * j)
            if kind in ("vertical", "chain", "weak"):
                roles = [int(r) for r in c.rng.permutation([v for v in range(nv) if v != bass])[:2]]
                if kind == "weak":
                    roles.sort()
            else:
                roles = [int(c.rng.integers(nv))]
            plants.append((s, kind, roles))
            c.planted.append((kind, s, roles))
            for v in roles:
                for tt in (s - 2, s - 1):
                    c.avoid[(v, tt)] = {c.lo, c.fa, (c.lo + 1) % 7, c.la}
        if ph.kind == "leap":
            c.forbid[T - 2] = L(g + 1)
        gp = None
        t = ph.start
        while t <= T:
            pos = {v: (prev[v] if prev[v] is not None else c.last_p(v)) for v in range(nv)}
            for s, kind, roles in plants:
                if s == t and not c.realise(c.plant_frames(kind, s, roles), pos):
                    return False
            if t == T - 4:
                # the cantizans' goal, with the tenorizans an octave below it
                a_t, b_t = RANGES[c.names[ten]]
                a_c, b_c = RANGES[c.names[cant]]
                gp = tp = None
                a_b, b_b = RANGES[c.names[bass]]
                for q in sorted([q for q in range(a_c, b_c + 1) if L(q) == g], key=lambda q: (abs(q - pos[cant]), q)):
                    if ph.kind == "leap":
                        if any(L(r) == g and r < q for r in range(a_b, b_b + 1)):
                            gp = q
                            break
                        continue
                    for cand in (q - 7, q):
                        if cand == q and ph.kind == "phrygian":
                            continue
                        if a_t <= cand <= b_t and (ph.kind == "phrygian" or any(L(r) == g and r < cand for r in range(a_b, b_b + 1))):
                            gp, tp = q, cand
                            break
                    if gp is not None:
                        break
                if gp is None:
                    return False
                lp = gp - 1
                c.req[(cant, T)] = (gp, 4)
                if ph.susp:
                    c.req[(cant, T - 2)] = (gp, 2)
                    c.req[(cant, T - 1)] = (lp, 1)
                    c.near[(cant, T - 4)] = gp
                    c.exempt[T - 2] = cant
                    c.suspensions.add(T - 2)
                else:
                    c.req[(cant, T - 2)] = (lp, 2)
                if L(lp) == c.fa:
                    for tt in (T - 6, T - 5, T - 4, T - 3):
                        c.avoid.setdefault((cant, tt), set()).add(c.lo)
                if tp is not None:
                    c.req[(ten, T - 2)] = (tp + 1, 2)
                    c.req[(ten, T)] = (tp, 4)
                    if L(tp + 1) == c.fa:
                        for tt in (T - 4, T - 3):
                            c.avoid.setdefault((ten, tt), set()).update({c.lo, c.la})
                bp = None
                if ph.kind != "phrygian":
                    bp = c.place(g, bass, pos[bass], hi=tp if tp is not None else gp)
                    if bp is None:
                        return False
                    c.req[(bass, T)] = (bp, 4)
                    ceiling = min(q for q in (tp + 1 if tp is not None else None, c.req[(cant, T - 2)][0]) if q is not None)
                    a, b = RANGES[c.names[bass]]
                    cands = [q for q in (bp + 4, bp - 3) if a <= q <= b and q < ceiling]
                    if not cands:
                        return False
                    c.req[(bass, T - 2)] = (min(cands, key=lambda q: abs(q - pos[bass])), 2)
                for tt in (T - 4, T - 3, T - 2, T - 1):
                    c.forbid.setdefault(tt, L(lp))
                if ph.cross:
                    cross_voice = None
                    for v in [int(x) for x in c.rng.permutation([v for v in range(nv) if v != cant and v != bass])]:
                        a, b = RANGES[c.names[v]]
                        if L(lp + 1) in c.avoid.get((v, T - 4), ()) or L(lp) in c.avoid.get((v, T - 3), ()):
                            continue
                        if any(L(q) == L(lp + 1) and span(q, pos[v]) <= 5 and a < q <= b for q in range(a, b + 1)):
                            cross_voice = v
                            break
                    if cross_voice is None:
                        return False
                    c.req[(cross_voice, T - 4)] = ("letter", L(lp + 1), 1)
                    c.req[(cross_voice, T - 3)] = ("letter", L(lp), 1)
            if t == T:
                letters = (L(gp), L(gp + 4)) if T == last_T else (L(gp), L(gp + 2), L(gp + 4))
                for v in range(nv):
                    if (v, T) in c.req:
                        continue
                    lower = max([c.req[(w, T)][0] for w in range(v + 1, nv) if (w, T) in c.req], default=None)
                    upper = min([c.req[(w, T)][0] for w in range(0, v) if (w, T) in c.req], default=None)
                    a, b = RANGES[c.names[v]]
                    cands = [q for q in range(a, b + 1) if L(q) in letters and span(q, pos[v]) <= 7
                             and (lower is None or q >= lower) and (upper is None or q <= upper)
                             and c.melodic_ok(v, q, T, [pos[v]])]
                    trial = [c.req.get((w, T), (None,))[0] for w in range(nv)]
                    good = []
                    for q in cands:
                        trial[v] = q
                        if not any(c.parallel(prev, trial, v, w) for w in range(nv) if w != v and trial[w] is not None):
                            good.append(q)
                    if good:
                        c.req[(v, T)] = (min(good, key=lambda q: (abs(q - pos[v]), q)), 4)
            cur = None
            for _ in range(12):
                cur = c.chord(t, prev)
                if cur is None:
                    break
                if t + 2 > T or c.chord(t + 2, cur) is not None:
                    break
                cur = None
            if cur is None:
                FAILS.append((T - t, {k: v for k, v in c.req.items() if k[1] == t}, dict(c.forbid), dict(c.near), c.exempt.get(t)))
                return False
            if t > ph.start:
                for v in range(nv):
                    c.fill(v, t - 2, prev, cur)
            prev = cur
            t += 2
        for v in range(nv):
            if c.notes[v] and c.notes[v][-1]["onset"] + c.notes[v][-1]["dur"] > T:
                return False
            c.add(v, T, 4, prev[v], planted=True)
        if ph.susp:
            fix_suspension(c, cant, T, gp)
        prev = [c.notes[v][-1]["p"] for v in range(nv)]
    # the formula must occur at the planned cadences only
    notes = []
    for v in range(nv):
        for k, n in enumerate(c.notes[v]):
            n["index"] = k
            notes.append(n)
    found = sorted(cd["t"] for cd in find_cadences({"signature": c.sig, "voices": c.names, "notes": notes}, c.notes))
    if found != sorted(ph.T for ph in plan):
        return False
    return True


def fix_suspension(c, cant, T, gp):
    notes = c.notes[cant]
    keep = [n for n in notes if n["onset"] < T - 4 or n["onset"] >= T]
    seg = [n for n in notes if T - 4 <= n["onset"] < T]
    first = seg[0]["p"]
    new = [{"voice": cant, "onset": T - 4, "dur": 1, "p": first, "written": None},
           {"voice": cant, "onset": T - 3, "dur": 2, "p": gp, "written": None},
           {"voice": cant, "onset": T - 1, "dur": 1, "p": gp - 1, "written": None}]
    c.notes[cant] = sorted(keep + new, key=lambda n: n["onset"])


# ----------------------------------------------------------------------------------------------
# Settledness
# ----------------------------------------------------------------------------------------------

ALTS = [frozenset(), frozenset(["onset_only"]), frozenset(["all_minims"]), frozenset(["breve_window"]),
        frozenset(["no_chain"]), frozenset(["no_peak"]), frozenset(["wide_outline"])]


def opening_keys(motet):
    return [i for i, n in enumerate(motet["notes"]) if n["onset"] < motet["opening_end"]]


def rest_keys(motet):
    return [i for i, n in enumerate(motet["notes"]) if n["onset"] >= motet["opening_end"]]


def consistent(motet, truth_filed, alt=frozenset()):
    """(practice, filed) for every practice whose pass under this reading reproduces the opening."""
    op = opening_keys(motet)
    out = []
    for pr in PRACTICES:
        try:
            infl, _ = supply(motet, pr, alt)
        except ValueError:
            continue
        f = filed(motet, infl)
        if all(f[i] == truth_filed[i] for i in op):
            out.append((pr, f))
    return out


def settle(rng, practice, min_cost=2, nvoices=None, signature=None):
    """A motet under this practice that passes every check: (motet, infl, truth, log) or
    (None, reason)."""
    motet = compose(rng, practice, nvoices, signature)
    if motet is None:
        return None, "compose"
    try:
        infl, log = supply(motet, practice)
    except ValueError:
        return None, "pass"
    truth = filed(motet, infl)
    rest = rest_keys(motet)
    for pr in PRACTICES:
        try:
            i2, _ = supply(motet, pr)
        except ValueError:
            return None, "practice invalid"
        if not check_consonance(motet, i2):
            return None, "practice dissonant"
    for alt in ALTS:
        cons = consistent(motet, truth, alt)
        if not alt and [pr for pr, _ in cons] != [practice]:
            return None, "opening pins %d" % len(cons)
        for pr, f in cons:
            if any(f[i] != truth[i] for i in rest):
                return None, "reading " + "+".join(sorted(alt)) + " unsettled"
    for r in RESPECTS:
        pr = dict(practice)
        pr[r] = [v for v in VALUES[r] if v != practice[r]][0]
        i2, _ = supply(motet, pr)
        f = filed(motet, i2)
        if sum(1 for i in rest if f[i] != truth[i]) < min_cost:
            return None, "single " + r
    i2, _ = supply(motet, practice, frozenset(["no_chain"]))
    f = filed(motet, i2)
    if sum(1 for i in rest if f[i] != truth[i]) < min_cost:
        return None, "single chains"
    if sum(1 for i in rest if truth[i] != "none") < 12:
        return None, "sparse"
    return (motet, infl, truth, log), "ok"


def scribe(rng, motet, infl, share=0.15):
    """The scribe writes a share of the later accidentals; the pass must give the same inflections."""
    rest = rest_keys(motet)
    cands = [i for i in rest if infl[i] != sig_infl(motet["notes"][i]["p"], motet["signature"])]
    k = int(round(share * len(cands)))
    for i in rng.choice(cands, size=k, replace=False) if k else []:
        motet["notes"][int(i)]["written"] = infl[int(i)]
    return motet
