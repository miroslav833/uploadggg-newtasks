"""Acceptance of the supply program.

The queue is checked first: twenty motets, each sealed ficta.csv covering every note of its
notes.csv, every opening note listed in opening.csv with the sealed accidental, each motet settled
(its practice record says so) and the six respects split ten and ten. Then the program must give the
later notes of at least 18 motets exactly as the sealed file has them."""
import csv
import os

import pytest

import sandbox

NEED = 18
SLIP = 0
RESPECTS = ["unsuspended", "leap", "remedy", "filled", "fa_super_la", "forgo_cross"]


def rows(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return {(r["voice"], r["index"]): r["accidental"] for r in csv.DictReader(fh)}


@pytest.fixture(scope="session")
def queue():
    out = {}
    for code in sandbox.motets():
        truth_dir = os.path.join(sandbox.QUEUE, "truth", code)
        motet_dir = os.path.join(sandbox.QUEUE, "motets", code)
        truth = rows(os.path.join(truth_dir, "ficta.csv"))
        opening = rows(os.path.join(motet_dir, "opening.csv"))
        with open(os.path.join(truth_dir, "practice.txt"), encoding="utf-8") as fh:
            practice = dict(line.split()[:2] for line in fh if line.strip())
        out[code] = (truth, opening, practice)
    return out


def test_twenty_motets_sealed(queue):
    assert len(queue) == 20
    for code, (truth, opening, _) in queue.items():
        notes = rows(os.path.join(sandbox.QUEUE, "motets", code, "notes.csv"))
        assert set(notes) == set(truth), code
        assert set(opening) < set(truth), code
        assert all(truth[k] == v for k, v in opening.items()), code
        assert all(v in ("none", "sharp", "flat", "natural") for v in truth.values()), code
        later = [k for k in truth if k not in opening]
        assert sum(1 for k in later if truth[k] != "none") >= 2 * (SLIP + 1), code


def test_every_motet_settled_and_the_plan_balanced(queue):
    for code, (_, _, practice) in queue.items():
        assert practice.get("settled") == "yes", code
    for r in RESPECTS:
        values = [practice[r] for _, _, practice in queue.values()]
        assert len(set(values)) == 2 and values.count(values[0]) == 10, r


def test_program_reaches_the_mark(queue):
    uid = sandbox.free_uid()
    passed = []
    for code, (truth, opening, _) in queue.items():
        got = sandbox.run_motet(code, uid) or {}
        later = {k: v for k, v in truth.items() if k not in opening}
        wrong = sum(1 for k, v in later.items() if got.get(k) != v)
        if wrong <= SLIP:
            passed.append(code)
    with open(os.path.join(sandbox.JOURNAL, "motets.txt"), "w", encoding="utf-8") as fh:
        fh.write("".join("%s %s\n" % (c, "pass" if c in passed else "fail") for c in queue))
    assert len(passed) >= NEED, "%d of %d motets supplied; %d needed" % (len(passed), len(queue), NEED)
