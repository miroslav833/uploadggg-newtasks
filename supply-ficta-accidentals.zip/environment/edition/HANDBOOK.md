# The motet edition: files and conventions

This is the working handbook of a complete-works edition of a sixteenth-century chapel's motets.
The choirbooks write few accidentals. Each volume of the edition is prepared by one editor, who
supplies above the staff the accidentals the singers would have added, and the series editor
checks every volume for consistency before it goes to the engraver. The motets in the queue are
transcribed into the files described here, and the volume editor's accidentals over each motet's
opening section are filed alongside so that the rest of the motet can be checked against them.

## A motet folder

`notes.csv`: one row per note, every voice in turn.

```
voice,index,onset,duration,letter,octave,accidental
cantus,0,0,2,D,5,none
```

- `voice` is `cantus`, `altus`, `tenor` or `bassus`; a motet has three voices (cantus, tenor,
  bassus) or four. `index` counts a voice's notes from 0 in time order.
- `onset` and `duration` are in minims. The motets are in tempus imperfectum: a breve is four
  minims and a semibreve two, so the semibreve beats fall on the even minims. The voices sing
  without rests from minim 0 to the final chord, which every voice holds for a breve.
- `letter` and `octave` name the written pitch: C4 is middle C, and the octave number changes
  between B and C. Pitches are diatonic letters; the signature and the accidentals inflect them.
- `accidental` is the scribe's own mark on the note: `sharp`, `flat`, `natural` or `none`. A marked
  note sounds as marked, and the editor never supplies anything on a note the scribe has marked.

`signature.csv`: one row per voice.

```
voice,signature
cantus,flat
```

`none` is cantus durus: every letter sounds at its natural pitch unless an accidental says
otherwise. `flat` is cantus mollis: every B sounds as B flat unless an accidental says otherwise.
All voices of a motet carry the same signature.

`opening.csv`: the volume editor's supplied accidentals for the notes of the opening section, which
runs from minim 0 to a phrase end and is the same span for every voice.

```
voice,index,accidental
cantus,0,none
```

Every note whose onset lies in the opening section is listed, with `sharp`, `flat`, `natural` or
`none`. The listing is what the editor supplies, so a note the scribe marked is `none` here even
though it sounds inflected. The opening section is a few phrases long and ends where the editor's
listing ends; the later notes of the motet are the ones not listed.

`ficta.csv` (sample motets only): the editor's supplied accidental for every note of the motet, in
the same columns. The three sample motets under `/app/edition/motets` carry this file; the motets
in the grading queue do not.

## How an accidental is filed

A supplied accidental names the pitch the note takes: `sharp` a semitone above the letter's natural
pitch, `flat` a semitone below it, `natural` the letter's own pitch where the signature would have
lowered it (a B sung as B natural under a flat signature). `none` means the note sounds as the
signature gives it. Every note the editor inflects is listed, including a note whose inflection
is forced by an accidental supplied elsewhere.

## What the edition supplies

The edition follows the practice of its period: accidentals are supplied at cadences, where a
diminished fifth or augmented fourth would otherwise sound between voices or be outlined within a
voice, and at the note above la. One supplied accidental can oblige the editor to supply another,
in the same voice or in a different one, so a volume's ficta is read as a whole and not note by
note.

The volumes of the series are not uniform. Each volume editor has settled six questions for the
whole volume, and the series editor reads the settlement from the opening section of any motet of
that volume:

- whether a clausula without the suspension is raised;
- whether a cadence over a bass leaping to the final, with no voice descending by step onto it, is
  raised;
- whether a diminished fifth or augmented fourth sounded between voices is perfected by lowering
  the one note or by raising the other;
- whether a tritone that a voice fills in by step counts as outlined;
- whether the note above la is supplied;
- whether a raise that would make a cross-relation with another voice is forgone.

Every motet in the queue comes from a volume whose editor has settled all six, and the opening
section of that motet shows the settlement.

## The program

```
python3 /app/ficta/supply.py MOTET_DIR OUT_CSV
```

`MOTET_DIR` is a motet folder as above. `OUT_CSV` is written with the columns of `ficta.csv` and
one row for every note of the motet that `opening.csv` does not list, giving the accidental the
volume's editor would supply there.
