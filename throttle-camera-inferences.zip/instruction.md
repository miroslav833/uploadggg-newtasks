Before a camera goes onto a real-time analytics schedule, the fleet team has to know how long each inference request in the planned log will take on that camera's accelerator. Build that prediction as `/app/fleet/predict.py`; it is invoked as

```
python3 /app/fleet/predict.py UNIT_DIR OUT_CSV
```

In UNIT_DIR you get `models.csv` (the models the fleet runs, with their work in milliseconds at full clock), `requests.csv` (when each request arrives and which model it runs) and `measured.csv` (latencies measured on this very unit, but only for requests early in the log). The accelerator, its thermal governor and the file formats are described in `/app/fleet-docs/GUIDE.md`. Three logs replayed in full on the team's reference unit are in `/app/fleet-docs/reference/`.

OUT_CSV must start with the line `request,latency_ms` and then list every request of the log with its latency, counted in milliseconds from arrival to the end of its inference:

```
request,latency_ms
0,65.30
1,23.10
```

Keep in mind that every unit behaves a little differently, and `measured.csv` is all you will ever see of a given unit.

Grading looks only at requests that `measured.csv` leaves out. Your latency for such a request is accepted when it is within 2 % of the true one or within 0.5 ms, whichever allows more; rows that are missing or cannot be parsed are not accepted. A unit is passed when no more than 3 % of its graded requests are unaccepted, and 18 of the 20 hidden units must be passed. The units are run one after another, each on a fresh copy of the folder, under an ordinary unprivileged account, with a 60-second limit per unit and nothing beyond python3 and its standard library. Keep any helper files the predictor needs inside `/app/fleet`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
