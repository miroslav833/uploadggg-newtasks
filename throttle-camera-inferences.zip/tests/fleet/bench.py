#!/usr/bin/env python3
"""Builds the request logs of the fleet-validation project: three reference units measured in
full, and twenty held units measured for their opening only, with their sealed constants.
stdlib only, seeded.

    bench.py reference OUT_DIR
    bench.py held UNITS_DIR TRUTH_DIR

One accelerator serves a unit's requests one at a time in arrival order. A request takes the unit's
dispatch overhead plus its model's work divided by the clock in force (1 at full clock, the unit's
throttled ratio when throttled). Die heat, normalised so that steady computing at full clock holds
it at 1, moves toward the clock in force while the accelerator computes and toward 0 while it is
idle, with the unit's time constant. Before each request the governor throttles if the heat has
reached the trip point and restores full clock if it has fallen to the release point. A request's
latency is from its arrival to its completion.
"""
import json
import math
import os
import random
import sys

MODELS = [("vehicle-detect", 48.0), ("person-detect", 63.5), ("plate-read", 21.0), ("face-embed", 17.5),
          ("pose-estimate", 92.0), ("scene-segment", 141.0), ("track-reid", 12.5), ("smoke-classify", 33.0)]
WORK = dict(MODELS)
REFERENCE = {"tau": 60.0, "trip": 0.70, "release": 0.52, "ratio": 0.60, "overhead": 1.8}
LENGTH = 900.0          # seconds of log
OPENING = 300.0         # seconds measured on a held unit
TOLERANCE = 0.02        # relative error a request may carry (instruction.md)
FLOOR_MS = 0.5          # ... or this many milliseconds, whichever is larger
SHARE_WRONG = 0.03      # share of a unit's graded requests that may be wrong (instruction.md)
MIN_RISE = 1.0
OPEN = 1e-6             # width below which a bound on the trip or release point counts as closed          # squared ms the opening's misfit must rise for any unit-failing move


# --------------------------------------------------------------------------- the unit ----
def serve(c, requests):
    """Latency in ms of every request: (arrival s, work ms) pairs in arrival order. Also returns
    whether each request ran throttled."""
    heat, clock_free, throttled = 0.0, 0.0, False
    out, states = [], []
    for arrival, work in requests:
        if not (math.isfinite(arrival) and math.isfinite(work)):
            raise ValueError("request time or work is not finite")
        start = max(arrival, clock_free)
        idle = start - clock_free
        if idle > 0:
            heat *= math.exp(-idle / c["tau"])
        if not throttled and heat >= c["trip"]:
            throttled = True
        elif throttled and heat <= c["release"]:
            throttled = False
        clock = c["ratio"] if throttled else 1.0
        service = (c["overhead"] + work / clock) / 1000.0
        heat = clock + (heat - clock) * math.exp(-service / c["tau"])
        clock_free = start + service
        out.append((clock_free - arrival) * 1000.0)
        states.append(throttled)
    return out, states


def draw_constants(rng):
    def away(lo, hi, ref, gap):
        while True:
            x = rng.uniform(lo, hi)
            if math.isfinite(x) and abs(x - ref) >= gap:
                return round(x, 4)
    while True:
        c = {"tau": away(18, 140, REFERENCE["tau"], 15), "trip": away(0.55, 0.88, REFERENCE["trip"], 0.05),
             "ratio": away(0.40, 0.78, REFERENCE["ratio"], 0.06), "overhead": away(0.6, 4.0, REFERENCE["overhead"], 0.4)}
        c["release"] = round(c["trip"] - rng.uniform(0.07, 0.26), 4)
        if abs(c["release"] - REFERENCE["release"]) >= 0.04 and c["release"] > 0.25:
            return c


def draw_log(rng):
    """Arrivals in phases of heavy, light and quiet load; a mix of the fleet's models."""
    weights = [rng.uniform(0.2, 1.0) for _ in MODELS]
    names = [m for m, _ in MODELS]
    mean_work = sum(w * WORK[m] for w, m in zip(weights, names)) / sum(weights)
    reqs, t = [], 0.0
    while t < LENGTH:
        kind = rng.choice(["heavy", "heavy", "light", "quiet"])
        dur = rng.uniform(25, 110) if kind == "heavy" else rng.uniform(15, 70)
        util = {"heavy": rng.uniform(0.82, 1.0), "light": rng.uniform(0.15, 0.4), "quiet": rng.uniform(0.0, 0.06)}[kind]
        rate = util * 1000.0 / (mean_work + 2.0)
        end = min(LENGTH, t + dur)
        while rate > 0:
            t += rng.expovariate(rate)
            if t >= end:
                break
            reqs.append((round(t, 4), rng.choices(names, weights)[0]))
        t = end
    return reqs


def build(code, seed, c, measured_until):
    rng = random.Random(seed)
    log = draw_log(rng)
    lat, states = serve(c, [(a, WORK[m]) for a, m in log])
    return {"code": code, "seed": seed, "constants": c, "log": log, "latency": [round(x, 2) for x in lat],
            "throttled": states, "measured_until": measured_until}


# -------------------------------------------------------------------------- the evidence ----
def switches(states):
    trips = sum(1 for a, b in zip(states, states[1:]) if not a and b)
    releases = sum(1 for a, b in zip(states, states[1:]) if a and not b)
    return trips, releases


def wrong(pred, truth):
    if not (math.isfinite(pred) and math.isfinite(truth)):
        return True
    return abs(pred - truth) > max(TOLERANCE * truth, FLOOR_MS)


def identifiable(unit):
    """Every constant, moved just far enough to put more than SHARE_WRONG of the graded requests
    wrong, raises the opening's squared misfit by at least MIN_RISE."""
    c, log, lat, cut = unit["constants"], unit["log"], unit["latency"], unit["measured_until"]
    reqs = [(a, WORK[m]) for a, m in log]
    opening = [k for k, (a, _) in enumerate(log) if a < cut]
    graded = [k for k, (a, _) in enumerate(log) if a >= cut]

    def misfit(cc):
        p, _ = serve(cc, reqs)
        if not all(math.isfinite(x) for x in p):
            return float("inf"), len(graded)
        return sum((p[k] - lat[k]) ** 2 for k in opening), sum(wrong(p[k], lat[k]) for k in graded)

    base, _ = misfit(c)
    for name in c:
        for sign in (1, -1):
            for frac in (0.003, 0.006, 0.01, 0.02, 0.035, 0.05, 0.08, 0.12, 0.18, 0.25):
                cc = dict(c)
                cc[name] = c[name] * (1 + sign * frac)
                if not (0 < cc["release"] < cc["trip"]) or cc["ratio"] >= 1:
                    break
                fit_, off = misfit(cc)
                if off > SHARE_WRONG * len(graded):
                    if not math.isfinite(fit_) or fit_ - base < MIN_RISE:
                        return False
                    break
    return True


def consistent_region(unit):
    """The constants the opening allows: the unit's true starts, services and clock states fix the
    heat before every request as a function of the time constant, and the trip and release points
    must lie between the heats at which the governor did and did not switch. Returns the time
    constants (finely near the unit's, coarsely elsewhere) for which both intervals are open by more
    than OPEN, with the intervals."""
    c, log, cut = unit["constants"], unit["log"], unit["measured_until"]
    n = sum(1 for a, _ in log if a < cut)
    starts, services, free = [], [], 0.0
    for k in range(n):
        a = log[k][0]
        start = max(a, free)
        done = a + unit["latency"][k] / 1000.0
        starts.append(start)
        services.append(done - start)
        free = done
    states = unit["throttled"][:n]

    def window(tau):
        heat, free, h = 0.0, 0.0, []
        for k in range(n):
            idle = starts[k] - free
            if idle > 0:
                heat *= math.exp(-idle / tau)
            h.append(heat)
            clock = c["ratio"] if states[k] else 1.0
            heat = clock + (heat - clock) * math.exp(-services[k] / tau)
            if not math.isfinite(heat):
                raise ValueError("heat is not finite")
            free = starts[k] + services[k]
        tlo, thi, rlo, rhi = -1.0, 2.0, -1.0, 2.0
        for k in range(1, n):
            was, now = states[k - 1], states[k]
            if not was and not now:
                tlo = max(tlo, h[k])
            elif not was and now:
                thi = min(thi, h[k])
            elif was and now:
                rhi = min(rhi, h[k])
            else:
                rlo = max(rlo, h[k])
        return tlo, thi, rlo, rhi

    # a fine scan within 6 per cent of the unit's time constant, a coarse one everywhere else
    taus = [c["tau"] * (1 + 0.0005 * i) for i in range(-120, 121)]
    t = 5.0
    while t <= 400.0:
        if abs(t / c["tau"] - 1) > 0.06:
            taus.append(t)
        t *= 1.02
    region = []
    for tau in sorted(taus):
        tlo, thi, rlo, rhi = window(tau)
        if thi - tlo > OPEN and rhi - rlo > OPEN:
            region.append((tau, tlo, thi, rlo, rhi))

    # a window narrower than the coarse grid can hide between its points: refine the best coarse
    # peaks away from the unit's time constant and count any that open
    def width(tau):
        tlo, thi, rlo, rhi = window(tau)
        m = min(thi - tlo, rhi - rlo)
        if not math.isfinite(m):
            return -1.0
        return -1.0 if abs(m) <= OPEN else m

    far = [t for t in (5.0 * 1.01 ** i for i in range(450)) if abs(t / c["tau"] - 1) > 0.06]
    peaks = sorted(((width(t), t) for t in far), reverse=True)[:8]
    for _, t in peaks:
        lo, hi = t / 1.01, t * 1.01
        for _ in range(40):
            a, b = lo + (hi - lo) * 0.382, lo + (hi - lo) * 0.618
            if width(a) >= width(b):
                hi = b
            else:
                lo = a
        mid = (lo + hi) / 2
        if width(mid) > OPEN:
            region.append((mid,) + window(mid))
    region.sort()
    return region


def settled(unit, samples=10):
    """The opening pins the unit: every time constant it allows lies within 3 per cent of the
    unit's, and constants drawn anywhere in the allowed region put at most half the allowed share
    of graded requests wrong."""
    c, log, lat, cut = unit["constants"], unit["log"], unit["latency"], unit["measured_until"]
    region = consistent_region(unit)
    if not region or any(not math.isfinite(t) or abs(t / c["tau"] - 1) > 0.03 for t, *_ in region):
        return False
    rng = random.Random(unit["seed"])
    reqs = [(a, WORK[m]) for a, m in log]
    graded = [k for k, (a, _) in enumerate(log) if a >= cut]
    trials = []
    for tau, tlo, thi, rlo, rhi in (region[0], region[len(region) // 2], region[-1]):
        for f in (0.01, 0.99):
            for g in (0.01, 0.99):
                trials.append((tau, tlo + f * (thi - tlo), rlo + g * (rhi - rlo)))
    for _ in range(samples):
        tau, tlo, thi, rlo, rhi = rng.choice(region)
        trials.append((tau, rng.uniform(tlo, thi), rng.uniform(rlo, rhi)))
    for tau, trip, release in trials:
        cc = dict(c, tau=tau, trip=trip, release=release)
        p, _ = serve(cc, reqs)
        if sum(wrong(p[k], lat[k]) for k in graded) > SHARE_WRONG / 2 * len(graded):
            return False
    return True


def opening_shows(unit):
    cut = unit["measured_until"]
    states = [s for (a, _), s in zip(unit["log"], unit["throttled"]) if a < cut]
    later = [s for (a, _), s in zip(unit["log"], unit["throttled"]) if a >= cut]
    t1, r1 = switches(states)
    t2, r2 = switches(later)
    return t1 >= 2 and r1 >= 2 and t2 >= 3 and r2 >= 3


# ----------------------------------------------------------------------------- writers ----
def write_unit(unit, out_dir):
    d = os.path.join(out_dir, unit["code"])
    write_models(d)
    with open(os.path.join(d, "requests.csv"), "w") as fh:
        fh.write("request,arrival,model\n")
        for k, (a, m) in enumerate(unit["log"]):
            fh.write("%d,%.4f,%s\n" % (k, a, m))
    with open(os.path.join(d, "measured.csv"), "w") as fh:
        fh.write("request,latency_ms\n")
        for k, (a, m) in enumerate(unit["log"]):
            if a < unit["measured_until"]:
                fh.write("%d,%.2f\n" % (k, unit["latency"][k]))


def write_sealed(unit, sealed_dir):
    os.makedirs(sealed_dir, exist_ok=True)
    with open(os.path.join(sealed_dir, unit["code"] + ".json"), "w") as fh:
        json.dump({"code": unit["code"], "seed": unit["seed"], "constants": unit["constants"],
                   "measured_until": unit["measured_until"],
                   "key": [[k, unit["latency"][k]] for k, (a, m) in enumerate(unit["log"])
                           if a >= unit["measured_until"]]}, fh)


def write_models(out_dir):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "models.csv"), "w") as fh:
        fh.write("model,work_ms\n")
        for m, w in MODELS:
            fh.write("%s,%.1f\n" % (m, w))


REFERENCE_UNITS = [("U1", 101), ("U2", 102), ("U3", 103)]
HELD = [("H%02d" % i, 3000 + i) for i in range(1, 21)]


def held_unit(spec, max_tries=400):
    code, seed = spec
    for t in range(max_tries):
        c = draw_constants(random.Random(seed * 1000 + t))
        unit = build(code, seed + 100000 * t, c, OPENING)
        if opening_shows(unit) and identifiable(unit) and settled(unit):
            return unit
    raise SystemExit("%s: no unit whose opening pins its constants in %d tries" % (code, max_tries))


def reference_unit(spec, max_tries=4000):
    """A reference log: the reference unit throttles and recovers at least twice in the first
    OPENING seconds, and those seconds settle the rest of the log."""
    code, seed = spec
    for t in range(max_tries):
        unit = build(code, seed + 100000 * t, dict(REFERENCE), OPENING)
        early = [s for (a, _), s in zip(unit["log"], unit["throttled"]) if a < OPENING]
        if min(switches(early)) >= 2 and settled(unit):
            unit["measured_until"] = 1e9
            return unit
    raise SystemExit("%s: no reference log in %d tries" % (code, max_tries))


def main():
    if sys.argv[1] == "reference":
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(3) as pool:
            for unit in pool.map(reference_unit, REFERENCE_UNITS):
                write_unit(unit, os.path.join(sys.argv[2], "reference"))
                print(unit["code"], "ok", len(unit["log"]), "requests")
    elif sys.argv[1] == "held":
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(min(8, os.cpu_count() or 1)) as pool:
            for unit in pool.map(held_unit, HELD):
                write_unit(unit, sys.argv[2])
                write_sealed(unit, sys.argv[3])
                print(unit["code"], "ok", len(unit["log"]), "requests", unit["constants"])
    else:
        raise SystemExit("bench.py reference OUT_DIR | held UNITS_DIR TRUTH_DIR")


if __name__ == "__main__":
    main()
