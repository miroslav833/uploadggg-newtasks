"""Runs the uploaded predictor on held camera units, one at a time, in a throwaway sandbox."""
import csv
import math
import os
import shutil
import signal
import subprocess
import time


class Bay:
    """One sandboxed run per unit.

    The unit folder is copied into a scratch area handed to an account number nobody else on the
    box uses. The predictor runs as that account, without supplementary groups, in a session of its
    own, under address-space, file-size and core limits and a wall-clock limit. When it is done every
    process of that account is killed; only then are its predictions read, from a regular file of
    bounded size opened without following links, as plain text.
    """

    units = "/tests/bench/units"
    reports = "/run/verifier"
    scratch = "/var/tmp/bay"
    predictor = "/app/fleet/predict.py"
    wall_seconds = 60
    max_bytes = 4 << 20
    first_uid = 52000

    def codes(self):
        return sorted(d for d in os.listdir(self.units) if os.path.isdir(os.path.join(self.units, d)))

    @staticmethod
    def _owners():
        owners = {}
        for entry in os.listdir("/proc"):
            if entry.isdigit():
                try:
                    owners[int(entry)] = os.stat("/proc/" + entry).st_uid
                except OSError:
                    pass
        return owners

    def _unused_uid(self):
        busy = set(self._owners().values())
        uid = self.first_uid
        while uid in busy:
            uid += 1
        return uid

    def _clear(self, uid):
        deadline = time.time() + 10
        while time.time() < deadline:
            left = [pid for pid, owner in self._owners().items() if owner == uid]
            if not left:
                return
            for pid in left:
                try:
                    os.kill(pid, signal.SIGKILL)
                except OSError:
                    pass
            time.sleep(0.05)

    def _read(self, path):
        if os.path.islink(path) or not os.path.isfile(path):
            return {}
        try:
            if os.lstat(path).st_size > self.max_bytes:
                return {}
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        except OSError:
            return {}
        with os.fdopen(fd, "r", encoding="utf-8", errors="replace", newline="") as fh:
            body = fh.read(self.max_bytes + 1)
        if len(body) > self.max_bytes:
            return {}
        table = {}
        for row in csv.DictReader(body.splitlines()):
            rid = (row.get("request") or "").strip()
            if not rid.isdigit() or int(rid) in table:
                continue
            try:
                value = float((row.get("latency_ms") or "").strip())
            except ValueError:
                continue
            if math.isfinite(value):
                table[int(rid)] = value
        return table

    def run(self, code):
        """The predictor's latencies for one unit, {request: ms}."""
        uid = self._unused_uid()
        area = os.path.join(self.scratch, code)
        shutil.rmtree(area, ignore_errors=True)
        os.makedirs(os.path.join(area, "home"))
        shutil.copytree(os.path.join(self.units, code), os.path.join(area, "unit"), symlinks=False)
        for root, dirs, files in os.walk(area):
            for name in [root] + [os.path.join(root, f) for f in files]:
                os.chown(name, uid, uid)
        target = os.path.join(area, "predictions.csv")
        line = "ulimit -v 2097152 -f 65536 -c 0; exec python3 %s %s %s" % (
            self.predictor, os.path.join(area, "unit"), target)
        with open(os.path.join(self.reports, code + ".log"), "wb") as log:
            try:
                subprocess.run(["bash", "-c", line], user=uid, group=uid, extra_groups=[],
                               cwd=os.path.join(area, "home"), stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                               env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": os.path.join(area, "home"),
                                    "LANG": "C.UTF-8"},
                               start_new_session=True, timeout=self.wall_seconds, check=False)
            except subprocess.TimeoutExpired:
                log.write(b"\n[wall-clock limit reached]\n")
        self._clear(uid)
        table = self._read(target)
        shutil.rmtree(area, ignore_errors=True)
        return table
