#!/usr/bin/env bash
# Camera-fleet grader. Order matters: the reward directory is locked to root before anything the
# agent wrote can run, the checks run, and only then is the single reward line written.
set -u

REWARD_DIR=/logs/verifier
REPORT_DIR=/run/verifier
reward=0

lock_reward_dir() {
    mkdir -p "$REWARD_DIR"
    chown 0:0 "$REWARD_DIR" 2>/dev/null
    chmod 700 /logs/verifier 2>/dev/null
    [ "$(stat -c '%u:%a' /logs/verifier 2>/dev/null)" = "0:700" ]
}

scrub_reward_dir() {
    # anything not written by root goes, and so does anything shaped like a reward or result
    find "$REWARD_DIR" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    find "$REWARD_DIR" -mindepth 1 -maxdepth 1 \( -iname 'reward*' -o -iname 'result*' -o -iname 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
}

write_reward() {
    scrub_reward_dir
    (umask 022; printf '%s\n' "$reward" > "$REWARD_DIR/reward.txt")
    for report in ctrf.json units.json; do
        if [ -f "$REPORT_DIR/$report" ]; then
            (umask 022; cp "$REPORT_DIR/$report" "$REWARD_DIR/$report")
        fi
    done
    chmod 755 "$REWARD_DIR" 2>/dev/null
}
trap write_reward EXIT

if ! lock_reward_dir; then
    echo "grader: /logs/verifier is not root-only; refusing to grade" >&2
    exit 0
fi
scrub_reward_dir
(umask 022; printf '0\n' > "$REWARD_DIR/reward.txt")

# the tests and the sealed units are root's alone; the bay's scratch area is shared
chmod -R go-rwx /tests 2>/dev/null
mkdir -p "$REPORT_DIR" /var/tmp/bay
chown 0:0 "$REPORT_DIR" && chmod 700 "$REPORT_DIR"
chmod 755 /var/tmp/bay
chmod -R a+rX /app/fleet 2>/dev/null

cd /tests || exit 0
if python3 -m pytest test_inferences.py -q -p no:cacheprovider --ctrf "$REPORT_DIR/ctrf.json"; then
    reward=1
fi
exit 0
