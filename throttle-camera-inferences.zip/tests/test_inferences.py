"""The camera fleet's grading.

TestBench serves every held unit's log again from its sealed constants with the verifier's own
governor model (tests/governor.py), so the key is exactly what the unit and its log imply.
TestPredictor runs the uploaded predictor on every held unit in the bay and needs enough units
predicted within the printed bounds.
"""
import csv
import json
import math
import os

import pytest

import governor
from bay import Bay

SEALS = "/tests/bench/seals"
HELD = 20
NEEDED = 18                                # units that must pass (instruction.md)
BAY = Bay()


def _unit(code):
    folder = os.path.join(BAY.units, code)
    with open(os.path.join(folder, "models.csv"), newline="") as fh:
        work = {r["model"]: float(r["work_ms"]) for r in csv.DictReader(fh)}
    with open(os.path.join(folder, "requests.csv"), newline="") as fh:
        rows = sorted(csv.DictReader(fh), key=lambda r: (float(r["arrival"]), int(r["request"])))
    with open(os.path.join(folder, "measured.csv"), newline="") as fh:
        measured = {int(r["request"]): float(r["latency_ms"]) for r in csv.DictReader(fh)}
    with open(os.path.join(SEALS, code + ".json")) as fh:
        sealed = json.load(fh)
    requests = [(int(r["request"]), float(r["arrival"])) for r in rows]
    works = {int(r["request"]): work[r["model"]] for r in rows}
    return sealed, requests, works, measured


class TestBench:
    def test_every_unit_is_served_as_sealed(self):
        codes = BAY.codes()
        assert len(codes) == HELD
        trouble = {}
        for code in codes:
            found = governor.problems(*_unit(code))
            if found:
                trouble[code] = found
        assert trouble == {}


class TestPredictor:
    @pytest.fixture(scope="class")
    def tally(self):
        counts = {}
        for code in BAY.codes():
            key = governor.key_of(_unit(code)[0])
            got = BAY.run(code)
            missed = 0
            for rid, truth in key.items():
                value = got.get(rid)
                if value is None or not math.isfinite(value) or governor.off(value, truth):
                    missed += 1
            counts[code] = (missed, len(key))
        with open(os.path.join(BAY.reports, "units.json"), "w") as fh:
            json.dump({c: {"wrong": m, "graded": n} for c, (m, n) in counts.items()}, fh, indent=1)
        return counts

    def test_enough_units_within_bounds(self, tally):
        passing = sorted(c for c, (m, n) in tally.items() if m <= governor.SHARE_WRONG * n)
        assert len(passing) >= NEEDED, "%d of %d units passed (%s), %d needed" % (len(passing), HELD, tally, NEEDED)
