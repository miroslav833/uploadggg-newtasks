"""The verifier's own model of an accelerator under its thermal governor.

From a unit's sealed constants it serves the unit's log again and checks the shipped files against
it: measured.csv is exactly the model's latencies for the requests that arrive before the measured
time, the sealed key is exactly its latencies for every later request, and the opening settles the
unit (every constant moved far enough to fail the unit raises the opening's misfit clearly).
"""
import math

TOLERANCE = 0.02       # relative error a graded request may carry (instruction.md)
FLOOR_MS = 0.5         # ... or this many milliseconds, whichever is larger
SHARE_WRONG = 0.03     # share of a unit's graded requests that may be wrong (instruction.md)
MIN_RISE = 1.0
NAMES = ("tau", "trip", "release", "ratio", "overhead")


def run_log(c, arrivals, works):
    """Completion minus arrival, in ms, for each request served in arrival order."""
    t_free, heat, slow = 0.0, 0.0, False
    latencies = []
    for arrival, work in zip(arrivals, works):
        begin = arrival if arrival > t_free else t_free
        if begin > t_free:
            heat = heat * math.exp(-(begin - t_free) / c["tau"])
        if slow and heat <= c["release"]:
            slow = False
        elif not slow and heat >= c["trip"]:
            slow = True
        speed = c["ratio"] if slow else 1.0
        busy = (c["overhead"] + work / speed) / 1000.0
        heat = speed + (heat - speed) * math.exp(-busy / c["tau"])
        if not math.isfinite(heat):
            raise ValueError("heat is not finite")
        t_free = begin + busy
        latencies.append(1000.0 * (t_free - arrival))
    return latencies


def off(predicted, truth):
    if not (math.isfinite(predicted) and math.isfinite(truth)):
        return True
    return abs(predicted - truth) > max(TOLERANCE * truth, FLOOR_MS)


def problems(sealed, requests, works, measured):
    """requests: [(id, arrival)] in arrival order; works: {id: work ms}; measured: {id: ms}."""
    out = []
    c = sealed["constants"]
    if not (0 < c["release"] < c["trip"]) or not (0 < c["ratio"] < 1) or c["tau"] <= 0 or c["overhead"] < 0:
        return ["the sealed constants are not a unit"]
    ids = [i for i, _ in requests]
    arrivals = [a for _, a in requests]
    w = [works[i] for i in ids]
    lat = run_log(c, arrivals, w)
    cut = sealed["measured_until"]
    opening = [k for k, a in enumerate(arrivals) if a < cut]
    graded = [k for k, a in enumerate(arrivals) if a >= cut]
    if measured != {ids[k]: round(lat[k], 2) for k in opening}:
        out.append("measured.csv is not the unit's latencies for the opening")
    if {i: v for i, v in sealed["key"]} != {ids[k]: round(lat[k], 2) for k in graded}:
        out.append("the sealed key is not the unit's latencies")
    base = sum((lat[k] - measured.get(ids[k], 0.0)) ** 2 for k in opening)
    for name in NAMES:
        for sign in (1, -1):
            for frac in (0.003, 0.006, 0.01, 0.02, 0.035, 0.05, 0.08, 0.12, 0.18, 0.25):
                moved = dict(c)
                moved[name] = c[name] * (1 + sign * frac)
                if not (0 < moved["release"] < moved["trip"]) or moved["ratio"] >= 1:
                    break
                other = run_log(moved, arrivals, w)
                if sum(off(other[k], lat[k]) for k in graded) > SHARE_WRONG * len(graded):
                    rise = sum((other[k] - measured.get(ids[k], 0.0)) ** 2 for k in opening) - base
                    if not math.isfinite(rise) or rise < MIN_RISE:
                        out.append("the opening does not settle %s" % name)
                    break
    return out


def key_of(sealed):
    return {i: v for i, v in sealed["key"]}
