# Fleet validation: request logs and the accelerator

## What we are doing

Every camera in the fleet runs its analytics models on a small neural accelerator. Before a camera
is admitted to a real-time schedule we replay a planned request log on it and need the latency of
every request. Running every plan on every camera is not possible, so we predict: each camera is
measured on the first stretch of a log, and the predictor gives the rest.

## The accelerator

The accelerator runs one inference at a time. Requests that arrive while it is busy wait their
turn, in arrival order; a request's latency runs from its arrival until its inference completes.
Each inference costs a fixed dispatch overhead plus the model's work, which `models.csv` gives in
milliseconds at full clock; at a lower clock the work takes proportionally longer.

The accelerator is protected by the vendor's thermal governor. As the vendor's integration guide
puts it: the die heats while the accelerator computes, more at a higher clock, and cools toward
ambient while it is idle; when the die reaches the trip temperature the governor steps the
accelerator down to its throttled clock, and it returns it to full clock only after the die has
cooled to the lower release temperature. The governor changes the clock between inferences, never
during one.

No two cameras are alike: heat sinks, enclosures and silicon differ, so each unit has its own
thermal time constant, trip and release temperatures, throttled clock and dispatch overhead. The
die starts each log cold.

## The files

A unit is a folder with three files.

`models.csv`, the fleet's models:

```
model,work_ms
vehicle-detect,48.0
```

`requests.csv`, one row per request; `arrival` is seconds from the start of the log:

```
request,arrival,model
0,0.0817,person-detect
1,0.1592,plate-read
```

`measured.csv`, the latencies measured on the unit, in milliseconds:

```
request,latency_ms
0,65.30
1,23.10
```

## The reference units

`reference/` holds three logs replayed in full on the project's reference unit, every request
measured. Every other unit is measured only for the requests that arrive in the first part of its
log; the rest is what the predictor must give.
