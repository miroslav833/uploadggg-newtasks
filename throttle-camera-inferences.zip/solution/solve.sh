#!/bin/bash
# Installs the predictor where the grader expects it and checks it on the three reference units:
# each is cut back to the measurements of its first 300 seconds, predicted, and compared with the
# full measurement.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/fleet /app/out
cp "$HERE/fleet/predict.py" /app/fleet/predict.py
for unit in /app/fleet-docs/reference/*/; do
    python3 - "$unit" "/app/out/$(basename "$unit")" <<'PY'
import csv, os, shutil, subprocess, sys
src, work = sys.argv[1], sys.argv[2]
shutil.rmtree(work, ignore_errors=True)
os.makedirs(work)
for name in ("models.csv", "requests.csv"):
    shutil.copy(os.path.join(src, name), work)
arrival = {r["request"]: float(r["arrival"]) for r in csv.DictReader(open(os.path.join(src, "requests.csv")))}
full = {r["request"]: float(r["latency_ms"]) for r in csv.DictReader(open(os.path.join(src, "measured.csv")))}
with open(os.path.join(work, "measured.csv"), "w") as fh:
    fh.write("request,latency_ms\n")
    for rid, v in full.items():
        if arrival[rid] < 300.0:
            fh.write("%s,%.2f\n" % (rid, v))
subprocess.run(["python3", "/app/fleet/predict.py", work, os.path.join(work, "out.csv")], check=True)
got = {r["request"]: float(r["latency_ms"]) for r in csv.DictReader(open(os.path.join(work, "out.csv")))}
later = [rid for rid in full if arrival[rid] >= 300.0]
close = sum(1 for rid in later if rid in got and abs(got[rid] - full[rid]) <= max(0.02 * full[rid], 0.5))
print("%s: %d of %d later requests within bounds" % (os.path.basename(src.rstrip("/")), close, len(later)))
PY
done
