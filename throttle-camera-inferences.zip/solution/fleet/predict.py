#!/usr/bin/env python3
"""Latency of every inference request on one edge camera's accelerator.

    python3 predict.py UNIT_DIR OUT_CSV

The accelerator serves requests one at a time in arrival order, so a measured request's service
time is its completion (arrival + latency) less the moment it could start (its arrival, or the
completion of the request before). Service = overhead + work / clock, with the clock 1 at full
speed and the unit's throttled ratio when the thermal governor has stepped it down; the measured
service times give the overhead, the ratio and which requests ran throttled.

Die heat (normalised: steady computing at full clock holds it at 1) moves toward the clock in force
while computing and toward 0 while idle, with the unit's time constant. The governor throttles
before a request once the heat has reached the trip point and restores full clock once it has
fallen to the release point. With the measured service times the heat before every request is a
function of the time constant alone; the trip and release points must lie between the heats at
which the governor did and did not switch. The time constant is the middle of those that leave both
bounds open, the points are the middles of the bounds, and the rest of the log is simulated.
"""
import csv
import math
import os
import sys


def read(path):
    with open(path, newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


class Unit:
    def __init__(self, unit_dir):
        work = {r["model"]: float(r["work_ms"]) for r in read(os.path.join(unit_dir, "models.csv"))}
        rows = sorted(read(os.path.join(unit_dir, "requests.csv")), key=lambda r: (float(r["arrival"]), int(r["request"])))
        self.ids = [int(r["request"]) for r in rows]
        self.arrival = [float(r["arrival"]) for r in rows]
        self.work = [work[r["model"]] for r in rows]
        path = os.path.join(unit_dir, "measured.csv")
        measured = {int(r["request"]): float(r["latency_ms"]) for r in read(path)} if os.path.exists(path) else {}
        self.measured = [measured.get(i) for i in self.ids]
        self.n_open = 0
        while self.n_open < len(self.ids) and self.measured[self.n_open] is not None:
            self.n_open += 1

    def services(self):
        """(start s, service ms) of every measured request, from the measured completions."""
        out, free = [], 0.0
        for k in range(self.n_open):
            start = max(self.arrival[k], free)
            done = self.arrival[k] + self.measured[k] / 1000.0
            out.append((start, (done - start) * 1000.0))
            free = done
        return out


def line(points):
    """Least-squares intercept and slope of y on x."""
    n = len(points)
    sx = sum(x for x, _ in points)
    sy = sum(y for _, y in points)
    sxx = sum(x * x for x, _ in points)
    sxy = sum(x * y for x, y in points)
    slope = (n * sxy - sx * sy) / (n * sxx - sx * sx)
    return (sy - slope * sx) / n, slope


def clocks(unit, served):
    """Overhead, throttled ratio and each measured request's clock state. A service is long for
    its work if it exceeds what the shortest services of the same work show by more than half the
    gap to the slowest: those ran throttled."""
    by_work = {}
    for k, (_, s) in enumerate(served):
        by_work.setdefault(unit.work[k], []).append(s)
    pivot = {}
    for w, ss in by_work.items():
        lo, hi = min(ss), max(ss)
        pivot[w] = (lo + hi) / 2 if hi - lo > 0.02 * lo else hi + 1
    slow = [s > pivot[unit.work[k]] for k, (_, s) in enumerate(served)]
    full_pts = [(unit.work[k], s) for k, (_, s) in enumerate(served) if not slow[k]]
    overhead, _ = line(full_pts)
    slow_pts = [(unit.work[k], s - overhead) for k, (_, s) in enumerate(served) if slow[k]]
    per_ms = sum(y for _, y in slow_pts) / max(1e-9, sum(x for x, _ in slow_pts))
    return overhead, 1.0 / per_ms if slow_pts else 0.6, slow


def heats(unit, served, slow, ratio, tau):
    """Heat just before every measured request starts."""
    out, heat, free = [], 0.0, 0.0
    for k, (start, service) in enumerate(served):
        idle = start - free
        if idle > 0:
            heat *= math.exp(-idle / tau)
        out.append(heat)
        clock = ratio if slow[k] else 1.0
        heat = clock + (heat - clock) * math.exp(-service / 1000.0 / tau)
        free = start + service / 1000.0
    return out


def bounds(h, slow):
    """(trip low, trip high, release low, release high) the governor's switches allow: trip is above
    every heat at which a full-clock unit stayed at full clock and at most the heat at which it
    stepped down; release is below every heat at which a throttled unit stayed throttled and at
    least the heat at which it stepped back up."""
    tlo, thi, rlo, rhi = -1.0, 2.0, -1.0, 2.0
    for k in range(1, len(h)):
        was, now = slow[k - 1], slow[k]
        if not was and not now:
            tlo = max(tlo, h[k])
        elif not was and now:
            thi = min(thi, h[k])
        elif was and was == now:
            rhi = min(rhi, h[k])
        else:
            rlo = max(rlo, h[k])
    return tlo, thi, rlo, rhi


OPEN = 1e-6


def margin(unit, served, slow, ratio, tau):
    """How far the trip and release bounds are from closing at a time constant: the smaller width,
    negative when one is closed. A width within OPEN of zero is the heat merely saturating at the
    clock, not a window, and ranks below every real one."""
    tlo, thi, rlo, rhi = bounds(heats(unit, served, slow, ratio, tau), slow)
    m = min(thi - tlo, rhi - rlo)
    if abs(m) <= OPEN:
        return -1.0
    return m


def fit(unit):
    """The time constant whose trip and release bounds stay open: the best few of a coarse scan of
    the bound margin, each refined by golden section and then scanned finely for the open window;
    the middle of the widest window found, and the middles of the bounds there."""
    served = unit.services()
    overhead, ratio, slow = clocks(unit, served)
    coarse = [5.0 * 1.01 ** i for i in range(450)]
    scored = sorted(((margin(unit, served, slow, ratio, t), t) for t in coarse), reverse=True)
    best = None
    for _, t in scored[:5]:
        lo, hi = t / 1.01, t * 1.01
        for _ in range(40):
            a, b = lo + (hi - lo) * 0.382, lo + (hi - lo) * 0.618
            if margin(unit, served, slow, ratio, a) >= margin(unit, served, slow, ratio, b):
                hi = b
            else:
                lo = a
        mid = (lo + hi) / 2
        window = [mid * (1 + 0.0002 * i) for i in range(-150, 151)
                  if margin(unit, served, slow, ratio, mid * (1 + 0.0002 * i)) > 0]
        if not window:
            window = [mid]
        width = window[-1] / window[0]
        if best is None or (len(window), width) > best[0]:
            best = ((len(window), width), math.sqrt(window[0] * window[-1]))
    tau = best[1]
    tlo, thi, rlo, rhi = bounds(heats(unit, served, slow, ratio, tau), slow)
    return {"tau": tau, "trip": (tlo + thi) / 2, "release": (rlo + rhi) / 2, "ratio": ratio, "overhead": overhead}


def simulate(unit, c):
    heat, free, throttled = 0.0, 0.0, False
    out = []
    for arrival, work in zip(unit.arrival, unit.work):
        start = max(arrival, free)
        idle = start - free
        if idle > 0:
            heat *= math.exp(-idle / c["tau"])
        if not throttled and heat >= c["trip"]:
            throttled = True
        elif throttled and heat <= c["release"]:
            throttled = False
        clock = c["ratio"] if throttled else 1.0
        service = (c["overhead"] + work / clock) / 1000.0
        heat = clock + (heat - clock) * math.exp(-service / c["tau"])
        free = start + service
        out.append((free - arrival) * 1000.0)
    return out


def solve(unit_dir):
    unit = Unit(unit_dir)
    c = fit(unit) if unit.n_open > 10 else {"tau": 60.0, "trip": 0.7, "release": 0.52, "ratio": 0.6, "overhead": 1.8}
    lat = simulate(unit, c)
    return [(i, unit.measured[k] if unit.measured[k] is not None else round(lat[k], 2)) for k, i in enumerate(unit.ids)]


def main():
    rows = solve(sys.argv[1])
    os.makedirs(os.path.dirname(os.path.abspath(sys.argv[2])), exist_ok=True)
    with open(sys.argv[2], "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["request", "latency_ms"])
        for i, v in sorted(rows):
            w.writerow([i, "%.2f" % v])


if __name__ == "__main__":
    main()
