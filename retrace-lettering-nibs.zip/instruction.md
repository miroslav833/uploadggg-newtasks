A type foundry keeps exemplar sheets: two lines of lettering written with a broad-edged pen by one of its scribes, scanned and filed under a code. When a hand is revived as a typeface, the designer starts from two numbers read off the sheet: how wide the nib was, and at what angle the scribe held it to the writing line. Reading those numbers off a scan by eye is slow and the designer wants it done by program.

Build `profile.py` so that

```
python3 /app/ductus/profile.py SHEET_DIR OUT_CSV
```

reads the one sheet filed in SHEET_DIR (`scan.pgm` or `scan.png`, with the catalogue line in `sheet.txt`) and writes OUT_CSV as three lines:

```
measure,value
nib_width_mm,1.85
pen_angle_deg,30.5
```

`nib_width_mm` is the nib's width as it was cut, in millimetres to two decimals. `pen_angle_deg` is the angle, in degrees to one decimal, between the nib's edge and the writing line, from 0 (edge lying along the line) to 90.

What is known about the sheets is in `/app/HANDBOOK.md`: how they are written and scanned, both scan formats with their headers, the catalogue keys, the three kinds of nib and two kinds of paper the scribes use and what each does to a stroke, how each of the four hands is made, and what the two measures mean. Four sheets with the designer's own ductus beside them (`ductus.csv`) are in `/app/archive/sheets`; all four were written with steel nibs on sized paper and scanned square.

Twenty further sheets from the same archive, written with the other nibs and papers too and scanned as they happened to lie, decide the score. One sheet is right only when both of its measures are: the nib width within 0.06 mm and the pen angle within 2.0 degrees. The program must get at least 18 of the 20 right. For each sheet it is started afresh by an unprivileged account in an empty working directory, with python3, numpy and the standard library and nothing else installed, and it has 300 seconds. Put whatever else it needs under `/app/ductus`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
