"""Runs the solver's /app/ductus/profile.py on every graded sheet and compares its ductus with the
sheet's own.

Each run gets its own copy of one sheet, an account number no process holds and no earlier run used,
300 seconds and fixed limits on CPU, memory and file size. Every process of that account is stopped
before anything it wrote is read. The output is opened without following links, must be a regular
file under 1 MiB, and is parsed as text: nothing it contains is executed.
"""
import csv
import io
import math
import os
import resource
import shutil
import signal
import stat
import subprocess
import time

VAULT = "/tests/vault"
TOOL = "/app/ductus/profile.py"
RUNS = "/var/tmp/ductus-runs"
SECONDS = 300
WITHIN = dict(nib_width_mm=0.06, pen_angle_deg=2.0)
CAP = 1 << 20


def sheets():
    return sorted(d for d in os.listdir(VAULT) if os.path.isdir(os.path.join(VAULT, d)))


def truth():
    with open(os.path.join(VAULT, "truth.csv"), newline="", encoding="utf-8") as f:
        return {r["sheet"]: {k: float(r[k]) for k in WITHIN} for r in csv.DictReader(f)}


_used = set()


def _new_account():
    taken = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                taken.add(os.stat("/proc/" + d).st_uid)
            except OSError:
                pass
    uid = 53000
    while uid in taken or uid in _used:
        uid += 1
    _used.add(uid)
    return uid


def _stop(uid):
    calm = 0
    for _ in range(300):
        found = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    if os.stat("/proc/" + d).st_uid == uid:
                        found.append(int(d))
                except OSError:
                    pass
        if not found:
            calm += 1
            if calm >= 3:
                return
            time.sleep(0.03)
            continue
        calm = 0
        for pid in found:
            for sig in (signal.SIGSTOP, signal.SIGKILL):
                try:
                    os.kill(pid, sig)
                except ProcessLookupError:
                    pass
        time.sleep(0.03)


def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (SECONDS, SECONDS))
    resource.setrlimit(resource.RLIMIT_AS, (3 << 30, 3 << 30))
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
    resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))


def run_tool(code, uid):
    room = os.path.join(RUNS, code)
    shutil.rmtree(room, ignore_errors=True)
    os.makedirs(room, mode=0o755)
    sheet = os.path.join(room, "sheet")
    shutil.copytree(os.path.join(VAULT, code), sheet)
    for fn in os.listdir(sheet):
        os.chmod(os.path.join(sheet, fn), 0o444)
    os.chmod(sheet, 0o555)
    os.chown(room, uid, uid)
    dst = os.path.join(room, "ductus.csv")

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        _limits()
    try:
        subprocess.run(["python3", TOOL, sheet, dst], cwd=room, preexec_fn=drop, timeout=SECONDS,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": room})
    except (subprocess.TimeoutExpired, OSError):
        pass
    _stop(uid)
    return dst


def read_output(path):
    """-> {measure: value} or None if the output is not a readable regular file of rows."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > CAP:
            return None
        raw = os.read(fd, CAP + 1)
    finally:
        os.close(fd)
    rows = {}
    try:
        for r in csv.DictReader(io.StringIO(raw.decode("utf-8"))):
            key = (r.get("measure") or "").strip()
            if key in rows:
                return None
            rows[key] = float(r["value"])
    except (KeyError, TypeError, ValueError, UnicodeDecodeError):
        return None
    return rows


def matches(got, want):
    """A sheet counts when every measure is present, finite and within its tolerance."""
    if got is None:
        return False
    for k, tol in WITHIN.items():
        v = got.get(k)
        if v is None or not math.isfinite(v) or abs(v - want[k]) > tol:
            return False
    return True


def bench():
    os.makedirs(RUNS, mode=0o711, exist_ok=True)
    want = truth()
    results = {}
    for code in sheets():
        uid = _new_account()
        results[code] = matches(read_output(run_tool(code, uid)), want[code])
    return results
