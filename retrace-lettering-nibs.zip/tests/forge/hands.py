"""Letterform skeletons of the archive's four hands (generator side; never ships).

A letter is a list of strokes; a stroke is (points, turned, pressed) where points are the pen's centre
path in nib units (x right, y up, baseline 0, x-line at k) in the order the scribe writes them,
`turned` marks a stroke the scribe makes with the pen turned off the hand's angle, and `pressed` a
straight pulled stroke that takes the scribe's pressure (a quill or reed opens there). `e` is half the vertical
extent of the nib at the hand's angle, so that a minim's ink runs exactly from the baseline to the
x-line. Each function returns (strokes, advance).
"""
import math

ASC = 2.6      # ascender height above the x-line, nib units
DESC = 2.2     # descender depth below the baseline


def arc(cx, cy, rx, ry, a0, a1, n=24):
    """points of an elliptical arc from angle a0 to a1 (degrees, counter-clockwise positive)."""
    return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
             cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]


def bez(p0, p1, p2, n=16):
    return [((1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0],
             (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]) for t in (i / n for i in range(n + 1))]


class Hand:
    """style: 'round' (serifed, semicircular arches, turned diagonals), 'italic' (slanted, branching
    arches), 'uncial' (flat pen, wide round forms, short ascenders), 'gothic' (angular, feet made with
    the pen turned)."""

    def __init__(self, style, k, e, alpha=30.0, slant_deg=0.0):
        self.style, self.k, self.e = style, k, e
        # the entry and exit strokes are hairlines: the nib slid along its own edge, at the pen angle;
        # the layout shears the letters by the slant, so the hairline is drawn at the angle that the
        # shear carries onto the pen angle
        hl = 1.0 if style == "uncial" else 1.3
        t = math.tan(math.radians(slant_deg))
        ta = math.tan(math.radians(alpha))
        beta = math.atan2(ta, 1 - t * ta)
        self.hx = hl * math.cos(beta)
        self.hy = hl * math.sin(beta)
        self.w = {"round": 0.66, "italic": 0.56, "uncial": 0.80, "gothic": 0.50}[style] * k   # letter width
        self.asc = k + (ASC * (0.55 if style == "uncial" else 1.0))
        self.desc = -DESC * (0.7 if style == "uncial" else 1.0)
        self.turn_diag = style == "round"
        self.feet = style == "gothic"

    # --- primitives -----------------------------------------------------------------------------------
    def stem(self, x, top, bottom=None, entry=True, exit_=True):
        """a pulled stroke from `top` down to the baseline band (or `bottom`), with the hand's entry and
        exit; gothic stems get a foot made with the pen turned."""
        k, e = self.k, self.e
        bottom = e if bottom is None else bottom
        strokes = []
        hx, hy = self.hx, self.hy
        if entry:
            strokes.append(([(x - hx, top - hy), (x, top)], False, False))
        strokes.append(([(x, top), (x, bottom)], False, True))
        at_base = math.isfinite(bottom) and abs(bottom - e) < 1e-9
        if exit_ and self.style in ("round", "italic") and at_base:
            strokes.append(([(x, bottom), (x + hx, bottom + hy)], False, False))
        if exit_ and self.style == "gothic" and at_base:
            # the foot: a short stroke made with the pen turned
            strokes.append(([(x, bottom + 0.45), (x + 0.5, bottom)], True, False))
        return strokes

    def arch(self, x, x2):
        """an arch from the stem at x to a new stem at x2 (the new stem is returned as part of it)."""
        k, e = self.k, self.e
        r = (x2 - x) / 2
        if self.style == "gothic":
            c = k - e - 0.9 * r
            pts = [(x, c), (x + r, k - e), (x2, c)]
        elif self.style == "italic":
            pts = bez((x, 0.42 * k), (x + 0.9 * r, k - e + 0.25), (x2, k - e - 0.55 * r))
        else:
            c = k - e - r
            pts = arc(x + r, c, r, r, 180, 0)
        strokes = [(pts, False)]
        strokes += self.stem(x2, pts[-1][1], entry=False)
        return strokes

    def bowl(self, x, open_right=False, small=False):
        """an o: two pulled strokes meeting at top and bottom; `open_right` leaves the right side out (c)."""
        k, e = self.k, self.e
        rx = self.w / 2 * (0.85 if small else 1.0)
        ry = (k - 2 * e) / 2 * (0.78 if small else 1.0)
        cy = e + ry
        cx = x + rx
        if self.style == "gothic":
            # the back of a gothic bowl is a curve, its right side is broken
            left = arc(cx, cy, rx, ry, 90, 270)
            right = [(cx, cy + ry), (cx + rx, cy + 0.45 * ry), (cx + rx, cy - 0.45 * ry), (cx, cy - ry)]
        else:
            left = arc(cx, cy, rx, ry, 90, 270)
            right = arc(cx, cy, rx, ry, 90, -90)
        strokes = [(left, False)]
        if open_right:
            strokes.append((arc(cx, cy, rx, ry, 90, 35, 8), False, False))
            strokes.append((arc(cx, cy, rx, ry, 270, 320, 8), False, False))
        else:
            strokes.append((right, False, False))
        return strokes, 2 * rx

    def diag(self, p0, p1):
        return ([p0, p1], self.turn_diag, p1[1] < p0[1])

    # --- letters --------------------------------------------------------------------------------------
    def letter(self, ch):
        k, e, w = self.k, self.e, self.w
        s = []
        if ch == "i":
            s += self.stem(0, k - e)
            s.append(([(0, k + 0.9), (0.05, k + 1.2)], False, False))
            return s, (1.2) + 0.9
        if ch == "l":
            s += self.stem(0, self.asc - e)
            return s, (1.2) + 0.9
        if ch == "n":
            s += self.stem(0, k - e, exit_=False)
            s += self.arch(0, w)
            return s, (w + 1.0) + 0.9
        if ch == "m":
            s += self.stem(0, k - e, exit_=False)
            s += self.arch(0, 0.85 * w)
            s[-1:] = s[-1:]
            s = s[:-1] if self.style in ("round", "italic") and not self.feet else s
            s += self.arch(0.85 * w, 1.7 * w)
            return s, (1.7 * w + 1.0) + 0.9
        if ch == "h":
            s += self.stem(0, self.asc - e, exit_=False)
            s += self.arch(0, w)
            return s, (w + 1.0) + 0.9
        if ch == "r":
            s += self.stem(0, k - e)
            top = self.arch(0, 0.8 * w)[0][0]
            s.append((top[: len(top) * 2 // 3], False, False))
            return s, (0.8 * w + 0.6) + 0.9
        if ch == "u":
            s += self.stem(0, k - e, exit_=False)
            r = w / 2
            if self.style == "gothic":
                s.append(([(0, e + 0.9 * r), (r, e), (w, e + 0.9 * r)], False, False))
            else:
                s.append((arc(r, e + r, r, r, 180, 360), False, False))
            s += self.stem(w, k - e, entry=True)
            return s, (w + 1.0) + 0.9
        if ch == "o":
            b, adv = self.bowl(0)
            return b, (adv + 0.9) + 0.9
        if ch == "c":
            b, adv = self.bowl(0, open_right=True)
            return b, (adv + 0.7) + 0.9
        if ch == "e":
            b, adv = self.bowl(0, open_right=True)
            b.append(([(0.08, k / 2 + 0.1), (adv - 0.08, k / 2 + 0.1)], False, False))
            return b, (adv + 0.7) + 0.9
        if ch == "a":
            s += self.stem(w * 0.78, k - e)
            b, adv = self.bowl(0, small=True)
            s += b
            return s, (w * 0.78 + 1.0) + 0.9
        if ch == "d":
            b, adv = self.bowl(0)
            s += b
            s += self.stem(adv, self.asc - e)
            return s, (adv + 1.0) + 0.9
        if ch == "q":
            b, adv = self.bowl(0)
            s += b
            s += self.stem(adv, k - e, bottom=self.desc, exit_=False)
            return s, (adv + 1.0) + 0.9
        if ch == "b":
            s += self.stem(0, self.asc - e, exit_=False)
            b, adv = self.bowl(0)
            s.append(b[1])
            s.append(([(0, e), (adv / 2, e)], False, False))
            return s, (adv + 0.9) + 0.9
        if ch == "p":
            s += self.stem(0, k - e, bottom=self.desc, exit_=False)
            b, adv = self.bowl(0)
            s.append(b[1])
            s.append(([(0, e), (adv / 2, e)], False, False))
            return s, (adv + 0.9) + 0.9
        if ch == "g":
            b, adv = self.bowl(0, small=True)
            s += b
            s.append(([(adv, k - e - 0.3), (adv, e - 0.4)], False, False))
            s.append((arc(adv / 2, self.desc + 0.9, adv / 2 + 0.2, 0.9, 0, -180), False, False))
            return s, (adv + 0.9) + 0.9
        if ch == "t":
            s += self.stem(0, k + 0.6)
            s.append(([(-0.4, k - e), (0.9, k - e)], False, False))
            return s, (1.5) + 0.9
        if ch == "f":
            s += self.stem(0, self.asc - e - 0.5, exit_=False)
            s.append((arc(0.6, self.asc - e - 0.5, 0.6, 0.6, 180, 60, 8), False, False))
            s.append(([(-0.4, k - e), (0.9, k - e)], False, False))
            return s, (1.5) + 0.9
        if ch == "s":
            cy1, cy2 = k * 0.72, k * 0.28
            s.append((arc(w * 0.4, cy1, w * 0.4, k * 0.26 - e * 0.5, 60, 270, 18) +
                      arc(w * 0.4, cy2, w * 0.4, k * 0.26 - e * 0.5, 90, -110, 18), False))
            return s, (w * 0.8 + 0.7) + 0.9
        if ch == "v":
            s.append(self.diag((0, k - e), (w / 2, e)))
            s.append(self.diag((w / 2, e), (w, k - e)))
            return s, (w + 0.8) + 0.9
        if ch == "w":
            s.append(self.diag((0, k - e), (w * 0.45, e)))
            s.append(self.diag((w * 0.45, e), (w * 0.9, k - e)))
            s.append(self.diag((w * 0.9, k - e), (w * 1.35, e)))
            s.append(self.diag((w * 1.35, e), (w * 1.8, k - e)))
            return s, (w * 1.8 + 0.8) + 0.9
        if ch == "x":
            s.append(self.diag((0, k - e), (w * 0.9, e)))
            s.append(self.diag((w * 0.9, k - e), (0, e)))
            return s, (w * 0.9 + 0.9) + 0.9
        if ch == "y":
            s.append(self.diag((0, k - e), (w / 2, e)))
            s.append(self.diag((w, k - e), (w * 0.25, self.desc + 0.3)))
            return s, (w + 0.8) + 0.9
        if ch == "j":
            s += self.stem(0, k - e, bottom=self.desc + 0.8, exit_=False)
            s.append((arc(-0.7, self.desc + 0.8, 0.7, 0.8, 0, -150, 8), False, False))
            s.append(([(0, k + 0.9), (0.05, k + 1.2)], False, False))
            return s, (1.2) + 0.9
        if ch == "k":
            s += self.stem(0, self.asc - e)
            s.append(self.diag((w * 0.75, k - e), (0.15, k * 0.45)))
            s.append(self.diag((0.3, k * 0.5), (w * 0.8, e)))
            return s, (w * 0.8 + 0.8) + 0.9
        if ch == "z":
            s.append(([(0, k - e), (w * 0.85, k - e)], False, False))
            s.append(self.diag((w * 0.85, k - e), (0, e)))
            s.append(([(0, e), (w * 0.85, e)], False, False))
            return s, (w * 0.85 + 0.9) + 0.9
        raise KeyError(ch)


def layout(hand, words, slant_deg=0.0, space=None):
    """strokes of a line of words laid out left to right (nib units, baseline 0); x advance by letter."""
    out = []
    x = 0.0
    sp = (hand.w * 0.9) if space is None else space
    t = math.tan(math.radians(slant_deg))
    for wi, word in enumerate(words):
        for ch in word:
            strokes, adv = hand.letter(ch)
            strokes = [st if len(st) == 3 else (st[0], st[1], False) for st in strokes]
            for pts, turned, pressed in strokes:
                out.append(([(x + px + t * py, py) for px, py in pts], turned, pressed))
            x += adv
        x += sp
    return out, x
