#!/usr/bin/env python3
"""The archive's sheets: the four samples the solver sees and the twenty graded sheets the verifier
image renders at build time (generator side; the forge copy runs inside tests/Dockerfile).

    forge_sheets.py samples OUT_DIR     -> OUT_DIR/<code>/{scan.*, sheet.txt, ductus.csv}
    forge_sheets.py hidden  OUT_DIR     -> OUT_DIR/<code>/{scan.*, sheet.txt} and OUT_DIR/truth.csv

Every sheet passes an evidence check before it is kept: the reference profiler recovers all three
measures within half their tolerances. A sheet that fails is re-drawn from the next seed with the
same classes, so the classes' counts are fixed by the plan, not by luck.
"""
import csv
import math
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import forge  # noqa: E402

TOL = dict(nib_width_mm=0.06, pen_angle_deg=2.0)
HALF = {k: v / 2 for k, v in TOL.items()}

# the samples are short sheets (50 mm of writing) so the archive stays small
SAMPLE_PLAN = [
    dict(hand="round", nib="steel", paper="sized", skew=0.0, dpi=300, fmt="png", verso=False, shading=0.0, exercise=True, turned=False, width_mm=50.0),
    dict(hand="italic", nib="steel", paper="sized", skew=0.0, dpi=300, fmt="png", verso=False, shading=0.0, exercise=True, turned=False, width_mm=50.0),
    dict(hand="uncial", nib="steel", paper="sized", skew=0.0, dpi=300, fmt="png", verso=False, shading=0.0, exercise=True, turned=False, width_mm=50.0),
    dict(hand="gothic", nib="steel", paper="sized", skew=0.0, dpi=300, fmt="png", verso=False, shading=0.0, exercise=True, turned=False, width_mm=50.0),
]

# the twenty graded sheets: each class on at least six of them, one sheet with no class beyond the samples'
HIDDEN_PLAN = [
    # hand     nib      paper    skew   dpi  fmt    verso  shading
    ("round",  "quill", "soft",   2.8,  300, "pgm", True,  0.00),
    ("italic", "steel", "soft",  -3.4,  400, "png", False, 0.08),
    ("uncial", "reed",  "sized",  0.0,  600, "pgm", True,  0.00),
    ("gothic", "steel", "sized",  1.1,  300, "pgm", False, 0.10),
    ("round",  "reed",  "soft",  -2.6,  600, "png", True,  0.00),
    ("italic", "quill", "sized",  3.1,  300, "pgm", False, 0.00),
    ("uncial", "steel", "soft",   0.0,  300, "pgm", True,  0.07),
    ("gothic", "quill", "soft",  -3.8,  400, "png", False, 0.00),
    ("round",  "steel", "sized",  0.6,  600, "pgm", False, 0.12),
    ("italic", "reed",  "soft",   2.5,  300, "png", True,  0.00),
    ("uncial", "quill", "sized", -1.2,  400, "pgm", False, 0.00),
    ("gothic", "reed",  "sized",  3.5,  600, "pgm", True,  0.09),
    ("round",  "quill", "soft",   0.0,  400, "png", False, 0.00),
    ("italic", "steel", "soft",  -2.9,  600, "pgm", True,  0.00),
    ("uncial", "reed",  "soft",   1.4,  300, "png", False, 0.06),
    ("gothic", "steel", "sized", -0.8,  300, "pgm", True,  0.00),
    ("round",  "steel", "soft",   3.2,  400, "pgm", False, 0.00),
    ("italic", "quill", "sized",  0.0,  600, "png", True,  0.11),
    ("uncial", "steel", "sized",  0.0,  300, "pgm", False, 0.00),   # nothing beyond the samples' classes
    ("gothic", "quill", "soft",   2.7,  400, "pgm", False, 0.00),
]


def code_of(rng):
    return "".join(rng.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(4))


def settled(sheet, out_dir, truth):
    sys.path.insert(0, os.path.join(HERE, "..", "solution"))
    sys.path.insert(0, HERE)
    import profile as P  # noqa: E402
    got = P.profile(out_dir)
    return all(math.isfinite(got[k]) and abs(got[k] - truth[k]) <= HALF[k] for k in TOL), got


def make(kind, out_dir, start_seed, plan, keep_ductus):
    os.makedirs(out_dir, exist_ok=True)
    rows = []
    seed = start_seed
    rng = random.Random(start_seed)
    for classes in plan:
        if isinstance(classes, tuple):
            classes = dict(zip(("hand", "nib", "paper", "skew", "dpi", "fmt", "verso", "shading"), classes))
        while True:
            seed += 1
            sheet = forge.define(seed, classes)
            code = code_of(rng)
            target = os.path.join(out_dir, code)
            truth = forge.render(sheet, target)
            ok, got = settled(sheet, target, truth)
            if ok:
                break
            print("   dropped seed %d (%s): %s vs %s" % (seed, classes["hand"], {k: round(v, 2) for k, v in got.items() if k in TOL}, truth), flush=True)
            for fn in os.listdir(target):
                os.remove(os.path.join(target, fn))
            os.rmdir(target)
        print("kept %s seed %d %s" % (code, seed, classes), flush=True)
        if keep_ductus:
            with open(os.path.join(target, "ductus.csv"), "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["measure", "value"])
                w.writerow(["nib_width_mm", "%.2f" % truth["nib_width_mm"]])
                w.writerow(["pen_angle_deg", "%.1f" % truth["pen_angle_deg"]])
        rows.append((code, truth))
    if not keep_ductus:
        with open(os.path.join(out_dir, "truth.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["sheet", "nib_width_mm", "pen_angle_deg"])
            for code, truth in rows:
                w.writerow([code, "%.2f" % truth["nib_width_mm"], "%.1f" % truth["pen_angle_deg"]])


if __name__ == "__main__":
    kind, out = sys.argv[1], sys.argv[2]
    if kind == "samples":
        make(kind, out, 500, SAMPLE_PLAN, keep_ductus=True)
    else:
        make(kind, out, int(sys.argv[3]) if len(sys.argv) > 3 else 7000, HIDDEN_PLAN, keep_ductus=False)
