"""Render an exemplar sheet as the foundry's scanner would see it (generator side; never ships).

A sheet: two lines of words in one hand, written with a nib of width `w` mm and edge `te` mm held at
`alpha` degrees to the writing line, x-height `k` nib widths. The nib is a w x te rectangle swept along
each stroke's centre path at four times the scan resolution; a quill or reed opens by `splay` on
pulled downstrokes; ink spreads `spread` mm past the nib on the paper; the sheet lies on the glass
skewed by `skew` degrees; a second side may show through faintly; the scanner adds shading, grain,
blur and 8-bit quantisation. Writes scan.pgm or scan.png, sheet.txt, and returns the truth.
"""
import json
import math
import os
import random
import struct
import zlib

import numpy as np

import hands

HI = 1200.0   # dots per inch of the rendering grid
MM = 25.4

WORDS = ("minimum annum union common moon lemon noon inn nun mini mountain onion "
         "manual human nominal million dominion domain canon anneal manor column".split())
WORDS_ALL = ("quartz vexing jumbo wolves zephyr waxy oxygen vivid yearly dozen zebra fox "
             "velvet wizard axiom pyx lynx wavy query zinc jury vortex yolk sixty buzz".split()) + WORDS


def gaussian_blur(img, sigma):
    if sigma <= 0:
        return img
    r = int(3 * sigma + 1)
    x = np.arange(-r, r + 1)
    g = np.exp(-x * x / (2 * sigma * sigma))
    g /= g.sum()
    out = np.apply_along_axis(lambda m: np.convolve(m, g, mode="same"), 0, img)
    return np.apply_along_axis(lambda m: np.convolve(m, g, mode="same"), 1, out)


def dilate(mask, radius_px):
    """binary dilation by a disc (radius in pixels)."""
    r = int(math.ceil(radius_px))
    if r <= 0:
        return mask
    out = mask.copy()
    h, w = mask.shape
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx * dx + dy * dy > radius_px * radius_px:
                continue
            if dy == 0 and dx == 0:
                continue
            ys = slice(max(0, dy), h + min(0, dy))
            yd = slice(max(0, -dy), h + min(0, -dy))
            xs = slice(max(0, dx), w + min(0, dx))
            xd = slice(max(0, -dx), w + min(0, -dx))
            out[yd, xd] |= mask[ys, xs]
    return out


class Stamps:
    """boolean footprints of the nib's mark (a rectangle width x te mm, grown by the ink's spread on
    every side) at an angle, on the rendering grid."""

    def __init__(self, te_mm, spread_mm=0.0):
        self.te = te_mm * HI / MM
        self.spread = spread_mm * HI / MM
        self.cache = {}

    def get(self, width_mm, angle_deg):
        key = (round(width_mm, 3), round(angle_deg * 2) / 2)
        if key in self.cache:
            return self.cache[key]
        wpx = key[0] * HI / MM
        a = math.radians(key[1])
        r = int(math.ceil(max(wpx, self.te) / 2 + self.spread + 2))
        yy, xx = np.mgrid[-r:r + 1, -r:r + 1].astype(np.float64)
        # image rows run downward: the nib edge rising to the right in sheet terms falls in image terms
        u = xx * math.cos(a) - yy * math.sin(a)
        v = xx * math.sin(a) + yy * math.cos(a)
        du = np.maximum(np.abs(u) - wpx / 2, 0.0)
        dv = np.maximum(np.abs(v) - self.te / 2, 0.0)
        # coverage with a one-pixel soft edge: the distance past the mark's edge, clipped
        dist = np.sqrt(du * du + dv * dv) - self.spread
        m = np.clip(0.5 - dist, 0.0, 1.0).astype(np.float32)
        self.cache[key] = (m, r)
        return m, r


def render_strokes(mask, strokes_mm, origin, stamps, w_mm, alpha, splay, turn_delta, skew):
    """sweep the nib along each stroke (points in mm, sheet coordinates) into `mask` (rows down)."""
    h, wpx = mask.shape
    s_px = HI / MM
    cs, sn = math.cos(math.radians(skew)), math.sin(math.radians(skew))
    for pts, turned, pressed in strokes_mm:
        ang = alpha + (turn_delta if turned else 0.0) + skew
        # rotate the path by the skew about the sheet's origin, then to image coordinates
        p = np.array([(origin[0] + (x * cs - y * sn), origin[1] - (x * sn + y * cs)) for x, y in pts]) * s_px
        for i in range(len(p) - 1):
            d = p[i + 1] - p[i]
            n = max(2, int(np.hypot(*d) / 0.5) + 1)
            # pressure: pulled strokes run downward in sheet terms (image rows increasing)
            down = d[1] / (np.hypot(*d) + 1e-9)
            pressure = min(1.0, max(0.0, (down - 0.90) / 0.08)) if pressed else 0.0
            width = w_mm * (1 + splay * pressure)
            st, r = stamps.get(width, ang)
            for t in np.linspace(0, 1, n):
                cx, cy = p[i] + d * t
                xi, yi = int(round(cx)), int(round(cy))
                y0, y1 = yi - r, yi + r + 1
                x0, x1 = xi - r, xi + r + 1
                if y0 < 0 or x0 < 0 or y1 > h or x1 > wpx:
                    continue
                np.maximum(mask[y0:y1, x0:x1], st, out=mask[y0:y1, x0:x1])


def write_pgm(path, img):
    with open(path, "wb") as f:
        f.write(b"P5\n%d %d\n255\n" % (img.shape[1], img.shape[0]))
        f.write(img.astype(np.uint8).tobytes())


def write_png(path, img, rng):
    """8-bit greyscale PNG, non-interlaced, with the per-row filters an encoder chooses."""
    h, w = img.shape
    rows = img.astype(np.uint8)
    raw = bytearray()
    prev = np.zeros(w, dtype=np.int32)
    for y in range(h):
        cur = rows[y].astype(np.int32)
        ftype = rng.choice([0, 1, 2, 4]) if y > 0 else rng.choice([0, 1])
        if ftype == 0:
            line = cur
        elif ftype == 1:
            line = (cur - np.concatenate([[0], cur[:-1]])) & 255
        elif ftype == 2:
            line = (cur - prev) & 255
        else:
            a = np.concatenate([[0], cur[:-1]])
            b = prev
            c = np.concatenate([[0], prev[:-1]])
            p = a + b - c
            pa, pb, pc = np.abs(p - a), np.abs(p - b), np.abs(p - c)
            pred = np.where((pa <= pb) & (pa <= pc), a, np.where(pb <= pc, b, c))
            line = (cur - pred) & 255
        raw.append(ftype)
        raw.extend(line.astype(np.uint8).tobytes())
        prev = cur

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 6))
    png += chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)


def fit_words(hand, words, slant, room):
    """as many of the words as fit in `room` nib units, never fewer than two."""
    for n in range(len(words), 1, -1):
        strokes, adv = hands.layout(hand, words[:n], slant)
        if adv <= room or n == 2:
            return strokes, adv
    return hands.layout(hand, words[:2], slant)


def render(sheet, out_dir):
    """sheet: dict(seed, hand, w, te, alpha, k, splay, spread, skew, dpi, fmt, verso, shading, slant,
    turn_delta, words (two lists), verso_words, ink, paper, grain). Writes out_dir/scan.*, sheet.txt."""
    rng = np.random.default_rng(sheet["seed"])
    prng = random.Random(sheet["seed"])
    w, te, alpha, k = sheet["w"], sheet["te"], sheet["alpha"], sheet["k"]
    ext = w * math.sin(math.radians(alpha)) + te * math.cos(math.radians(alpha))
    e = ext / (2 * w)
    hand = hands.Hand(sheet["hand"], k, e, alpha, sheet["slant"])
    # layout in mm
    pitch = (hand.asc - hand.desc) * w + 2.0 * w          # line pitch
    margin = 10.0
    width_mm = sheet.get("width_mm", 150.0)
    lines = []
    for li, words in enumerate(sheet["words"]):
        strokes, adv = fit_words(hand, words, sheet["slant"], (width_mm - 2 * margin) / w)
        base_y = margin + (1 - li) * pitch + (-hand.desc) * w  # line 0 on top
        for pts, turned, pressed in strokes:
            lines.append(([(margin + px * w, base_y + py * w) for px, py in pts], turned, pressed))
    height_mm = 2 * margin + 2 * pitch
    dpi = sheet["dpi"]
    ss = int(round(HI / dpi))
    W = int(round(width_mm * dpi / MM)) * ss
    H = int(round(height_mm * dpi / MM)) * ss
    mask = np.zeros((H, W), dtype=np.float32)
    stamps = Stamps(te, sheet["spread"])
    # rotate about the sheet centre: origin so that the centre maps onto itself
    cx, cy = width_mm / 2, height_mm / 2
    cs, sn = math.cos(math.radians(sheet["skew"])), math.sin(math.radians(sheet["skew"]))
    origin = (cx - (cx * cs - cy * sn), cy + (cx * sn + cy * cs))
    render_strokes(mask, lines, origin, stamps, w, alpha, sheet["splay"], sheet["turn_delta"], sheet["skew"])
    cov = mask.reshape(H // ss, ss, W // ss, ss).mean(axis=(1, 3))
    paper, ink = sheet["paper_level"], sheet["ink_level"]
    img = paper * (1 - cov) + ink * cov
    if sheet["verso"]:
        vmask = np.zeros((H, W), dtype=np.float32)
        vlines = []
        for li, words in enumerate(sheet["verso_words"]):
            strokes, adv = fit_words(hand, words, sheet["slant"], (width_mm - 2 * margin) / w)
            base_y = margin + (1 - li) * pitch + (-hand.desc) * w + 0.37 * pitch
            for pts, turned, pressed in strokes:
                # the other side is mirrored left to right
                vlines.append(([(width_mm - (margin + px * w), base_y + py * w) for px, py in pts], turned, pressed))
        render_strokes(vmask, vlines, origin, Stamps(te, sheet["spread"]), w, -alpha, sheet["splay"], -sheet["turn_delta"], sheet["skew"])
        vcov = vmask.reshape(H // ss, ss, W // ss, ss).mean(axis=(1, 3))
        vcov = gaussian_blur(vcov, 1.2)
        img = img - sheet["verso_depth"] * (paper - ink) * vcov
    h, wd = img.shape
    if sheet["shading"] > 0:
        yy, xx = np.mgrid[0:h, 0:wd]
        img = img * (1 - sheet["shading"] * (0.7 * xx / wd + 0.3 * yy / h))
    # paper texture and grain
    tex = rng.normal(0, 1, (h // 8 + 1, wd // 8 + 1))
    tex = gaussian_blur(tex, 1.0)
    tex = np.kron(tex, np.ones((8, 8)))[:h, :wd]
    img = img + sheet["grain"] * 1.5 * tex
    img = gaussian_blur(img, sheet["blur"])
    img = img + rng.normal(0, sheet["grain"], img.shape)
    img = np.clip(np.round(img), 0, 255).astype(np.uint8)
    os.makedirs(out_dir, exist_ok=True)
    for fn in os.listdir(out_dir):
        os.remove(os.path.join(out_dir, fn))
    if sheet["fmt"] == "png":
        write_png(os.path.join(out_dir, "scan.png"), img, prng)
    else:
        write_pgm(os.path.join(out_dir, "scan.pgm"), img)
    with open(os.path.join(out_dir, "sheet.txt"), "w") as f:
        f.write("hand: %s\nnib: %s\npaper: %s\ndpi: %d\nscribe: %s\n" % (
            sheet["hand"], sheet["nib"], sheet["paper_name"], dpi, sheet["scribe"]))
    return dict(nib_width_mm=w, pen_angle_deg=alpha, x_height_nibs=k)


HANDS = {
    #            alpha range, k range, slant, turn_delta
    "round":  ((27.0, 36.0), (4.0, 5.0), 0.0, 15.0),
    "italic": ((40.0, 50.0), (4.5, 5.5), 7.0, 0.0),
    "uncial": ((15.0, 27.0), (3.2, 4.2), 0.0, 0.0),
    "gothic": ((36.0, 46.0), (4.4, 5.4), 0.0, -20.0),
}


def draw_words(rng, pool, n):
    return [rng.choice(pool) for _ in range(n)]


def define(seed, classes):
    """a sheet definition from a seed and a set of class flags:
    nib: steel|quill|reed; paper: sized|soft; skew: float degrees; hand; dpi; fmt; verso; shading."""
    rng = random.Random(seed)
    hand = classes["hand"]
    ar, kr, slant, turn = HANDS[hand]
    nib = classes["nib"]
    splay = {"steel": 0.0, "quill": rng.uniform(0.10, 0.16), "reed": rng.uniform(0.14, 0.22)}[nib]
    te = {"steel": rng.uniform(0.09, 0.11), "quill": rng.uniform(0.045, 0.065), "reed": rng.uniform(0.07, 0.09)}[nib]
    paper = classes["paper"]
    spread = rng.uniform(0.015, 0.03) if paper == "sized" else rng.uniform(0.08, 0.16)
    w = round(rng.uniform(1.2, 3.0), 2)
    pool = WORDS if classes.get("exercise") else WORDS_ALL
    nwords = 4 if w > 2.2 else (5 if w > 1.6 else 7)
    return dict(
        seed=seed, hand=hand, w=w, te=round(te, 3), alpha=round(rng.uniform(*ar), 1), k=round(rng.uniform(*kr), 1),
        nib=nib, splay=round(splay, 3), paper_name=paper, spread=round(spread, 3), skew=classes["skew"],
        dpi=classes["dpi"], fmt=classes["fmt"], verso=classes["verso"], verso_depth=rng.uniform(0.14, 0.22),
        shading=classes["shading"], slant=slant, turn_delta=turn if classes.get("turned", True) else 0.0,
        words=[draw_words(rng, pool, nwords), draw_words(rng, pool, nwords)],
        verso_words=[draw_words(rng, pool, nwords), draw_words(rng, pool, nwords)],
        paper_level=rng.uniform(222, 242), ink_level=rng.uniform(28, 60), grain=rng.uniform(2.0, 3.5),
        blur=rng.uniform(0.5, 0.75), scribe=rng.choice(["AB", "CD", "EF", "GH", "JK"]),
        width_mm=classes.get("width_mm", 150.0))


if __name__ == "__main__":
    import sys
    cls = dict(hand=sys.argv[2], nib=sys.argv[3], paper=sys.argv[4], skew=float(sys.argv[5]), dpi=int(sys.argv[6]),
               fmt=sys.argv[7], verso=sys.argv[8] == "1", shading=float(sys.argv[9]))
    sh = define(int(sys.argv[1]), cls)
    print(render(sh, sys.argv[10]), sh["w"], sh["alpha"], sh["k"], sh["splay"], sh["spread"])
