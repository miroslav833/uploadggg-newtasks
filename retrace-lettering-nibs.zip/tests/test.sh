#!/bin/bash
# The reward is 0 unless the program at /app/ductus/profile.py gets enough graded sheets right.
# Nothing the program writes is trusted: it runs under an invented account that is stopped before
# the verifier reads its output, and the reward file is written by root alone.
mkdir -p /logs/verifier
# the harness reads the reward afterwards as its own user: note the folder's owner and mode, lock it
# while the program runs, and give them back once the reward is written
owner_before=$(stat -c '%u:%g' /logs/verifier)
mode_before=$(stat -c '%a' /logs/verifier)
chown 0:0 /logs/verifier
chmod 700 /logs/verifier
if [ "$(stat -c '%u %a' /logs/verifier)" != "0 700" ]; then
  echo "verifier folder is not root-only; refusing to grade"
  exit 1
fi
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
find /logs/verifier -mindepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' -o ! -uid 0 \) -exec rm -rf {} + 2>/dev/null
echo 0 > /logs/verifier/reward.txt
REPORT=/run/verifier
mkdir -p "$REPORT"
chmod 700 "$REPORT"
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
if [ -d /app/ductus ]; then
  chown -R 0:0 /app/ductus
  chmod -R u+rwX,go+rX,go-w /app/ductus
fi
chmod 1777 /tmp /var/tmp 2>/dev/null
cd /tests || exit 0
if python3 -m pytest -q -s -p no:cacheprovider -rA --ctrf "$REPORT/ctrf.json" test_ductus.py; then
  verdict=1
else
  verdict=0
fi
find /logs/verifier -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
rm -f /logs/verifier/reward*
echo "$verdict" > /logs/verifier/reward.txt
cp "$REPORT/ctrf.json" /logs/verifier/ctrf.json 2>/dev/null
chmod 644 /logs/verifier/reward.txt /logs/verifier/ctrf.json 2>/dev/null
chown "$owner_before" /logs/verifier 2>/dev/null
chmod "$mode_before" /logs/verifier 2>/dev/null
exit 0
