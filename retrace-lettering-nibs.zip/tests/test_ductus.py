"""The forged sheets are complete, and the solver's program gets enough of them right."""
import os

import bench

SHEETS = 20
MARK = 18


def test_forged_sheets_are_complete():
    codes = bench.sheets()
    want = bench.truth()
    assert len(codes) == SHEETS and set(codes) == set(want)
    for code in codes:
        files = os.listdir(os.path.join(bench.VAULT, code))
        assert "sheet.txt" in files and ("scan.pgm" in files or "scan.png" in files), code
        assert all(v > 0 for v in want[code].values()), code


def test_program_reaches_the_mark():
    assert os.path.isfile(bench.TOOL), "no /app/ductus/profile.py"
    results = bench.bench()
    right = sum(results.values())
    print("sheets right: %d of %d (mark %d)" % (right, len(results), MARK))
    print("missed: %s" % sorted(c for c, ok in results.items() if not ok))
    assert right >= MARK
