#!/usr/bin/env python3
"""Reference profiler: a hand's ductus from a scanned exemplar sheet (numpy and the standard library).

The nib is a rectangle, width w and edge te, held at the pen angle to the writing line; a stroke's
thickness across its direction is w|sin f| + te|cos f| with f the angle between the nib's edge and the
stroke, plus the ink halo on both edges. Every edge pixel of the ink gives one (direction, thickness)
sample by a ray cast across the stroke; the densest thickness in each direction bin is the hand's own
strokes (junctions, crossings and turned-pen strokes are sparser). The pen angle and the halo come
from the hairlines (the nib slid along its own edge), and the nib from the bins near the thick
direction away from the pulled downstrokes, where a quill or reed opens under pressure. The writing
line is found by shearing the ink to the sharpest row profile.
"""
import math
import os
import struct
import sys
import zlib

import numpy as np


# ---- the scan -----------------------------------------------------------------------------------
def read_pgm(path):
    data = open(path, "rb").read()
    fields, i = [], 0
    while len(fields) < 4:
        while data[i:i + 1].isspace():
            i += 1
        if data[i:i + 1] == b"#":
            while data[i:i + 1] not in (b"\n", b""):
                i += 1
            continue
        j = i
        while not data[j:j + 1].isspace():
            j += 1
        fields.append(data[i:j])
        i = j
    i += 1
    assert fields[0] == b"P5" and int(fields[3]) == 255
    w, h = int(fields[1]), int(fields[2])
    return np.frombuffer(data[i:i + w * h], dtype=np.uint8).reshape(h, w)


def read_png(path):
    data = open(path, "rb").read()
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    i, idat, w, h = 8, [], None, None
    while i < len(data):
        n = struct.unpack(">I", data[i:i + 4])[0]
        tag, body = data[i + 4:i + 8], data[i + 8:i + 8 + n]
        if tag == b"IHDR":
            w, h, depth, ctype, _, _, inter = struct.unpack(">IIBBBBB", body)
            assert depth == 8 and ctype == 0 and inter == 0
        elif tag == b"IDAT":
            idat.append(body)
        elif tag == b"IEND":
            break
        i += 12 + n
    raw = zlib.decompress(b"".join(idat))
    out = np.zeros((h, w), dtype=np.int32)
    prev = np.zeros(w, dtype=np.int32)
    stride = w + 1
    for y in range(h):
        f = raw[y * stride]
        line = np.frombuffer(raw[y * stride + 1:(y + 1) * stride], dtype=np.uint8).astype(np.int32)
        if f == 0:
            cur = line
        elif f == 1:
            cur = np.cumsum(line) & 255
        elif f == 2:
            cur = (line + prev) & 255
        elif f == 3:
            cur = np.zeros(w, dtype=np.int32)
            for x in range(w):
                cur[x] = (line[x] + ((cur[x - 1] if x else 0) + prev[x]) // 2) & 255
        else:
            cur = np.zeros(w, dtype=np.int32)
            for x in range(w):
                a = cur[x - 1] if x else 0
                b = prev[x]
                c = prev[x - 1] if x else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pred = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                cur[x] = (line[x] + pred) & 255
        out[y] = cur
        prev = cur
    return out.astype(np.uint8)


def read_sheet(sheet_dir):
    meta = {}
    for line in open(os.path.join(sheet_dir, "sheet.txt")):
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    if os.path.exists(os.path.join(sheet_dir, "scan.pgm")):
        img = read_pgm(os.path.join(sheet_dir, "scan.pgm"))
    else:
        img = read_png(os.path.join(sheet_dir, "scan.png"))
    return img.astype(np.float64), float(meta["dpi"]), meta


# ---- helpers ------------------------------------------------------------------------------------
def blur(img, sigma):
    """Gaussian blur, the borders padded with their own edge values."""
    r = int(3 * sigma + 1)
    x = np.arange(-r, r + 1)
    g = np.exp(-x * x / (2 * sigma * sigma))
    g /= g.sum()
    pad = np.pad(img, r, mode="edge")
    out = np.apply_along_axis(lambda m: np.convolve(m, g, mode="valid"), 0, pad)
    return np.apply_along_axis(lambda m: np.convolve(m, g, mode="valid"), 1, out)


def scharr(img):
    """(d/drow, d/dcol) by the Scharr kernels, whose response hardly turns with the edge's angle."""
    k1 = np.array([3.0, 10.0, 3.0]) / 16.0
    k2 = np.array([1.0, 0.0, -1.0]) / 2.0
    gy = np.apply_along_axis(lambda m: np.convolve(m, k1, mode="same"), 1, img)
    gy = np.apply_along_axis(lambda m: np.convolve(m, k2, mode="same"), 0, gy)
    gx = np.apply_along_axis(lambda m: np.convolve(m, k1, mode="same"), 0, img)
    gx = np.apply_along_axis(lambda m: np.convolve(m, k2, mode="same"), 1, gx)
    return gy, gx


def paper_level(img, block=128):
    """the scanner's shading: the bright level of each block (wider than any stroke), interpolated."""
    h, w = img.shape
    bh, bw = -(-h // block), -(-w // block)
    pad = np.full((bh * block, bw * block), np.nan)
    pad[:h, :w] = img
    blocks = pad.reshape(bh, block, bw, block).transpose(0, 2, 1, 3).reshape(bh, bw, -1)
    lvl = np.nanpercentile(blocks, 98, axis=2)
    big = np.kron(lvl, np.ones((block, block)))[:h, :w]
    return blur(big, block / 2)


def normalise(img):
    n = img / paper_level(img)
    ink = np.percentile(n, 0.3)
    thr = 0.5 * (1.0 + ink)
    return n, thr


# ---- the writing line ---------------------------------------------------------------------------
def shear_profile(mask, angle_deg):
    """row sums of the ink after shearing columns so a line at `angle_deg` (counter-clockwise on the
    sheet) becomes horizontal."""
    h, w = mask.shape
    t = math.tan(math.radians(angle_deg))
    xs = np.arange(w)
    shift = np.round(xs * t).astype(int)
    prof = np.zeros(h + 2 * (abs(shift).max() + 1))
    off = abs(shift).max() + 1
    cols = mask.sum(axis=0)  # unused shortcut guard
    del cols
    for s in np.unique(shift):
        sel = xs[shift == s]
        rows = mask[:, sel].sum(axis=1)
        prof[off + s:off + s + h] += rows
    return prof, off


def skew_of(mask):
    best = None
    for a in np.arange(-6.0, 6.01, 0.25):
        p, _ = shear_profile(mask, a)
        score = float((p * p).sum())
        if best is None or score > best[0]:
            best = (score, a)
    a0 = best[1]
    best = None
    for a in np.arange(a0 - 0.3, a0 + 0.31, 0.05):
        p, _ = shear_profile(mask, a)
        score = float((p * p).sum())
        if best is None or score > best[0]:
            best = (score, a)
    return best[1]


# ---- thickness by direction ---------------------------------------------------------------------
def bilinear(img, ys, xs):
    h, w = img.shape
    ys = np.clip(ys, 0, h - 1.001)
    xs = np.clip(xs, 0, w - 1.001)
    y0 = ys.astype(int)
    x0 = xs.astype(int)
    fy, fx = ys - y0, xs - x0
    v = (img[y0, x0] * (1 - fy) * (1 - fx) + img[y0 + 1, x0] * fy * (1 - fx)
         + img[y0, x0 + 1] * (1 - fy) * fx + img[y0 + 1, x0 + 1] * fy * fx)
    return v


def samples(n, thr, mask, max_len, rng, cap=70000, positions=False):
    """(direction degrees in sheet terms mod 180, thickness px) for edge pixels of the ink."""
    gy, gx = scharr(n)
    # the edge orientation from the structure tensor over a small neighbourhood: a single pixel's
    # gradient wobbles by several degrees on a grained scan, the tensor's axis does not
    jyy, jxx, jxy = blur(gy * gy, 1.5), blur(gx * gx, 1.5), blur(gx * gy, 1.5)
    inner = mask.copy()
    inner[1:] &= mask[:-1]
    inner[:-1] &= mask[1:]
    inner[:, 1:] &= mask[:, :-1]
    inner[:, :-1] &= mask[:, 1:]
    edge = mask & ~inner
    edge[:2] = edge[-2:] = False
    edge[:, :2] = edge[:, -2:] = False
    ys, xs = np.nonzero(edge)
    if len(ys) > cap:
        pick = rng.choice(len(ys), cap, replace=False)
        ys, xs = ys[pick], xs[pick]
    g = np.stack([gy[ys, xs], gx[ys, xs]], axis=1)
    mag = np.hypot(g[:, 0], g[:, 1])
    ok = mag > 0.02
    ys, xs, g, mag = ys[ok], xs[ok], g[ok], mag[ok]
    # the tensor's major axis (the normal's orientation), signed by the pixel's own gradient
    a, b, c = jyy[ys, xs], jxx[ys, xs], jxy[ys, xs]
    theta = 0.5 * np.arctan2(2 * c, a - b)          # orientation of the (row, col) normal
    ax = np.stack([np.cos(theta), np.sin(theta)], axis=1)
    sign = np.sign((ax * g).sum(axis=1))
    sign[sign == 0] = 1
    nrm = -ax * sign[:, None]       # into the ink (ink is dark)
    step = 0.25
    ts = np.arange(-6.0, max_len, step)
    ink = 2 * thr - 1          # the ink's own level (thr is the midpoint between paper and ink)
    dirs, thick, pos, mass = [], [], [], []
    for s in range(0, len(ys), 8000):
        yy, xx, nn = ys[s:s + 8000], xs[s:s + 8000], nrm[s:s + 8000]
        py = yy[:, None] + ts[None, :] * nn[:, 0:1]
        px = xx[:, None] + ts[None, :] * nn[:, 1:2]
        v = bilinear(n, py, px)
        dark = v < thr
        # entry: first dark sample at or after the start; exit: first light sample after it
        first = np.argmax(dark, axis=1)
        has_entry = dark[np.arange(len(yy)), first]
        after = dark.copy()
        after[np.arange(len(yy))[:, None] * 0 + np.arange(len(ts))[None, :] <= first[:, None]] = True
        exit_ = np.argmax(~after, axis=1)
        has_exit = (~after)[np.arange(len(yy)), exit_]
        good = has_entry & has_exit & (first > 0) & (exit_ > first)
        if not good.any():
            continue
        idx = np.nonzero(good)[0]
        f, e = first[idx], exit_[idx]
        # subpixel crossings by linear interpolation of the level
        v0a, v0b = v[idx, f - 1], v[idx, f]
        t_in = ts[f - 1] + step * (v0a - thr) / np.maximum(v0a - v0b, 1e-6)
        v1a, v1b = v[idx, e - 1], v[idx, e]
        t_out = ts[e - 1] + step * (thr - v1a) / np.maximum(v1b - v1a, 1e-6)
        th = t_out - t_in
        # the ink's mass along the ray, from 3 px before the entry to 3 px past the exit: blur moves ink
        # about but conserves it, so this is the geometric thickness even for a hairline
        span = (ts[None, :] >= (t_in - 3.0)[:, None]) & (ts[None, :] <= (t_out + 3.0)[:, None])
        before = ts[None, :] < (t_in - 3.0)[:, None]
        paper = (v[idx] * before).sum(axis=1) / np.maximum(before.sum(axis=1), 1)
        ms = ((paper[:, None] - v[idx]) * span).sum(axis=1) * step / np.maximum(paper - ink, 0.2)
        # the stroke runs across the normal: a vertical stroke's normal points along the columns, a
        # horizontal stroke's along the rows; on the sheet (rows run downward) that is this angle
        ang = np.degrees(np.arctan2(nn[idx, 1], nn[idx, 0]))
        dirs.append(np.mod(ang, 180.0))
        thick.append(th)
        mass.append(ms)
        pos.append(np.stack([yy[idx], xx[idx]], axis=1))
    if positions:
        return np.concatenate(dirs), np.concatenate(thick), np.concatenate(pos), np.concatenate(mass)
    return np.concatenate(dirs), np.concatenate(thick), np.concatenate(mass)


EDGE_MM = {"steel": 0.10, "quill": 0.055, "reed": 0.08}   # the archive's nib stock: edge thickness


def thickness_scale(thick, max_len):
    """about the widest stroke: the thickest of the strong peaks of the whole thickness histogram
    (the hand's strokes peak at their thicknesses; rays through junctions and along strokes only
    spread)."""
    hist, edges = np.histogram(thick[(thick > 0.5) & (thick < 0.5 * max_len)], bins=np.arange(0, 0.5 * max_len, 0.25))
    hist = np.convolve(hist, np.ones(7) / 7, mode="same")
    top = hist.max()
    peaks = [i for i in range(1, len(hist) - 1) if hist[i] >= hist[i - 1] and hist[i] > hist[i + 1] and hist[i] >= 0.12 * top]
    return float(edges[peaks[-1]] + 0.125) if peaks else float(edges[int(np.argmax(hist))] + 0.125)


TURNED = {"round": 15.0, "gothic": -20.0}   # the handbook: which hands turn the pen, and by about how much


def angle_from_hairlines(dirs, thick, wmax, te_px, mass=None, hand=None):
    """the pen angle and the ink's halo from the hairlines: the entry and exit strokes are the nib
    slid along its own edge, so they run at the pen angle and are the thinnest marks on the sheet
    (the nib's edge plus the halo on both sides). Returns (angle, halo, second angle or None), the
    second being a turned pen's strokes if their ends make a peak of their own among the long rays."""
    thin = (thick > 0.5) & (thick < 0.3 * wmax)
    d = dirs[thin]
    hist, edges = np.histogram(d, bins=np.arange(0, 180.5, 0.5))
    hist = np.convolve(hist, np.ones(5) / 5, mode="same")
    centres = edges[:-1] + 0.25
    m = int(np.argmax(hist))
    lo, hi = max(0, m - 3), min(len(hist), m + 4)
    wts = hist[lo:hi]
    ang = float((centres[lo:hi] * wts).sum() / wts.sum())
    hair = None
    meas = thick if mass is None else mass
    for _ in range(2):
        near = thin & (np.abs(np.sin(np.radians(dirs - ang))) < np.sin(np.radians(3)))
        t = meas[near]
        h2, e2 = np.histogram(t, bins=np.arange(0, 0.3 * wmax + 0.2, 0.2))
        h2 = np.convolve(h2, np.ones(3) / 3, mode="same")
        k = int(np.argmax(h2))
        lo2, hi2 = max(0, k - 2), min(len(h2), k + 3)
        hair = float(((e2[lo2:hi2] + 0.1) * h2[lo2:hi2]).sum() / h2[lo2:hi2].sum())
        # second pass: only the hairlines themselves (curves passing near the angle are thicker)
        thin = (thick > 0.5) & (thick < hair + 1.0)
        d = dirs[thin]
        hist, edges = np.histogram(d, bins=np.arange(0, 180.5, 0.5))
        hist = np.convolve(hist, np.ones(5) / 5, mode="same")
        m = int(np.argmax(hist))
        lo, hi = max(0, m - 3), min(len(hist), m + 4)
        wts = hist[lo:hi]
        ang = float((centres[lo:hi] * wts).sum() / wts.sum())
    halo = max(0.0, hair - te_px)
    # a turned pen, in the hands the handbook says turn it: the turned strokes' ends make a peak of
    # their own among the long rays, near the documented offset from the hand's angle
    second = None
    if hand in TURNED:
        long_ = thick > 1.5 * wmax
        if long_.sum() >= 200:
            h3, e3 = np.histogram(dirs[long_], bins=np.arange(0, 180.5, 0.5))
            h3 = np.convolve(h3, np.ones(5) / 5, mode="same")
            c3 = e3[:-1] + 0.25
            want = np.mod(ang + TURNED[hand], 180.0)
            gap = np.abs(c3 - want)
            gap = np.minimum(gap, 180 - gap)
            h3[gap > 6] = 0
            if h3.max() > 0:
                j = int(np.argmax(h3))
                second = float(c3[j])
    return ang, halo, second


def proper_modes(dirs, thick, max_len, cap=None, bin_deg=4.0, hairline=None):
    """per direction bin, the thickness of the hand's own strokes: the strongest peak of the bin's
    thickness histogram below `cap` (rays through junctions and along stroke ends are longer and
    spread out; a turned pen's strokes are fewer). Within a few degrees of `hairline` (the pen angle)
    the hand's own strokes are the thinnest there are, so the lowest prominent peak is taken."""
    out = []
    edges = np.arange(0, 180 + bin_deg / 2, bin_deg)
    top_t = max_len if cap is None else cap
    for a, b in zip(edges[:-1], edges[1:]):
        sel = (dirs >= a) & (dirs < b) & (thick > 0.5) & (thick < top_t)
        if sel.sum() < 40:
            continue
        t = thick[sel]
        hist, hedges = np.histogram(t, bins=np.arange(0, top_t + 0.25, 0.25))
        hist = np.convolve(hist, np.ones(5) / 5, mode="same")
        m = int(np.argmax(hist))
        if hairline is not None and math.isfinite(hairline) and abs(np.sin(np.radians((a + b) / 2 - hairline))) < np.sin(np.radians(6)):
            top = hist.max()
            lows = [i for i in range(1, len(hist) - 1) if hist[i] >= hist[i - 1] and hist[i] > hist[i + 1]
                    and hist[i] >= 0.35 * top]
            if lows:
                m = lows[0]
        if hist[m] < 6:
            continue
        lo, hi = max(0, m - 1), min(len(hist), m + 2)
        wts = hist[lo:hi]
        centre = ((hedges[lo:hi] + 0.125) * wts).sum() / wts.sum()
        near = sel.copy()
        near[sel] = np.abs(t - centre) < 0.6
        out.append((float(dirs[near].mean()) if near.sum() else (a + b) / 2, centre, float(near.sum())))
    return out


def fit_width(modes, ang, te_px, halo_px, second=None, debug=False):
    """w: thickness - te|cos(d-ang)| - halo = w|sin(d-ang)| over the bins near the thick direction
    (ang + 90) that lie off the vertical, where a quill or reed opens on the pulled strokes."""
    d = np.array([m[0] for m in modes])
    t = np.array([m[1] for m in modes])
    wgt = np.array([m[2] for m in modes])
    f = np.radians(d - ang)
    sf = np.abs(np.sin(f))
    off_vertical = np.abs(d - 90) > 27
    # within 18 degrees of the thick direction the model is flat to 5 per cent, and a sample binned a
    # few degrees off (junctions, short strokes) keeps its true thickness
    keep = off_vertical & (sf > 0.95) & (wgt >= 30)
    if second is not None:
        keep &= np.abs(np.sin(np.radians(d - second - 90))) > np.sin(np.radians(10))
    if not keep.any():
        keep = off_vertical & (sf > 0.85) & (wgt >= 20)
    y = t - te_px * np.abs(np.cos(f)) - halo_px
    est = y / np.maximum(sf, 1e-6)
    if not keep.any():
        return (float("nan"), []) if debug else float("nan")
    order = np.argsort(est[keep])
    cum = np.cumsum(wgt[keep][order])
    w = float(est[keep][order][int(np.searchsorted(cum, cum[-1] / 2))])   # weighted median to start
    for _ in range(2):
        res = np.abs(est - w)
        nxt = keep & (res < 1.0)
        if nxt.sum() < 1 or nxt.sum() == keep.sum():
            break
        keep = nxt
        w = float((est[keep] * wgt[keep]).sum() / wgt[keep].sum())
    w = float((est[keep] * wgt[keep]).sum() / wgt[keep].sum())
    if debug:
        return w, [(round(float(a), 1), round(float(b), 2), int(c), bool(k)) for a, b, c, k in zip(d, t, wgt, keep)]
    return w


def profile(sheet_dir, debug=False):
    img, dpi, meta = read_sheet(sheet_dir)
    n, thr = normalise(img)
    n = blur(n, 0.5)
    mask = n < thr
    skew = skew_of(mask[::2, ::2]) if mask.shape[0] > 1200 else skew_of(mask)
    px_mm = dpi / 25.4
    max_len = 3.6 * 3.0 * px_mm
    rng = np.random.default_rng(0)
    dirs, thick, mass = samples(n, thr, mask, max_len=max_len, rng=rng)
    dirs = np.mod(dirs - skew, 180.0)
    wmax = thickness_scale(thick, max_len)
    te_px = EDGE_MM.get(meta.get("nib", "steel"), 0.10) * px_mm
    ang, halo_px, second = angle_from_hairlines(dirs, thick, wmax, te_px, mass, meta.get("hand"))
    modes = proper_modes(dirs, thick, max_len, cap=1.6 * wmax, hairline=ang)
    w_px, rows = fit_width(modes, ang, te_px, halo_px, second, debug=True)
    out = dict(nib_width_mm=w_px / px_mm, pen_angle_deg=ang,
               skew=skew, halo_mm=halo_px / px_mm, wmax_mm=wmax / px_mm)
    if debug:
        out["rows"], out["second"], out["px_mm"] = rows, second, px_mm
    return out


def main():
    sheet_dir, out = sys.argv[1], sys.argv[2]
    r = profile(sheet_dir)
    with open(out, "w") as f:
        f.write("measure,value\n")
        f.write("nib_width_mm,%.2f\n" % r["nib_width_mm"])
        f.write("pen_angle_deg,%.1f\n" % r["pen_angle_deg"])


if __name__ == "__main__":
    main()
