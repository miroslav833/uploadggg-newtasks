#!/bin/bash
# Installs the reference profiler where the instruction asks for it and checks it on the samples.
set -euo pipefail
mkdir -p /app/ductus
cp "$(dirname "$0")/profile.py" /app/ductus/profile.py
for d in /app/archive/sheets/*/; do
  python3 /app/ductus/profile.py "$d" /tmp/ductus_check.csv
  python3 - "$d" <<'PY'
import csv, sys
d = sys.argv[1]
want = {r["measure"]: float(r["value"]) for r in csv.DictReader(open(d + "ductus.csv"))}
got = {r["measure"]: float(r["value"]) for r in csv.DictReader(open("/tmp/ductus_check.csv"))}
tol = dict(nib_width_mm=0.06, pen_angle_deg=2.0)
ok = all(abs(got[k] - want[k]) <= tol[k] for k in tol)
print("%s %s %s" % (d, "ok" if ok else "OFF", {k: (got[k], want[k]) for k in tol}))
PY
done
