# The exemplar archive

How the foundry's exemplar sheets are written, scanned and filed, and what the designer's ductus
for a hand means. Every format below is one the sheets use.

## What a sheet is

A scribe writes two lines of exemplar text in one hand on a ruled writing line, with one nib, on one
paper, and the sheet goes into the archive under a four-letter code. The archive keeps each sheet as
`archive/sheets/<code>/scan.pgm` or `scan.png` with its catalogue line `sheet.txt`:

```
hand: round
nib: quill
paper: soft
dpi: 400
scribe: GH
```

`hand` is one of `round`, `italic`, `uncial`, `gothic`; `nib` one of `steel`, `quill`, `reed`;
`paper` one of `sized`, `soft`; `dpi` the scan's resolution in dots per inch (300, 400 or 600);
`scribe` the scribe's initials.

## The scans

Sheets are laid on the scanner's glass as they come and scanned as they lie: a sheet may sit a few
degrees off square. Scans are 8-bit greyscale, 0 black to 255 white, and are saved either as a
binary PGM or as a PNG.

- **PGM (`P5`).** A text header, then one byte per pixel, rows from the top, pixels from the left:

  ```
  P5
  1772 648
  255
  ```

  followed by 1772 x 648 bytes.
- **PNG.** Colour type 0 (greyscale), bit depth 8, not interlaced, as the scanner's software writes
  it: a signature, an `IHDR` chunk, one or more `IDAT` chunks whose concatenated data is a zlib
  stream of the rows, each row one filter-type byte (0 none, 1 sub, 2 up, 3 average, 4 Paeth, as
  the software chooses row by row) followed by the row's bytes, then `IEND`.

Scanners differ: some shade the sheet a little darker toward one edge, all add their own grain and a
little blur. The paper's own texture shows. A sheet written on both sides shows the other side's
writing faintly through the paper, mirrored.

## The nibs and papers

The archive's nibs are broad-edged: a flat edge of a set width, cut square. Three kinds are in use.

- **Steel** nibs keep their width whatever the scribe does; the archive's steel nibs have an edge
  about 0.10 mm thick.
- **Quills** are cut from feather; the edge is about 0.05 mm thick. A quill is springy: under the
  pressure of a pulled stroke (the straight strokes drawn down the sheet) its two halves open and
  the stroke comes out wider than the nib; where the pen glides, on curves and on strokes drawn across
  or upward, it closes to its cut width again.
- **Reeds** are cut from cane, with an edge about 0.08 mm thick; a reed opens under a pulled stroke
  like a quill, and rather more.

Nib widths in the archive run from about 1.2 to 3 mm; a hand's nib is what the scribe chose for the
sheet.

Two papers are in use. **Sized** paper (hot-pressed, hard) takes ink cleanly: a stroke's edge lies
within a few hundredths of a millimetre of where the nib's edge passed. **Soft** paper (unsized) is
absorbent: ink spreads outward from every stroke edge by a tenth of a millimetre or more, the same on
every side of every stroke, so each stroke on soft paper is wider all round than the nib made it.

## How a broad pen writes

A broad-edged nib held at a fixed angle to the writing line draws a stroke whose thickness depends on
the stroke's direction: a stroke drawn straight across the edge is as wide as the nib, a stroke drawn
along the edge is a hairline no thicker than the edge itself, and a stroke in between is in between.
The pen angle is the angle between the nib's edge and the writing line: at 0 degrees the edge lies
along the line and the downstrokes are the widest strokes; at 30 degrees a downstroke is somewhat
narrower than the nib and the hairline direction rises at 30 degrees to the line.

Every stroke begins and ends on the nib's edge, so a stroke's ends are straight edges as long as the
nib is wide, set at the pen angle. The scribe makes the entry stroke at the top of a minim and the
exit at its foot by sliding the nib along its own edge: these are hairlines, about a nib width long,
running at the pen angle.

The hands in the archive are made as follows.

- **Round hand** (the foundational hand): upright, built on the circle, the pen held at about 30
  degrees. Entries and exits are hairlines. The diagonal strokes of v, w, x, y, z and k are made with
  the pen turned steeper, about 15 degrees past the hand's angle, so that they come out neither too
  heavy nor too thin.
- **Italic**: slanted about 7 degrees, compressed, arches branching from the stem, the pen at about
  45 degrees. Entries and exits are hairlines. No stroke is made with the pen turned.
- **Uncial**: wide round letters, a flat pen at about 20 degrees, short ascenders and descenders.
  Entries are short hairlines. No stroke is made with the pen turned.
- **Gothic** (textura): narrow, angular, the pen at about 40 degrees, every minim a straight
  downstroke. Entries are hairlines; the feet are short strokes made with the pen turned flatter,
  about 20 degrees less than the hand's angle. Bowls are curved on the left and broken on the right.

In every hand the minims (the straight downstrokes of i, n, m, u and the like) run from the x-line to
the baseline, and the bodies of the letters fill the band between those two lines; ascenders and
descenders reach beyond it.

## The ductus

The designer's ductus for a hand starts from two numbers, the ones a scribe is taught a hand by:

- `nib_width_mm`: the width of the nib as cut, in millimetres;
- `pen_angle_deg`: the pen angle, in degrees between the nib's edge and the writing line, from 0
  (edge along the line) to 90.

The sample sheets carry the designer's ductus as `ductus.csv`:

```
measure,value
nib_width_mm,1.85
pen_angle_deg,30.5
```
