# Station st-0952 build sheet

- network: defectnet 1.3, four exits (`/app/model/defectnet.json`)
- stage latencies: 5, 3, 5, 3 ms (stage 1 to 4, each including its exit head)
- frame handling: 1 ms per frame, whether or not the network runs
- scheduling: one frame at a time, in arrival order
