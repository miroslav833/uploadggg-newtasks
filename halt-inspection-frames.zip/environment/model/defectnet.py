"""defectnet 1.3: a four-exit network over 32 frame features.

    probs = exits(model, x)    # four probability vectors, one per exit, in exit order

Each stage is tanh(W h + b); each exit head is a softmax over the stage's state. Stations run it in
float64, exactly as below."""
import json
import math
import os


def load(path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "defectnet.json")):
    with open(path) as fh:
        return json.load(fh)


def exits(model, x):
    out, h = [], x
    for stage, head in zip(model["stages"], model["heads"]):
        h = [math.tanh(sum(w * v for w, v in zip(row, h)) + b) for row, b in zip(stage["w"], stage["b"])]
        z = [sum(w * v for w, v in zip(row, h)) + b for row, b in zip(head["w"], head["b"])]
        top = max(z)
        e = [math.exp(v - top) for v in z]
        s = sum(e)
        out.append([v / s for v in e])
    return out
