# Bottling line inspection stations

Every filling line has an inspection station: a camera takes a frame of each bottle as it passes, and
the station's edge box classifies the frame into one of six classes, `ok`, `chip`, `crack`, `fill_low`,
`cap_skew` and `label_tear`. Bottles answered with anything but `ok` are pushed off the line.

## The network

All stations run defectnet 1.3 (`/app/model/defectnet.json`). A frame is 32 features from the
camera's front end. The network has four stages, and after each stage an exit head gives a probability
for each class. `/app/model/defectnet.py` is the forward pass the stations run (float64): it returns
the four exits' probability vectors for a frame.

Running every stage costs time, so a station may stop a frame at an earlier exit and answer from
there. Exit 4 always answers when no earlier exit did. Which exits a frame may stop at, and when, is
decided by the station's build: builds differ in the stopping rule and in its level, and neither is
written on the build sheet.

## Scheduling

A station takes one frame at a time, in the order frames arrive. A frame starts when it has arrived
and the frame before it is done. It takes the frame handling time plus the latency of each stage it
runs; both are on the build sheet.

Frames do not arrive evenly. A jam that clears sends several bottles past the camera at once, and
frames then wait. Some builds change how they answer when frames back up: a frame may be answered from
exit 1, whatever the stopping rule would have done, or given the answer of the frame before it without
running the network at all. A frame given the previous answer takes the frame handling time only and
is logged with exit `0`. Builds that do this differ in when they do it.

## A station folder

```
BUILD.md                    the build sheet
calibration/log.csv         one shift the station answered, with completion times
calibration/frames.jsonl    that shift's frames
production/log.csv          another shift, arrival times only
production/frames.jsonl     that shift's frames
```

The sample stations in `/app/stations` also have `expected.csv`, the answers the station gave its
production shift.

### Formats

`BUILD.md` is a short list. The lines a program needs read like this:

```
- stage latencies: 6, 6, 3, 4 ms (stage 1 to 4, each including its exit head)
- frame handling: 1 ms per frame, whether or not the network runs
```

`calibration/log.csv`, in arrival order. Times are milliseconds from the start of the shift, `done_ms`
is when the station finished the frame, `exit` is 1 to 4 or 0, and `label` is the class it answered:

```
frame,arrival_ms,done_ms,exit,label
c0001,51.81,64.81,2,ok
```

`production/log.csv`, in arrival order:

```
frame,arrival_ms
p0001,48.27
```

`frames.jsonl`, one frame per line:

```
{"frame": "c0001", "x": [-1.3101, -3.2939, ..., 1.3481]}
```

`expected.csv` (samples only) has the layout the program must write, in arrival order:

```
frame,exit,label
p0001,2,cap_skew
```
