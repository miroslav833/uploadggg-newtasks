Our quality team keeps asking why a station kicked a particular bottle off the line, and the honest answer right now is that we can't re-run a shift and get what the station got. The edge boxes don't always run the whole network. They stop early on some frames, and when frames pile up some builds cut corners, and none of that is written down per build. I'd like a program that takes one station's folder and tells me, for every frame of its production shift, which exit answered it and what class it gave:

```
python3 /app/halting/halt.py STATION_DIR OUT_CSV
```

Start with /app/station/HANDBOOK.md, which says what the stations do with a frame, what's in a station folder and what every file looks like. The network itself is in /app/model, with a small forward pass you can use. Each folder comes with a calibration shift where we logged what the station did, completion times included, and a production shift where all we kept is when each frame arrived. The two stations in /app/stations also have an expected.csv with the real answers for their production shift, so you can compare.

OUT_CSV should start with the header frame,exit,label and have a row for each production frame, for example `p0001,2,cap_skew`. Exit is 1 to 4 for the exit that answered, or 0 when the station handed the frame the previous answer without running the network. A frame only counts as right when both the exit and the label match what the station did. Missing rows are wrong.

Grading uses 20 other stations that you won't see. I generate them when the grading image is built, and some of their builds act differently from the two samples here. Every one of them has 160 production frames. If the program misses 3 frames or fewer at a station, that station passes, and I need 18 stations out of 20 to pass.

Each station gets its own fresh copy of the folder. The program is started under a plain user account with python3 from the image, standard library only, and it gets 120 seconds a station. At grading time /app/model is present but nothing else outside /app/halting is, so anything the program depends on goes in /app/halting.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
