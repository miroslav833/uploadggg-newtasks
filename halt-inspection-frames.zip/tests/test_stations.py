"""Two checks: every sealed answer is what the verifier's own station model gives, and the uploaded
program answers enough held stations."""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import halting  # noqa: E402
import sandbox  # noqa: E402

STATIONS = 20
FRAMES = 160
WRONG_ALLOWED = 3   # frames a station may get wrong and still count (instruction.md)
NEEDED = 18         # stations of the 20 that must count (instruction.md)


def sealed(code):
    with open(os.path.join(sandbox.VAULT, "sealed", code + ".json")) as fh:
        rec = json.load(fh)
    key = {}
    for line in rec["answer"].splitlines()[1:]:
        f, e, l = line.split(",")
        key[f] = (int(e), l)
    return rec["build"], key


@pytest.fixture(scope="module")
def scores():
    uid = sandbox.free_account()
    wrong = {}
    for code in sandbox.codes():
        _, key = sealed(code)
        got = sandbox.run(code, uid)
        wrong[code] = FRAMES if got is None else sum(1 for f in key if got.get(f) != key[f])
        if wrong[code] > WRONG_ALLOWED:
            tail = open(os.path.join(sandbox.NOTES, code + ".stderr"), "rb").read()[-600:]
            print("%s: %d wrong; stderr tail: %r" % (code, wrong[code], tail))
    with open(os.path.join(sandbox.NOTES, "stations.json"), "w") as fh:
        json.dump(wrong, fh, indent=1)
    print(json.dumps(wrong))
    return wrong


def test_sealed_answers_match_station_model():
    net = halting.network(os.path.join(sandbox.VAULT, "defectnet.json"))
    assert len(sandbox.codes()) == STATIONS
    for code in sandbox.codes():
        build, key = sealed(code)
        mine = halting.reckon(build, os.path.join(sandbox.VAULT, "stations", code), net)
        assert len(key) == FRAMES and mine == key, code


def test_enough_stations_answered(scores):
    good = [c for c, w in scores.items() if w <= WRONG_ALLOWED]
    assert len(good) >= NEEDED, "%d of %d stations counted (%s); %d needed" % (len(good), STATIONS, scores, NEEDED)
