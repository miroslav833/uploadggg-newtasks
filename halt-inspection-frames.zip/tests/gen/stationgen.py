#!/usr/bin/env python3
"""Inspection stations of a bottling line: a multi-exit defect network, each station's build (its
stopping rule and level, and what it does when frames back up), a calibration shift and a production
shift.

    python3 stationgen.py model OUT_JSON                 the network (fixed seed)
    python3 stationgen.py samples MODEL OUTDIR           the two sample stations, with expected.csv
    python3 stationgen.py graded MODEL OUTDIR SEALED     the 20 graded stations and their sealed truth

Every station is kept only when every build of the menu below that agrees with its calibration log
gives the same production answers (so the log settles the answer), and when its backlog behaviour, if
any, changes at least MIN_SHED production answers."""
import bisect
import json
import math
import os
import random
import sys

CLASSES = ["ok", "chip", "crack", "fill_low", "cap_skew", "label_tear"]
DIM, WIDTH, EXITS = 32, 24, 4
CAL_FRAMES, PROD_FRAMES = 320, 160
MIN_SHED = 8
REJECT = {}


def _rej(why):
    REJECT[why] = REJECT.get(why, 0) + 1
FAMILIES = ["top", "margin", "entropy"]
SOURCES = ["exit", "mean"]


# ---------------------------------------------------------------- the network
def _gauss_solve(a, b):
    n = len(a)
    m = [row[:] + brow[:] for row, brow in zip(a, b)]
    k = len(b[0])
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(m[r][c]))
        m[c], m[p] = m[p], m[c]
        piv = m[c][c]
        for j in range(c, n + k):
            m[c][j] /= piv
        for r in range(n):
            if r != c and m[r][c]:
                f = m[r][c]
                for j in range(c, n + k):
                    m[r][j] -= f * m[c][j]
    return [row[n:] for row in m]


def make_model(seed=20261024):
    rng = random.Random(seed)
    protos = [[rng.gauss(0, 1) for _ in range(DIM)] for _ in CLASSES]
    stages, heads = [], []
    xs = []
    for _ in range(1500):
        c = rng.randrange(len(CLASSES))
        xs.append((c, frame_vector(rng, protos, c, rng.uniform(0.5, 1.7))))
    hs = [x for _, x in xs]
    sharp = [2.2, 3.0, 3.8, 4.6]
    for k in range(EXITS):
        n_in = DIM if k == 0 else WIDTH
        w = [[round(rng.gauss(0, 1.0 / math.sqrt(n_in)) * 1.6, 6) for _ in range(n_in)] for _ in range(WIDTH)]
        b = [round(rng.gauss(0, 0.1), 6) for _ in range(WIDTH)]
        stages.append({"w": w, "b": b})
        hs = [[math.tanh(sum(wi * hi for wi, hi in zip(row, h)) + bi) for row, bi in zip(w, b)] for h in hs]
        # ridge readout of the class from this stage's state, sharpened deeper in the network
        feats = [h + [1.0] for h in hs]
        n = WIDTH + 1
        ata = [[sum(f[i] * f[j] for f in feats) + (2.0 if i == j else 0.0) for j in range(n)] for i in range(n)]
        aty = [[sum(f[i] * (1.0 if xs[t][0] == c else -0.2) for t, f in enumerate(feats)) for c in range(len(CLASSES))]
               for i in range(n)]
        sol = _gauss_solve(ata, aty)
        v = [[round(sol[i][c] * sharp[k], 6) for i in range(WIDTH)] for c in range(len(CLASSES))]
        cb = [round(sol[WIDTH][c] * sharp[k], 6) for c in range(len(CLASSES))]
        heads.append({"w": v, "b": cb})
    return {"name": "defectnet", "version": "1.3", "classes": CLASSES, "input": DIM, "width": WIDTH,
            "stages": stages, "heads": heads, "protos": [[round(v, 6) for v in p] for p in protos]}


def frame_vector(rng, protos, c, sigma):
    return [round(1.2 * p + rng.gauss(0, sigma), 4) for p in protos[c]]


def forward(model, x):
    out, h = [], x
    for st, hd in zip(model["stages"], model["heads"]):
        h = [math.tanh(sum(wi * hi for wi, hi in zip(row, h)) + bi) for row, bi in zip(st["w"], st["b"])]
        z = [sum(wi * hi for wi, hi in zip(row, h)) + bi for row, bi in zip(hd["w"], hd["b"])]
        m = max(z)
        e = [math.exp(v - m) for v in z]
        s = sum(e)
        out.append([v / s for v in e])
    return out


# ---------------------------------------------------------------- the build
def argmax(d):
    return max(range(len(d)), key=lambda i: d[i])


def dist_at(probs, k, source):
    if source == "exit":
        return probs[k]
    return [sum(probs[j][c] for j in range(k + 1)) / (k + 1) for c in range(len(probs[0]))]


def confidence(d, family):
    if family == "top":
        return max(d)
    if family == "margin":
        s = sorted(d, reverse=True)
        return s[0] - s[1]
    h = -sum(p * math.log(p) for p in d if p > 0)
    return 1.0 - h / math.log(len(d))


def normal_answer(probs, rule):
    """(exit 1-4, class index) the stopping rule gives a frame that runs normally."""
    if rule["family"] == "patience":
        p = rule["level"]
        for k in range(p - 1, EXITS - 1):
            tops = {argmax(probs[j]) for j in range(k - p + 1, k + 1)}
            if len(tops) == 1:
                return k + 1, argmax(probs[k])
        return EXITS, argmax(probs[EXITS - 1])
    for k in range(EXITS):
        d = dist_at(probs, k, rule["source"])
        if k == EXITS - 1 or confidence(d, rule["family"]) >= rule["level"]:
            return k + 1, argmax(d)


def simulate(build, arrivals, probs):
    """Run a shift through the station: one frame at a time in arrival order."""
    lat, over = build["latency_ms"], build["handling_ms"]
    back = build["backlog"]
    done_prev, prev_label, out = -1e18, None, []
    for i, a in enumerate(arrivals):
        start = max(a, done_prev)
        depth = bisect.bisect_right(arrivals, start) - i - 1
        wait = start - a
        shed = (back["kind"] == "depth" and depth >= back["param"]) or (back["kind"] == "wait" and wait > back["param"])
        if shed and back["action"] == "repeat":
            ex, lab, cost = 0, prev_label, over
        elif shed:
            ex, lab, cost = 1, argmax(probs[i][0]), over + lat[0]
        else:
            ex, lab = normal_answer(probs[i], build["rule"])
            cost = over + sum(lat[:ex])
        done = round(start + cost, 2)
        out.append({"exit": ex, "label": lab, "start": start, "done": done, "depth": depth, "wait": wait})
        done_prev, prev_label = done, lab
    return out


# ---------------------------------------------------------------- the menu a log is checked against
def log_starts(arrivals, dones):
    starts, prev = [], -1e18
    for a, d in zip(arrivals, dones):
        starts.append(max(a, prev))
        prev = d
    return starts


def backlog_menu(arrivals, starts):
    waits = sorted({round(s - a, 2) for a, s in zip(arrivals, starts)})
    menu = [("none", None, lo, hi) for lo, hi in [(None, None)]]
    for q in range(1, 16):
        menu.append(("depth", q, None, None))
    cuts = [-1.0] + waits
    for m in range(len(cuts)):
        lo = cuts[m]
        hi = cuts[m + 1] if m + 1 < len(cuts) else None
        menu.append(("wait", None, lo, hi))
    return menu


def consistent_builds(arrivals, dones, exits, labels, probs):
    """Every build of the menu that reproduces the calibration log, as (rule, backlog) with levels
    as feasible intervals."""
    starts = log_starts(arrivals, dones)
    n = len(arrivals)
    depth = [sum(1 for j in range(i + 1, n) if arrivals[j] <= starts[i]) for i in range(n)]
    wait = [starts[i] - arrivals[i] for i in range(n)]
    found = []
    for kind, q, lo_w, hi_w in backlog_menu(arrivals, starts):
        if kind == "none":
            shed = [False] * n
        elif kind == "depth":
            shed = [d >= q for d in depth]
        else:
            shed = [w > lo_w + 1e-9 for w in wait]
        for action in (["first", "repeat"] if kind != "none" else ["-"]):
            ok = True
            for i in range(n):
                if shed[i]:
                    if action == "repeat":
                        ok = exits[i] == 0 and i > 0 and labels[i] == labels[i - 1]
                    else:
                        ok = exits[i] == 1 and labels[i] == argmax(probs[i][0])
                elif exits[i] == 0:
                    ok = False
                if not ok:
                    break
            if not ok:
                continue
            normal = [i for i in range(n) if not shed[i]]
            for rule in rule_fits(normal, exits, labels, probs):
                found.append((rule, {"kind": kind, "q": q, "lo": lo_w, "hi": hi_w, "action": action}))
    return found


def rule_fits(idx, exits, labels, probs):
    fits = []
    for p in (2, 3):
        rule = {"family": "patience", "level": p}
        if all(normal_answer(probs[i], rule) == (exits[i], labels[i]) for i in idx):
            fits.append(dict(rule, lo=p, hi=p))
    for fam in FAMILIES:
        for src in SOURCES:
            lo, hi, ok = -1.0, 2.0, True
            for i in idx:
                e = exits[i]
                for k in range(e - 1):
                    lo = max(lo, confidence(dist_at(probs[i], k, src), fam))
                d = dist_at(probs[i], e - 1, src)
                if argmax(d) != labels[i]:
                    ok = False
                    break
                if e < EXITS:
                    hi = min(hi, confidence(d, fam))
                if lo >= hi:
                    ok = False
                    break
            if ok and lo < hi:
                fits.append({"family": fam, "source": src, "lo": lo, "hi": hi})
    return fits


def variants(rule, back, build):
    """Concrete builds spanning a consistent menu entry's feasible intervals."""
    out = []
    if rule["family"] == "patience":
        rules = [{"family": "patience", "level": rule["level"]}]
    else:
        lo, hi = rule["lo"], rule["hi"]
        rules = [{"family": rule["family"], "source": rule["source"], "level": v}
                 for v in (lo + 1e-7, (lo + hi) / 2, hi)]
    if back["kind"] == "none":
        backs = [{"kind": "none", "param": None, "action": "-"}]
    elif back["kind"] == "depth":
        backs = [{"kind": "depth", "param": back["q"], "action": back["action"]}]
    else:
        lo, hi = back["lo"], back["hi"]
        vals = [lo + 1e-6, hi - 1e-6] if hi is not None else [lo + 1e-6, lo + 400.0]
        backs = [{"kind": "wait", "param": v, "action": back["action"]} for v in vals]
    for r in rules:
        for b in backs:
            out.append(dict(build, rule=r, backlog=b))
    return out


# ---------------------------------------------------------------- shifts and stations
def arrivals_for(rng, n, bursts, gap_ms, t0=50.0):
    out, t = [], t0
    burst_at = set(rng.sample(range(8, n - 10), bursts))
    i = 0
    while len(out) < n:
        if i in burst_at:
            size = rng.randint(3, 8)
            for _ in range(min(size, n - len(out))):
                t += rng.uniform(0.2, 2.5)
                out.append(round(t, 2))
            t += rng.expovariate(1.0 / gap_ms)
        else:
            t += rng.expovariate(1.0 / gap_ms) + 0.3
            out.append(round(t, 2))
        i += 1
    return out[:n]


def ties(arrivals, sim):
    aset = sorted(arrivals)
    for s in sim:
        for a in aset:
            if not (math.isfinite(a) and math.isfinite(s["start"])):
                return True
            if a != s["start"] and abs(a - s["start"]) < 0.006:
                return True
    return False


def choose_level(rng, rule, probs_cal):
    if rule["family"] == "patience":
        return rule["level"]
    c1 = sorted(confidence(dist_at(p, 0, rule["source"]), rule["family"]) for p in probs_cal)
    return round(c1[int(len(c1) * rng.uniform(0.62, 0.78))], 4)


def build_station(seed, profile, model):
    rng = random.Random(seed)
    protos = model["protos"]
    for attempt in range(400):
        lat = [rng.randint(3, 6) for _ in range(EXITS)]
        build = {"latency_ms": lat, "handling_ms": 1, "rule": dict(profile["rule"]), "backlog": dict(profile["backlog"])}

        def draw(n):
            cls = [rng.randrange(len(CLASSES)) for _ in range(n)]
            return [frame_vector(rng, protos, c, rng.uniform(0.5, 1.9)) for c in cls]

        cal_x = draw(CAL_FRAMES)
        cal_p = [forward(model, x) for x in cal_x]
        build["rule"]["level"] = choose_level(rng, build["rule"], cal_p)
        cal_a = arrivals_for(rng, CAL_FRAMES, 18, 30.0)
        cal = simulate(build, cal_a, cal_p)
        if ties(cal_a, cal):
            _rej('caltie')
            continue
        fits = consistent_builds(cal_a, [s["done"] for s in cal], [s["exit"] for s in cal],
                                 [s["label"] for s in cal], cal_p)
        if not fits:
            raise AssertionError("true build not found in its own log")
        prod_a = arrivals_for(rng, PROD_FRAMES, 10, 30.0)
        prod_x = draw(PROD_FRAMES)
        settled = False
        for _ in range(40):
            prod_p = [forward(model, x) for x in prod_x]
            truth = simulate(build, prod_a, prod_p)
            if ties(prod_a, truth) or max(t["depth"] for t in truth) > max(c["depth"] for c in cal) or \
                    max(t["wait"] for t in truth) > max(c["wait"] for c in cal):
                _rej('prodrange')
                break
            bad = set()
            for rule, back in fits:
                for v in variants(rule, back, build):
                    alt = simulate(v, prod_a, prod_p)
                    for i, (s, t) in enumerate(zip(alt, truth)):
                        if (s["exit"], s["label"]) != (t["exit"], t["label"]):
                            bad.add(i)
                            break
            if not bad:
                settled = True
                break
            for i in bad:
                prod_x[i] = draw(1)[0]
        if not settled:
            _rej('unsettled')
            continue
        if build["backlog"]["kind"] != "none":
            plain = simulate(dict(build, backlog={"kind": "none", "param": None, "action": "-"}), prod_a, prod_p)
            moved = sum(1 for s, t in zip(plain, truth) if (s["exit"], s["label"]) != (t["exit"], t["label"]))
            if moved < MIN_SHED:
                _rej('moved')
                continue
            calplain = simulate(dict(build, backlog={"kind": "none", "param": None, "action": "-"}), cal_a, cal_p)
            if sum(1 for s, t in zip(calplain, cal) if s["exit"] != t["exit"]) < 6:
                _rej('calmoved')
                continue
        exits_used = {t["exit"] for t in truth if t["exit"] > 0}
        if len(exits_used) < 2:
            _rej('exits')
            continue
        return {"build": build, "fits": len(fits), "cal": (cal_a, cal_x, cal), "prod": (prod_a, prod_x, truth),
                "attempts": attempt + 1}
    raise RuntimeError("no settled station for seed %d" % seed)


def write_station(code, st, outdir, sealed_dir=None, expected=False):
    base = os.path.join(outdir, code)
    for sub in ("calibration", "production"):
        os.makedirs(os.path.join(base, sub), exist_ok=True)
    b = st["build"]
    lat = b["latency_ms"]
    with open(os.path.join(base, "BUILD.md"), "w") as fh:
        fh.write("# Station %s build sheet\n\n" % code)
        fh.write("- network: defectnet 1.3, four exits (`/app/model/defectnet.json`)\n")
        fh.write("- stage latencies: %d, %d, %d, %d ms (stage 1 to 4, each including its exit head)\n" % tuple(lat))
        fh.write("- frame handling: %d ms per frame, whether or not the network runs\n" % b["handling_ms"])
        fh.write("- scheduling: one frame at a time, in arrival order\n")
    cal_a, cal_x, cal = st["cal"]
    prod_a, prod_x, truth = st["prod"]
    with open(os.path.join(base, "calibration", "log.csv"), "w") as fh:
        fh.write("frame,arrival_ms,done_ms,exit,label\n")
        for i, (a, s) in enumerate(zip(cal_a, cal)):
            fh.write("c%04d,%.2f,%.2f,%d,%s\n" % (i + 1, a, s["done"], s["exit"], CLASSES[s["label"]]))
    with open(os.path.join(base, "calibration", "frames.jsonl"), "w") as fh:
        for i, x in enumerate(cal_x):
            fh.write(json.dumps({"frame": "c%04d" % (i + 1), "x": x}) + "\n")
    with open(os.path.join(base, "production", "log.csv"), "w") as fh:
        fh.write("frame,arrival_ms\n")
        for i, a in enumerate(prod_a):
            fh.write("p%04d,%.2f\n" % (i + 1, a))
    with open(os.path.join(base, "production", "frames.jsonl"), "w") as fh:
        for i, x in enumerate(prod_x):
            fh.write(json.dumps({"frame": "p%04d" % (i + 1), "x": x}) + "\n")
    answer = "frame,exit,label\n" + "".join("p%04d,%d,%s\n" % (i + 1, t["exit"], CLASSES[t["label"]])
                                            for i, t in enumerate(truth))
    if expected:
        with open(os.path.join(base, "expected.csv"), "w") as fh:
            fh.write(answer)
    if sealed_dir:
        os.makedirs(sealed_dir, exist_ok=True)
        with open(os.path.join(sealed_dir, code + ".json"), "w") as fh:
            json.dump({"build": b, "answer": answer}, fh)


SAMPLES = [
    ("st-0417", {"rule": {"family": "top", "source": "exit"}, "backlog": {"kind": "none", "param": None, "action": "-"}}),
    ("st-0952", {"rule": {"family": "margin", "source": "exit"}, "backlog": {"kind": "none", "param": None, "action": "-"}}),
]


def graded_profiles():
    rules = ([{"family": "top", "source": "exit"}] * 3 + [{"family": "top", "source": "mean"}] * 2 +
             [{"family": "margin", "source": "exit"}] * 2 + [{"family": "margin", "source": "mean"}] * 3 +
             [{"family": "entropy", "source": "exit"}] * 2 + [{"family": "entropy", "source": "mean"}] * 2 +
             [{"family": "patience", "level": 2}] * 3 + [{"family": "patience", "level": 3}] * 3)
    backs = ([{"kind": "none", "param": None, "action": "-"}] * 7 +
             [{"kind": "depth", "param": q, "action": a} for q, a in
              [(2, "first"), (3, "repeat"), (4, "first"), (2, "repeat"), (3, "first"), (4, "repeat"), (3, "first")]] +
             [{"kind": "wait", "param": d, "action": a} for d, a in
              [(12, "first"), (20, "repeat"), (30, "first"), (12, "repeat"), (20, "first"), (30, "repeat")]])
    rng = random.Random(2410)
    rng.shuffle(backs)
    return [{"rule": dict(r), "backlog": dict(b)} for r, b in zip(rules, backs)]


def station_code(rng):
    return "st-%04d" % rng.randrange(1000, 9999)


def build_graded(model, outdir, sealed_dir, seed0=70001):
    rng = random.Random(seed0)
    codes = set()
    for n, prof in enumerate(graded_profiles()):
        code = station_code(rng)
        while code in codes:
            code = station_code(rng)
        codes.add(code)
        st = build_station(seed0 + 101 * n, prof, model)
        write_station(code, st, outdir, sealed_dir)


def build_samples(model, outdir):
    for n, (code, prof) in enumerate(SAMPLES):
        st = build_station(5101 + 13 * n, prof, model)
        write_station(code, st, outdir, expected=True)


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "model":
        json.dump(make_model(), open(sys.argv[2], "w"))
    else:
        model = json.load(open(sys.argv[2]))
        if cmd == "samples":
            build_samples(model, sys.argv[3])
        else:
            build_graded(model, sys.argv[3], sys.argv[4])
