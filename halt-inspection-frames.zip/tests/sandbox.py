"""Runs the uploaded halt.py on one held station at a time and reads back what it wrote.

Each station is copied to a fresh folder owned by a numeric account no process of the image uses.
The program runs under that account in its own session, with no groups, 2 GiB of address space and
120 seconds. Afterwards every process left under the account is killed, and only then is the output
looked at: a regular file of at most 1 MiB, parsed as CSV text."""
import csv
import os
import resource
import shutil
import signal
import subprocess
import time

VAULT = "/tests/vault"
NOTES = "/run/verifier"
SPACE = "/var/tmp/stations"
ENTRY = "/app/halting/halt.py"
LIMIT_S = 120
CAP = 1 << 20


def free_account(base=52300):
    owners = set()
    for pid in os.listdir("/proc"):
        if pid.isdigit():
            try:
                owners.add(os.stat("/proc/" + pid).st_uid)
            except FileNotFoundError:
                continue
    while base in owners:
        base += 1
    return base


def reap(uid):
    for _ in range(200):
        alive = []
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                if os.stat("/proc/" + pid).st_uid == uid:
                    alive.append(int(pid))
            except FileNotFoundError:
                continue
        if not alive:
            return
        for pid in alive:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        time.sleep(0.05)


def parse(path):
    got = {}
    with open(path, newline="", encoding="utf-8", errors="replace") as fh:
        for row in csv.DictReader(fh):
            frame = (row.get("frame") or "").strip()
            if not frame or frame in got:
                continue
            ex = (row.get("exit") or "").strip()
            got[frame] = (int(ex) if ex.isdigit() else None, (row.get("label") or "").strip())
    return got


def run(code, uid):
    home = os.path.join(SPACE, code)
    shutil.rmtree(home, ignore_errors=True)
    os.makedirs(home, mode=0o755)
    copy, tmp = os.path.join(home, "station"), os.path.join(home, "tmp")
    shutil.copytree(os.path.join(VAULT, "stations", code), copy, symlinks=False)
    os.makedirs(tmp)
    os.makedirs(os.path.join(home, "out"))
    for root, dirs, files in os.walk(home):
        for name in dirs + files:
            os.chown(os.path.join(root, name), uid, uid)
    os.chown(home, uid, uid)
    target = os.path.join(home, "out", "frames.csv")

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": tmp, "TMPDIR": tmp, "LANG": "C.UTF-8",
           "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
    with open(os.path.join(NOTES, code + ".stderr"), "wb") as err:
        child = subprocess.Popen(["python3", ENTRY, copy, target], stdin=subprocess.DEVNULL, stdout=err,
                                 stderr=err, cwd=tmp, env=env, preexec_fn=drop)
        try:
            child.wait(timeout=LIMIT_S)
        except subprocess.TimeoutExpired:
            pass
    reap(uid)
    got = None
    if os.path.isfile(target) and not os.path.islink(target) and os.path.getsize(target) <= CAP:
        got = parse(target)
    shutil.rmtree(home, ignore_errors=True)
    return got


def codes():
    return sorted(os.listdir(os.path.join(VAULT, "stations")))
