"""The verifier's own account of a station: from the sealed build, the network and the production
shift's arrivals, which exit answered each frame and with what. Written apart from the generator."""
import csv
import json
import math
import os


def network(path):
    with open(path) as fh:
        return json.load(fh)


def exit_probs(net, x):
    probs, state = [], list(x)
    for stage, head in zip(net["stages"], net["heads"]):
        state = [math.tanh(b + sum(w * s for w, s in zip(row, state))) for row, b in zip(stage["w"], stage["b"])]
        logits = [b + sum(w * s for w, s in zip(row, state)) for row, b in zip(head["w"], head["b"])]
        peak = max(logits)
        ex = [math.exp(z - peak) for z in logits]
        tot = sum(ex)
        probs.append([v / tot for v in ex])
    return probs


def top_class(vec):
    best = 0
    for c in range(1, len(vec)):
        if vec[c] > vec[best]:
            best = c
    return best


def stop_score(vec, family):
    ranked = sorted(vec, reverse=True)
    if family == "top":
        return ranked[0]
    if family == "margin":
        return ranked[0] - ranked[1]
    ent = 0.0
    for p in vec:
        if p > 0:
            ent -= p * math.log(p)
    return 1.0 - ent / math.log(len(vec))


def stop(probs, rule):
    last = len(probs) - 1
    if rule["family"] == "patience":
        need = rule["level"]
        for k in range(last):
            if k + 1 >= need and all(top_class(probs[j]) == top_class(probs[k]) for j in range(k - need + 1, k)):
                return k + 1, top_class(probs[k])
        return last + 1, top_class(probs[last])
    running = [0.0] * len(probs[0])
    for k in range(last + 1):
        running = [r + p for r, p in zip(running, probs[k])]
        vec = probs[k] if rule["source"] == "exit" else [r / (k + 1) for r in running]
        if k == last or stop_score(vec, rule["family"]) >= rule["level"]:
            return k + 1, top_class(vec)


def reckon(build, station_dir, net):
    rows = list(csv.DictReader(open(os.path.join(station_dir, "production", "log.csv"))))
    xs = {}
    for line in open(os.path.join(station_dir, "production", "frames.jsonl")):
        if line.strip():
            r = json.loads(line)
            xs[r["frame"]] = r["x"]
    arrive = [float(r["arrival_ms"]) for r in rows]
    lat, handling, back = build["latency_ms"], build["handling_ms"], build["backlog"]
    free_at, last_label, answers = float("-inf"), None, {}
    for i, r in enumerate(rows):
        begin = max(arrive[i], free_at)
        queued = len([a for a in arrive[i + 1:] if a <= begin])
        shed = ((back["kind"] == "depth" and queued >= back["param"]) or
                (back["kind"] == "wait" and begin - arrive[i] > back["param"]))
        probs = exit_probs(net, xs[r["frame"]])
        if shed and back["action"] == "repeat":
            ex, lab, took = 0, last_label, handling
        elif shed:
            ex, lab, took = 1, top_class(probs[0]), handling + lat[0]
        else:
            ex, lab = stop(probs, build["rule"])
            took = handling + sum(lat[:ex])
        free_at = round(begin + took, 2)
        last_label = lab
        answers[r["frame"]] = (ex, net["classes"][lab])
    return answers
