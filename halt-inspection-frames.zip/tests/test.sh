#!/usr/bin/env bash
# Before anything uploaded runs, the reward folder is made root-only and every reward-like file in it
# is removed; reward.txt starts at 0. The program then runs under an invented account (sandbox.py).
# When grading ends, files root did not write are removed and only reward.txt is written.
set -u
LOGS=/logs/verifier
KEEP=/run/verifier

mkdir -p "$LOGS"
was="$(stat -c %a "$LOGS" 2>/dev/null || echo 755)"
chown 0:0 "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

scrub() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) \
        -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
}
award() {
    scrub
    (umask 022; printf '%s\n' "$1" > "$LOGS/reward.txt")
}
leave() {
    chmod "$was" "$LOGS" 2>/dev/null
    exit 0
}

award 0
if [ "$(stat -c '%u:%a' "$LOGS" 2>/dev/null)" != "0:700" ]; then
    echo "grading stopped: $LOGS is not root-only" >&2
    leave
fi
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
mkdir -p "$KEEP" && chown 0:0 "$KEEP" && chmod 700 "$KEEP"
chmod -R a+rX /app/halting /app/model 2>/dev/null

passed=no
if ( cd /tests && python3 -m pytest test_stations.py -q -p no:cacheprovider --ctrf "$KEEP/ctrf.json" ); then
    passed=yes
fi
if [ "$passed" = yes ]; then award 1; else award 0; fi
for f in ctrf.json stations.json; do
    [ -f "$KEEP/$f" ] && (umask 022; cp "$KEEP/$f" "$LOGS/$f")
done
leave
