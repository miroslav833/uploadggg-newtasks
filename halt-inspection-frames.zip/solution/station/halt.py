#!/usr/bin/env python3
"""halt.py STATION_DIR OUT_CSV: which exit of defectnet answered each production frame, and with what.

The station's build is read from its calibration shift. Every frame's start is the later of its
arrival and the previous frame's completion; from the starts come the queue depth (frames already
arrived and waiting) and the wait each frame met. A backlog behaviour is a condition (depth at or
above Q, or wait above D) under which frames were answered from exit 1 or given the previous answer
(exit 0); a stopping rule is a confidence (top probability, top-two margin, 1 - normalised entropy) on
the exit's own output or on the running mean of the exits so far, with a level, or a patience count
of agreeing exits. The simplest pair that reproduces every calibration row is taken and the production
shift is simulated through the same queue with the build sheet's latencies."""
import csv
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATHS = ["/app/model/defectnet.json", os.path.join(HERE, "..", "..", "environment", "model", "defectnet.json")]
DEFAULTS = {"backlog": "fit", "level": "mid", "rules": "all", "q_shift": 0, "conds": "all", "actions": "all",
            "repeat_exit": 0, "wait_pick": "mid"}


def load_model():
    for p in MODEL_PATHS:
        if os.path.exists(p):
            return json.load(open(p))
    raise SystemExit("defectnet.json not found")


def run_net(model, x):
    out, h = [], x
    for st, hd in zip(model["stages"], model["heads"]):
        h = [math.tanh(sum(a * b for a, b in zip(row, h)) + c) for row, c in zip(st["w"], st["b"])]
        z = [sum(a * b for a, b in zip(row, h)) + c for row, c in zip(hd["w"], hd["b"])]
        top = max(z)
        e = [math.exp(v - top) for v in z]
        s = sum(e)
        out.append([v / s for v in e])
    return out


def best(d):
    return max(range(len(d)), key=lambda i: d[i])


def scored(probs, k, source):
    if source == "exit":
        return probs[k]
    return [sum(probs[j][c] for j in range(k + 1)) / (k + 1) for c in range(len(probs[0]))]


def conf(d, measure):
    if measure == "top":
        return max(d)
    if measure == "margin":
        a, b = sorted(d, reverse=True)[:2]
        return a - b
    return 1.0 - (-sum(p * math.log(p) for p in d if p > 0)) / math.log(len(d))


def answer_normal(probs, rule):
    n = len(probs)
    if rule[0] == "patience":
        p = rule[1]
        for k in range(p - 1, n - 1):
            if len({best(probs[j]) for j in range(k - p + 1, k + 1)}) == 1:
                return k + 1, best(probs[k])
        return n, best(probs[-1])
    _, measure, source, level = rule
    for k in range(n):
        d = scored(probs, k, source)
        if k == n - 1 or conf(d, measure) >= level:
            return k + 1, best(d)


def read_station(path):
    sheet = open(os.path.join(path, "BUILD.md")).read()
    lat = [int(v) for v in re.search(r"stage latencies:\s*([\d,\s]+)ms", sheet).group(1).replace(",", " ").split()]
    handling = int(re.search(r"frame handling:\s*(\d+)\s*ms", sheet).group(1))

    def frames(sub):
        xs = {}
        for line in open(os.path.join(path, sub, "frames.jsonl")):
            if line.strip():
                r = json.loads(line)
                xs[r["frame"]] = r["x"]
        return xs

    cal = list(csv.DictReader(open(os.path.join(path, "calibration", "log.csv"))))
    prod = list(csv.DictReader(open(os.path.join(path, "production", "log.csv"))))
    return lat, handling, cal, frames("calibration"), prod, frames("production")


def queue_facts(arrivals, starts):
    n = len(arrivals)
    order = sorted(range(n), key=lambda i: arrivals[i])
    depth = []
    for i in range(n):
        depth.append(sum(1 for j in range(i + 1, n) if arrivals[j] <= starts[i]))
    return depth, [starts[i] - arrivals[i] for i in range(n)]


def fit_rules(rows, probs, classes, opt):
    """Every stopping rule consistent with the rows that ran normally: (rule, low, high)."""
    fits = []
    for p in (2, 3):
        if all(answer_normal(probs[i], ("patience", p)) == (e, classes.index(l)) for i, e, l in rows):
            fits.append((("patience", p), p, p))
    for measure in ("top", "margin", "entropy"):
        for source in ("exit", "mean"):
            lo, hi, ok = -1.0, 2.0, True
            for i, e, l in rows:
                for k in range(e - 1):
                    lo = max(lo, conf(scored(probs[i], k, source), measure))
                d = scored(probs[i], e - 1, source)
                if best(d) != classes.index(l):
                    ok = False
                    break
                if e < len(probs[i]):
                    hi = min(hi, conf(d, measure))
                if lo >= hi:
                    ok = False
                    break
            if ok:
                level = {"mid": (lo + hi) / 2, "lo": lo + 1e-9, "hi": hi}[opt["level"]]
                fits.append((("conf", measure, source, level), lo, hi))
    return fits


def loose_rule(rows, probs, classes, measure, source):
    """For a reading restricted to one rule: the level with the fewest calibration rows wrong."""
    cands = sorted({conf(scored(probs[i], k, source), measure) for i, _, _ in rows for k in range(3)})
    cands = cands[::max(1, len(cands) // 60)] + [2.0]
    best_level, best_bad = None, None
    for level in cands:
        rule = ("conf", measure, source, level)
        bad = sum(1 for i, e, l in rows if answer_normal(probs[i], rule) != (e, classes.index(l)))
        if best_bad is None or bad < best_bad:
            best_level, best_bad = level, bad
    return ("conf", measure, source, best_level), best_bad


def fit_station(lat, handling, cal, cal_x, model, classes, opt):
    arrivals = [float(r["arrival_ms"]) for r in cal]
    dones = [float(r["done_ms"]) for r in cal]
    exits = [int(r["exit"]) for r in cal]
    labels = [r["label"] for r in cal]
    probs = [run_net(model, cal_x[r["frame"]]) for r in cal]
    starts, prev = [], -1e18
    for a, d in zip(arrivals, dones):
        starts.append(max(a, prev))
        prev = d
    depth, wait = queue_facts(arrivals, starts)
    n = len(cal)
    conds = [("none", None)]
    if opt["backlog"] == "fit":
        conds += [("depth", q) for q in range(1, 16)]
        ws = sorted({round(w, 2) for w in wait})
        conds += [("wait", (lo, hi)) for lo, hi in zip([-1.0] + ws, ws + [None])]
    if opt["conds"] != "all":
        conds = [c for c in conds if c[0] == "none" or c[0] in opt["conds"]]
    loose = opt["rules"] != "all" or opt["conds"] != "all" or opt["actions"] != "all"
    choice, fewest = (None, ("none", None, "-")), None
    for cond, par in conds:
        if loose and cond == "wait" and par[1] is not None and int(par[0] * 7) == int(par[1] * 7):
            continue
        if cond == "none":
            shed = [False] * n
        elif cond == "depth":
            shed = [d >= par for d in depth]
        else:
            shed = [w > par[0] + 1e-9 for w in wait]
        acts = ("first", "repeat") if opt["actions"] == "all" else tuple(opt["actions"])
        for action in (acts if cond != "none" else ("-",)):
            if loose:
                bad = 0
                for i in range(n):
                    if shed[i]:
                        if action == "repeat":
                            bad += not (exits[i] == 0 and i > 0 and labels[i] == labels[i - 1])
                        else:
                            bad += not (exits[i] == 1 and labels[i] == classes[best(probs[i][0])])
                rows = [(i, exits[i], labels[i]) for i in range(n) if not shed[i] and exits[i] != 0]
                bad += sum(1 for i in range(n) if not shed[i] and exits[i] == 0)
                if opt["rules"] == "all":
                    fits = fit_rules(rows, probs, classes, opt)
                    rule, more = (fits[0][0], 0) if fits else loose_rule(rows, probs, classes, "top", "exit")
                else:
                    rule, more = loose_rule(rows, probs, classes, *opt["rules"])
                bad += more
                if fewest is None or bad < fewest:
                    p2 = par
                    if cond == "wait":
                        p2 = (par[0] + par[1]) / 2 if par[1] is not None else par[0] + 50.0
                    fewest, choice = bad, (rule, (cond, p2, action))
                continue
            ok = True
            for i in range(n):
                if shed[i]:
                    if action == "repeat":
                        ok = exits[i] == 0 and i > 0 and labels[i] == labels[i - 1]
                    else:
                        ok = exits[i] == 1 and labels[i] == classes[best(probs[i][0])]
                else:
                    ok = exits[i] != 0
                if not ok:
                    break
            if not ok:
                continue
            rows = [(i, exits[i], labels[i]) for i in range(n) if not shed[i]]
            fits = fit_rules(rows, probs, classes, opt)
            if fits:
                if cond == "wait":
                    lo, hi = par
                    span = hi - lo if hi is not None else 100.0
                    par = lo + span * {"lo": 1e-6, "mid": 0.5, "hi": 1 - 1e-6}[opt["wait_pick"]]
                elif cond == "depth":
                    par += opt["q_shift"]
                return fits[0][0], (cond, par, action)
    return choice


def simulate(rule, backlog, lat, handling, arrivals, probs, opt):
    cond, par, action = backlog
    out, prev_done, prev_label = [], -1e18, 0
    n = len(arrivals)
    for i, a in enumerate(arrivals):
        start = max(a, prev_done)
        depth = sum(1 for j in range(i + 1, n) if arrivals[j] <= start)
        wait = start - a
        shed = (cond == "depth" and depth >= par) or (cond == "wait" and wait > par)
        if shed and action == "repeat":
            e, lab, cost = opt["repeat_exit"], prev_label, handling
        elif shed:
            e, lab, cost = 1, best(probs[i][0]), handling + lat[0]
        elif rule is None:
            e, lab = len(lat), best(probs[i][-1])
            cost = handling + sum(lat)
        else:
            e, lab = answer_normal(probs[i], rule)
            cost = handling + sum(lat[:e])
        prev_done = round(start + cost, 2)
        prev_label = lab
        out.append((e, lab))
    return out


def halt(path, opt=None):
    opt = dict(DEFAULTS, **(opt or {}))
    model = load_model()
    classes = model["classes"]
    lat, handling, cal, cal_x, prod, prod_x = read_station(path)
    rule, backlog = fit_station(lat, handling, cal, cal_x, model, classes, opt)
    if opt.get("force_rule"):
        rule = opt["force_rule"]
    arrivals = [float(r["arrival_ms"]) for r in prod]
    probs = [run_net(model, prod_x[r["frame"]]) for r in prod]
    answers = simulate(rule, backlog, lat, handling, arrivals, probs, opt)
    return [(r["frame"], e, classes[lab]) for r, (e, lab) in zip(prod, answers)]


def main():
    station, out = sys.argv[1], sys.argv[2]
    rows = halt(station)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    with open(out, "w") as fh:
        fh.write("frame,exit,label\n")
        for f, e, l in rows:
            fh.write("%s,%d,%s\n" % (f, e, l))


if __name__ == "__main__":
    main()
