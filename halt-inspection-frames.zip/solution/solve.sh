#!/usr/bin/env bash
# Installs the reference program and checks it against both sample stations' expected answers.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/halting
cp "$HERE/station/halt.py" /app/halting/halt.py
for s in /app/stations/*/; do
  code="$(basename "$s")"
  python3 /app/halting/halt.py "$s" "/tmp/$code.csv"
  if cmp -s "/tmp/$code.csv" "$s/expected.csv"; then echo "$code: matches expected.csv"; else echo "$code: differs from expected.csv"; fi
done
