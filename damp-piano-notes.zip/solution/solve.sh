#!/bin/bash
python3 "$(dirname "$0")/damp_notes.py" /app
