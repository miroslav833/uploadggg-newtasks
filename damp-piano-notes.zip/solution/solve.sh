#!/bin/bash
# Installs the reference tool where the instruction asks for it.
mkdir -p /app/damper
cp "$(dirname "$0")/damp_notes.py" /app/damper/spans.py
