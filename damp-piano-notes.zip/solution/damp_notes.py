#!/usr/bin/env python3
"""Reference tool: when each note of a recorded performance starts sounding and when its damper falls.

Usage: spans.py PERFORMANCE.mid OUT.csv   (installed by solve.sh as /app/damper/spans.py)
"""
import csv
import os
import struct
import sys
from fractions import Fraction


def read_vlq(data, i):
    n = 0
    while True:
        b = data[i]
        i += 1
        n = (n << 7) | (b & 0x7F)
        if not b & 0x80:
            return n, i


def parse(path):
    """-> (format, division word, [track events]); an event is (tick, status, data bytes or meta)."""
    data = open(path, "rb").read()
    assert data[:4] == b"MThd"
    hlen, fmt, ntrk, div = struct.unpack(">IHHH", data[4:14])
    i = 8 + hlen
    tracks = []
    while len(tracks) < ntrk and i < len(data):
        cid, clen = data[i:i + 4], struct.unpack(">I", data[i + 4:i + 8])[0]
        body = data[i + 8:i + 8 + clen]
        i += 8 + clen
        if cid != b"MTrk":
            continue
        evs, j, tick, status = [], 0, 0, None
        while j < len(body):
            dt, j = read_vlq(body, j)
            tick += dt
            b = body[j]
            if b == 0xFF:
                typ = body[j + 1]
                ln, j = read_vlq(body, j + 2)
                evs.append((tick, "meta", typ, body[j:j + ln]))
                j += ln
                status = None                       # meta events cancel running status
            elif b in (0xF0, 0xF7):
                ln, j = read_vlq(body, j + 1)
                j += ln
                status = None                       # so do sysex events
            else:
                if b & 0x80:
                    status = b
                    j += 1
                hi = status & 0xF0
                n = 1 if hi in (0xC0, 0xD0) else 2
                evs.append((tick, "ch", status, tuple(body[j:j + n])))
                j += n
        tracks.append(evs)
    return fmt, div, tracks


def clock(div, tempo_events):
    """tick -> seconds. With an SMPTE division (top bit set) time is frames and ticks per frame,
    and the tempo map does not apply; otherwise ticks per quarter under the conductor's tempo map."""
    if div & 0x8000:
        fps = 256 - (div >> 8)
        tpf = div & 0xFF
        if fps == 29:
            fps = Fraction(30000, 1001)      # -29 is 30 drop-frame, whose frames run at 29.97 a second
        per = Fraction(1, fps * tpf)
        return lambda t: t * per
    ppq = div
    changes = sorted(tempo_events)
    if not changes or changes[0][0] > 0:
        changes = [(0, 500000)] + changes
    segs, sec = [], Fraction(0)
    for tk, us in changes:
        if segs:
            pt, ps, pp = segs[-1]
            sec = ps + (tk - pt) * pp
        segs.append((tk, sec, Fraction(us, 10 ** 6 * ppq)))

    def at(t):
        cur = segs[0]
        for s in segs:
            if s[0] <= t:
                cur = s
            else:
                break
        return cur[1] + (t - cur[0]) * cur[2]
    return at


def damper_fall(key, on, off, pedals, intervals):
    """The tick a note's damper falls on the piano. A damper is up while its key is down, while the
    sustain pedal (controller 64 at 64 or more) is down, or while the sostenuto pedal (66) holds it:
    pressing the sostenuto catches every damper raised at that moment - the keys then down, and all
    of them if the sustain pedal is down - and keeps them raised, whatever is played on those keys,
    until it comes up. (spans_of also ends a note when its key is struck again.) The pedals are the instrument's, so they act on every key, whichever MIDI
    channel or track the messages travel in. Controller 67 (una corda) does not touch the dampers."""
    sus = sos = False
    caught, every = set(), False

    def raised():
        return sus or (sos and (every or key in caught))

    def apply(tick, ctl, val):
        nonlocal sus, sos, caught, every
        down = val >= 64
        if ctl == 64:
            sus = down
        elif ctl == 66:
            if down and not sos:
                caught = {k for k, a, b in intervals if a < tick < b}
                every = sus
            if not down:
                caught, every = set(), False
            sos = down

    for tick, ctl, val in pedals:
        if tick >= off:
            break
        apply(tick, ctl, val)
    if not raised():
        return off
    for tick, ctl, val in pedals:
        if tick <= off:
            continue
        apply(tick, ctl, val)
        if not raised():
            return tick
    return off


def spans_of(path):
    """[(note id "<track>:<n>", onset seconds, release seconds)] for one performance."""
    rows = []
    fmt, div, tracks = parse(path)
    # the tempo map is the conductor's: the first track (the only one in format 0)
    tempo = [(t, int.from_bytes(d, "big")) for t, k, typ, d in tracks[0] if k == "meta" and typ == 0x51]
    at = clock(div, tempo)
    # which instrument each channel belongs to: the General MIDI program it was set to. Program 8 (GM 9)
    # is the celesta, whose keyboard some sessions recorded alongside the grand; everything else is the grand.
    program = {}
    for evs in tracks:
        for t, k, st, d in evs:
            if k == "ch" and st & 0xF0 == 0xC0:
                program[st & 0x0F] = d[0]

    def inst(ch):
        return "celesta" if program.get(ch) == 8 else "piano"

    pedals = {}
    for evs in tracks:
        for t, k, st, d in evs:
            if k == "ch" and st & 0xF0 == 0xB0 and d[0] in (64, 66):
                pedals.setdefault(inst(st & 0x0F), []).append((t, d[0], d[1]))
    for v in pedals.values():
        v.sort()
    per_track = []
    for tn, evs in enumerate(tracks, start=1):
        held, n, notes = {}, 0, []
        for t, k, st, d in evs:
            if k != "ch":
                continue
            hi, ch = st & 0xF0, st & 0x0F
            if hi == 0x90 and d[1] > 0:
                n += 1
                held.setdefault((ch, d[0]), []).append((n, t))
            elif hi == 0x80 or (hi == 0x90 and d[1] == 0):
                lst = held.get((ch, d[0]))
                if lst:
                    num, on = lst.pop(0)
                    notes.append((num, inst(ch), d[0], on, t))
        per_track.append((tn, notes))
    intervals = {}
    for _, notes in per_track:
        for _, ins, key, on, off in notes:
            intervals.setdefault(ins, []).append((key, on, off))
    last = max(t for evs in tracks for t, k, a, b in evs)       # the file's last event
    strikes = {}
    for ins, lst in intervals.items():
        for key, on, off in lst:
            strikes.setdefault((ins, key), []).append(on)
    for tn, notes in per_track:
        for num, ins, key, on, off in sorted(notes):
            rel = damper_fall(key, on, off, pedals.get(ins, []), intervals[ins])
            if ins == "piano" and key > 89:
                rel = last        # above F6 the grand has no dampers: nothing stops the strings
            # one set of strings (or one bar) per key: striking the key again ends the note it was sounding
            later = [t for t in strikes[(ins, key)] if t > on]
            if later and min(later) < rel:
                rel = min(later)
            rows.append(("%d:%d" % (tn, num), float(at(on)), float(at(rel))))
    return rows


def main(argv):
    """spans.py PERFORMANCE.mid OUT.csv"""
    src, dst = argv[1], argv[2]
    with open(dst, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["note", "onset", "release"])
        for nid, on, rel in spans_of(src):
            w.writerow([nid, "%.6f" % on, "%.6f" % rel])


if __name__ == "__main__":
    main(sys.argv)
