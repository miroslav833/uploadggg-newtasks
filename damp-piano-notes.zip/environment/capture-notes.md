# Capture notes

The twelve performances were played on the hall's MIDI-equipped concert grand during the
October recording sessions and captured from the instrument's MIDI output, keys and pedals,
by the session sequencer. The instrument's three pedals - una corda, sostenuto and sustain - are
captured as controllers 67, 66 and 64, as the piano's MIDI system sends them. Each was exported as a Standard MIDI File and is listed in
`pieces.csv`. Most were exported with the sequencer's multitrack setting, the conductor track
first and the hands, and on some sessions the pedals, on tracks of their own; a few were exported
as a single track. The exports the video team requested were written with SMPTE time so that
they line up with the camera files. On some sessions the keyboard was split, and its left half
sent on the second MIDI channel. Nothing was edited, quantised or re-timed after capture.
