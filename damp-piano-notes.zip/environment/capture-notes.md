# Capture notes

The performances were played on the hall's MIDI-equipped concert grand during the October recording
sessions. The session sequencer recorded everything the instrument's MIDI output sent while each
performance was played, and exported each performance as a Standard MIDI File using whichever export
settings that session's engineer chose. Nothing was edited, quantised or re-timed after capture.
