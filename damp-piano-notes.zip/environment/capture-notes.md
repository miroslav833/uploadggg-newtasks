# Capture notes

The performances were played on the hall's MIDI-equipped concert grand, whose dampers cover the keys
from A0 up to F6, during the October recording sessions. The session sequencer recorded every MIDI
input that was live during each take, and exported each performance as a Standard MIDI File using
whichever export settings that session's engineer chose. Nothing was edited, quantised or re-timed
after capture.
