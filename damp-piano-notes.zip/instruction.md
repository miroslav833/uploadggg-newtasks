The engravers turning twelve recorded piano performances into scores, and the editor aligning each score with the concert recording, need to know when every note starts sounding and when its damper falls and it stops sounding.

Inputs:

- `/app/midi/<piece>.mid`: the twelve performances as Standard MIDI Files, exactly as the session sequencer exported them.
- `/app/pieces.csv`: `piece`, `title`, `performer`, `instrument`, `file`.
- `/app/capture-notes.md`: how the performances were captured and exported.

Write `/app/out/notes.csv` with a header row and one row per note:

```
note,onset,release
zz9q:2:17,12.406250,13.880208
```

A note is identified as `<piece>:<track>:<n>`: the piece code (the file name without `.mid`), the track in which its note-on appears (tracks counted from 1 in file order), and `n`, the note's position among that track's note-on messages with a velocity above 0, counted from 1. `onset` is the time in seconds from the start of the file at which the key goes down. `release` is the time in seconds at which the note stops sounding on the piano that played it, with every pedal message in the file in effect.

A row is right when both its onset and its release are within 0.005 s of the key. At least 682 of the 757 notes must be right.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
