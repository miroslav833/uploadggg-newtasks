The engravers turning the hall's recorded piano performances into scores, and the editor aligning each score with its concert recording, need a tool that says when every note of a performance starts sounding and when its damper falls and it stops sounding. It should be a program you run as

```
python3 /app/damper/spans.py PERFORMANCE.mid OUT.csv
```

where PERFORMANCE.mid is one performance as the session sequencer exported it, a Standard MIDI File. OUT.csv must get a header row and one row per note:

```
note,onset,release
2:17,12.406250,13.880208
```

A note is identified as `<track>:<n>`: the track in which its note-on appears (tracks counted from 1 in file order) and `n`, the note's position among that track's note-on messages with a velocity above 0, counted from 1. `onset` is the time in seconds from the start of the file at which the key goes down. `release` is the time in seconds at which the note stops sounding on the instrument that played it, with every pedal message in the file in effect. A note that nothing stops before the file ends is filed with the time of the file's last event. `/app/capture-notes.md` says how the performances were captured and exported.

Four of the session's exports are in `/app/samples/midi` for trying it out. Grading uses 24 other performances from the same sessions that are not in here, and they were not all exported the way these four were. A performance counts when OUT.csv lists exactly its notes and every onset and every release is within 0.005 s of when that note really starts and stops sounding. At least 22 of the 24 have to count.

For grading your program runs once per performance on a fresh copy of the file, as an unprivileged user, under the image's python3 with the standard library only, and gets 60 seconds per performance. Anything else it needs should go in `/app/damper`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
