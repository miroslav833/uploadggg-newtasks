"""Runs the solver's /app/damper/spans.py on every hidden performance and compares it with the forged spans.

Each run gets its own copy of one performance, an account number no process holds and no earlier run used, 60 seconds and
fixed limits on CPU, memory and file size. Every process of that account is stopped before anything
it wrote is read. The output is opened without following links, must be a regular file under 4 MiB,
and is parsed as text: nothing it contains is executed.
"""
import csv
import io
import math
import os
import resource
import shutil
import signal
import stat
import subprocess
import time

VAULT = "/tests/vault"
TOOL = "/app/damper/spans.py"
RUNS = "/var/tmp/damper-runs"
SECONDS = 60
WITHIN = 0.005
CAP = 4 << 20


def performances():
    return sorted(n[:-4] for n in os.listdir(os.path.join(VAULT, "midi")) if n.endswith(".mid"))


def forged(name):
    with open(os.path.join(VAULT, "spans", name + ".csv"), newline="", encoding="utf-8") as f:
        return {r["note"]: (float(r["onset"]), float(r["release"])) for r in csv.DictReader(f)}


def _new_account():
    taken = set()
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                taken.add(os.stat("/proc/" + d).st_uid)
            except OSError:
                pass
    uid = 52000
    while uid in taken or uid in _used:
        uid += 1
    _used.add(uid)
    return uid


_used = set()


def _stop(uid):
    calm = 0
    for _ in range(300):
        found = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    if os.stat("/proc/" + d).st_uid == uid:
                        found.append(int(d))
                except OSError:
                    pass
        if not found:
            calm += 1
            if calm >= 3:
                return
            time.sleep(0.03)
            continue
        calm = 0
        for pid in found:
            for sig in (signal.SIGSTOP, signal.SIGKILL):
                try:
                    os.kill(pid, sig)
                except ProcessLookupError:
                    pass
        time.sleep(0.03)


def _limits():
    resource.setrlimit(resource.RLIMIT_CPU, (SECONDS, SECONDS))
    resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
    resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))


def run_tool(name, uid):
    room = os.path.join(RUNS, name)
    shutil.rmtree(room, ignore_errors=True)
    os.makedirs(room, mode=0o755)
    src = os.path.join(room, name + ".mid")
    shutil.copyfile(os.path.join(VAULT, "midi", name + ".mid"), src)
    os.chmod(src, 0o444)
    os.chown(room, uid, uid)
    dst = os.path.join(room, "spans.csv")

    def drop():
        os.setsid()
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)
        _limits()
    try:
        subprocess.run(["python3", TOOL, src, dst], cwd=room, preexec_fn=drop, timeout=SECONDS,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": room})
    except (subprocess.TimeoutExpired, OSError):
        pass
    _stop(uid)
    return dst


def read_output(path):
    """-> {note: (onset, release)} or None if the output is not a readable regular file of rows."""
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError:
        return None
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > CAP:
            return None
        raw = os.read(fd, CAP + 1)
    finally:
        os.close(fd)
    rows = {}
    try:
        for r in csv.DictReader(io.StringIO(raw.decode("utf-8"))):
            nid = (r.get("note") or "").strip()
            if nid in rows:
                return None
            rows[nid] = (float(r["onset"]), float(r["release"]))
    except (KeyError, TypeError, ValueError, UnicodeDecodeError):
        return None
    return rows


def matches(got, want):
    """A performance counts when the tool lists exactly its notes, each onset and release within 0.005 s."""
    if got is None or set(got) != set(want):
        return False
    for nid, (on, rel) in want.items():
        a, b = got[nid]
        if not (math.isfinite(a) and math.isfinite(b) and abs(a - on) <= WITHIN and abs(b - rel) <= WITHIN):
            return False
    return True


def bench():
    os.makedirs(RUNS, mode=0o711, exist_ok=True)
    results = {}
    for name in performances():
        uid = _new_account()
        results[name] = matches(read_output(run_tool(name, uid)), forged(name))
    return results
