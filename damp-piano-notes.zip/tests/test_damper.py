"""The forged spans agree with the verifier's own model, and the solver's tool gets enough performances right."""
import json
import math
import os

import bench
import dampers

PERFORMANCES = 24
MARK = 22


def test_forged_spans_agree_with_the_model():
    names = bench.performances()
    assert len(names) == PERFORMANCES
    with open(os.path.join(bench.VAULT, "world.json"), encoding="utf-8") as f:
        model = dampers.rebuild(json.load(f))
    for name in names:
        for nid, (on, rel) in bench.forged(name).items():
            m_on, m_rel = model["%s:%s" % (name, nid)]
            assert math.isfinite(float(m_rel)) and abs(float(m_on) - on) < 1e-5 and abs(float(m_rel) - rel) < 1e-5, (name, nid)


def test_tool_reaches_the_mark():
    assert os.path.isfile(bench.TOOL), "no /app/damper/spans.py"
    results = bench.bench()
    right = sum(results.values())
    print("performances right: %d of %d (mark %d)" % (right, len(results), MARK))
    print("missed: %s" % sorted(n for n, ok in results.items() if not ok))
    assert right >= MARK
