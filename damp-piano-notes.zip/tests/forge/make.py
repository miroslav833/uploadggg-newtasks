#!/usr/bin/env python3
"""Generator for damp-piano-notes (never ships). Writes environment/ and tests/sealed/."""
import csv
import json
import math
import os
import random
import shutil
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from model import spans, CELESTA as CELESTA_PROGRAM, instrument, DEFAULT  # noqa: E402

LANE = os.path.dirname(HERE)
ENV = os.path.join(LANE, "environment")
SEALED = os.path.join(LANE, "tests", "sealed")
SEED = int(os.environ.get("SEED", "20261019"))
TOL = 0.005
MARK_SHARE = 0.9

# piece plans: (format, division, left-hand channel, pedal track of its own, sostenuto)
PLANS = [
    (1, ("ppq", 480), 0, True, True), (1, ("ppq", 960), 1, True, True), (1, ("ppq", 384), 1, True, True),
    (1, ("smpte", 25, 40), 0, True, True), (1, ("ppq", 480), 1, False, True), (1, ("ppq", 240), 0, True, True),
    (1, ("smpte", 30, 80), 1, False, False), (1, ("ppq", 960), 0, True, True),
    (0, ("ppq", 480), 0, False, True), (0, ("smpte", 24, 50), 1, False, True), (0, ("ppq", 192), 1, False, False),
    (0, ("ppq", 480), 0, False, False),
]
TITLES = ["Nocturne in B", "Étude-tableau 4", "Barcarolle sketch", "Prelude in F sharp", "Intermezzo",
          "Ballade fragment", "Lullaby for Ines", "Night Train", "Arabesque 2", "Toccatina", "Elegy", "Siciliano"]
PERFORMERS = ["M. Okafor", "L. Brandt", "S. Ivanova", "T. Mori"]


def code(rng):
    return "".join(rng.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(4))


def beat_ticks(div):
    return div[1] if div[0] == "ppq" else div[1] * div[2] // 2


def make_piece(rng, plan, name, through=0.4, extras=True):
    top = 98 if extras else 86     # the hidden performances reach the undamped treble; the samples do not
    fmt, div, lh_ch, pedal_own, sost = plan
    bt = beat_ticks(div)
    tempo = []
    bpm = rng.uniform(58, 132)
    tempo.append((0, int(60e6 / bpm)))
    t = 0
    for _ in range(rng.randint(3, 6)):
        t += rng.randint(3, 7) * bt + rng.randint(1, bt - 1)
        bpm *= rng.uniform(0.78, 1.22)
        tempo.append((t, int(60e6 / bpm)))
    notes = {2: [], 3: []} if fmt == 1 else {1: []}
    # the right hand: the samples stay below F6, the hidden performances reach the undamped strings above
    hands = [(2 if fmt == 1 else 1, 0, (60, top)), (3 if fmt == 1 else 1, lh_ch, (33, 62))]
    used = set()
    for tr, ch, (lo, hi) in hands:
        tick = rng.randint(1, bt)
        recent = []
        for _ in range(rng.randint(22, 30)):
            dur = int(bt * rng.choice([0.2, 0.35, 0.5, 0.7, 0.9, 1.2, 1.6]) * rng.uniform(0.9, 1.1)) + 1
            for _k in range(rng.choice([1, 1, 1, 2])):
                # repeated keys, as playing has them; under a pedal a repeat re-strikes ringing strings
                key = rng.choice(recent[-6:]) if recent and rng.random() < 0.3 else rng.randint(lo, hi)
                recent.append(key)
                notes[tr].append([ch, key, tick, tick + dur + rng.randint(0, bt // 8), rng.randint(28, 112)])
            tick += int(bt * rng.choice([0.25, 0.5, 0.5, 0.75, 1, 1.5]) * rng.uniform(0.94, 1.06)) + 1
    end = max(n[3] for tr in notes for n in notes[tr])
    # sustain pedal on channel 0: down/up cycles across the piece, ending up
    ped = []
    tk = rng.randint(bt // 2, 2 * bt)
    while tk < end - 2 * bt:
        d = tk
        u = d + rng.randint(bt, 3 * bt)
        ped.append([d, 64, rng.randint(65, 127)])
        if rng.random() < 0.4:
            ped.append([(d + u) // 2, 64, rng.randint(70, 127)])       # still down
        ped.append([u, 64, rng.choice([0, 0, rng.randint(1, 63)])])
        tk = u + rng.randint(bt // 2, 3 * bt)
    if sost:
        tk = rng.randint(2 * bt, 4 * bt)
        sus_down = [(p[0], p[0] + 1) for p in ped if p[1] == 64]
        while tk < end - 3 * bt:
            if rng.random() < through:
                # pressed while the sustain pedal is down: inside one of its down stretches
                downs = [(a[0], b[0]) for a, b in zip([p for p in sorted(ped) if p[1] == 64 and p[2] >= 64],
                                                      [p for p in sorted(ped) if p[1] == 64 and p[2] < 64])
                         if a[0] > tk and b[0] - a[0] > 4]
                if downs:
                    a, b = downs[0]
                    tk = rng.randint(a + 2, b - 2)
            ped.append([tk, 66, rng.randint(65, 127)])
            tk2 = tk + rng.randint(4 * bt, 8 * bt)
            ped.append([tk2, 66, rng.choice([0, rng.randint(1, 63)])])
            tk = tk2 + rng.randint(1 * bt, 3 * bt)
    for _ in range(rng.randint(0, 3)):
        a = rng.randint(bt, max(bt + 1, end - 3 * bt))
        ped.append([a, 67, rng.randint(65, 127)])
        ped.append([a + rng.randint(bt, 3 * bt), 67, 0])
    # keep pedal ticks off every note tick
    note_ticks = {n[2] for tr in notes for n in notes[tr]} | {n[3] for tr in notes for n in notes[tr]}
    for p in ped:
        while p[0] in note_ticks:
            p[0] += 1
    ped.sort()
    pedal_track = (4 if pedal_own else 3) if fmt == 1 else 1
    tracks = {}
    for tr in notes:
        tracks.setdefault(tr, [])
    if fmt == 1:
        tracks[1] = []
        tracks.setdefault(4, []) if pedal_own else None
    for tr, evs in notes.items():
        evs.sort(key=lambda n: (n[2], n[1]))
        for i, (ch, key, on, off, vel) in enumerate(evs):
            tracks[tr].append((on, "note", (ch, key, on, off, i + 1, vel)))
    for tick, ctl, val in ped:
        tracks[pedal_track].append((tick, "cc", (0, ctl, val)))
    names = {2: "Piano RH", 3: "Piano LH", 4: "Pedals"} if fmt == 1 else {}
    celesta_ch = None
    if extras and rng.random() < 0.4:
        # the celesta player's keyboard was live in this take: its own channel, program, pedal and track
        celesta_ch = 2
        ctr = (max(tracks) + 1) if fmt == 1 else 1
        tracks.setdefault(ctr, [])
        names[ctr] = "Celesta"
        tick = rng.randint(bt, 3 * bt)
        cel = []
        for _ in range(rng.randint(14, 22)):
            dur = int(bt * rng.choice([0.25, 0.4, 0.6, 0.9]) * rng.uniform(0.9, 1.1)) + 1
            cel.append([celesta_ch, rng.randint(64, 100), tick, tick + dur, rng.randint(30, 100)])
            tick += int(bt * rng.choice([0.5, 0.75, 1, 1.5]) * rng.uniform(0.94, 1.06)) + 1
        cel.sort(key=lambda n: (n[2], n[1]))
        for i, (ch, key, on, off, vel) in enumerate(cel):
            tracks[ctr].append((on, "note", (ch, key, on, off, 0, vel)))
        cend = max(n[3] for n in cel)
        cel_ticks = {n[2] for n in cel} | {n[3] for n in cel}
        tk = rng.randint(bt // 2, 2 * bt)
        while tk < cend - bt:
            u = tk + rng.randint(bt, 3 * bt)
            for t_, v_ in ((tk, rng.randint(65, 127)), (u, rng.choice([0, rng.randint(1, 63)]))):
                while t_ in cel_ticks:
                    t_ += 1
                tracks[ctr].append((t_, "cc", (celesta_ch, 64, v_)))
            tk = u + rng.randint(bt // 2, 2 * bt)
        tracks[ctr].append((0, "misc", (0xC0 | celesta_ch, CELESTA_PROGRAM)))
    # the rest of what an instrument and a sequencer send: programs, volume, pan and reverb at the
    # start, and on the hidden sessions pitch bend, channel and key pressure along the way
    for tr, ch, _ in hands:
        tracks[tr].append((0, "misc", (0xC0 | ch, 0)))
        tracks[tr].append((0, "misc", (0xB0 | ch, 7, rng.randint(90, 127))))
        if extras:
            tracks[tr].append((0, "misc", (0xB0 | ch, 10, rng.randint(40, 88))))
            tracks[tr].append((0, "misc", (0xB0 | ch, 91, rng.randint(10, 60))))
            for _ in range(rng.randint(2, 6)):
                at = rng.randint(1, end) | 1
                kind = rng.choice(["bend", "chanpress", "polypress"])
                if kind == "bend":
                    tracks[tr].append((at, "misc", (0xE0 | ch, rng.randint(0, 127), rng.randint(60, 68))))
                elif kind == "chanpress":
                    tracks[tr].append((at, "misc", (0xD0 | ch, rng.randint(0, 127))))
                else:
                    tracks[tr].append((at, "misc", (0xA0 | ch, rng.randint(lo, hi), rng.randint(0, 127))))
    # number each track's note-ons in file order (the writer keeps the list's order within a tick)
    for tr in tracks:
        order = sorted(range(len(tracks[tr])), key=lambda i: tracks[tr][i][0])
        n = 0
        for i in order:
            t_, k_, d_ = tracks[tr][i]
            if k_ == "note":
                n += 1
                tracks[tr][i] = (t_, k_, (d_[0], d_[1], d_[2], d_[3], n, d_[5]))
    piece = dict(name=name, format=fmt, division=div, tempo=tempo, conductor=1, tracks=tracks, top=top,
                 celesta_ch=celesta_ch, names=names)
    return piece


def repair(piece, rng):
    """Move every note that clashes (see clashes) to another key in its hand's range."""
    for _ in range(600):
        bad = clashes(piece)
        if not bad:
            return True
        on, off, on_s, rel_s, tr, idx = bad[0]
        d = piece["tracks"][tr][idx][2]
        if d[0] == piece.get("celesta_ch"):
            lo, hi = 64, 100
        else:
            lo, hi = (60, piece.get("top", 86)) if d[1] >= 60 else (33, 62)
        nd = (d[0], rng.randint(lo, hi)) + tuple(d[2:])
        piece["tracks"][tr][idx] = (piece["tracks"][tr][idx][0], "note", nd)
    return False


def model_view(piece):
    """The piece as the model reads it (note data without velocity)."""
    tracks = {}
    for tr, evs in piece["tracks"].items():
        tracks[tr] = [(t, k, d[:5] if k == "note" else d) for t, k, d in evs]
    return dict(piece, tracks=tracks)


def clashes(piece):
    """Notes that no piano can play or no ear can settle: a key struck again while it is still held
    down, or struck again within 0.03 s of the moment its earlier note's damper would fall."""
    free = spans(model_view(piece), dict(restrike="ignore"))
    by = {}
    for tr, evs in piece["tracks"].items():
        for idx, (t, k, d) in enumerate(evs):
            if k == "note":
                on_s, rel_s = free["%s:%d:%d" % (piece["name"], tr, d[4])]
                by.setdefault((instrument(piece, DEFAULT, d[0]), d[1]), []).append(
                    (d[2], d[3], float(on_s), float(rel_s), tr, idx))
    out = []
    for lst in by.values():
        lst.sort()
        for a, b in zip(lst, lst[1:]):
            if b[0] <= a[1] + 2 or not math.isfinite(a[3]) or abs(b[2] - a[3]) < 0.03 or b[0] == a[0]:
                out.append(b)
    return out


def conflicts(piece):
    return len(clashes(piece))


# ------------------------------------------------------------------ Standard MIDI File writer
def vlq(n):
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append(0x80 | (n & 0x7F))
        n >>= 7
    return bytes(reversed(out))


def track_bytes(events, rng, vel0_off):
    """events: (tick, order, bytes-producer) -> chunk with running status where the writer wants it."""
    evs = sorted(events, key=lambda e: (e[0], e[1]))
    out = bytearray()
    last_tick = 0
    status = None
    for tick, order, kind, payload in evs:
        out += vlq(tick - last_tick)
        last_tick = tick
        if kind == "meta":
            typ, data = payload
            out += bytes([0xFF, typ]) + vlq(len(data)) + data
            status = None
        elif kind == "sysex":
            out += bytes([0xF0]) + vlq(len(payload)) + payload
            status = None
        else:
            st, data = payload[0], payload[1:]
            if st != status or rng.random() < 0.15:
                out.append(st)
                status = st
            out += bytes(data)
    out += vlq(0) + b"\xff\x2f\x00"
    return b"MTrk" + struct.pack(">I", len(out)) + bytes(out)


def smf(piece, rng):
    vel0_off = rng.random() < 0.5
    chunks = []
    meta_tempo = [(t, 0, "meta", (0x51, struct.pack(">I", us)[1:])) for t, us in piece["tempo"]]
    head_meta = [(0, 0, "meta", (0x58, bytes([4, 2, 24, 8]))), (0, 0, "meta", (0x59, bytes([rng.randint(0, 4), 0])))]
    for tr in sorted(piece["tracks"]):
        evs = []
        if tr == 1:
            evs += meta_tempo + head_meta
            evs.append((0, 0, "meta", (0x03, ("Conductor" if piece["format"] == 1 else piece["title"]).encode())))
            if rng.random() < 0.6:
                evs.append((0, 1, "sysex", bytes([0x7E, 0x7F, 0x09, 0x01, 0xF7])))
        else:
            evs.append((0, 0, "meta", (0x03, piece["names"].get(tr, "Track %d" % tr).encode())))
        for t, k, d in piece["tracks"][tr]:
            if k == "note":
                ch, key, on, off, n, vel = d
                evs.append((on, 3, "ch", (0x90 | ch, key, vel)))
                if vel0_off:
                    evs.append((off, 2, "ch", (0x90 | ch, key, 0)))
                else:
                    evs.append((off, 2, "ch", (0x80 | ch, key, rng.randint(0, 64))))
            elif k == "cc":
                ch, ctl, val = d
                evs.append((t, 2, "ch", (0xB0 | ch, ctl, val)))
            else:
                evs.append((t, 1 if t == 0 else 2, "ch", tuple(d)))
        if tr != 1 and piece.get("extras") and rng.random() < 0.5:
            last = max(d[3] if k == "note" else t for evs_ in piece["tracks"].values() for t, k, d in evs_)
            evs.append((rng.randint(1, max(2, last - 1)), 0, "meta",
                        (rng.choice([0x01, 0x06]), rng.choice([b"take 2", b"bar 33", b"retake"]))))
        chunks.append(track_bytes(evs, rng, vel0_off))
    div = piece["division"]
    divword = div[1] if div[0] == "ppq" else ((256 - div[1]) << 8) | div[2]
    head = b"MThd" + struct.pack(">IHHH", 6, piece["format"], len(chunks), divword)
    body = list(chunks)
    if piece.get("extras") and rng.random() < 0.45:
        # a sequencer's own chunk, which is not a track: a reader skips chunk types it does not know
        blob = bytes(rng.randint(0, 255) for _ in range(rng.randint(8, 60)))
        body.insert(rng.randint(0, len(body)), b"XFIH" + struct.pack(">I", len(blob)) + blob)
    return head + b"".join(body)


# the four sample performances shipped with the task: ticks-per-quarter only, and no sostenuto pressed
# through the sustain pedal (the hidden performances have both)
SAMPLE_PLANS = [(1, ("ppq", 480), 0, True, True), (0, ("ppq", 384), 0, False, False),
                (1, ("ppq", 960), 1, False, True), (1, ("ppq", 240), 0, True, False)]


def random_plan(rng):
    fmt = 1 if rng.random() < 0.65 else 0
    if rng.random() < 0.34:
        fps = rng.choice([24, 25, 29, 29, 29, 30])
        div = ("smpte", fps, rng.choice([4, 8, 10, 40, 50, 80, 100]))
    else:
        div = ("ppq", rng.choice([96, 120, 192, 240, 384, 480, 960]))
    return (fmt, div, 1 if rng.random() < 0.35 else 0, fmt == 1 and rng.random() < 0.5, rng.random() < 0.75)


def place(rng, plan, name, through, extras=True):
    for _ in range(60):
        p = make_piece(rng, plan, name, through, extras)
        p["extras"] = extras
        if repair(p, rng) and conflicts(p) == 0:
            return p
    return None


def build(seed, outdir=None, plans=None, through=0.4, count=None, extras=True):
    rng = random.Random(seed)
    pieces, names = [], set()
    plans = list(plans) if plans else [random_plan(rng) for _ in range(count)]
    for i, plan in enumerate(plans):
        name = code(rng)
        while name in names:
            name = code(rng)
        names.add(name)
        p = place(rng, plan, name, through, extras)
        while p is None:
            plan = random_plan(rng)
            p = place(rng, plan, name, through, extras)
        p["title"] = TITLES[i % len(TITLES)]
        p["performer"] = rng.choice(PERFORMERS)
        pieces.append(p)
    if outdir:
        os.makedirs(os.path.join(outdir, "midi"), exist_ok=True)
        for p in pieces:
            with open(os.path.join(outdir, "midi", p["name"] + ".mid"), "wb") as f:
                f.write(smf(p, rng))
    return pieces


def world_of(pieces):
    world = []
    for p in pieces:
        notes, pedals = [], []
        for tr, evs in p["tracks"].items():
            for t, k, d in evs:
                if k == "note":
                    notes.append(dict(id="%d:%d" % (tr, d[4]), track=tr, channel=d[0], key=d[1], on=d[2], off=d[3],
                                      instrument=instrument(p, DEFAULT, d[0])))
                elif k == "cc":
                    pedals.append(dict(track=tr, channel=d[0], tick=t, controller=d[1], value=d[2],
                                       instrument=instrument(p, DEFAULT, d[0])))
        last = max([d[3] if k == "note" else t for evs in p["tracks"].values() for t, k, d in evs] +
                   [t for t, _ in p["tempo"]])
        world.append(dict(performance=p["name"], division=list(p["division"]), tempo=[list(x) for x in p["tempo"]],
                          notes=notes, pedals=pedals, last_event=last))
    return world


def forge(seed, count, outdir):
    """The hidden performances (run inside the verifier image): MIDI files, each one's spans, and the world
    the verifier's own model rebuilds them from."""
    pieces = build(seed, outdir, count=count)
    os.makedirs(os.path.join(outdir, "spans"), exist_ok=True)
    for p in pieces:
        t = spans(model_view(p))
        with open(os.path.join(outdir, "spans", p["name"] + ".csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["note", "onset", "release"])
            for nid in sorted(t, key=lambda k: tuple(int(x) for x in k.split(":")[1:])):
                on, rel = t[nid]
                w.writerow([nid.split(":", 1)[1], "%.6f" % on, "%.6f" % rel])
    with open(os.path.join(outdir, "world.json"), "w") as f:
        json.dump(world_of(pieces), f)
    return pieces


def to_json(pieces):
    return [dict(name=p["name"], format=p["format"], division=list(p["division"]), tempo=[list(x) for x in p["tempo"]],
                 conductor=p["conductor"], celesta_ch=p.get("celesta_ch"), top=p.get("top", 86),
                 names={str(k): v for k, v in p.get("names", {}).items()},
                 tracks={str(tr): [[t, k, list(d)] for t, k, d in evs] for tr, evs in p["tracks"].items()})
            for p in pieces]


def from_json(data):
    return [dict(d, division=tuple(d["division"]), tempo=[tuple(x) for x in d["tempo"]],
                 tracks={int(tr): [(t, k, tuple(dd)) for t, k, dd in evs] for tr, evs in d["tracks"].items()})
            for d in data]


def truth(pieces, flags=None):
    out = {}
    for p in pieces:
        out.update(spans(model_view(p), flags))
    return out


HIDDEN_SEED = 7310452
HIDDEN_COUNT = 24


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "forge":
        forge(int(sys.argv[2]), int(sys.argv[3]), sys.argv[4])
        return
    shutil.rmtree(os.path.join(ENV, "samples"), ignore_errors=True)
    shutil.rmtree(os.path.join(ENV, "midi"), ignore_errors=True)
    for stale in ("pieces.csv",):
        if os.path.exists(os.path.join(ENV, stale)):
            os.remove(os.path.join(ENV, stale))
    samples = build(SEED, os.path.join(ENV, "samples"), plans=SAMPLE_PLANS, through=0.0, extras=False)
    # the verifier image forges the hidden set with this same code
    os.makedirs(os.path.join(LANE, "tests", "forge"), exist_ok=True)
    for fn in ("make.py", "model.py"):
        shutil.copyfile(os.path.join(HERE, fn), os.path.join(LANE, "tests", "forge", fn))
    with open(os.path.join(ENV, "capture-notes.md"), "w") as f:
        f.write(NOTES)
    # the hidden set, as the verifier image forges it, kept beside the generator for readings and probes
    held = os.path.join(HERE, "held")
    shutil.rmtree(held, ignore_errors=True)
    hidden = forge(HIDDEN_SEED, HIDDEN_COUNT, held)
    with open(os.path.join(HERE, "pieces.json"), "w") as f:
        json.dump(to_json(hidden), f)
    n = sum(1 for p in hidden for tr in p["tracks"].values() for e in tr if e[1] == "note")
    print("samples %d (%s); hidden %d performances, %d notes; SMPTE %d, split %d, format 0 %d" % (
        len(samples), ", ".join(p["name"] for p in samples), len(hidden), n,
        sum(p["division"][0] == "smpte" for p in hidden),
        sum(any(e[2][0] == 1 for tr in p["tracks"].values() for e in tr if e[1] == "note") for p in hidden),
        sum(p["format"] == 0 for p in hidden)))


NOTES = """# Capture notes

The performances were played on the hall's MIDI-equipped concert grand, whose dampers cover the keys
from A0 up to F6, during the October recording sessions. The session sequencer recorded every MIDI
input that was live during each take, and exported each performance as a Standard MIDI File using
whichever export settings that session's engineer chose. Nothing was edited, quantised or re-timed
after capture.
"""

if __name__ == "__main__":
    main()
