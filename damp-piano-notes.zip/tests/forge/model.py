"""The sounding spans behind damp-piano-notes (generator side; never ships).

A piece is {division: ("ppq", n) | ("smpte", fps, tpf), tempo: [(tick, us_per_quarter)] from the
conductor track (track 1, or the only track of a format 0 file), tracks: {track number:
[event]}}, where an event is (tick, kind, data):
  ("note", channel, key, on_tick, off_tick, n)   n = the note's ordinal among its track's note-ons
  ("cc", channel, controller, value)
spans(piece, flags) -> {note id: (onset seconds, release seconds)}
"""
from fractions import Fraction

DAMPER_TOP = 89          # the instrument's dampers run from A0 up to F6 (MIDI 89); the strings above have none

CELESTA = 8              # General MIDI program 9 (0-based 8): a celesta, with its own damper pedal

DEFAULT = dict(instruments="honour", undamped="honour", restrike="honour", pedals="honour", sostenuto="physical", scope="all", tempo="conductor", smpte="honour", df29="drop",
               threshold=64, arithmetic="fraction")


def clock(piece, f, track):
    """tick -> seconds for notes of `track`, as the reading takes the division and tempo map."""
    div = piece["division"]
    if div[0] == "smpte":
        fps, tpf = div[1], div[2]
        if f["smpte"] == "honour":
            # -29 is 30 drop-frame: frames run at 30/1.001 a second (29 or 30 are the readings that miss it)
            rate = Fraction(30000, 1001) if fps == 29 and f["df29"] == "drop" else (30 if fps == 29 and f["df29"] == "thirty" else fps)
            per = Fraction(1, rate * tpf)
            return (lambda t: float(t * per)) if f["arithmetic"] == "float" else (lambda t: t * per)
        # read as ticks per quarter: the 15 low bits of the division word, under the tempo map
        ppq = ((256 - fps) << 8 | tpf) & 0x7FFF
    else:
        ppq = div[1]
    tempo = piece["tempo"] if (f["tempo"] == "conductor" or track == piece["conductor"]) else []
    changes = sorted(tempo)
    if not changes or changes[0][0] > 0:
        changes = [(0, 500000)] + changes
    segs = []      # (start tick, start seconds, seconds per tick)
    sec = Fraction(0)
    for i, (tk, us) in enumerate(changes):
        per = Fraction(us, 10 ** 6 * ppq)
        if segs:
            pt, ps, pp = segs[-1]
            sec = ps + (tk - pt) * pp
        segs.append((tk, sec, per))

    def at(t):
        cur = segs[0]
        for s in segs:
            if s[0] <= t:
                cur = s
            else:
                break
        v = cur[1] + (t - cur[0]) * cur[2]
        return float(v) if f["arithmetic"] == "float" else v
    return at


def instrument(piece, f, channel):
    """Which instrument a channel's messages come from: the celesta's channel when the file has one."""
    if f["instruments"] == "honour" and channel == piece.get("celesta_ch"):
        return "celesta"
    return "piano"


def pedal_events(piece, f, track, channel):
    mine = instrument(piece, f, channel)
    out = []
    for tr, evs in piece["tracks"].items():
        if f["scope"] == "track" and tr != track:
            continue
        for tick, kind, data in evs:
            if kind != "cc":
                continue
            ch, ctl, val = data
            if ctl not in (64, 66) or instrument(piece, f, ch) != mine:
                continue
            if f["scope"] == "channel" and ch != channel:
                continue
            out.append((tick, ctl, val))
    return sorted(out)


def keys_in_scope(piece, f, track, channel):
    mine = instrument(piece, f, channel)
    out = []
    for tr, evs in piece["tracks"].items():
        if f["scope"] == "track" and tr != track:
            continue
        for tick, kind, data in evs:
            if kind == "note" and instrument(piece, f, data[0]) == mine and (f["scope"] != "channel" or data[0] == channel):
                out.append((data[1], data[2], data[3]))
    return out


def down(val, f):
    return val > 0 if f["threshold"] == "nonzero" else val >= f["threshold"]


def release_tick(key, on, off, peds, keys, f):
    """The tick the note's damper falls. Physical sostenuto (the default): pressing it catches every
    damper raised at that moment - the keys then held down, and every damper if the sustain pedal is
    down - and a caught damper stays up, whatever is played on its key, until the sostenuto comes up."""
    if f["pedals"] == "ignore":
        return off
    mode = f["sostenuto"]
    sus = sos = sus2 = False
    caught_keys, caught_all, caught_note = set(), False, False

    def held():
        if sus:
            return True
        if mode == "as_sustain":
            return sus2
        if mode == "ignore" or not sos:
            return False
        if mode == "midi":
            return caught_note
        return caught_all or key in caught_keys

    def apply(tick, ctl, val):
        nonlocal sus, sos, sus2, caught_keys, caught_all, caught_note
        d = down(val, f)
        if ctl == 64:
            sus = d
            return
        if mode == "as_sustain":
            sus2 = d
            return
        if d and not sos:
            caught_keys = {k for k, a, b in keys if a < tick < b}
            caught_all = sus
            caught_note = on < tick < off
        if not d:
            caught_keys, caught_all, caught_note = set(), False, False
        sos = d

    for tick, ctl, val in peds:
        if tick >= off:
            break
        apply(tick, ctl, val)
    if not held():
        return off
    for tick, ctl, val in peds:
        if tick <= off:
            continue
        apply(tick, ctl, val)
        if not held():
            return tick
    if f == DEFAULT:
        raise ValueError("note still sounding at the end of the file")
    return peds[-1][0]          # a wrong reading may leave it held: it ends with the last pedal message


def spans(piece, flags=None):
    f = dict(DEFAULT)
    if flags:
        f.update(flags)
    ticks = {}
    strikes = {}
    last = 0
    for tr, evs in piece["tracks"].items():
        for tick, kind, data in evs:
            last = max(last, data[3] if kind == "note" else tick)
    last = max([last] + [t for t, _ in piece["tempo"]])
    for tr, evs in piece["tracks"].items():
        cache = {}
        for tick, kind, data in evs:
            if kind != "note":
                continue
            ch, key, on, off, n = data[:5]
            if ch not in cache:
                cache[ch] = (pedal_events(piece, f, tr, ch), keys_in_scope(piece, f, tr, ch))
            rel = release_tick(key, on, off, cache[ch][0], cache[ch][1], f)
            inst = instrument(piece, f, ch)
            if inst == "piano" and key > DAMPER_TOP and f["undamped"] == "honour":
                rel = last                # no damper: nothing stops it before the file's last event
            ticks[(tr, n)] = (tr, (inst, key), on, rel)
            strikes.setdefault((inst, key), []).append(on)
    out = {}
    for (tr, n), (tr_, key, on, rel) in ticks.items():
        if f["restrike"] == "honour":
            later = [t for t in strikes[key] if t > on]
            if later and min(later) < rel:
                rel = min(later)          # the key struck again: its strings take the new note
        at = clock(piece, f, tr)
        out["%s:%d:%d" % (piece["name"], tr, n)] = (at(on), at(rel))
    return out
