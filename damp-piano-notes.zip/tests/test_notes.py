"""The sealed spans agree with the verifier's own model, and the filing reaches the printed mark."""
import os

import dampers
import grade

SEALED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sealed")
FILING = "/app/out/notes.csv"
NOTES = 757
MARK = 682


def test_model_rebuilds_the_sealed_spans():
    sealed = grade.sealed_spans(os.path.join(SEALED, "spans.csv"))
    model = dampers.rebuild(dampers.load(os.path.join(SEALED, "performances.json")))
    assert len(sealed) == NOTES and set(sealed) == set(model)
    worst = max(max(abs(float(model[n][0]) - on), abs(float(model[n][1]) - rel)) for n, (on, rel) in sealed.items())
    assert worst < 1e-5


def test_filing_reaches_the_mark():
    report = grade.count(grade.sealed_spans(os.path.join(SEALED, "spans.csv")), FILING)
    print("filing: %r (mark %d of %d)" % (report, MARK, NOTES))
    assert report["right"] >= MARK
