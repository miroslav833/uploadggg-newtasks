"""The verifier's own model of the performances (tests/sealed/performances.json): note spans in seconds.

Every performance lists its division, its conductor tempo map, each note's track, channel and key-down
and key-up ticks, and every pedal controller message with its track and channel. Time comes from the
division (ticks per quarter under the tempo map, or SMPTE frames and ticks per frame, under which the
tempo map has no effect). A note sounds from key-down until its key is up and no pedal of the piano
keeps its damper raised: the sustain pedal while it is down, and the sostenuto pedal while it stays
down after catching the dampers raised at its press (the keys then down, or every key when the sustain
pedal was down), or until its key is struck again, since the key's strings then sound the new note. It shares no code with the reference.
"""
import json
from fractions import Fraction


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _seconds(division, tempo):
    if division[0] == "smpte":
        step = Fraction(1, division[1] * division[2])
        return lambda tick: tick * step
    ppq = division[1]
    points = sorted((t, us) for t, us in tempo)
    if not points or points[0][0] != 0:
        points.insert(0, (0, 500000))
    starts = [Fraction(0)]
    for (t0, us0), (t1, _) in zip(points, points[1:]):
        starts.append(starts[-1] + Fraction((t1 - t0) * us0, 10 ** 6 * ppq))

    def conv(tick):
        k = max(i for i, (t, _) in enumerate(points) if t <= tick)
        return starts[k] + Fraction((tick - points[k][0]) * points[k][1], 10 ** 6 * ppq)
    return conv


def _falls(note, pedals, notes):
    sustain = sostenuto = every = False
    caught = frozenset()
    for p in pedals:
        if p["tick"] >= note["off"]:
            break
        caught, every, sustain, sostenuto = _step(p, notes, caught, every, sustain, sostenuto)
    if not _up(note, caught, every, sustain, sostenuto):
        return note["off"]
    for p in pedals:
        if p["tick"] <= note["off"]:
            continue
        caught, every, sustain, sostenuto = _step(p, notes, caught, every, sustain, sostenuto)
        if not _up(note, caught, every, sustain, sostenuto):
            return p["tick"]
    raise AssertionError("a note never stops sounding")


def _step(p, notes, caught, every, sustain, sostenuto):
    is_down = p["value"] >= 64
    if p["controller"] == 64:
        return caught, every, is_down, sostenuto
    if is_down and not sostenuto:
        return frozenset(n["key"] for n in notes if n["on"] < p["tick"] < n["off"]), sustain, sustain, True
    if not is_down:
        return frozenset(), False, sustain, False
    return caught, every, sustain, sostenuto


def _up(note, caught, every, sustain, sostenuto):
    return sustain or (sostenuto and (every or note["key"] in caught))


def rebuild(world):
    """-> {note id: (onset seconds, release seconds)}"""
    spans = {}
    for perf in world:
        sec = _seconds(perf["division"], perf["tempo"])
        pedals = sorted((p for p in perf["pedals"] if p["controller"] in (64, 66)), key=lambda p: p["tick"])
        for note in perf["notes"]:
            end = _falls(note, pedals, perf["notes"])
            again = min((n["on"] for n in perf["notes"] if n["key"] == note["key"] and n["on"] > note["on"]), default=None)
            if again is not None and again < end:
                end = again           # the same strings struck again
            spans["%s:%s" % (perf["performance"], note["id"])] = (sec(note["on"]), sec(end))
    return spans
