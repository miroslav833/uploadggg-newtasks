#!/bin/bash
# The reward is 0 unless the tool at /app/damper/spans.py gets enough hidden performances right.
# Nothing the tool writes is trusted: it runs under an invented account that is stopped before the
# verifier reads its output, and the reward file is written by root alone.
LOGS=/logs/verifier
mkdir -p "$LOGS"
rm -f "$LOGS/reward.txt"
echo 0 > "$LOGS/reward.txt"
chmod -R go-rwx /tests 2>/dev/null
chmod 700 /tests 2>/dev/null
if [ -d /app/damper ]; then
  chown -R 0:0 /app/damper
  chmod -R u+rwX,go+rX,go-w /app/damper
fi
chmod 1777 /tmp /var/tmp 2>/dev/null
cd /tests || exit 0
if python3 -m pytest -q -s -p no:cacheprovider -rA --ctrf /tests/ctrf.json test_damper.py; then
  verdict=1
else
  verdict=0
fi
find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
rm -f "$LOGS/reward.txt"
echo "$verdict" > "$LOGS/reward.txt"
cp /tests/ctrf.json "$LOGS/ctrf.json" 2>/dev/null
exit 0
