#!/bin/bash
# Reward stays 0 unless the pytest suite for the filed note spans passes.
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt
cd /tests || exit 0
if python3 -m pytest -q -rA --ctrf /logs/verifier/ctrf.json test_notes.py; then
  echo 1 > /logs/verifier/reward.txt
fi
exit 0
