"""Reads the sealed spans and a filing as text and counts the notes filed right. Nothing filed is run."""
import csv
import math

WITHIN = 0.005      # seconds, on the onset and on the release alike


def sealed_spans(path):
    with open(path, newline="", encoding="utf-8") as f:
        return {r["note"]: (float(r["onset"]), float(r["release"])) for r in csv.DictReader(f)}


def count(sealed, filing_path):
    seen, twice, bad = {}, set(), set()
    try:
        with open(filing_path, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                nid = (r.get("note") or "").strip()
                if not nid:
                    continue
                if nid in seen:
                    twice.add(nid)
                try:
                    seen[nid] = (float(r["onset"]), float(r["release"]))
                except (KeyError, TypeError, ValueError):
                    bad.add(nid)
    except OSError:
        pass
    right = 0
    for nid, (on, rel) in sealed.items():
        if nid not in seen or nid in twice or nid in bad:
            continue
        a, b = seen[nid]
        if math.isfinite(a) and math.isfinite(b) and abs(a - on) <= WITHIN and abs(b - rel) <= WITHIN:
            right += 1
    return dict(right=right, filed=len(seen), duplicated=len(twice), unreadable=len(bad), notes=len(sealed))
