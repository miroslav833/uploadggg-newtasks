Write a player that plays the rest of a part the way that part's playback engine played its opening bars. It is run as

```
python3 /app/player/play.py PART_DIR OUT_CSV
```

where PART_DIR is one part's directory, laid out as `/app/HANDBOOK.md` describes (`part.json`, `score.csv`, `played.csv`). OUT_CSV must get a header row and one row per note the engine sends for the written notes after bar `played_bars`:

```
onset_ms,length_ms,key,velocity
6666.7,416.7,67,80
```

Four parts are in `/app/parts` for trying it out, each with an `answer.csv`. Grading uses 20 other parts, played by engines that don't all play the way these four do and carrying marks these four don't; every part follows the handbook, and every engine plays the same way in a part's opening bars as in the rest of it.

A note in OUT_CSV matches a note of the engine's when its key is the same, its onset and length are each within 4 ms and its velocity is within 2. Notes are matched one to one, and a part counts when at most one note is left unmatched in total, counting both the engine's notes you missed and your notes left over. At least 18 of the 20 parts must count. Each part's run gets its own copy of the part, runs as an unprivileged user under the image's python3 with the standard library only, and has 60 seconds. Anything the player needs must be in `/app/player`.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
