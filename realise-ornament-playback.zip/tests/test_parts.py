import json
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine       # noqa: E402
import run_parts    # noqa: E402

HELD = run_parts.HELD


def test_answers_are_the_engine_output():
    parts = sorted(os.listdir(HELD))
    assert len(parts) == 20
    for part in parts:
        d = os.path.join(HELD, part)
        meta, rows = engine.read_part(d)
        prof = engine.load_profile(os.path.join(d, "profile.json"))
        opening = {r["n"] for r in rows if r["bar"] <= meta["played_bars"]}
        rest = sorted((a, b, k, v) for n, a, b, k, v in engine.render(meta, rows, prof) if n not in opening)
        sealed = sorted(run_parts.answer_of(part))
        assert len(rest) == len(sealed), part
        for x, y in zip(rest, sealed):
            assert all(math.isfinite(t) for t in y[:2]), part
            assert abs(x[0] - y[0]) < 0.06 and abs(x[1] - y[1]) < 0.06 and x[2:] == y[2:], (part, x, y)


def test_player_reaches_the_mark():
    assert os.path.isfile(run_parts.PLAYER), "no /app/player/play.py"
    left = run_parts.play_all()
    good = [p for p, n in left.items() if n <= run_parts.SLIPS]
    print("parts counted %d of %d: %s" % (len(good), len(left),
                                          ", ".join("%s %d" % (p, n) for p, n in sorted(left.items()))))
    assert len(good) >= run_parts.NEEDED, "%d of 20 parts counted; %d needed" % (len(good), run_parts.NEEDED)
