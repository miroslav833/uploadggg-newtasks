#!/bin/bash
# Reward 0 unless test_parts.py passes with the player run on the 20 graded parts. The reward folder
# is root-only before the player runs, cleared of anything already in it, and left holding the reward.
umask 077
mkdir -p /logs/verifier
chown 0:0 /logs/verifier 2>/dev/null
chmod 700 /logs/verifier
if [ "$(stat -c %u:%a /logs/verifier)" != "0:700" ]; then
    echo "reward folder could not be locked; not grading" >&2
    exit 0
fi
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
find /logs/verifier -mindepth 1 -exec rm -rf {} + 2>/dev/null
echo 0 > /logs/verifier/reward.txt
OUTDIR=$(mktemp -d /run/part-report.XXXXXX)
cd /tests || exit 0
if python3 -m pytest -q -rA -p no:cacheprovider -s --ctrf "$OUTDIR/ctrf.json" test_parts.py; then
    verdict=1
else
    verdict=0
fi
find /logs/verifier -mindepth 1 ! -user 0 -exec rm -rf {} + 2>/dev/null
rm -f /logs/verifier/reward.json
cp "$OUTDIR/ctrf.json" /logs/verifier/ctrf.json 2>/dev/null
echo "$verdict" > /logs/verifier/reward.txt
find /logs/verifier -mindepth 1 -type f -exec chmod 644 {} +
chmod 755 /logs/verifier
exit 0
