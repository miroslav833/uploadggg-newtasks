"""Run the solver's player on each graded part and count the notes it leaves unmatched.

Every part gets a fresh copy, readable by everyone and owned by root, and an output folder owned by a
numeric account no user or process holds. The player runs under that account in its own session, with
memory, file-size and wall-time limits; every process of the account is killed before its output is
read. Only a regular file of at most 1 MiB is read, as text, and nothing in it is run.
"""
import csv
import math
import os
import pwd
import resource
import shutil
import signal
import subprocess
import time

HELD = "/tests/held"
SCRATCH = "/var/tmp/part-runs"
PLAYER = "/app/player/play.py"
LIMIT_S = 60
MS, VEL = 4.0, 2          # a note matches on key, onset and length within MS, velocity within VEL
SLIPS = 1                 # unmatched notes a part may have in total
NEEDED = 18               # parts of 20
CAP = 1 << 20


def busy(uid):
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    return True
            except FileNotFoundError:
                pass
    return False


def unused_uid(after):
    known = {p.pw_uid for p in pwd.getpwall()}
    uid = after + 1
    while uid in known or busy(uid):
        uid += 1
    return uid


def reap(uid):
    for _ in range(100):
        found = False
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                if os.stat("/proc/" + d).st_uid == uid:
                    found = True
                    os.kill(int(d), signal.SIGKILL)
            except (FileNotFoundError, ProcessLookupError):
                pass
        if not found:
            return
        time.sleep(0.05)


def read_notes(path):
    """[(onset, length, key, velocity)] read as text; rows that do not parse are skipped."""
    notes = []
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return notes
    if not os.path.isfile(path) or os.path.islink(path) or st.st_size > CAP:
        return notes
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(fd, newline="", encoding="utf-8", errors="replace") as fh:
        for rec in csv.DictReader(fh):
            try:
                o, ln = float(rec["onset_ms"]), float(rec["length_ms"])
                k, v = int(float(rec["key"])), int(float(rec["velocity"]))
            except (TypeError, ValueError, KeyError):
                continue
            if math.isfinite(o) and math.isfinite(ln):
                notes.append((o, ln, k, v))
    return notes


def unmatched(filed, key):
    """Notes left over on either side after matching each engine note to its nearest filed note."""
    left = [n for n in filed if math.isfinite(n[0]) and math.isfinite(n[1])]
    missed = 0
    for o, ln, k, v in key:
        best, at = None, None
        for i, (o2, l2, k2, v2) in enumerate(left):
            if k2 == k and abs(o2 - o) <= MS and abs(l2 - ln) <= MS and abs(v2 - v) <= VEL:
                d = abs(o2 - o) + abs(l2 - ln)
                if best is None or d < best:
                    best, at = d, i
        if at is None:
            missed += 1
        else:
            del left[at]
    return missed + len(left)


def play_part(part, uid):
    base = os.path.join(SCRATCH, part)
    shutil.rmtree(base, ignore_errors=True)
    src = os.path.join(base, "part")
    os.makedirs(src)
    for name in ("part.json", "score.csv", "played.csv"):
        shutil.copyfile(os.path.join(HELD, part, name), os.path.join(src, name))
    out = os.path.join(base, "out")
    os.makedirs(out)
    for root, dirs, files in os.walk(base):
        os.chown(root, 0, 0)
        os.chmod(root, 0o755)
        for f in files:
            os.chown(os.path.join(root, f), 0, 0)
            os.chmod(os.path.join(root, f), 0o644)
    os.chown(out, uid, uid)
    os.chmod(out, 0o700)
    target = os.path.join(out, "notes.csv")

    def as_player():
        os.setsid()
        resource.setrlimit(resource.RLIMIT_AS, (1 << 31, 1 << 31))
        resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))
        os.setgroups([])
        os.setgid(uid)
        os.setuid(uid)

    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": out, "TMPDIR": out}
    try:
        subprocess.run(["python3", PLAYER, src, target], preexec_fn=as_player, env=env, cwd=out,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=LIMIT_S)
    except subprocess.TimeoutExpired:
        pass
    reap(uid)
    return read_notes(target)


def answer_of(part):
    return read_notes(os.path.join(HELD, part, "answer.csv"))


def play_all():
    os.makedirs(SCRATCH, exist_ok=True)
    os.chmod(SCRATCH, 0o755)
    left = {}
    uid = 47000
    for part in sorted(os.listdir(HELD)):
        uid = unused_uid(uid)
        left[part] = unmatched(play_part(part, uid), answer_of(part))
    return left
