"""The verifier's playback engine: the notes it sends for a notated part under a sealed profile.

A part is part.json (tempo, metre, key signature) and score.csv (one row per written note, grace notes
included). A profile fixes how this engine plays each mark. Nothing here reads a filing.
"""
import csv
import json
import os
from fractions import Fraction as F

LETTERS = "CDEFGAB"
BASE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}
SHARPS, FLATS = "FCGDAEB", "BEADGCF"
ALTER = {"#": 1, "b": -1, "n": 0}
DYNAMICS = ["pp", "p", "mp", "mf", "f", "ff"]


def key_alteration(fifths, letter):
    if fifths > 0 and letter in SHARPS[:fifths]:
        return 1
    if fifths < 0 and letter in FLATS[:-fifths]:
        return -1
    return 0


def midi(letter, octave, alter):
    return 12 * (octave + 1) + BASE[letter] + alter


def step(letter, octave, d):
    i = LETTERS.index(letter) + d
    return LETTERS[i % 7], octave + i // 7


def read_part(part_dir):
    meta = json.load(open(os.path.join(part_dir, "part.json")))
    rows = []
    with open(os.path.join(part_dir, "score.csv"), newline="") as fh:
        for r in csv.DictReader(fh):
            rows.append(dict(n=int(r["n"]), bar=int(r["bar"]), beat=F(r["beat"]), letter=r["pitch"][0],
                             octave=int(r["pitch"][1:]), acc=r["accidental"], length=F(r["length"]),
                             dynamic=r["dynamic"], marks=r["marks"].split()))
    return meta, rows


def is_dotted(length):
    return length in (F(3, 4), F(3, 2), F(3))


def mark_of(marks, name):
    for m in marks:
        if m == name or m.startswith(name + "/"):
            return m
    return None


def own_accidentals(mark):
    """turn/u#/lb -> {'u': 1, 'l': -1}; tr/# -> {'u': 1}; mordent/b -> {'l': -1}."""
    out = {}
    for part in mark.split("/")[1:]:
        if part[0] in "ul":
            out[part[0]] = ALTER[part[1:]]
        else:
            out["x"] = ALTER[part]
    return out


def render(meta, rows, prof):
    """[(n, onset_ms, length_ms, key, velocity)] for every sounded note, n the written note it belongs to."""
    mpq = 60000.0 / meta["tempo"]
    bar_q = F(meta["beats"]) * F(4, meta["beat_unit"])
    fifths = meta["fifths"]
    swing = prof["swing"]

    # pitches with the bar's accidentals carried, and each note's sounding key
    bar_acc, cur_bar = {}, None
    for r in rows:
        if r["bar"] != cur_bar:
            bar_acc, cur_bar = {}, r["bar"]
        k = (r["letter"], r["octave"])
        if r["acc"]:
            bar_acc[k] = ALTER[r["acc"]]
        alt = bar_acc.get(k, key_alteration(fifths, r["letter"]))
        r["key"] = midi(r["letter"], r["octave"], alt)

        def aux(d, own, letter0=r["letter"], octave0=r["octave"], in_force=dict(bar_acc)):
            """The auxiliary a degree `d` from this note, with the accidentals in force where it stands."""
            letter, octave = step(letter0, octave0, d)
            if own is not None:
                a = own
            else:
                a = in_force.get((letter, octave), key_alteration(fifths, letter))
            return midi(letter, octave, a)
        r["aux"] = aux

    # notated positions -> milliseconds, with swing and fermata holds
    mains = [r for r in rows if r["length"] > 0]
    for i, r in enumerate(mains):
        r["q"] = (r["bar"] - 1) * bar_q + r["beat"]
        r["qlen"] = r["length"]
    if swing:
        for i, r in enumerate(mains[:-1]):
            nx = mains[i + 1]
            if (r["length"] == F(1, 2) and nx["length"] == F(1, 2) and r["beat"].denominator == 1
                    and nx["q"] == r["q"] + F(1, 2)):
                r["qlen"] = F(swing)
                nx["q"] = r["q"] + F(swing)
                nx["qlen"] = 1 - F(swing)
    delay = 0.0
    dyn = "mf"
    for r in mains:
        r["on"] = float(r["q"]) * mpq + delay
        r["span"] = float(r["qlen"]) * mpq
        if r["dynamic"]:
            dyn = r["dynamic"]
        v = prof["v_mf"] + prof["v_step"] * (DYNAMICS.index(dyn) - DYNAMICS.index("mf"))
        if "accent" in r["marks"]:
            v += prof["accent"]
        if "marcato" in r["marks"]:
            v += prof["marcato"]
        r["vel"] = max(1, min(127, v))
        if "fermata" in r["marks"]:
            extra = r["span"] * (prof["fermata"] - 1.0)
            r["span"] += extra
            delay += extra

    out = []
    prev_main = None
    pending = []
    for r in rows:
        if r["length"] == 0:
            pending.append(r)
            continue
        m = r["marks"]
        if "staccatissimo" in m:
            gate = prof["g_staccatissimo"]
        elif "staccato" in m:
            gate = prof["g_staccato"]
        elif "tenuto" in m or "slur" in m:
            gate = 1.0
        else:
            gate = prof["g_normal"]
        on, span, vel = r["on"], r["span"], r["vel"]
        end = on + span * gate
        auxv = max(1, vel - prof["aux_drop"])
        notes = []
        # grace notes written before this note
        for g in pending:
            if "appoggiatura" in g["marks"]:
                frac = F(2, 3) if is_dotted(r["length"]) else F(1, 2)
                gl = span * float(frac)
                notes.append([g["n"], on, gl, g["key"], vel])
                on += gl
            else:
                gl = prof["grace_ms"]
                if prof["grace_place"] == "on":
                    notes.append([g["n"], on, gl, g["key"], auxv])
                    on += gl
                else:
                    notes.append([g["n"], on - gl, gl, g["key"], auxv])
                    if prev_main is not None:
                        pn = prev_main
                        if pn[1] + pn[2] > on - gl:
                            pn[2] = (on - gl) - pn[1]
        pending = []
        tr = mark_of(m, "tr")
        mo = mark_of(m, "mordent")
        pr = mark_of(m, "prall")
        tu = mark_of(m, "turn")
        it = mark_of(m, "invturn")
        if tr:
            own = own_accidentals(tr)
            up = r["aux"](1, own.get("x", own.get("u")))
            d = mpq / prof["trill_rate"]
            count = int(round((end - on) / d))
            count = max(count, 2)
            seq = []
            first_upper = prof["trill_start"] == "upper"
            for j in range(count):
                upper = (j % 2 == 0) == first_upper
                seq.append((up if upper else r["key"], auxv if upper else vel))
            t = on
            for j, (k, v) in enumerate(seq):
                ln = d if j < count - 1 else end - t
                notes.append([r["n"], t, ln, k, v])
                t += d
        elif mo or pr:
            mk = mo or pr
            own = own_accidentals(mk)
            a = r["aux"](-1 if mo else 1, own.get("x"))
            d = mpq / prof["orn_rate"]
            notes += [[r["n"], on, d, r["key"], vel], [r["n"], on + d, d, a, auxv],
                      [r["n"], on + 2 * d, end - on - 2 * d, r["key"], vel]]
        elif tu or it:
            mk = tu or it
            own = own_accidentals(mk)
            u = r["aux"](1, own.get("u", own.get("x")))
            lo = r["aux"](-1, own.get("l", own.get("x")))
            order = [u, r["key"], lo, r["key"]] if tu else [lo, r["key"], u, r["key"]]
            vels = [auxv, vel, auxv, vel]
            if prof["turn"] == "equal":
                d = (end - on) / 4.0
            else:
                d = mpq / prof["turn"]
            t = on
            for j in range(4):
                ln = d if j < 3 else end - t
                notes.append([r["n"], t, ln, order[j], vels[j]])
                t += d
        else:
            notes.append([r["n"], on, end - on, r["key"], vel])
        out += notes
        prev_main = notes[-1]
    return [(n, round(a, 1), round(b, 1), k, v) for n, a, b, k, v in out]


def load_profile(path):
    return json.load(open(path))
