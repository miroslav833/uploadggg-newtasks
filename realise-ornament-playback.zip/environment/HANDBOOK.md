# Playback handbook

A publisher renders single-line parts (one melody instrument, no chords) to MIDI for rehearsal
tracks. Each part is played by one notation-playback engine, and engines differ in how they play a
score: how much of each note's value they hold for each articulation, the velocity of each dynamic
and accent, whether they swing pairs of eighth notes, how long a fermata holds, how fast and in what
shape they play each ornament and which note a trill starts on, and how long a grace note is and
whether it falls on the beat or before it. To show which way a part's engine plays, the opening bars
of every part are captured from that engine before the rest is rendered. A part directory holds three
files.

## `part.json`

```
{"part": "allemande", "title": "Allemande in the old style", "tempo": 72, "beats": 4, "beat_unit": 4, "fifths": -2, "played_bars": 5}
```

| field | meaning |
|---|---|
| `tempo` | quarter notes per minute, constant for the whole part |
| `beats`, `beat_unit` | the time signature (`beat_unit` is always 4) |
| `fifths` | the key signature: sharps if positive, flats if negative |
| `played_bars` | how many opening bars `played.csv` covers |

## `score.csv`

One row per written note, in written order:

```
n,bar,beat,pitch,accidental,length,dynamic,marks
1,1,0,B4,,2,mp,staccato
2,1,2,C5,,1,,slur mordent/b
3,1,3,G4,b,1,,tenuto
11,5,1/2,A4,,0,,acciaccatura
```

- `bar` counts from 1; `beat` is the note's position in the bar in quarter notes from the barline;
  `length` is its written value in quarter notes (`1/2` an eighth, `3/2` a dotted quarter). Both are
  exact fractions.
- `pitch` is the written letter and octave (C4 is middle C, key 60). `accidental` is the accidental
  written on the note: `#`, `b`, `n` (natural) or empty. The key signature applies to every note, and
  a written accidental holds for the rest of its bar on that letter and octave.
- `dynamic` is written only where it changes (`pp`, `p`, `mp`, `mf`, `f`, `ff`); a part with none
  written plays at `mf`.
- A grace note is its own row with `length` 0, written just before the note it ornaments, at the
  same bar and beat, marked `acciaccatura` (a short, crushed grace) or `appoggiatura` (a leaning
  grace).
- `marks` is a space-separated list from this vocabulary:

| mark | in notation |
|---|---|
| `staccato`, `staccatissimo` | detached; very detached |
| `tenuto` | held for its full value |
| `slur` | the note is slurred to the next one |
| `accent`, `marcato` | accented; strongly accented |
| `fermata` | a hold on the note |
| `tr` | a trill, alternating the note with the note a step above |
| `mordent` | the note, the note a step below, the note |
| `prall` | the note, the note a step above, the note (Pralltriller, upper mordent) |
| `turn` | the note above, the note, the note below, the note |
| `invturn` | the note below, the note, the note above, the note |

An ornament may carry its own accidental for its auxiliary note: `tr/#`, `mordent/b`, `prall/n`,
and for the two notes of a turn `turn/u#` (upper), `turn/lb` (lower) or both, `turn/u#/lb`. A step is
the next degree of the scale in the written letters.

## `played.csv`

What the engine sent for the notes of the opening bars, ordered by onset:

```
onset_ms,length_ms,key,velocity
0.0,833.3,70,62
1666.7,52.1,72,62
```

`onset_ms` counts from the start of bar 1 and `length_ms` is how long the key is held, both to 0.1 ms;
`key` is the MIDI key number and `velocity` the MIDI velocity. An ornament or a grace note sends one
row per key it plays. Playback is exact: the engine has no random timing or velocity.

Parts in `/app/parts` also carry `answer.csv`, the engine's notes for the bars after the opening
bars, in the same form as `played.csv`.
