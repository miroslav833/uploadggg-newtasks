#!/usr/bin/env python3
"""Play the rest of a part the way its engine played the opening bars.

    python3 play.py PART_DIR OUT_CSV

Reads part.json, score.csv and played.csv. Every setting of the engine (lengths per articulation,
velocities, swing, fermata hold, trill start and rate, mordent and turn timing, grace-note length and
placement) is chosen so that rendering the opening bars reproduces played.csv; the rest of the part is
then rendered with those settings.
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render as R  # noqa: E402

GRID = {
    "g_normal": [0.8, 0.825, 0.85, 0.875, 0.9, 0.925, 0.95],
    "g_staccato": [0.35, 0.4, 0.45, 0.5, 0.55, 0.6],
    "g_staccatissimo": [0.15, 0.2, 0.25, 0.3],
    "v_mf": [68, 72, 76, 80, 84, 88],
    "v_step": [8, 10, 12, 14, 16],
    "accent": [6, 8, 10, 12, 14, 16],
    "marcato": [16, 18, 20, 22, 24, 28],
    "aux_drop": [0, 4, 6, 8, 10],
    "swing": [0, "2/3", "3/5"],
    "fermata": [1.5, 1.75, 2.0, 2.25, 2.5],
    "trill_rate": [4, 6, 8],
    "trill_start": ["main", "upper"],
    "orn_rate": [6, 8, 12, 16],
    "turn": ["equal", 8, 12, 16],
    "grace_ms": [40, 50, 60, 70, 80, 90],
    "grace_place": ["on", "before"],
}
START = {k: v[len(v) // 2] if k not in ("swing", "trill_start", "grace_place", "turn") else v[0]
         for k, v in GRID.items()}
TOL_MS, TOL_VEL = 2.0, 0


def read_played(path):
    with open(path, newline="") as fh:
        return [(float(r["onset_ms"]), float(r["length_ms"]), int(r["key"]), int(r["velocity"]))
                for r in csv.DictReader(fh)]


def agreement(mine, theirs):
    """Notes of `theirs` matched one-to-one by `mine`, less the notes of `mine` left over."""
    left = list(mine)
    hit = 0
    for o, ln, k, v in theirs:
        for i, (o2, l2, k2, v2) in enumerate(left):
            if k2 == k and abs(o2 - o) <= TOL_MS and abs(l2 - ln) <= TOL_MS and abs(v2 - v) <= TOL_VEL:
                hit += 1
                del left[i]
                break
    return hit - len(left)


MISS = 400.0
# settings that only show together: one moved alone may not lower the mismatch
PAIRS = [("trill_rate", "trill_start"), ("grace_ms", "grace_place"), ("v_mf", "v_step"), ("swing", "g_normal"),
         ("fermata", "g_normal"), ("accent", "v_mf"), ("aux_drop", "trill_start"), ("orn_rate", "aux_drop"),
         ("turn", "aux_drop"), ("g_staccato", "fermata"), ("g_staccatissimo", "fermata"),
         ("g_staccato", "g_staccatissimo"), ("g_normal", "g_staccato"), ("g_normal", "g_staccatissimo")]


def mismatch(mine, theirs, vel_weight=3.0, squared=False):
    """A graded distance: each played note against the nearest rendered note of its key, one to one."""
    left = sorted(mine)
    cost = 0.0
    for o, ln, k, v in theirs:
        best, bi = None, None
        for i, (o2, l2, k2, v2) in enumerate(left):
            if k2 != k or abs(o2 - o) > 250:
                continue
            c = abs(o2 - o) + abs(l2 - ln) + vel_weight * abs(v2 - v)
            if squared:
                c = c * c / MISS
            if best is None or c < best:
                best, bi = c, i
        if bi is None:
            cost += MISS
        else:
            cost += best
            del left[bi]
    return cost + MISS * len(left)


def descend(prof, cost, grid, pairs, passes):
    best = cost(prof)
    for _ in range(passes):
        moved = False
        for name, values in grid.items():
            for val in values:
                if val == prof[name]:
                    continue
                trial = dict(prof, **{name: val})
                c = cost(trial)
                if c < best - 1e-9:
                    prof, best, moved = trial, c, True
        for a, b in pairs:
            for va in grid[a]:
                for vb in grid[b]:
                    trial = dict(prof, **{a: va, b: vb})
                    c = cost(trial)
                    if c < best - 1e-9:
                        prof, best, moved = trial, c, True
        if not moved:
            break
    return prof, best


def fit(meta, rows, played, opening, variant=None):
    """`variant` (readings only) pins settings or switches a rule off: {name: value}, or {name: [values]}.
    The search runs from several starting settings and keeps the one that matches the opening best."""
    variant = variant or {}
    grid = {k: (variant[k] if isinstance(variant.get(k), list) else v) for k, v in GRID.items()}
    vw, sq, passes = variant.get("_vel_weight", 3.0), variant.get("_squared", False), variant.get("_passes", 8)
    pairs = [] if variant.get("_no_pairs") else PAIRS
    fixed = {k: v for k, v in variant.items() if not isinstance(v, list)}

    def cost(p):
        try:
            notes = R.render(meta, [dict(r) for r in rows], p)
        except (ZeroDivisionError, ValueError):
            return float("inf")
        return mismatch([(a, b, k, v) for n, a, b, k, v in notes if n in opening], played, vw, sq)

    starts = [{k: v[-1] for k, v in grid.items()}] if variant.get("_start_high") else \
        [START, {k: v[-1] for k, v in grid.items()}, {k: v[0] for k, v in grid.items()},
         {k: v[len(v) // 3] for k, v in grid.items()}]
    if variant.get("_one_start"):
        starts = [START]
    else:
        # a few more fixed starting points, tried only while no start has matched the opening exactly
        import random
        rng = random.Random(len(played))
        starts += [{k: rng.choice(v) for k, v in grid.items()} for _ in range(4)]
    best = None
    for st in starts:
        prof = {k: (st[k] if st[k] in grid[k] else grid[k][0]) for k in grid}
        prof.update(fixed)
        prof, c = descend(prof, cost, grid, pairs, passes)
        if best is None or c < best[1]:
            best = (prof, c)
        if c == 0:
            break
    return best[0]


def play(part_dir, variant=None):
    meta, rows = R.read_part(part_dir)
    played = read_played(os.path.join(part_dir, "played.csv"))
    opening = {r["n"] for r in rows if r["bar"] <= meta["played_bars"]}
    prof = fit(meta, rows, played, opening, variant)
    notes = R.render(meta, [dict(r) for r in rows], prof)
    return [(a, b, k, v) for n, a, b, k, v in notes if n not in opening]


def main(part_dir, out_csv):
    meta, rows = R.read_part(part_dir)
    played = read_played(os.path.join(part_dir, "played.csv"))
    opening = {r["n"] for r in rows if r["bar"] <= meta["played_bars"]}
    prof = fit(meta, rows, played, opening)
    notes = R.render(meta, [dict(r) for r in rows], prof)
    with open(out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["onset_ms", "length_ms", "key", "velocity"])
        for n, a, b, k, v in sorted(notes, key=lambda x: (x[1], x[3])):
            if n not in opening:
                w.writerow(["%.1f" % a, "%.1f" % b, k, v])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
