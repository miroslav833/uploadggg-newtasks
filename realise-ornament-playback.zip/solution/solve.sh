#!/bin/bash
set -e
mkdir -p /app/player
cp "$(dirname "$0")"/player/*.py /app/player/
