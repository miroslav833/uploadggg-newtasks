"""Chord-note pitch errors of a polysynth session.

    python3 detune.py SESSION_DIR OUT_TSV

Each voice is out by its own offset and octave-scaling error, both growing with the instrument's warm-up
(exponential toward full warmth while on, decaying while off, carried across a power cycle). The master
tune set at a retune zeroes the voice that took the tuning note at that moment. Which voice took each key
follows the assign mode; every mode is tried, the voices' terms and the warm-up constants are fitted to the
measured solo notes by least squares, and the mode that fits best gives the chord notes' errors."""
import math
import sys
from pathlib import Path

VOICES = 6
MODES = ("rotate", "lowest", "oldest", "same")


def read(folder):
    folder = Path(folder)
    release, power = 0.0, []
    for line in folder.joinpath("SESSION.md").read_text().splitlines():
        line = line.strip()
        if line.startswith("- Patch release:"):
            release = float(line.split(":")[1].split()[0])
        elif line.startswith("- switched"):
            power.append((float(line.split(" at ")[1].split()[0]), "on" if "switched on" in line else "off"))
    notes = []
    for line in folder.joinpath("notes.tsv").read_text().splitlines()[1:]:
        start, end, key, passage, cents = line.split("\t")
        notes.append({"start": float(start), "end": float(end), "key": int(key), "passage": passage,
                      "cents": float(cents) if cents.strip() else None})
    return release, sorted(power), notes


def voices_for(notes, mode, release):
    free_at = [-1e9] * VOICES
    ended = [-1e9] * VOICES
    began = [-1e9] * VOICES
    keyed = [None] * VOICES
    used = [False] * VOICES
    last = VOICES - 1
    out = []
    for n in notes:
        t = n["start"]
        free = [v for v in range(VOICES) if free_at[v] <= t]
        if free:
            if mode == "rotate":
                v = min(free, key=lambda x: (x - last - 1) % VOICES)
            elif mode == "lowest":
                v = free[0]
            else:
                same = [x for x in free if keyed[x] == n["key"]] if mode == "same" else []
                if same:
                    v = min(same, key=lambda x: (ended[x], x))
                else:
                    v = min(free, key=lambda x: (used[x], ended[x], x))
        else:
            gone = [x for x in range(VOICES) if ended[x] <= t]
            v = min(gone, key=lambda x: (ended[x], x)) if gone else min(range(VOICES), key=lambda x: (began[x], x))
        out.append(v)
        free_at[v], ended[v], began[v], keyed[v], used[v] = n["end"] + release, n["end"], t, n["key"], True
        last = v
    return out


def warmth_at(power, times, heat, cool):
    """Warm-up at each of the (sorted) times."""
    out, w, i, on, last = [], 0.0, 0, False, None
    for t in times:
        while i < len(power) and power[i][0] <= t:
            if last is not None:
                w = 1 - (1 - w) * math.exp(-(power[i][0] - last) / heat) if on else w * math.exp(-(power[i][0] - last) / cool)
            last, on = power[i][0], power[i][1] == "on"
            i += 1
        if last is None:
            out.append(0.0)
        else:
            out.append(1 - (1 - w) * math.exp(-(t - last) / heat) if on else w * math.exp(-(t - last) / cool))
    return out


def rows_for(notes, voices, warmth):
    rows, ref = [], None
    for n, v, w in zip(notes, voices, warmth):
        o = (n["key"] - 60) / 12.0
        r = [0.0] * (4 * VOICES)
        r[4 * v:4 * v + 4] = [1.0, o, w, w * o]
        if n["passage"] == "tune":
            ref = r
        rows.append([x - y for x, y in zip(r, ref)] if ref else r)
    return rows


def least_squares(X, y):
    n = len(X[0])
    A = [[sum(r[i] * r[j] for r in X) + (1e-6 if i == j else 0.0) for j in range(n)] for i in range(n)]
    b = [sum(r[i] * t for r, t in zip(X, y)) for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda i: abs(A[i][c]))
        A[c], A[p], b[c], b[p] = A[p], A[c], b[p], b[c]
        for i in range(c + 1, n):
            f = A[i][c] / A[c][c]
            if f:
                for j in range(c, n):
                    A[i][j] -= f * A[c][j]
                b[i] -= f * b[c]
    x = [0.0] * n
    for i in reversed(range(n)):
        x[i] = (b[i] - sum(A[i][j] * x[j] for j in range(i + 1, n))) / A[i][i]
    return x


def trial(notes, power, voices, heat, cool, measured):
    rows = rows_for(notes, voices, warmth_at(power, [n["start"] for n in notes], heat, cool))
    X = [rows[i] for i in measured]
    y = [notes[i]["cents"] for i in measured]
    beta = least_squares(X, y)
    sq = sum((sum(a * b for a, b in zip(r, beta)) - t) ** 2 for r, t in zip(X, y))
    return sq, [sum(a * b for a, b in zip(r, beta)) for r in rows]


def best_fit(notes, power, voices, measured):
    span = lambda lo, hi, k: [lo * (hi / lo) ** (i / (k - 1)) for i in range(k)]
    best = None
    for heat in span(300, 2500, 14):
        for cool in (span(500, 4000, 10) if len(power) > 1 else [1000.0]):
            sq, pred = trial(notes, power, voices, heat, cool, measured)
            if best is None or sq < best[0]:
                best = (sq, heat, cool, pred)
    _, h0, c0, _ = best
    for heat in span(h0 / 1.18, h0 * 1.18, 7):
        for cool in (span(c0 / 1.25, c0 * 1.25, 7) if len(power) > 1 else [c0]):
            sq, pred = trial(notes, power, voices, heat, cool, measured)
            if sq < best[0]:
                best = (sq, heat, cool, pred)
    return best


def main(folder, out):
    release, power, notes = read(folder)
    measured = [i for i, n in enumerate(notes) if n["passage"] == "solo" and n["cents"] is not None]
    fits = [best_fit(notes, power, voices_for(notes, m, release), measured) for m in MODES]
    pred = min(fits, key=lambda f: f[0])[3]
    with open(out, "w") as fh:
        fh.write("start\tkey\tcents\n")
        for n, p in zip(notes, pred):
            if n["passage"] == "chord":
                fh.write("%.3f\t%d\t%.2f\n" % (n["start"], n["key"], p))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
