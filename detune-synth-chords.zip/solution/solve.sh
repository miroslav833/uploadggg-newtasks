#!/usr/bin/env bash
# Installs the reference program and checks it against the three sample sessions' truth.tsv.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /app/tuning
cp "$HERE/tuning/detune.py" /app/tuning/detune.py
for s in /app/sessions/*/; do
  code="$(basename "$s")"
  python3 /app/tuning/detune.py "$s" "/tmp/$code.tsv"
  python3 - "/tmp/$code.tsv" "$s/truth.tsv" "$code" <<'PY'
import sys
def table(p):
    return {(l.split("\t")[0], l.split("\t")[1]): float(l.split("\t")[2]) for l in open(p).read().splitlines()[1:]}
got, want = table(sys.argv[1]), table(sys.argv[2])
right = sum(1 for k, v in want.items() if k in got and abs(got[k] - v) <= 1.0)
print("%s: %d of %d chord notes within 1.0 cent of truth.tsv" % (sys.argv[3], right, len(want)))
PY
done
