We record our old six-voice polysynth a lot, and every chord it plays is slightly out of tune, each note by its own amount. Fixing that by hand takes forever. The analyser can measure the notes of the solo lines but not the notes inside chords, so I want a program that works out the chord notes' errors from the rest of the session.

```
python3 /app/tuning/detune.py SESSION_DIR OUT_TSV
```

/app/studio/HANDBOOK.md explains how a session is logged and measured, and what's in each folder (SESSION.md and notes.tsv). Three sessions are in /app/sessions with a truth.tsv each, which is every chord note's error as we eventually measured it from isolated stems.

OUT_TSV: header start, key, cents (tabs between), then one row per chord note in the order notes.tsv lists them, for instance `667.426	54	-0.59`. A chord note counts as right when your cents are within 1.0 of ours. Rows we can't match to a chord note, and chord notes without a row, count as wrong.

The marking uses twenty more sessions, generated inside the marking image where you can't see them. Expect them to differ from the three samples: other assign modes, and sessions where the synth got switched off and back on partway through. A session passes when at least 95 percent of its chord notes are right, and 18 of the 20 sessions need to pass.

Each session is run separately on its own copy of the folder, under an unprivileged account, with plain python3 from the image and only the standard library, and a limit of 120 seconds. Only the /app/tuning folder is carried over to marking, so put the program and anything it loads in there.

You have 9000 seconds to complete this task. Do not cheat by using online solutions or hints specific to this task.
