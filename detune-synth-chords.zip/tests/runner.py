"""Puts the uploaded /app/tuning/detune.py to work on one held session and collects its chord-note errors.

A session is copied into a workspace owned by an account number that no process in the image has; the
program is started as that account, in a new session, with no supplementary groups, a 2 GiB address
space and a 120-second budget. When it ends or runs out of time, every process of that account is
killed; only then is the output looked at, and only if it is a plain file of 1 MiB or less. The table
is read as tab-separated text and nothing in it is executed."""
import math
import os
import resource
import shutil
import signal
import subprocess
import time
from pathlib import Path

VAULT = Path("/tests/vault")
PRIVATE = Path("/run/verifier")
WORKSPACES = Path("/var/tmp/sessions")
ENTRY = "/app/tuning/detune.py"
BUDGET_S = 120
MAX_TABLE = 1 << 20


class Account:
    """A numeric uid with no process, picked fresh for the grading run."""

    def __init__(self, first=58700):
        busy = set()
        for entry in Path("/proc").iterdir():
            if entry.name.isdigit():
                try:
                    busy.add(entry.stat().st_uid)
                except FileNotFoundError:
                    pass
        self.uid = first
        while self.uid in busy:
            self.uid += 1

    def processes(self):
        found = []
        for entry in Path("/proc").iterdir():
            if entry.name.isdigit():
                try:
                    if entry.stat().st_uid == self.uid:
                        found.append(int(entry.name))
                except FileNotFoundError:
                    pass
        return found

    def kill_everything(self):
        for _ in range(200):
            pids = self.processes()
            if not pids:
                return
            for pid in pids:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            time.sleep(0.05)

    def become(self):
        os.setsid()
        os.setgroups([])
        os.setgid(self.uid)
        os.setuid(self.uid)
        for limit, value in ((resource.RLIMIT_AS, 2 << 30), (resource.RLIMIT_FSIZE, 32 << 20), (resource.RLIMIT_CORE, 0)):
            resource.setrlimit(limit, (value, value))


def table(path):
    """{(start, key): cents} from the tab-separated output; malformed or non-finite rows are dropped, and
    the first row for a note wins."""
    rows = {}
    with open(path, encoding="utf-8", errors="replace") as fh:
        for n, line in enumerate(fh):
            fields = line.rstrip("\r\n").split("\t")
            if n == 0 or len(fields) != 3:
                continue
            try:
                where, cents = (round(float(fields[0]), 3), int(fields[1])), float(fields[2])
            except ValueError:
                continue
            if math.isfinite(cents) and math.isfinite(where[0]) and where not in rows:
                rows[where] = cents
    return rows


def grade_run(code, account):
    space = WORKSPACES / code
    shutil.rmtree(space, ignore_errors=True)
    space.mkdir(parents=True, mode=0o755)
    shutil.copytree(VAULT / "sessions" / code, space / "session", symlinks=False)
    (space / "tmp").mkdir()
    (space / "out").mkdir()
    for root, dirs, files in os.walk(space):
        for name in dirs + files:
            os.chown(os.path.join(root, name), account.uid, account.uid)
    os.chown(space, account.uid, account.uid)
    target = space / "out" / "errors.tsv"
    env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": str(space / "tmp"), "TMPDIR": str(space / "tmp"),
           "LANG": "C.UTF-8", "OMP_NUM_THREADS": "2", "OPENBLAS_NUM_THREADS": "2", "MKL_NUM_THREADS": "2"}
    with open(PRIVATE / (code + ".err"), "wb") as err:
        child = subprocess.Popen(["python3", ENTRY, str(space / "session"), str(target)], stdin=subprocess.DEVNULL,
                                 stdout=err, stderr=err, cwd=str(space / "tmp"), env=env, preexec_fn=account.become)
        try:
            child.wait(timeout=BUDGET_S)
        except subprocess.TimeoutExpired:
            pass
    account.kill_everything()
    rows = None
    if target.is_file() and not target.is_symlink() and target.stat().st_size <= MAX_TABLE:
        rows = table(target)
    shutil.rmtree(space, ignore_errors=True)
    return rows


def held_sessions():
    return sorted(p.name for p in (VAULT / "sessions").iterdir())
