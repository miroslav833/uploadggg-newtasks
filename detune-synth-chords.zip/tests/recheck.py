"""The verifier's own replay of a held session from its sealed instrument, written apart from the generator:
which voice took every note under the sealed assign mode, and every chord note's error."""
import math
from pathlib import Path


def session_notes(folder):
    rows = Path(folder, "notes.tsv").read_text().splitlines()[1:]
    out = []
    for r in rows:
        start, end, key, passage, _ = r.split("\t")
        out.append((float(start), float(end), int(key), passage))
    return out


class Pool:
    """Six voices and the assign mode's choice of one for each key."""

    def __init__(self, mode, release):
        self.mode, self.release = mode, release
        self.until = [-math.inf] * 6
        self.off = [-math.inf] * 6
        self.on = [-math.inf] * 6
        self.key = [None] * 6
        self.fresh = [True] * 6
        self.prev = 5

    def take(self, start, end, key):
        idle = [v for v in range(6) if self.until[v] <= start]
        if not idle:
            quiet = [v for v in range(6) if self.off[v] <= start]
            v = min(quiet, key=lambda x: (self.off[x], x)) if quiet else min(range(6), key=lambda x: (self.on[x], x))
        elif self.mode == "rotate":
            v = next((self.prev + s) % 6 for s in range(1, 7) if (self.prev + s) % 6 in idle)
        elif self.mode == "lowest":
            v = min(idle)
        else:
            match = [x for x in idle if self.mode == "same" and self.key[x] == key]
            pool = match or idle
            v = min(pool, key=lambda x: ((not self.fresh[x]) if not match else 0, self.off[x], x))
        self.until[v], self.off[v], self.on[v], self.key[v], self.fresh[v] = end + self.release, end, start, key, False
        self.prev = v
        return v


def warm(power, t, heat, cool):
    level, since, running = 0.0, None, False
    for when, what in power:
        if when > t:
            break
        if since is not None:
            level = 1 - (1 - level) * math.exp((since - when) / heat) if running else level * math.exp((since - when) / cool)
        since, running = when, what == "on"
    if since is None:
        return 0.0
    return 1 - (1 - level) * math.exp((since - t) / heat) if running else level * math.exp((since - t) / cool)


def replay(folder, sealed):
    """(voices, {(start, key): cents} for the chord notes)."""
    a, b, c, d = sealed["terms"]
    power = [tuple(p) for p in sealed["power"]]
    pool = Pool(sealed["mode"], sealed["release"])
    master, voices, chord = 0.0, [], {}
    for start, end, key, passage in session_notes(folder):
        v = pool.take(start, end, key)
        voices.append(v)
        w = warm(power, start, sealed["heat"], sealed["cool"])
        octs = (key - 60) / 12
        raw = a[v] + b[v] * octs + w * (c[v] + d[v] * octs)
        if passage == "tune":
            master = -raw
        if passage == "chord":
            chord[(round(start, 3), key)] = raw + master
    return voices, chord
