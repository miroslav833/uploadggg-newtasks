"""Session folders.

    python3 mint.py graded OUT_DIR SEALED_DIR     the 20 held sessions
    python3 mint.py samples OUT_DIR               the sample sessions (with truth.tsv)

A session is kept only when its solo notes settle it: fitted under its own assign mode, the chord-note
errors come out within TOL of the truth on at least KEEP of the notes, and every other mode fits the solo
notes at least SEPARATE times worse."""
import json
import math
import multiprocessing
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fit       # noqa: E402
import session   # noqa: E402
import synth     # noqa: E402

TOL = 1.0
KEEP = 0.99
SEPARATE = 4.0
SAMPLES = [("S-0412", 5101), ("S-0977", 5133), ("S-1530", 5177)]


def settled(notes, power, syn):
    res = fit.fit(notes, power, syn.release)
    own = res[syn.mode]
    chord = [(n, p) for n, p in zip(notes, own[3]) if n["passage"] == "chord"]
    right = sum(1 for n, p in chord if math.isfinite(p) and abs(p - n["true"]) <= TOL)
    if right < KEEP * len(chord):
        return False
    return all(r[0] >= SEPARATE * own[0] for m, r in res.items() if m != syn.mode)


def draw(seed, mode, restart):
    for t in range(200):
        rng = random.Random(seed * 1000 + t)
        syn = session.instrument(rng, mode)
        power, notes = session.plan(rng)
        if (len(power) > 1) != restart:
            continue
        session.perform(rng, syn, power, notes)
        if settled(notes, power, syn):
            return syn, power, notes
    raise SystemExit("no settled session for seed %d" % seed)


def write(folder, code, syn, power, notes, truth):
    os.makedirs(folder, exist_ok=True)
    lines = ["# Session %s" % code, "", "- Instrument: six-voice polysynth, studio unit 2",
             "- Patch release: %.2f s" % syn.release, "- Power:"]
    for when, what in power:
        lines.append("  - %s at %.3f s" % ("switched on" if what == "on" else "switched off", when))
    with open(os.path.join(folder, "SESSION.md"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    with open(os.path.join(folder, "notes.tsv"), "w") as fh:
        fh.write("start\tend\tkey\tpassage\tcents\n")
        for n in notes:
            m = "" if n["measured"] is None else "%.1f" % n["measured"]
            fh.write("%.3f\t%.3f\t%d\t%s\t%s\n" % (n["start"], n["end"], n["key"], n["passage"], m))
    if truth:
        with open(os.path.join(folder, "truth.tsv"), "w") as fh:
            fh.write(answer(notes))


def answer(notes):
    return "start\tkey\tcents\n" + "".join("%.3f\t%d\t%.2f\n" % (n["start"], n["key"], n["true"])
                                          for n in notes if n["passage"] == "chord")


def build_graded(out_dir, sealed_dir, seed0=91001, n=20):
    rng = random.Random(seed0)
    modes = [synth.MODES[j % 4] for j in range(n)]
    rng.shuffle(modes)
    restarts = [j % 5 < 3 for j in range(n)]      # 12 of 20 sessions switch the instrument off and on
    rng.shuffle(restarts)
    codes = set()
    while len(codes) < n:
        codes.add("S-%04d" % rng.randint(1000, 9999))
    codes = sorted(codes)
    rng.shuffle(codes)
    with multiprocessing.Pool(min(8, os.cpu_count() or 1)) as pool:
        drawn = pool.starmap(draw, [(seed0 + 31 * j, modes[j], restarts[j]) for j in range(n)])
    os.makedirs(sealed_dir, exist_ok=True)
    for code, (syn, power, notes) in zip(codes, drawn):
        write(os.path.join(out_dir, code), code, syn, power, notes, truth=False)
        with open(os.path.join(sealed_dir, code + ".json"), "w") as fh:
            json.dump({"mode": syn.mode, "heat": syn.heat, "cool": syn.cool, "release": syn.release,
                       "terms": [syn.a, syn.b, syn.c, syn.d], "power": power,
                       "voices": [n["voice"] for n in notes], "answer": answer(notes)}, fh)


def build_samples(out_dir):
    with multiprocessing.Pool(3) as pool:
        drawn = pool.starmap(draw, [(seed, "rotate", False) for _, seed in SAMPLES])
    for (code, _), (syn, power, notes) in zip(SAMPLES, drawn):
        write(os.path.join(out_dir, code), code, syn, power, notes, truth=True)


if __name__ == "__main__":
    if sys.argv[1] == "graded":
        build_graded(sys.argv[2], sys.argv[3], *(int(x) for x in sys.argv[4:5]))
    else:
        build_samples(sys.argv[2])
