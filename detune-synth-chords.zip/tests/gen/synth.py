"""A six-voice analogue polysynth in a recording session: which voice plays each key, and how far out of
tune each voice is at each moment.

Voices. Voice v's error in cents at key k, at a moment whose warm-up is W:
    a[v] + b[v] * (k - 60) / 12 + W * (c[v] + d[v] * (k - 60) / 12) + master
a and b are the voice's own trim (offset and octave scaling when cold), c and d how they grow as the
instrument warms. master is the master-tune setting, changed only at a retune.

Warm-up. W rises toward 1 while the instrument is on: W(t) = 1 - (1 - W0) * exp(-(t - on) / heat), and
falls while it is off: W(t) = W_off * exp(-(t - off) / cool). The instrument is first switched on cold.

Retune. At a retune the engineer plays the reference key (69) once and turns master tune until that note
is in tune: master changes so that the voice that took the tuning note is at 0 cents at that moment.
The tuning note is in the log like any other note (passage "tune").

Assign modes. A voice is busy from a note's start until its end plus the patch's release time; a key goes
to a free voice chosen by the mode, and when every voice is busy, to the busy voice whose note ended
first (one still held only if all are held, then the one held longest).
    rotate   the next free voice after the voice that took the previous key, in voice order
    lowest   the lowest-numbered free voice
    oldest   the free voice whose last note ended longest ago (never-used voices first, in voice order)
    same     a free voice whose last note had this key, if any; otherwise as oldest
"""
import math

VOICES = 6
REF_KEY = 69
MODES = ("rotate", "lowest", "oldest", "same")


class Synth:
    def __init__(self, a, b, c, d, heat, cool, mode, release):
        self.a, self.b, self.c, self.d = a, b, c, d
        self.heat, self.cool, self.mode, self.release = heat, cool, mode, release

    def warmth(self, power, t):
        """power: sorted list of (time, 'on'|'off'), starting with an 'on'. Warm-up at time t."""
        w, last_t, on = 0.0, None, False
        for when, what in power:
            if when > t:
                break
            if last_t is not None:
                w = self.evolve(w, on, when - last_t)
            last_t, on = when, what == "on"
        return self.evolve(w, on, t - last_t) if last_t is not None else 0.0

    def evolve(self, w, on, dt):
        if on:
            return 1 - (1 - w) * math.exp(-dt / self.heat)
        return w * math.exp(-dt / self.cool)

    def drift(self, v, key, w):
        o = (key - 60) / 12.0
        return self.a[v] + self.b[v] * o + w * (self.c[v] + self.d[v] * o)


def assign(notes, mode, release):
    """notes: list of dicts with key, start, end, sorted by start. Returns the voice of each note."""
    busy_until = [-1e9] * VOICES     # end + release of the voice's last note
    held_end = [-1e9] * VOICES       # end of the voice's last note
    started = [-1e9] * VOICES
    last_key = [None] * VOICES
    used = [False] * VOICES
    prev = VOICES - 1
    out = []
    for n in notes:
        t = n["start"]
        free = [v for v in range(VOICES) if busy_until[v] <= t]
        if free:
            if mode == "rotate":
                v = min(free, key=lambda x: (x - prev - 1) % VOICES)
            elif mode == "lowest":
                v = free[0]
            else:
                pick = None
                if mode == "same":
                    same = [x for x in free if last_key[x] == n["key"]]
                    if same:
                        pick = min(same, key=lambda x: (held_end[x], x))
                v = pick if pick is not None else min(free, key=lambda x: (used[x], held_end[x], x))
        else:
            released = [x for x in range(VOICES) if held_end[x] <= t]
            if released:
                v = min(released, key=lambda x: (held_end[x], x))
            else:
                v = min(range(VOICES), key=lambda x: (started[x], x))
        out.append(v)
        busy_until[v] = n["end"] + release
        held_end[v] = n["end"]
        started[v] = t
        last_key[v] = n["key"]
        used[v] = True
        prev = v
    return out


def errors(synth, notes, power, voices):
    """Pitch error of every note (cents), master tune following the retunes."""
    master = 0.0
    out = []
    for n, v in zip(notes, voices):
        w = synth.warmth(power, n["start"])
        if n["passage"] == "tune":
            master = -synth.drift(v, n["key"], w)
        out.append(synth.drift(v, n["key"], w) + master)
    return out
