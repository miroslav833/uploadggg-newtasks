"""Sessions: the instrument, the power and retune log, the played notes, the measured solo errors."""
import math
import random

import synth as S

NOISE = 0.25      # cents, the studio's pitch measurement on a solo note
SCALES = [(0, 2, 4, 5, 7, 9, 11), (0, 2, 3, 5, 7, 8, 10), (0, 2, 4, 7, 9), (0, 3, 5, 7, 10)]


def instrument(rng, mode):
    a = [rng.gauss(0, 6) for _ in range(S.VOICES)]
    b = [rng.gauss(0, 4) for _ in range(S.VOICES)]
    c = [rng.gauss(0, 9) for _ in range(S.VOICES)]
    d = [rng.gauss(0, 6) for _ in range(S.VOICES)]
    return S.Synth(a, b, c, d, heat=rng.uniform(500, 1500), cool=rng.uniform(900, 2400), mode=mode,
                   release=round(rng.uniform(0.25, 1.4), 2))


def scale_keys(rng, low, high):
    root = rng.randint(0, 11)
    sc = rng.choice(SCALES)
    return [k for k in range(low, high + 1) if (k - root) % 12 in sc]


def solo(rng, t, keys):
    notes = []
    k = rng.randrange(len(keys))
    for _ in range(rng.randint(14, 30)):
        k = max(0, min(len(keys) - 1, k + rng.choice((-3, -2, -1, -1, 1, 1, 2, 3, 4, -4))))
        dur = rng.choice((0.18, 0.25, 0.25, 0.35, 0.5, 0.75))
        notes.append({"key": keys[k], "start": round(t, 3), "end": round(t + dur * rng.uniform(0.6, 0.95), 3),
                      "passage": "solo"})
        t += dur
    return notes, t


def chords(rng, t, keys):
    notes = []
    for _ in range(rng.randint(4, 10)):
        size = rng.choice((3, 3, 4, 4, 5))
        base = rng.randrange(0, max(1, len(keys) - 9))
        picks = sorted(set(base + j * 2 + rng.choice((0, 0, 1)) for j in range(size)))
        dur = rng.choice((0.9, 1.4, 2.0, 2.8))
        for j, p in enumerate(picks):
            p = min(p, len(keys) - 1)
            st = t + j * rng.choice((0.0, 0.004, 0.011))
            notes.append({"key": keys[p], "start": round(st, 3), "end": round(t + dur * rng.uniform(0.85, 0.97), 3),
                          "passage": "chord"})
        t += dur + rng.choice((0.0, 0.05, 0.3))
    # keys of one chord are unique
    seen, out = set(), []
    for n in notes:
        if (n["key"], n["start"]) not in seen:
            seen.add((n["key"], n["start"]))
            out.append(n)
    return out, t


def tune(t):
    return [{"key": S.REF_KEY, "start": round(t, 3), "end": round(t + 3.0, 3), "passage": "tune"}], t + 3.0


def plan(rng):
    """The session's power log and notes."""
    keys = scale_keys(rng, 43, 91)
    power = [(0.0, "on")]
    t = rng.uniform(240, 900)               # the engineer waits a little before the first take
    notes = []
    first, t = tune(t)
    notes += first
    t += rng.uniform(20, 60)
    restart = rng.random() < 0.6
    off_at = rng.uniform(2200, 3200) if restart else None
    retunes = sorted(rng.uniform(1200, 4500) for _ in range(rng.randint(1, 2)))
    end = rng.uniform(4800, 6000)
    kind = "solo"
    while t < end:
        if off_at is not None and t > off_at:
            power.append((round(t, 3), "off"))
            t += rng.uniform(300, 1200)
            power.append((round(t, 3), "on"))
            t += rng.uniform(30, 120)
            off_at = None
            kind = "solo"
        if retunes and t > retunes[0]:
            retunes.pop(0)
            more, t = tune(t)
            notes += more
            t += rng.uniform(5, 30)
        if kind == "solo":
            more, t = solo(rng, t, keys)
            kind = "chord" if rng.random() < 0.7 else "solo"
        else:
            more, t = chords(rng, t, keys)
            kind = "solo" if rng.random() < 0.75 else "chord"
        notes += more
        t += rng.uniform(15, 140)
    notes.sort(key=lambda n: (n["start"], n["key"]))
    return power, notes


def perform(rng, synth, power, notes):
    voices = S.assign(notes, synth.mode, synth.release)
    errs = S.errors(synth, notes, power, voices)
    for n, v, e in zip(notes, voices, errs):
        n["voice"], n["true"] = v, e
        n["measured"] = round(e + rng.gauss(0, NOISE), 1) if n["passage"] == "solo" else None
    return notes
