"""Fit a session: for each assign mode, the voices' terms and the warm-up constants by least squares on the
measured solo notes; predictions for every note. Standard library only (small normal equations)."""
import math

import synth as S


def solve(rows, ys, ridge=1e-6):
    n = len(rows[0])
    A = [[0.0] * n for _ in range(n)]
    r = [0.0] * n
    for x, y in zip(rows, ys):
        for i in range(n):
            if x[i]:
                xi = x[i]
                r[i] += xi * y
                Ai = A[i]
                for j in range(n):
                    if x[j]:
                        Ai[j] += xi * x[j]
    for i in range(n):
        A[i][i] += ridge
    # Gaussian elimination with partial pivoting
    M = [A[i] + [r[i]] for i in range(n)]
    for col in range(n):
        piv = max(range(col, n), key=lambda i: abs(M[i][col]))
        M[col], M[piv] = M[piv], M[col]
        p = M[col][col]
        if not math.isfinite(p) or abs(p) < 1e-15:
            continue
        for i in range(col + 1, n):
            f = M[i][col] / p
            if f:
                Mi, Mc = M[i], M[col]
                for j in range(col, n + 1):
                    Mi[j] -= f * Mc[j]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n))
        x[i] = s / M[i][i] if math.isfinite(M[i][i]) and abs(M[i][i]) > 1e-15 else 0.0
    return x


def features(v, key, w):
    f = [0.0] * (4 * S.VOICES)
    o = (key - 60) / 12.0
    f[4 * v], f[4 * v + 1], f[4 * v + 2], f[4 * v + 3] = 1.0, o, w, w * o
    return f


def design(notes, voices, power, heat, cool):
    probe = S.Synth([0] * 6, [0] * 6, [0] * 6, [0] * 6, heat, cool, None, 0)
    rows, tune_row = [], None
    for n, v in zip(notes, voices):
        w = probe.warmth(power, n["start"])
        f = features(v, n["key"], w)
        if n["passage"] == "tune":
            tune_row = f
        rows.append([a - b for a, b in zip(f, tune_row)] if tune_row else f)
    return rows


def fit_mode(notes, power, mode, release, heats, cools):
    voices = S.assign(notes, mode, release)
    best = None
    solo = [i for i, n in enumerate(notes) if n["passage"] == "solo" and n.get("measured") is not None]
    ys = [notes[i]["measured"] for i in solo]
    for heat in heats:
        for cool in cools:
            rows = design(notes, voices, power, heat, cool)
            X = [rows[i] for i in solo]
            beta = solve(X, ys)
            res = sum((sum(a * b for a, b in zip(x, beta)) - y) ** 2 for x, y in zip(X, ys))
            rms = math.sqrt(res / len(ys))
            if best is None or rms < best[0]:
                best = (rms, heat, cool, beta, rows)
    rms, heat, cool, beta, rows = best
    preds = [sum(a * b for a, b in zip(r, beta)) for r in rows]
    return rms, heat, cool, preds, voices


def grid(lo, hi, n):
    return [lo * (hi / lo) ** (i / (n - 1)) for i in range(n)]


def fit(notes, power, release, modes=S.MODES):
    out = {}
    for m in modes:
        rms, heat, cool, preds, voices = fit_mode(notes, power, m, release, grid(300, 2500, 14), grid(500, 4000, 10))
        # refine around the best
        rms, heat, cool, preds, voices = fit_mode(notes, power, m, release, grid(heat / 1.18, heat * 1.18, 7),
                                                  grid(cool / 1.25, cool * 1.25, 7))
        out[m] = (rms, heat, cool, preds, voices)
    return out
