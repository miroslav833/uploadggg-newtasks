#!/usr/bin/env bash
# Grading for the chord-error program.
#   1. Close the reward folder first: owned by root, mode 700, verified; any reward/result/score file
#      already there is deleted and reward.txt is set to 0.
#   2. The uploaded detune.py runs inside tests/runner.py under a throwaway numeric account.
#   3. Afterwards everything root did not write in the folder goes, and only reward.txt is written.
set -u
LOGS=/logs/verifier
SCRATCH=/run/verifier

mkdir -p "$LOGS"
saved_mode=$(stat -c %a "$LOGS" 2>/dev/null || echo 755)
chown root:root "$LOGS" 2>/dev/null
chmod 700 "$LOGS" 2>/dev/null

write_reward() {
    find "$LOGS" -mindepth 1 -maxdepth 1 \( -name 'reward*' -o -name 'result*' -o -name 'score*' \) -exec rm -rf {} + 2>/dev/null
    find "$LOGS" -mindepth 1 ! -uid 0 -exec rm -rf {} + 2>/dev/null
    (umask 022; echo "$1" > "$LOGS/reward.txt")
}

write_reward 0
case "$(stat -c '%u %a' "$LOGS" 2>/dev/null)" in
    "0 700") ;;
    *) echo "reward folder is not root-only; nothing is run" >&2
       chmod "$saved_mode" "$LOGS" 2>/dev/null
       exit 0 ;;
esac

chmod -R go-rwx /tests 2>/dev/null; chmod 700 /tests 2>/dev/null
install -d -o root -g root -m 700 "$SCRATCH"
chmod -R a+rX /app/tuning 2>/dev/null

cd /tests
python3 -m pytest test_sessions.py -q -p no:cacheprovider --ctrf "$SCRATCH/ctrf.json"
outcome=$?

[ "$outcome" -eq 0 ] && write_reward 1 || write_reward 0
for report in ctrf.json sessions.json; do
    if [ -f "$SCRATCH/$report" ]; then (umask 022; cp "$SCRATCH/$report" "$LOGS/$report"); fi
done
chmod "$saved_mode" "$LOGS" 2>/dev/null
exit 0
