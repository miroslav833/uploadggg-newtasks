"""The held sessions: each sealed instrument replays its own voices and chord errors, and the uploaded program
gets enough chord notes of enough sessions right."""
import json
import math
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import recheck  # noqa: E402
import runner   # noqa: E402

SESSIONS = 20
TOL = 1.0       # cents (instruction.md)
SHARE = 0.95    # of a session's chord notes that must be right (instruction.md)
NEEDED = 18     # sessions of 20 that must pass (instruction.md)


def sealed(code):
    rec = json.loads((runner.VAULT / "sealed" / (code + ".json")).read_text())
    want = {}
    for line in rec["answer"].splitlines()[1:]:
        start, key, cents = line.split("\t")
        want[(round(float(start), 3), int(key))] = float(cents)
    return rec, want


def share_right(got, want):
    right = sum(1 for k, v in want.items() if k in got and math.isfinite(got[k]) and abs(got[k] - v) <= TOL)
    return right / len(want)


@pytest.fixture(scope="module")
def shares():
    account = runner.Account()
    out = {}
    for code in runner.held_sessions():
        want = sealed(code)[1]
        got = runner.grade_run(code, account)
        out[code] = 0.0 if not got else round(share_right(got, want), 4)
        if out[code] < SHARE:
            tail = (runner.PRIVATE / (code + ".err")).read_bytes()[-600:]
            print("%s: %.3f right; stderr tail: %r" % (code, out[code], tail))
    (runner.PRIVATE / "sessions.json").write_text(json.dumps(out, indent=1))
    print(json.dumps(out))
    return out


def test_sealed_instruments_replay_their_sessions():
    codes = runner.held_sessions()
    assert len(codes) == SESSIONS
    for code in codes:
        rec, want = sealed(code)
        voices, chord = recheck.replay(runner.VAULT / "sessions" / code, rec)
        assert voices == rec["voices"], code
        assert set(chord) == set(want), code
        assert all(math.isfinite(chord[k]) and abs(chord[k] - want[k]) <= 0.006 for k in want), code


def test_enough_sessions_corrected(shares):
    passed = [c for c, s in shares.items() if s >= SHARE]
    assert len(passed) >= NEEDED, "%d of %d sessions passed (%s); %d needed" % (len(passed), SESSIONS, shares, NEEDED)
