# Session S-0412

- Instrument: six-voice polysynth, studio unit 2
- Patch release: 0.49 s
- Power:
  - switched on at 0.000 s
