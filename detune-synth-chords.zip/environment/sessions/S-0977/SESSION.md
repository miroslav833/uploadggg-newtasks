# Session S-0977

- Instrument: six-voice polysynth, studio unit 2
- Patch release: 0.98 s
- Power:
  - switched on at 0.000 s
