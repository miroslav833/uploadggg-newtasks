# Session S-1530

- Instrument: six-voice polysynth, studio unit 2
- Patch release: 1.05 s
- Power:
  - switched on at 0.000 s
