# Studio 2 session notes: the polysynth

Studio 2 keeps a vintage six-voice analogue polysynth for sessions. Each of its six voices has its own
oscillator, and they never stay quite in tune with each other or with themselves: every voice is a few
cents out in its own way, by an amount that depends on the key and that changes as the instrument warms up
after it is switched on and cools down while it is switched off. Clients like the sound, so we do not
service the voices between sessions; we correct the recordings instead.

## How a session is logged

The sequencer records every key played, when it went down and when it came up, and the session sheet
records when the instrument was switched on and off. Before the first take, and now and then during a
session, the engineer retunes: they hold the A above middle C (key 69) and turn the master tune knob until
that note reads in tune on the strobe tuner, then let it go. The master tune moves every voice by the
same amount; nothing else on the panel is touched.

The synth's assign mode decides which voice takes each key. It is a panel setting, the sessions do not
all use the same one, and nobody writes it down. A voice is not free again the moment its key comes up: it
keeps sounding through the patch's release, and the session sheet gives the release time of the patch
used. With all six busy, a new key takes over the voice that was let go earliest; a voice whose key is
still down gets taken over only when all six keys are down, and then it is the one pressed earliest.

After the session the pitch analyser measures the error of every note of the solo passages, where one
note sounds at a time; it reads to a tenth of a cent and is good to about a quarter of a cent. Notes of
chord passages cannot be measured that way, and those are the ones we need: each chord note gets
corrected by its own error before the mix.

## What a session folder holds

`SESSION.md`, for example:

```
# Session S-0412

- Instrument: six-voice polysynth, studio unit 2
- Patch release: 0.49 s
- Power:
  - switched on at 0.000 s
```

`notes.tsv`: every note of the session in order of its start, with `start` and `end` (seconds from the
moment the instrument was first switched on), `key` (MIDI key number, 60 is middle C), `passage` (`tune`
for a retuning note, `solo` or `chord`) and `cents` (the measured error of a solo note, sharp positive;
empty for every other note).

```
start	end	key	passage	cents
441.204	444.204	69	tune	
479.915	480.325	85	solo	-3.1
```

The sample sessions also carry `truth.tsv`, the error of every chord note as the studio later measured it
note by note from isolated stems: `start`, `key`, `cents`.

## The program

The correction pass runs `python3 /app/tuning/detune.py SESSION_DIR OUT_TSV` once per session. It writes
`OUT_TSV` in the form of `truth.tsv`: a header `start	key	cents` and one row for every chord note, in the
order of `notes.tsv`. The program runs under the image's python3 with the standard library only and no
network.
